<?php
/**
 * Scheduled registry backup (SmarterASP.NET Schedule Task - HTTP GET).
 *
 * Scope: civil records, staff, print calibration, related files (registry export bundle).
 * Output: storage/backups/registry/alcros-registry-YYYY-mm-dd-His.zip (not web-accessible).
 *
 * Example URL (token from System Settings → Admin Tools → Backup):
 *   https://YOUR-DOMAIN.com/api/registry_backup.php?token=SECRET
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/api_helpers.php';
require_once __DIR__ . '/../includes/registry_backup.php';

requireRegistryBackupCronToken();

try {
    $pdo = getDB();
    $result = runAlcrosRegistryHostedBackup($pdo, true);
    if (!$result['ok']) {
        apiJsonResponse($result, 400);
    }

    $payload = [
        'ok'       => true,
        'filename' => $result['filename'] ?? '',
        'bytes'    => $result['bytes'] ?? 0,
        'pruned'   => $result['pruned'] ?? 0,
        'message'  => $result['message'] ?? '',
    ];
    if (isset($result['gdrive']) && is_array($result['gdrive'])) {
        $payload['gdrive'] = [
            'ok'      => (bool) ($result['gdrive']['ok'] ?? false),
            'message' => (string) ($result['gdrive']['message'] ?? ''),
            'pruned'  => (int) ($result['gdrive']['pruned'] ?? 0),
        ];
    }
    apiJsonResponse($payload);
} catch (Throwable $e) {
    apiError('Registry backup failed.', 500);
}
