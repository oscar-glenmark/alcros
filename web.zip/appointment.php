<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/appointment_follow_up.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/staff_id_lightbox.php';
require_once __DIR__ . '/includes/staff_resource_locks.php';
requireStaffLogin();
requirePageAccess('appointment.php');
releaseSessionLock();

$activePage = 'appointment.php';
$pdo = getDB();
ensureCitizenNotifyColumns($pdo);

function appointmentStatusFilters(): array
{
    return ['all', 'scheduled', 'confirmed', 'completed', 'no_show', 'cancelled', 'all_appointments', 'recently_deleted', 'follow_ups'];
}

function appointmentsRedirectFilters(): array
{
    $status = $_POST['redirect_status'] ?? $_GET['status'] ?? 'all';
    if (!in_array($status, appointmentStatusFilters(), true)) {
        $status = 'all';
    }

    $rawDate = $_POST['redirect_date'] ?? $_GET['date'] ?? null;
    $date = is_string($rawDate) && $rawDate !== '' ? trim($rawDate) : null;
    $date = resolveAppointmentsManageDate(getDB(), $date);

    return [
        'status' => $status,
        'date'   => $date,
        'q'      => $_POST['redirect_q'] ?? $_GET['q'] ?? '',
    ];
}

function isAppointmentAjax(): bool
{
    return ($_POST['ajax'] ?? '') === '1';
}

function appointmentJsonResponse(bool $ok, string $message, ?array $redirectQuery = null, ?string $type = null): never
{
    header('Content-Type: application/json; charset=utf-8');
    $payload = [
        'ok'      => $ok,
        'type'    => $type ?? ($ok ? 'success' : 'error'),
        'message' => $message,
    ];
    if ($redirectQuery !== null) {
        $payload['redirect_url'] = buildAuthUrl('appointment.php', array_filter($redirectQuery, static fn ($v) => $v !== null && $v !== ''));
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filters = appointmentsRedirectFilters();
    $viewDate = $filters['date'];
    $id = (int) ($_POST['appointment_id'] ?? 0);
    $isAjax = isAppointmentAjax();
    $responseOk = false;
    $responseMessage = 'Could not complete this action. Please try again.';

    $isDelete = isset($_POST['delete_appointment']);
    $isBulkDelete = isset($_POST['bulk_delete']);
    $isBulkDeleteAll = isset($_POST['bulk_delete_all']);
    $isBulkRestore = isset($_POST['bulk_restore']);
    $isBulkPurge = isset($_POST['bulk_purge']);
    $isFollowUpSave = isset($_POST['follow_up_save']);
    $isFollowUpCancel = isset($_POST['follow_up_cancel']);
    $isFollowUpComplete = isset($_POST['follow_up_complete']);
    $isFollowUpAction = $isFollowUpSave || $isFollowUpCancel || $isFollowUpComplete;
    $isVisitNoShow = isset($_POST['mark_visit_no_show']);
    $isUpdate = !$isFollowUpAction && !$isVisitNoShow && (isset($_POST['update_status']) || (!$isDelete && !$isBulkDelete && !$isBulkDeleteAll && !$isBulkRestore && !$isBulkPurge && isset($_POST['status'])));

    if ($isFollowUpAction) {
        $staffId = (string) ($_SESSION['staff_id'] ?? '');
        $followUpRedirectQuery = null;
        if ($isFollowUpSave) {
            if ($id <= 0) {
                $responseMessage = 'Appointment not found.';
            } else {
                $interval = trim((string) ($_POST['follow_up_interval'] ?? ''));
                $customDate = trim((string) ($_POST['follow_up_date'] ?? ''));
                if ($interval === 'custom') {
                    $followUpDate = $customDate;
                } elseif ($interval !== '') {
                    $followUpDate = appointmentFollowUpDateFromInterval($interval) ?? '';
                } else {
                    $followUpDate = $customDate;
                }
                if ($followUpDate === '') {
                    $responseMessage = 'Choose a follow-up date or interval.';
                } else {
                    $result = saveAppointmentFollowUp(
                        $pdo,
                        $id,
                        $followUpDate,
                        (string) ($_POST['follow_up_note'] ?? ''),
                        $staffId
                    );
                    $responseOk = !empty($result['ok']);
                    $responseMessage = (string) ($result['message'] ?? $responseMessage);
                    if ($responseOk) {
                        $followUpRedirectQuery = ['status' => 'follow_ups'];
                    }
                    if ($responseOk && !$isAjax) {
                        appointmentFlashSet('success', $responseMessage);
                    }
                }
            }
        } elseif ($isFollowUpCancel) {
            $followUpId = (int) ($_POST['follow_up_id'] ?? 0);
            $visitDate = appointmentVisitDateForFollowUp($pdo, $followUpId);
            $result = cancelAppointmentFollowUp($pdo, $followUpId, 'staff');
            $responseOk = !empty($result['ok']);
            $responseMessage = (string) ($result['message'] ?? $responseMessage);
            if ($responseOk) {
                $followUpRedirectQuery = array_filter([
                    'status' => 'completed',
                    'date'   => $visitDate ?? $viewDate,
                ]);
            }
            if ($responseOk && !$isAjax) {
                appointmentFlashSet('success', $responseMessage);
            }
        } elseif ($isFollowUpComplete) {
            $followUpId = (int) ($_POST['follow_up_id'] ?? 0);
            $visitDate = appointmentVisitDateForFollowUp($pdo, $followUpId);
            $result = completeAppointmentFollowUp($pdo, $followUpId);
            $responseOk = !empty($result['ok']);
            $responseMessage = (string) ($result['message'] ?? $responseMessage);
            if ($responseOk) {
                $followUpRedirectQuery = array_filter([
                    'status' => 'completed',
                    'date'   => $visitDate ?? $viewDate,
                ]);
            }
            if ($responseOk && !$isAjax) {
                appointmentFlashSet('success', $responseMessage);
            }
        }

        if (!$responseOk && !$isAjax) {
            appointmentFlashSet('error', $responseMessage);
        }

        if ($isAjax) {
            appointmentJsonResponse($responseOk, $responseMessage, $followUpRedirectQuery);
        }

        redirectWithAuth('appointment.php', array_filter(
            $followUpRedirectQuery ?? [
                'date'   => $viewDate,
                'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
                'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
            ]
        ));
    }

    if ($isVisitNoShow) {
        if ($id > 0 && appointmentLockEligible($pdo, $id)) {
            try {
                assertStaffResourceLockForWrite($pdo, STAFF_LOCK_TYPE_APPOINTMENT, $id, staffId(), staffName());
            } catch (InvalidArgumentException $e) {
                $responseMessage = $e->getMessage();
                if ($isAjax) {
                    appointmentJsonResponse(false, $responseMessage);
                }
                appointmentFlashSet('error', $responseMessage);
                redirectWithAuth('appointment.php', array_filter(
                    [
                        'date'   => $viewDate,
                        'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
                        'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
                    ]
                ));
            }
        }

        if ($id > 0 && markAppointmentVisitNoShow($pdo, $id)) {
            clearStaffResourceLock($pdo, STAFF_LOCK_TYPE_APPOINTMENT, $id);
            $responseOk = true;
            $responseMessage = 'Appointment marked as no-show.';
            $responseMessage = staffCitizenNotifyAppendToStaffMessage($responseMessage);
            $responseType = staffCitizenNotifyFlashType(true);
            if (!$isAjax) {
                appointmentFlashSet($responseType, $responseMessage);
            }
        } else {
            $responseMessage = 'Could not mark no-show. The visit may not be 20 minutes late yet, or it was already updated.';
            if (!$isAjax) {
                appointmentFlashSet('error', $responseMessage);
            }
        }

        if ($isAjax) {
            appointmentJsonResponse($responseOk, $responseMessage);
        }

        redirectWithAuth('appointment.php', array_filter(
            [
                'date'   => $viewDate,
                'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
                'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
            ]
        ));
    }

    if ($isUpdate) {
        if ($id > 0 && appointmentLockEligible($pdo, $id)) {
            try {
                assertStaffResourceLockForWrite($pdo, STAFF_LOCK_TYPE_APPOINTMENT, $id, staffId(), staffName());
            } catch (InvalidArgumentException $e) {
                $responseMessage = $e->getMessage();
                if ($isAjax) {
                    appointmentJsonResponse(false, $responseMessage);
                }
                appointmentFlashSet('error', $responseMessage);
                redirectWithAuth('appointment.php', array_filter(
                    [
                        'date'   => $viewDate,
                        'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
                        'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
                    ]
                ));
            }
        }

        $status = (string) ($_POST['status'] ?? '');
        $rejectionReason = null;
        if ($status === 'cancelled') {
            $rejectionReason = normalizeStaffRejectionReason($_POST['rejection_reason'] ?? null);
            if ($rejectionReason === null) {
                $responseMessage = 'Please enter a reason for rejecting this appointment.';
                if (!$isAjax) {
                    appointmentFlashSet('error', $responseMessage);
                }
                if ($isAjax) {
                    appointmentJsonResponse(false, $responseMessage);
                }
                redirectWithAuth('appointment.php', array_filter(
                    [
                        'date'   => $viewDate,
                        'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
                        'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
                    ]
                ));
            }
        }
        if ($id > 0 && updateAppointmentStatus($pdo, $id, $status, $rejectionReason)) {
            clearStaffResourceLock($pdo, STAFF_LOCK_TYPE_APPOINTMENT, $id);
            $responseOk = true;
            $responseMessage = match ($status) {
                'confirmed' => 'Appointment confirmed - citizen will be notified.',
                'completed' => 'Appointment marked completed.',
                'cancelled' => 'Appointment rejected - citizen will be notified.',
                'no_show'   => 'Appointment marked as no-show.',
                default     => 'Appointment status saved as ' . appointmentStatusLabel($status) . '.',
            };
            $responseMessage = staffCitizenNotifyAppendToStaffMessage($responseMessage);
            $responseType = staffCitizenNotifyFlashType(true);
            if (!$isAjax) {
                appointmentFlashSet($responseType, $responseMessage);
            }
        } else {
            $responseMessage = $status === 'cancelled'
                ? 'Could not reject this appointment. It may have already been updated, or the reason was missing.'
                : 'Could not update appointment status. Another staff member may have already updated this visit.';
            if (!$isAjax) {
                appointmentFlashSet('error', $responseMessage);
            }
        }
    } elseif ($isBulkDelete || $isBulkDeleteAll || $isBulkRestore || $isBulkPurge) {
        $bulkIds = parseBulkIdsFromPost();
        $count = 0;

        if ($isBulkDelete) {
            $count = softDeleteAppointments($pdo, $bulkIds);
            $responseOk = $count > 0;
            $responseMessage = $count > 0
                ? ($count === 1 ? '1 appointment moved to recently deleted.' : $count . ' appointments moved to recently deleted.')
                : 'No finished appointments were selected for deletion.';
        } elseif ($isBulkDeleteAll) {
            $count = softDeleteAllDeletableAppointments($pdo, $viewDate);
            $responseOk = $count > 0;
            $responseMessage = $count > 0
                ? ($count === 1 ? '1 appointment moved to recently deleted.' : $count . ' appointments moved to recently deleted.')
                : 'No finished appointments are available to delete for this date.';
        } elseif ($isBulkRestore) {
            $count = restoreAppointments($pdo, $bulkIds);
            $responseOk = $count > 0;
            $responseMessage = $count > 0
                ? ($count === 1 ? '1 appointment restored.' : $count . ' appointments restored.')
                : 'No appointments were selected for restore.';
        } elseif ($isBulkPurge) {
            $count = purgeAppointments($pdo, $bulkIds);
            $responseOk = $count > 0;
            $responseMessage = $count > 0
                ? ($count === 1 ? '1 appointment permanently deleted.' : $count . ' appointments permanently deleted.')
                : 'No appointments were selected for permanent deletion.';
        }

        if (!$isAjax) {
            appointmentFlashSet($responseOk ? 'success' : 'error', $responseMessage);
        }
    } elseif ($isDelete) {
        if ($id > 0) {
            if (softDeleteAppointment($pdo, $id)) {
                $responseOk = true;
                $responseMessage = 'Appointment moved to recently deleted.';
                if (!$isAjax) {
                    appointmentFlashSet('success', $responseMessage);
                }
            } else {
                $responseMessage = 'Only completed appointments can be deleted.';
                if (!$isAjax) {
                    appointmentFlashSet('error', $responseMessage);
                }
            }
        }
    }

    if ($isAjax) {
        $ajaxType = $responseOk && $isUpdate ? staffCitizenNotifyFlashType(true) : ($responseOk ? 'success' : 'error');
        appointmentJsonResponse($responseOk, $responseMessage, null, $ajaxType);
    }

    redirectWithAuth('appointment.php', array_filter([
        'date'   => $viewDate,
        'status' => $filters['status'] !== 'all' ? $filters['status'] : null,
        'q'      => trim($filters['q']) !== '' ? trim($filters['q']) : null,
    ]));
}

$requestedViewDate = isset($_GET['date']) ? trim((string) $_GET['date']) : null;
if ($requestedViewDate === '') {
    $requestedViewDate = null;
}
$viewDate = resolveAppointmentsManageDate($pdo, $requestedViewDate);

$filterStatus = $_GET['status'] ?? 'all';
$search = trim($_GET['q'] ?? '');
$flash = appointmentFlashGet();
$isSearchMode = $search !== '';

if (!in_array($filterStatus, appointmentStatusFilters(), true)) {
    $filterStatus = 'all';
}

$isFollowUpsView = $filterStatus === 'follow_ups';
$awaitingAllDates = appointmentManageAwaitingAllDates(['status' => $filterStatus, 'q' => $search]);
$showDateNav = !$isFollowUpsView && !$awaitingAllDates;
ensureAppointmentFollowUpsTable($pdo);
$upcomingFollowUps = $isFollowUpsView ? fetchUpcomingFollowUps($pdo) : [];
$pendingFollowUpCount = countPendingAppointmentFollowUps($pdo);

$prevDate = date('Y-m-d', strtotime($viewDate . ' -1 day'));
$nextDate = date('Y-m-d', strtotime($viewDate . ' +1 day'));

$standaloneSql = appointmentStandaloneSql('a');
$statsStmt = $pdo->prepare(
    "SELECT status, COUNT(*) AS cnt FROM appointments a
     WHERE a.appointment_date = ? AND {$standaloneSql} AND a.deleted_at IS NULL
     GROUP BY status"
);
$statsStmt->execute([$viewDate]);
$statusCounts = [];
foreach ($statsStmt->fetchAll() as $statRow) {
    $statusCounts[(string) $statRow['status']] = (int) $statRow['cnt'];
}

$recentlyDeletedStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM appointments a
     WHERE a.appointment_date = ? AND {$standaloneSql} AND a.deleted_at IS NOT NULL"
);
$recentlyDeletedStmt->execute([$viewDate]);
$recentlyDeletedCount = (int) $recentlyDeletedStmt->fetchColumn();

$appointmentStats = [
    'total'            => array_sum($statusCounts),
    'scheduled'        => countPendingAppointments($pdo),
    'confirmed'        => (int) ($statusCounts['confirmed'] ?? 0),
    'completed'        => countCompletedAppointmentsWithoutPendingFollowUp($pdo, $viewDate),
    'no_show'          => (int) ($statusCounts['no_show'] ?? 0),
    'cancelled'        => (int) ($statusCounts['cancelled'] ?? 0),
    'recently_deleted' => $recentlyDeletedCount,
    'follow_ups'       => $pendingFollowUpCount,
];

$todayDate = alcrosTodayDate();
$totalStatLabel = $viewDate === $todayDate ? 'Total Today' : 'Total This Day';
$completedStatHint = $viewDate === $todayDate ? 'Served today' : 'Served this date';

$statCards = [
    ['label' => $totalStatLabel, 'hint' => 'All visits on selected date', 'value' => $appointmentStats['total'], 'icon' => 'calendar-days', 'tone' => 'blue', 'filter' => 'all_appointments'],
    ['label' => 'Awaiting', 'hint' => 'All dates · need confirmation', 'value' => $appointmentStats['scheduled'], 'icon' => 'clock', 'tone' => 'amber', 'filter' => 'scheduled'],
    ['label' => 'Confirmed', 'hint' => 'Ready to serve', 'value' => $appointmentStats['confirmed'], 'icon' => 'badge-check', 'tone' => 'violet', 'filter' => 'confirmed'],
    ['label' => 'Completed', 'hint' => $completedStatHint, 'value' => $appointmentStats['completed'], 'icon' => 'check-circle-2', 'tone' => 'emerald', 'filter' => 'completed'],
    ['label' => 'No-Show', 'hint' => 'Did not arrive', 'value' => $appointmentStats['no_show'], 'icon' => 'user-x', 'tone' => 'rose', 'filter' => 'no_show'],
    ['label' => 'Rejected', 'hint' => 'Declined by staff', 'value' => $appointmentStats['cancelled'], 'icon' => 'ban', 'tone' => 'rose', 'filter' => 'cancelled'],
    ['label' => 'Follow-ups', 'hint' => 'Pending return visits', 'value' => $appointmentStats['follow_ups'], 'icon' => 'calendar-clock', 'tone' => 'sky', 'filter' => 'follow_ups'],
];

$filterLabels = [
    'all'              => 'Awaiting queue (all dates)',
    'scheduled'        => 'Awaiting Confirmation',
    'confirmed'        => 'Confirmed',
    'completed'        => 'Completed',
    'no_show'          => 'No-Show',
    'cancelled'        => 'Rejected',
    'all_appointments' => 'All Appointments',
    'recently_deleted' => 'Recently Deleted',
    'follow_ups'       => 'Upcoming follow-ups',
];
$currentFilterLabel = $filterLabels[$filterStatus] ?? 'Awaiting Queue';
$showSidePanel = !$isFollowUpsView && !in_array($filterStatus, ['completed', 'confirmed', 'recently_deleted'], true);
$isRecentlyDeletedView = $filterStatus === 'recently_deleted';
$showBulkActions = !$isFollowUpsView && $isRecentlyDeletedView;
$showVisitLateNoShowColumn = $filterStatus === 'confirmed';

$appointments = [];
$appointmentLockMap = [];
$resultCount = 0;

if ($isFollowUpsView) {
    $resultCount = count($upcomingFollowUps);
} else {

$sql = "SELECT a.*, dr.date_of_birth, dr.date_of_marriage, dr.sex, dr.document_type AS request_document_type
        FROM appointments a
        LEFT JOIN document_requests dr ON dr.tracking_code = a.tracking_code AND dr.deleted_at IS NULL
        WHERE {$standaloneSql}";
$params = [];

if ($isSearchMode) {
    if ($filterStatus === 'recently_deleted') {
        $sql .= ' AND a.deleted_at IS NOT NULL';
    } else {
        $sql .= ' AND a.deleted_at IS NULL';
    }
} elseif ($filterStatus === 'recently_deleted') {
    $sql .= ' AND a.appointment_date = ? AND a.deleted_at IS NOT NULL';
    $params[] = $viewDate;
} elseif ($awaitingAllDates) {
    $sql .= ' AND a.deleted_at IS NULL';
} else {
    $sql .= ' AND a.appointment_date = ? AND a.deleted_at IS NULL';
    $params[] = $viewDate;
}

if ($search !== '') {
    if ($filterStatus !== 'all' && $filterStatus !== '' && $filterStatus !== 'all_appointments') {
        $sql .= ' AND a.status = ?';
        $params[] = $filterStatus;
        if ($filterStatus === 'completed') {
            $sql .= ' AND ' . appointmentSqlExcludePendingFollowUp('a');
        }
    }
} elseif ($filterStatus === 'all_appointments') {
    // All active statuses for this date.
} elseif ($filterStatus === 'recently_deleted') {
    // Deleted items only for this date.
} elseif ($filterStatus === 'all' || $filterStatus === '') {
    $sql .= " AND a.status = 'scheduled'";
} else {
    $sql .= ' AND a.status = ?';
    $params[] = $filterStatus;
    if ($filterStatus === 'completed') {
        $sql .= ' AND ' . appointmentSqlExcludePendingFollowUp('a');
    }
}

[$searchSql, $searchParams] = appointmentSearchClause($search, 'a');
$sql .= $searchSql;
$params = array_merge($params, $searchParams);

if ($isSearchMode) {
    $sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time ASC LIMIT 100';
} elseif ($awaitingAllDates) {
    $sql .= ' ORDER BY a.appointment_date ASC, a.appointment_time ASC';
} else {
    $sql .= $filterStatus === 'recently_deleted' ? ' ORDER BY a.deleted_at DESC' : ' ORDER BY a.appointment_time ASC';
}
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$appointments = $stmt->fetchAll();
$appointmentLockMap = fetchStaffResourceLocksMap(
    $pdo,
    STAFF_LOCK_TYPE_APPOINTMENT,
    array_map(static fn (array $row): int => (int) ($row['id'] ?? 0), $appointments)
);
$resultCount = count($appointments);

} // end !follow_ups list

$overviewCardHighlight = resolveAppointmentOverviewCardHighlight(
    $filterStatus,
    $search,
    $appointments,
    $isFollowUpsView
);

$pageTitle = 'Appointments';
$pageSubtitle = 'Review, confirm, and complete citizen visits and special service bookings.';
$pageHeaderMeta = $awaitingAllDates
    ? '<p class="admin-header__meta">Viewing <strong>all awaiting visits</strong></p>'
    : '<p class="admin-header__meta">Viewing <strong>' . htmlspecialchars(formatDateEmailDisplay($viewDate)) . '</strong></p>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title>Appointments - ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= adminLayoutHeadStyles('appointment') ?>
    <?= staffIdLightboxHeadStyles() ?>
    <?= vendorScriptTag('lucide.min.js') ?>
</head>
<body class="flex min-h-screen" data-staff-lock-type="<?= htmlspecialchars(STAFF_LOCK_TYPE_APPOINTMENT) ?>">

    <?php require __DIR__ . '/includes/admin_sidebar.php'; ?>

    <main class="admin-main flex flex-col min-h-screen">
        <?php require __DIR__ . '/includes/admin_header.php'; ?>

        <div class="p-4 sm:p-6 lg:p-8 w-full admin-page-wrap manage-requests-page appointments-page">

            <section class="manage-section" aria-label="Appointment overview">
                <div class="manage-section__head">
                    <h2 class="manage-section__title"><?php
                        if ($isFollowUpsView) {
                            echo 'Overview · Upcoming follow-ups';
                        } elseif ($awaitingAllDates) {
                            echo 'Overview · All awaiting visits';
                        } else {
                            echo 'Overview · ' . htmlspecialchars(formatDateEmailDisplay($viewDate));
                        }
                    ?></h2>
                    <p class="manage-section__hint">Click a card to filter the list below</p>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-3">
                <?php foreach ($statCards as $card):
                    $cardFilter = $card['filter'];
                    if ($cardFilter === 'follow_ups') {
                        $cardHref = buildAuthUrl('appointment.php', ['status' => 'follow_ups']);
                    } else {
                        $cardQuery = [
                            'status' => $cardFilter,
                            'q'      => $search !== '' ? $search : null,
                        ];
                        if ($cardFilter === 'all') {
                            unset($cardQuery['status']);
                        }
                        if (!appointmentManageAwaitingAllDates(['status' => $cardFilter === 'all' ? 'all' : $cardFilter, 'q' => $search])) {
                            $cardQuery['date'] = $viewDate;
                        }
                        $cardHref = buildAuthUrl('appointment.php', array_filter($cardQuery));
                    }
                    $cardActive = $cardFilter === $overviewCardHighlight;
                    if ($cardActive) {
                        $cardHref .= '#appointmentsBody';
                    }
                ?>
                <a href="<?= htmlspecialchars($cardHref) ?>"
                   class="manage-stat-card manage-stat-card--<?= htmlspecialchars($card['tone']) ?><?= $cardActive ? ' is-active' : '' ?>"
                   data-stat-key="<?= htmlspecialchars($cardFilter) ?>">
                    <div class="manage-stat-card__icon">
                        <i data-lucide="<?= htmlspecialchars($card['icon']) ?>" class="w-4 h-4"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="manage-stat-card__value"><?= number_format($card['value']) ?></p>
                        <p class="manage-stat-card__label"><?= htmlspecialchars($card['label']) ?></p>
                        <p class="manage-stat-card__hint"><?= htmlspecialchars($card['hint']) ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
                </div>
            </section>

            <section class="manage-section manage-section--controls" aria-label="Search and filters">
                <div class="manage-controls">
                    <div class="manage-controls__context">
                        <span class="manage-controls__label">Current view</span>
                        <span class="manage-controls__view"><?= htmlspecialchars($currentFilterLabel) ?></span>
                        <span class="manage-controls__count"><?= number_format($resultCount) ?> shown</span>
                        <?php if ($filterStatus !== 'all' || $search !== ''): ?>
                        <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php')) ?>" class="manage-controls__reset">Reset</a>
                        <?php endif; ?>
                    </div>
                    <div class="appointments-controls__tools">
                        <?php if ($showDateNav): ?>
                        <div class="appointments-date-nav" aria-label="Change date">
                            <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php', array_filter(['date' => $prevDate, 'status' => $filterStatus !== 'all' ? $filterStatus : null, 'q' => $search ?: null]))) ?>" class="appointments-date-nav__btn" aria-label="Previous day">
                                <i data-lucide="chevron-left" class="w-4 h-4"></i>
                            </a>
                            <label class="appointments-date-nav__date alcros-date-picker">
                                <i data-lucide="calendar" class="w-3.5 h-3.5 text-blue-600 shrink-0" aria-hidden="true"></i>
                                <span id="appointmentDateNavLabel" class="appointments-date-nav__label" data-date-picker-label><?= htmlspecialchars(formatDateEmailDisplay($viewDate)) ?></span>
                                <input type="date" id="appointmentDatePicker" value="<?= htmlspecialchars($viewDate) ?>" class="appointments-date-nav__input" aria-label="Choose appointment date">
                            </label>
                            <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php', array_filter(['date' => $nextDate, 'status' => $filterStatus !== 'all' ? $filterStatus : null, 'q' => $search ?: null]))) ?>" class="appointments-date-nav__btn" aria-label="Next day">
                                <i data-lucide="chevron-right" class="w-4 h-4"></i>
                            </a>
                        </div>
                        <?php endif; ?>
                        <form method="GET" action="<?= htmlspecialchars(buildAuthUrl('appointment.php')) ?>" class="manage-controls__search" data-manage-ajax-search="1" data-list-panel-id="manageAppointmentsListPanel">
                            <?= authFormField() ?>
                            <?php if ($search === '' && !$awaitingAllDates): ?>
                            <input type="hidden" name="date" value="<?= htmlspecialchars($viewDate) ?>">
                            <?php endif; ?>
                            <?php if ($filterStatus !== 'all' && $filterStatus !== 'all_appointments'): ?>
                            <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
                            <?php elseif ($filterStatus === 'all_appointments'): ?>
                            <input type="hidden" name="status" value="all_appointments">
                            <?php elseif ($filterStatus === 'recently_deleted'): ?>
                            <input type="hidden" name="status" value="recently_deleted">
                            <?php endif; ?>
                            <div class="manage-requests-toolbar__search">
                                <i data-lucide="search" class="w-3.5 h-3.5 text-gray-400"></i>
                                <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="First, middle, last, full name, DOB, DOM…" class="manage-requests-toolbar__input" autocomplete="off">
                            </div>
                            <button type="submit" class="manage-requests-toolbar__btn manage-requests-toolbar__btn--primary" data-loading-text="Searching…">
                                Search
                            </button>
                        </form>
                    </div>
                </div>
            </section>

            <div class="manage-requests-body" id="appointmentsBody">
                <div class="manage-requests-main">
            <div id="manageAppointmentsListPanel" class="manage-list-panel">
            <?php if ($isFollowUpsView): ?>
            <div class="manage-requests-table-card">
                <div class="manage-table-head">
                    <div>
                        <h2 class="manage-table-head__title">Upcoming follow-ups</h2>
                        <p class="manage-table-head__meta"><?= number_format($resultCount) ?> pending reminder<?= $resultCount === 1 ? '' : 's' ?> · sorted by follow-up date</p>
                    </div>
                    <p class="manage-table-head__tip">Citizens receive email or SMS at 8:00 AM the day before the follow-up date staff set (if they opted in at booking). Booking a new appointment cancels pending reminders automatically.</p>
                </div>
                <?php if (empty($upcomingFollowUps)): ?>
                <div class="manage-requests-empty manage-requests-empty--inset">
                    <p>No pending follow-ups on or after today.</p>
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                <table class="manage-requests-table w-full text-left text-sm min-w-[880px]">
                    <thead>
                        <tr>
                            <th class="manage-col-citizen">Citizen</th>
                            <th class="manage-col-service">Service</th>
                            <th class="manage-col-last-visit">Last visit</th>
                            <th class="manage-col-follow-up">Follow-up by</th>
                            <th class="manage-col-reminders">Reminders</th>
                            <th class="manage-cell-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($upcomingFollowUps as $fuRow):
                            $fuApptId = (int) ($fuRow['appointment_id'] ?? 0);
                            $fuAppt = fetchAppointmentRowForFollowUp($pdo, $fuApptId);
                            if (!$fuAppt) {
                                continue;
                            }
                            $joinRow = array_merge($fuAppt, [
                                'date_of_birth' => null,
                                'date_of_marriage' => null,
                                'sex' => null,
                                'request_document_type' => null,
                            ]);
                            $fuView = appointmentViewData($joinRow, $pdo);
                            $reminderBits = [];
                            if (!empty($fuRow['notify_email'])) {
                                $reminderBits[] = !empty($fuRow['reminder_sent_at']) ? 'Email sent' : 'Email pending';
                            }
                            if (!empty($fuRow['notify_sms'])) {
                                $reminderBits[] = !empty($fuRow['sms_reminder_sent_at']) ? 'SMS sent' : 'SMS pending';
                            }
                            if ($reminderBits === []) {
                                $reminderBits[] = 'No channels';
                            }
                        ?>
                        <tr class="manage-requests-row"
                            data-appointment-row="<?= $fuApptId ?>"
                            data-appointment="<?= htmlspecialchars(json_encode($fuView, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8') ?>">
                            <td>
                                <p class="manage-citizen-name"><?= htmlspecialchars(personNameFromRow($fuRow)) ?></p>
                                <p class="manage-citizen-meta"><?= htmlspecialchars($fuRow['appointment_code'] ?? '') ?></p>
                            </td>
                            <td><span class="manage-doc-type"><?= htmlspecialchars(appointmentServiceLabel((string) ($fuRow['service_type'] ?? ''))) ?></span></td>
                            <td class="manage-col-visit"><?= manageTableDateTimeHtml($fuRow['visit_date'] ?? null, $fuRow['visit_time'] ?? null) ?></td>
                            <td><span class="manage-date"><?= htmlspecialchars(formatDateEmailDisplay((string) ($fuRow['follow_up_date'] ?? ''))) ?></span></td>
                            <td><span class="text-xs text-gray-600"><?= htmlspecialchars(implode(' · ', $reminderBits)) ?></span></td>
                            <td class="manage-cell-actions">
                                <button type="button"
                                        class="view-appointment-btn manage-row-action manage-row-action--labeled"
                                        title="View appointment"
                                        data-appointment-row="<?= $fuApptId ?>"
                                        data-appointment="<?= htmlspecialchars(json_encode($fuView, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8') ?>">
                                    <span class="manage-row-action__label">VIEW</span>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>
            </div>
            <?php elseif (empty($appointments)): ?>
            <div class="manage-requests-empty">
                <div class="manage-requests-empty__icon">
                    <i data-lucide="calendar-off" class="w-10 h-10"></i>
                </div>
                <h2>No appointments in this view</h2>
                <p><?= $search !== '' ? 'No matches for your search. Try different keywords or reset filters.' : ($awaitingAllDates ? 'No appointments are awaiting confirmation.' : 'There are no appointments for the selected filter on this date.') ?></p>
                <?php if ($search === '' && !$awaitingAllDates && in_array($filterStatus, ['all', 'scheduled'], true) && ($appointmentStats['total'] ?? 0) > 0): ?>
                <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php', ['date' => $viewDate, 'status' => 'all_appointments'])) ?>" class="manage-empty-reset">View all <?= number_format($appointmentStats['total']) ?> appointment<?= $appointmentStats['total'] === 1 ? '' : 's' ?> on this date</a>
                <?php elseif ($filterStatus !== 'all' || $search !== ''): ?>
                <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php')) ?>" class="manage-empty-reset">View awaiting queue</a>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="manage-requests-table-card">
                <div class="manage-table-head">
                    <div>
                        <h2 class="manage-table-head__title"><?= htmlspecialchars($currentFilterLabel) ?></h2>
                        <p class="manage-table-head__meta">
                            <?= number_format($resultCount) ?> appointment<?= $resultCount === 1 ? '' : 's' ?>
                            <?php if ($isSearchMode): ?>
                            · search across all dates
                            <?php elseif ($awaitingAllDates): ?>
                            · all visit dates · earliest first
                            <?php else: ?>
                            · <?= htmlspecialchars(formatDateEmailDisplay($viewDate)) ?>
                            <?php endif; ?>
                            <?= $search !== '' ? ' · matching “' . htmlspecialchars($search) . '”' : '' ?>
                            <?php if (!$isRecentlyDeletedView): ?>
                            · <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php', ['date' => $viewDate, 'status' => 'recently_deleted'])) ?>" class="manage-bulk-meta-link">Recently deleted<?= $appointmentStats['recently_deleted'] > 0 ? ' (' . number_format($appointmentStats['recently_deleted']) . ')' : '' ?></a>
                            <?php else: ?>
                            · <a href="<?= htmlspecialchars(buildAuthUrl('appointment.php', ['date' => $viewDate, 'status' => 'all_appointments'])) ?>" class="manage-bulk-meta-link">Back to all appointments</a>
                            <?php endif; ?>
                        </p>
                    </div>
                    <p class="manage-table-head__tip"><?php
                        if ($isRecentlyDeletedView) {
                            echo 'Select items to restore or permanently delete them';
                        } elseif ($showSidePanel) {
                            echo 'Click Verify to review details, then confirm or reject the appointment in the popup';
                        } elseif ($filterStatus === 'confirmed') {
                            echo 'Click Complete to open the visit popup and mark it served';
                        } else {
                            echo 'Click a row action to review or update this visit';
                        }
                    ?></p>
                </div>
                <?php if ($showBulkActions): ?>
                <form method="POST" action="<?= htmlspecialchars(buildAuthUrl('appointment.php')) ?>" id="manageBulkForm" class="manage-bulk-form" data-manage-bulk-form>
                    <?= authFormField() ?>
                    <input type="hidden" name="redirect_status" value="<?= htmlspecialchars($filterStatus) ?>">
                    <input type="hidden" name="redirect_date" value="<?= htmlspecialchars($viewDate) ?>">
                    <input type="hidden" name="redirect_q" value="<?= htmlspecialchars($search) ?>">
                    <div class="manage-bulk-toolbar hidden" data-bulk-toolbar aria-hidden="true">
                        <label class="manage-bulk-toolbar__all">
                            <input type="checkbox" class="manage-bulk-check manage-bulk-check--all" aria-label="Select all">
                            <span>All</span>
                        </label>
                        <?php if ($isRecentlyDeletedView): ?>
                        <button type="submit" name="bulk_restore" value="1" class="manage-bulk-toolbar__btn manage-bulk-toolbar__btn--primary" data-bulk-require-selection data-loading-text="Restoring…">Restore</button>
                        <button type="submit" name="bulk_purge" value="1" class="manage-bulk-toolbar__btn manage-bulk-toolbar__btn--danger" data-bulk-require-selection data-bulk-confirm="Permanently delete the selected appointments? This cannot be undone." data-loading-text="Deleting…">Delete</button>
                        <?php else: ?>
                        <button type="submit" name="bulk_delete" value="1" class="manage-bulk-toolbar__btn manage-bulk-toolbar__btn--danger" data-bulk-delete-btn data-bulk-require-selection data-bulk-confirm="Move the selected finished appointments to recently deleted?" data-loading-text="Deleting…">Delete</button>
                        <?php endif; ?>
                    </div>
                </form>
                <?php endif; ?>
                <div class="overflow-x-auto">
                <table class="manage-requests-table w-full text-left text-sm min-w-[1040px]">
                    <thead>
                        <tr>
                            <?php if ($showBulkActions): ?><th class="manage-bulk-col"><span class="sr-only">Select</span></th><?php endif; ?>
                            <th class="manage-col-code">Code</th>
                            <th class="manage-col-citizen">Citizen</th>
                            <th class="manage-col-service">Service</th>
                            <?php if ($isSearchMode): ?><th class="manage-col-date">Date</th><?php endif; ?>
                            <th class="manage-col-visit">Visit</th>
                            <?php if ($isRecentlyDeletedView): ?><th class="manage-col-submitted">Deleted</th><?php endif; ?>
                            <th class="manage-col-status">Status</th>
                            <?php if ($showVisitLateNoShowColumn): ?><th class="manage-col-visit-late">Late / No-show</th><?php endif; ?>
                            <th class="manage-cell-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments as $ap): ?>
                        <?php
                        $viewData = appointmentViewData($ap, $pdo);
                        $apLock = $appointmentLockMap[(int) $ap['id']] ?? null;
                        $viewData['lock'] = staffResourceLockDisplay(
                            $pdo,
                            STAFF_LOCK_TYPE_APPOINTMENT,
                            (int) $ap['id'],
                            $apLock,
                            staffId()
                        );
                        $canBulkSelect = $isRecentlyDeletedView || appointmentIsDeletable($ap);
                        ?>
                        <tr class="manage-requests-row"
                            data-appointment-row="<?= (int) $ap['id'] ?>"
                            data-appointment="<?= htmlspecialchars(json_encode($viewData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8') ?>">
                            <?php if ($showBulkActions): ?>
                            <td class="manage-bulk-col" onclick="event.stopPropagation()">
                                <?php if ($canBulkSelect): ?>
                                <input type="checkbox" form="manageBulkForm" name="bulk_ids[]" value="<?= (int) $ap['id'] ?>" class="manage-bulk-check manage-bulk-row-check" aria-label="Select appointment <?= htmlspecialchars($ap['appointment_code']) ?>">
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                            <td class="manage-col-code"><span class="manage-id"><?= htmlspecialchars($ap['appointment_code']) ?></span></td>
                            <td class="manage-col-citizen">
                                <p class="manage-citizen-name"><?= htmlspecialchars(personNameFromRow($ap)) ?></p>
                                <p class="manage-citizen-meta"><?= htmlspecialchars($ap['phone'] ?: 'No phone on file') ?></p>
                            </td>
                            <td class="manage-col-service"><span class="manage-doc-type"><?= htmlspecialchars(appointmentServiceLabel($ap['service_type'])) ?></span></td>
                            <?php if ($isSearchMode): ?>
                            <td><span class="manage-date"><?= htmlspecialchars(formatDateEmailDisplay($ap['appointment_date'])) ?></span></td>
                            <?php endif; ?>
                            <td class="manage-col-visit"><?= manageTableDateTimeHtml($ap['appointment_date'] ?? null, $ap['appointment_time'] ?? null) ?></td>
                            <?php if ($isRecentlyDeletedView): ?>
                            <td class="manage-col-submitted"><?= !empty($ap['deleted_at']) ? manageTableDateTimeHtml($ap['deleted_at']) : manageTableDateTimeHtml(null) ?></td>
                            <?php endif; ?>
                            <td class="manage-cell-status">
                                <?= appointmentStatusBadge($ap['status'], $ap['rejection_reason'] ?? null) ?>
                                <?php if (!empty($viewData['lock']) && !empty($viewData['lock']['active'])): ?>
                                <p class="manage-lock-badge" data-lock-badge-for="<?= (int) $ap['id'] ?>"><?= htmlspecialchars($viewData['lock']['label']) ?></p>
                                <?php else: ?>
                                <p class="manage-lock-badge hidden" data-lock-badge-for="<?= (int) $ap['id'] ?>"></p>
                                <?php endif; ?>
                            </td>
                            <?php if ($showVisitLateNoShowColumn): ?>
                            <td class="manage-col-visit-late">
                                <?= renderManageVisitLateNoShowCell(
                                    $pdo,
                                    $ap,
                                    'appointment',
                                    buildAuthUrl('appointment.php'),
                                    [
                                        'redirect_status' => $filterStatus,
                                        'redirect_date'   => $viewDate,
                                        'redirect_q'      => $search,
                                    ]
                                ) ?>
                            </td>
                            <?php endif; ?>
                            <td class="manage-cell-actions">
                                <div class="manage-row-actions" onclick="event.stopPropagation()">
                                    <?php if (!$isRecentlyDeletedView): ?>
                                    <?php
                                    $rowStatus = (string) ($ap['status'] ?? 'scheduled');
                                    $viewLabel = match ($rowStatus) {
                                        'scheduled' => 'Verify',
                                        'confirmed' => 'Complete',
                                        default     => 'View',
                                    };
                                    $isCompleteAction = $rowStatus === 'confirmed';
                                    $showVerifyEye = $rowStatus === 'scheduled';
                                    ?>
                                    <button type="button"
                                            class="view-appointment-btn manage-row-action manage-row-action--labeled<?= $isCompleteAction ? ' manage-row-action--complete' : '' ?>"
                                            title="<?= htmlspecialchars($viewLabel . ' appointment') ?>"
                                            aria-label="<?= htmlspecialchars($viewLabel . ' appointment') ?>"
                                            data-appointment-row="<?= (int) $ap['id'] ?>"
                                            data-appointment="<?= htmlspecialchars(json_encode($viewData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8') ?>">
                                        <?php if ($showVerifyEye): ?>
                                        <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                        <?php endif; ?>
                                        <span class="manage-row-action__label"><?= htmlspecialchars($isCompleteAction ? $viewLabel : strtoupper($viewLabel)) ?></span>
                                    </button>
                                    <?php if (($ap['status'] ?? '') === 'completed'): ?>
                                    <form method="POST" action="<?= htmlspecialchars(buildAuthUrl('appointment.php')) ?>" class="manage-delete-form">
                                        <?= authFormField() ?>
                                        <input type="hidden" name="redirect_status" value="<?= htmlspecialchars($filterStatus) ?>">
                                        <input type="hidden" name="redirect_date" value="<?= htmlspecialchars($viewDate) ?>">
                                        <input type="hidden" name="redirect_q" value="<?= htmlspecialchars($search) ?>">
                                        <input type="hidden" name="appointment_id" value="<?= (int) $ap['id'] ?>">
                                        <input type="hidden" name="delete_appointment" value="1">
                                        <button type="submit" title="Delete completed appointment" aria-label="Delete completed appointment" class="manage-row-action manage-row-action--labeled manage-row-action--danger" data-loading-text="Deleting…">
                                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                            <span class="manage-row-action__label">DELETE</span>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <span class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Deleted</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>
            <?php endif; ?>
            </div>
                </div>

                <?php if ($showSidePanel): ?>
                <aside id="appointmentDetailPanel" class="manage-request-detail">
                    <div id="appointmentDetailEmpty" class="manage-request-detail__empty">
                        <i data-lucide="mouse-pointer-click" class="w-8 h-8 text-gray-300"></i>
                        <p class="manage-detail-empty__title">Select an appointment</p>
                        <p class="manage-detail-empty__hint">Click Verify on a visit to review and confirm or reject it</p>
                    </div>

                    <div id="appointmentDetailContent" class="manage-request-detail__content hidden">
                        <div class="manage-request-detail__header">
                            <div class="min-w-0 flex-1">
                                <h2 id="appointmentViewTitle" class="manage-detail-title truncate">-</h2>
                                <p id="appointmentViewCode" class="manage-detail-code"></p>
                                <p id="appt-view-created" class="manage-detail-meta"></p>
                            </div>
                            <button type="button" id="appointmentDetailClose" class="manage-request-detail__close" aria-label="Close details">
                                <i data-lucide="x" class="w-4 h-4"></i>
                            </button>
                        </div>

                        <div class="manage-request-detail__body">
                            <section class="manage-detail-block">
                                <h3>Citizen</h3>
                                <dl class="manage-detail-rows">
                                    <div class="manage-detail-row manage-detail-row--full"><dt>Name</dt><dd id="appt-view-name"></dd></div>
                                    <div class="manage-detail-row hidden" id="appt-view-dom-wrap"><dt>DOM</dt><dd id="appt-view-dom"></dd></div>
                                    <div class="manage-detail-row"><dt>Phone</dt><dd id="appt-view-phone"></dd></div>
                                    <div class="manage-detail-row manage-detail-row--full"><dt>Email</dt><dd id="appt-view-email"></dd></div>
                                    <div class="manage-detail-row"><dt>Gmail alerts</dt><dd id="appt-view-notify"></dd></div>
                                </dl>
                            </section>

                            <section class="manage-detail-block">
                                <h3>Visit</h3>
                                <dl class="manage-detail-rows">
                                    <div class="manage-detail-row"><dt>Service</dt><dd id="appt-view-service"></dd></div>
                                    <div class="manage-detail-row manage-detail-row--full"><dt>Schedule</dt><dd id="appt-view-schedule"></dd></div>
                                    <div class="manage-detail-row"><dt>Status</dt><dd id="appt-view-status"></dd></div>
                                    <p id="appt-view-lock-banner" class="manage-lock-badge manage-lock-detail-banner hidden" aria-live="polite"></p>
                                    <div class="manage-detail-row"><dt>Type</dt><dd id="appt-view-source"></dd></div>
                                    <div class="manage-detail-row manage-detail-row--full" id="appt-view-tracking-wrap"><dt>Tracking</dt><dd id="appt-view-tracking"></dd></div>
                                </dl>
                            </section>

                            <section class="manage-detail-block">
                                <h3>IDs</h3>
                                <div id="appt-view-id-files" class="manage-detail-ids"></div>
                            </section>

                            <section id="appt-view-notes-wrap" class="manage-detail-block hidden">
                                <h3>Notes</h3>
                                <p id="appt-view-notes" class="manage-detail-notes"></p>
                            </section>

                            <section id="appt-view-rejection-wrap" class="manage-detail-block hidden">
                                <h3>Reason for rejection</h3>
                                <p id="appt-view-rejection" class="manage-detail-notes"></p>
                            </section>

                            <section id="appt-view-follow-up-wrap" class="manage-detail-block manage-detail-block--follow-up hidden" aria-label="Follow-up reminder">
                                <h3 class="manage-follow-up-heading">
                                    <span>Follow-up reminder</span>
                                    <div class="manage-follow-up-heading__tools">
                                        <details class="manage-follow-up-log hidden" data-follow-up-log>
                                            <summary class="manage-follow-up-log__trigger" aria-label="Follow-up history">
                                                <i data-lucide="scroll-text" class="manage-follow-up-log__icon"></i>
                                            </summary>
                                            <div class="manage-follow-up-log__panel" data-follow-up-log-panel role="log"></div>
                                        </details>
                                        <details class="manage-follow-up-info">
                                            <summary class="manage-follow-up-info__trigger" aria-label="Citizen notification info">
                                                <i data-lucide="info" class="manage-follow-up-info__icon"></i>
                                            </summary>
                                            <div class="manage-follow-up-info__panel" role="note">
                                                <p class="manage-follow-up-notice__title">Citizen notification</p>
                                                <p class="manage-follow-up-notice__text">The <strong>day before</strong> the follow-up date at <strong>8:00 AM</strong> (office time), citizens who opted in at booking receive email or SMS reminding them of their next visit date (no online re-booking).</p>
                                            </div>
                                        </details>
                                    </div>
                                </h3>
                                <div id="appt-view-follow-up-body" class="manage-follow-up"></div>
                            </section>
                        </div>

                        <div id="appointmentDetailActions" class="manage-request-detail__actions hidden" aria-label="Appointment actions"></div>
                    </div>
                </aside>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <div id="appointmentReviewModal" class="manage-request-modal hidden" aria-hidden="true">
        <div class="manage-request-modal__backdrop" data-close-appointment-modal></div>
        <div class="manage-request-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="modalAppointmentViewTitle">
            <div class="manage-request-modal__header">
                <div class="min-w-0 flex-1">
                    <h2 id="modalAppointmentViewTitle" class="manage-detail-title truncate">-</h2>
                    <p id="modalAppointmentViewCode" class="manage-detail-code"></p>
                    <p id="modal-appt-view-created" class="manage-detail-meta"></p>
                </div>
                <p id="modal-appt-header-lock" class="manage-modal-header-lock hidden" aria-live="polite"></p>
                <button type="button" class="manage-request-modal__close" data-close-appointment-modal aria-label="Close review popup">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <div class="manage-request-modal__body" id="modalAppointmentDetailBody">
                <section id="modal-appt-view-follow-up-wrap" class="manage-detail-block manage-detail-block--follow-up hidden" aria-label="Follow-up details">
                    <h3 class="manage-follow-up-heading">
                        <span>Follow-up details</span>
                        <div class="manage-follow-up-heading__tools">
                            <details class="manage-follow-up-log hidden" data-follow-up-log>
                                <summary class="manage-follow-up-log__trigger" aria-label="Follow-up history">
                                    <i data-lucide="scroll-text" class="manage-follow-up-log__icon"></i>
                                </summary>
                                <div class="manage-follow-up-log__panel" data-follow-up-log-panel role="log"></div>
                            </details>
                            <details class="manage-follow-up-info">
                                <summary class="manage-follow-up-info__trigger" aria-label="Citizen notification info">
                                    <i data-lucide="info" class="manage-follow-up-info__icon"></i>
                                </summary>
                                <div class="manage-follow-up-info__panel" role="note">
                                    <p class="manage-follow-up-notice__title">Citizen notification</p>
                                    <p class="manage-follow-up-notice__text">The <strong>day before</strong> the follow-up date at <strong>8:00 AM</strong> (office time), citizens who opted in at booking receive email or SMS reminding them of their next visit date (no online re-booking).</p>
                                </div>
                            </details>
                        </div>
                    </h3>
                    <div id="modal-appt-view-follow-up-body" class="manage-follow-up"></div>
                </section>

                <p id="modal-appt-details-heading" class="manage-appointment-details-heading hidden" role="heading" aria-level="3">Appointment details</p>

                <div id="modal-appt-appointment-details" class="manage-appointment-details-group">
                    <section class="manage-detail-block">
                        <h3>Citizen</h3>
                        <dl class="manage-detail-rows">
                            <div class="manage-detail-row manage-detail-row--full"><dt>Name</dt><dd id="modal-appt-view-name"></dd></div>
                            <div class="manage-detail-row hidden" id="modal-appt-view-dom-wrap"><dt>DOM</dt><dd id="modal-appt-view-dom"></dd></div>
                            <div class="manage-detail-row"><dt>Phone</dt><dd id="modal-appt-view-phone"></dd></div>
                            <div class="manage-detail-row manage-detail-row--full"><dt>Email</dt><dd id="modal-appt-view-email"></dd></div>
                            <div class="manage-detail-row"><dt>Gmail alerts</dt><dd id="modal-appt-view-notify"></dd></div>
                        </dl>
                    </section>

                    <section class="manage-detail-block">
                        <h3>Visit</h3>
                        <dl class="manage-detail-rows">
                            <div class="manage-detail-row"><dt>Service</dt><dd id="modal-appt-view-service"></dd></div>
                            <div class="manage-detail-row manage-detail-row--full"><dt>Schedule</dt><dd id="modal-appt-view-schedule"></dd></div>
                            <div class="manage-detail-row"><dt>Status</dt><dd id="modal-appt-view-status"></dd></div>
                            <p id="modal-appt-view-lock-banner" class="manage-lock-badge manage-lock-detail-banner hidden" aria-live="polite"></p>
                            <div class="manage-detail-row"><dt>Type</dt><dd id="modal-appt-view-source"></dd></div>
                            <div class="manage-detail-row manage-detail-row--full" id="modal-appt-view-tracking-wrap"><dt>Tracking</dt><dd id="modal-appt-view-tracking"></dd></div>
                        </dl>
                    </section>

                    <section class="manage-detail-block">
                        <h3>IDs</h3>
                        <div id="modal-appt-view-id-files" class="manage-detail-ids"></div>
                    </section>

                    <section id="modal-appt-view-notes-wrap" class="manage-detail-block hidden">
                        <h3>Notes</h3>
                        <p id="modal-appt-view-notes" class="manage-detail-notes"></p>
                    </section>

                    <section id="modal-appt-view-rejection-wrap" class="manage-detail-block hidden">
                        <h3>Reason for rejection</h3>
                        <p id="modal-appt-view-rejection" class="manage-detail-notes"></p>
                    </section>
                </div>
            </div>

            <div id="modalAppointmentDetailActions" class="manage-request-modal__actions hidden" aria-label="Appointment actions"></div>
        </div>
    </div>

    <?= pageConfigJson([
        'formAction'     => buildAuthUrl('appointment.php'),
        'redirectStatus' => $filterStatus,
        'redirectDate'   => $viewDate,
        'redirectQ'      => $search,
        'useSidePanel'   => $showSidePanel,
        'bulkActions'    => $showBulkActions,
        'pollUrl'               => buildAuthUrl('api/appointments.php'),
        'locksApiUrl'           => buildAuthUrl('api/staff_locks.php'),
        'lockType'              => STAFF_LOCK_TYPE_APPOINTMENT,
        'pollEnabled'           => !$isFollowUpsView,
        'awaitingAllDates'      => $awaitingAllDates,
        'overviewCardHighlight' => $overviewCardHighlight,
        'minFollowUpDate'        => minFollowUpPickDate(),
        'todayDate'              => alcrosTodayDate(),
        'officeHolidayDates'     => officeHolidayClientConfig()['dates'],
        'officeHolidayRecurring' => recurringOfficeHolidaySuffixes(),
    ]) ?>
    <div id="appointmentActionAuthFields" class="hidden" aria-hidden="true"><?= authFormField() ?></div>
    <?= staffIdLightboxMarkup() ?>
    <?= actionResultScript($flash) ?>
    <?= scriptTag('core/staff-id-view.js') ?>
    <?= scriptTag('admin/id-preview.js') ?>
    <?= scriptTag('core/page-config.js') ?>
    <?= scriptTag('core/admin-search.js') ?>
    <?= scriptTag('core/manage-list-search.js') ?>
    <?= scriptTag('admin/manage-bulk.js') ?>
    <?= scriptTag('core/staff-resource-locks.js') ?>
    <?= scriptTag('admin/appointment.js') ?>
    <?= lucideInitScript() ?>
</body>
</html>
