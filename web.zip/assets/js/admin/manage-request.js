(function () {
    'use strict';

    var panel = document.getElementById('requestDetailPanel');
    var emptyState = document.getElementById('requestDetailEmpty');
    var content = document.getElementById('requestDetailContent');
    var bodyWrap = document.getElementById('manageRequestsBody');
    var panelActionsWrap = document.getElementById('requestDetailActions');
    var modal = document.getElementById('requestReviewModal');
    var modalActionsWrap = document.getElementById('modalRequestDetailActions');
    var authFieldsEl = document.getElementById('requestActionAuthFields');
    var pageConfig = window.AlcrosPage && typeof window.AlcrosPage.readConfig === 'function'
        ? window.AlcrosPage.readConfig('page-config')
        : {};
    var useSidePanel = pageConfig.useSidePanel === true;

    function dismissBlockingUi() {
        if (window.AlcrosConfirm && typeof window.AlcrosConfirm.dismissBlockingLayers === 'function') {
            window.AlcrosConfirm.dismissBlockingLayers();
        }
        if (window.AlcrosLoading && typeof window.AlcrosLoading.page === 'function') {
            window.AlcrosLoading.page(false);
        }
        document.body.classList.remove('alcros-loading-open', 'overflow-hidden');
    }

    if (!panel || !emptyState || !content || !bodyWrap) {
        if (!bodyWrap) return;
    }

    var panelView = {
        prefix: '',
        title: 'requestViewTitle',
        code: 'requestViewCode',
        submitted: 'view-submitted',
        actions: panelActionsWrap
    };

    var modalView = {
        prefix: 'modal-',
        title: 'modalRequestViewTitle',
        code: 'modalRequestViewCode',
        submitted: 'modal-view-submitted',
        actions: modalActionsWrap
    };

    function setText(id, value) {
        var el = document.getElementById(id);
        if (!el) return;
        var display = value || '-';
        el.textContent = display;
        el.classList.toggle('manage-detail-value--empty', !value || value === '-');
    }

    function setHtml(id, html) {
        var el = document.getElementById(id);
        if (!el) return;
        if (html) {
            el.innerHTML = html;
            el.classList.remove('manage-detail-value--empty');
        } else {
            el.textContent = '-';
            el.classList.add('manage-detail-value--empty');
        }
    }

    function toggleDomRow(prefix, data) {
        var wrap = document.getElementById(prefix + 'view-dom-wrap');
        if (!wrap) return;
        var isMarriage = data.document_type_key === 'marriage';
        var hasDom = data.date_of_marriage && data.date_of_marriage !== '-';
        if (isMarriage || hasDom) {
            setText(prefix + 'view-dom', data.date_of_marriage);
            wrap.classList.remove('hidden');
        } else {
            wrap.classList.add('hidden');
        }
    }

    function renderIdFiles(container, data) {
        if (!container) return;
        if (window.AlcrosIdPreview && typeof window.AlcrosIdPreview.renderGrid === 'function') {
            container.innerHTML = window.AlcrosIdPreview.renderGrid(data.id_front_path, data.id_back_path);
            if (typeof window.AlcrosIdPreview.wireCards === 'function') {
                window.AlcrosIdPreview.wireCards(container);
            }
            if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
                lucide.createIcons({ nodes: [container] });
            }
            return;
        }
        container.innerHTML = '<span class="text-xs text-gray-400 italic">No ID files uploaded.</span>';
    }

    function markSelectedRow(row) {
        document.querySelectorAll('.manage-requests-row.is-selected').forEach(function (el) {
            el.classList.remove('is-selected');
        });
        if (row) row.classList.add('is-selected');
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function isDetailActionPair(data, canPrint) {
        if (!data || !data.status_key) return false;
        if (data.status_key === 'pending') return true;
        if (canPrint && data.status_key === 'ready') {
            return Array.isArray(data.actions) && data.actions.length > 0;
        }
        return false;
    }

    function sortVerifyActionsFirst(actions) {
        var rejectFirst = { rejected: 1, cancelled: 1 };
        return actions.slice().sort(function (a, b) {
            var aReject = rejectFirst[a.value] ? 0 : 1;
            var bReject = rejectFirst[b.value] ? 0 : 1;
            return aReject - bReject;
        });
    }

    function actionButtonClass(action, pairLayout) {
        if (pairLayout) {
            if (action === 'rejected' || action === 'cancelled') {
                return 'manage-detail-action manage-detail-action--pair manage-detail-action--danger';
            }
            if (action === 'verified' || action === 'confirmed' || action === 'completed') {
                return 'manage-detail-action manage-detail-action--pair manage-detail-action--primary';
            }
        }
        if (action === 'verified' || action === 'completed') {
            return 'manage-detail-action manage-detail-action--primary';
        }
        if (action === 'rejected') {
            return 'manage-detail-action manage-detail-action--danger';
        }
        return 'manage-detail-action';
    }

    function actionButtonIcon(action, pairLayout) {
        if (!pairLayout) return '';
        if (action === 'rejected' || action === 'cancelled') return 'x-circle';
        if (action === 'verified' || action === 'confirmed' || action === 'completed') return 'circle-check';
        return '';
    }

    function actionConfirmMessage(action, data) {
        var code = data.tracking_code || 'this request';
        if (action === 'verified') {
            return 'Accept request ' + code + '? The citizen will be notified that their document is ready for pickup.';
        }
        if (action === 'rejected') {
            return 'Reject ' + code + '? The citizen will be notified that the request was declined.';
        }
        if (action === 'completed') {
            return 'Mark ' + code + ' as completed? Use this when the citizen has claimed the document.';
        }
        return 'Update ' + code + '?';
    }

    function buildStatusForm(data, action, label, pairLayout) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = pageConfig.formAction || 'manage_request.php';
        form.className = 'manage-detail-action-form' + (pairLayout ? ' manage-detail-action-form--pair' : '');
        form.dataset.noConfirm = '';
        form.dataset.ajax = '1';
        form.dataset.noLoading = '';

        if (authFieldsEl) {
            form.innerHTML = authFieldsEl.innerHTML;
        }

        var iconName = actionButtonIcon(action, pairLayout);
        var buttonInner = iconName
            ? '<i data-lucide="' + iconName + '" class="w-4 h-4 shrink-0"></i><span>' + escapeHtml(label) + '</span>'
            : escapeHtml(label);

        form.insertAdjacentHTML('beforeend',
            '<input type="hidden" name="redirect_status" value="' + escapeHtml(pageConfig.redirectStatus || 'all') + '">' +
            '<input type="hidden" name="redirect_date" value="' + escapeHtml(pageConfig.redirectDate || '') + '">' +
            '<input type="hidden" name="redirect_q" value="' + escapeHtml(pageConfig.redirectQ || '') + '">' +
            '<input type="hidden" name="request_id" value="' + escapeHtml(data.id) + '">' +
            '<input type="hidden" name="update_status" value="1">' +
            '<input type="hidden" name="status" value="' + escapeHtml(action) + '">' +
            '<button type="button" class="' + actionButtonClass(action, pairLayout) + ' manage-action-trigger" data-manage-action="' + escapeHtml(action) + '" data-loading-text="Saving…">' + buttonInner + '</button>'
        );

        return form;
    }

    function buildDeleteForm(data) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = pageConfig.formAction || 'manage_request.php';
        form.className = 'manage-detail-action-form';
        form.dataset.noConfirm = '';
        form.dataset.ajax = '1';
        form.dataset.noLoading = '';

        if (authFieldsEl) {
            form.innerHTML = authFieldsEl.innerHTML;
        }

        form.insertAdjacentHTML('beforeend',
            '<input type="hidden" name="redirect_status" value="' + escapeHtml(pageConfig.redirectStatus || 'all') + '">' +
            '<input type="hidden" name="redirect_date" value="' + escapeHtml(pageConfig.redirectDate || '') + '">' +
            '<input type="hidden" name="redirect_q" value="' + escapeHtml(pageConfig.redirectQ || '') + '">' +
            '<input type="hidden" name="request_id" value="' + escapeHtml(data.id) + '">' +
            '<input type="hidden" name="delete_request" value="1">' +
            '<button type="button" class="manage-detail-action manage-detail-action--danger manage-action-trigger" data-manage-action="delete" data-loading-text="Deleting…" title="Delete completed request" aria-label="Delete completed request">' +
                '<i data-lucide="trash-2" class="w-4 h-4 shrink-0"></i>' +
                '<span>Delete</span>' +
            '</button>'
        );

        return form;
    }

    function inlineConfirmYesLabel(action) {
        if (action === 'verified') return 'Yes, accept';
        if (action === 'rejected') return 'Yes, reject';
        if (action === 'completed') return 'Yes, complete';
        if (action === 'delete') return 'Yes, delete';
        return 'Yes, continue';
    }

    function setFormRejectionReason(form, reason) {
        if (!form) return;
        var el = form.querySelector('input[name="rejection_reason"]');
        if (!el) {
            el = document.createElement('input');
            el.type = 'hidden';
            el.name = 'rejection_reason';
            form.appendChild(el);
        }
        el.value = reason || '';
    }

    function isManageRejectAction(action) {
        return action === 'rejected';
    }

    function confirmManageAction(form, msg, action, loadingMessage) {
        if (isManageRejectAction(action) && window.AlcrosConfirm && typeof window.AlcrosConfirm.askWithReason === 'function') {
            window.AlcrosConfirm.askWithReason(msg, {
                label: 'Reason for rejection',
                placeholder: 'Explain why this request is being rejected…',
                okLabel: 'Reject'
            }).then(function (reason) {
                if (!reason) return;
                setFormRejectionReason(form, reason);
                submitManageForm(form, loadingMessage);
            });
            return;
        }

        if (window.AlcrosConfirm && typeof window.AlcrosConfirm.ask === 'function') {
            window.AlcrosConfirm.ask(msg).then(function (ok) {
                if (!ok) return;
                submitManageForm(form, loadingMessage);
            });
            return;
        }

        var actionsWrap = form.closest('#modalRequestDetailActions, #requestDetailActions');
        showInlineConfirm(actionsWrap, (actionsWrap && actionsWrap._requestData) || {}, form, action);
    }

    function submitManageForm(form, loadingMessage) {
        if (!form) return;

        if (window.AlcrosLoading && typeof window.AlcrosLoading.page === 'function') {
            window.AlcrosLoading.page(true, loadingMessage || 'Saving…');
        }

        var formData = new FormData(form);
        formData.set('ajax', '1');
        if (window.AlcrosStaffLocks && typeof window.AlcrosStaffLocks.syncStaffPostAuth === 'function') {
            window.AlcrosStaffLocks.syncStaffPostAuth(formData);
        }

        fetch(form.action || pageConfig.formAction || 'manage_request.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            .then(function (res) {
                return res.json().catch(function () {
                    return { ok: false, message: 'Could not save. Please try again.' };
                });
            })
            .then(function (data) {
                if (window.AlcrosLoading && typeof window.AlcrosLoading.page === 'function') {
                    window.AlcrosLoading.page(false);
                }
                closeModal();

                if (data.ok) {
                    var actionsWrap = form.closest('#modalRequestDetailActions, #requestDetailActions');
                    var reqData = actionsWrap && actionsWrap._requestData;
                    if (reqData) {
                        ackNotificationForRequest(reqData);
                    }
                    var resultType = data.type || 'success';
                    var refreshList = function () {
                        window.location.reload();
                    };
                    if (window.AlcrosActionResult && typeof window.AlcrosActionResult.show === 'function') {
                        var resultOptions = resultType === 'warning' ? { onClose: refreshList } : {};
                        window.AlcrosActionResult.show(resultType, data.message || 'Saved successfully.', resultOptions);
                    }
                    if (resultType !== 'warning') {
                        window.setTimeout(refreshList, 900);
                    }
                    return;
                }

                if (window.AlcrosActionResult && typeof window.AlcrosActionResult.show === 'function') {
                    window.AlcrosActionResult.show('error', data.message || 'Could not save. Please try again.');
                }
            })
            .catch(function () {
                if (window.AlcrosLoading && typeof window.AlcrosLoading.page === 'function') {
                    window.AlcrosLoading.page(false);
                }
                if (window.AlcrosActionResult && typeof window.AlcrosActionResult.show === 'function') {
                    window.AlcrosActionResult.show('error', 'Could not save. Please check your connection and try again.');
                }
            });
    }

    function showInlineConfirm(actionsWrap, data, form, action) {
        if (window.AlcrosConfirm && typeof window.AlcrosConfirm.dismissBlockingLayers === 'function') {
            window.AlcrosConfirm.dismissBlockingLayers();
        }

        var msg = manageActionConfirmMessage(data, action);

        var rejectField = isManageRejectAction(action)
            ? '<label class="manage-inline-confirm__label">Reason for rejection<textarea class="manage-inline-confirm__reason" rows="3" maxlength="2000" placeholder="Explain why this request is being rejected…"></textarea></label>'
            : '';

        actionsWrap.innerHTML =
            '<div class="manage-inline-confirm">' +
                '<p class="manage-inline-confirm__msg">' + escapeHtml(msg) + '</p>' +
                rejectField +
                '<div class="manage-detail-actions__buttons">' +
                    '<button type="button" class="manage-detail-action manage-detail-action--primary" data-inline-confirm-yes>' + escapeHtml(inlineConfirmYesLabel(action)) + '</button>' +
                    '<button type="button" class="manage-detail-action" data-inline-confirm-back>Go back</button>' +
                '</div>' +
            '</div>';
        actionsWrap.classList.remove('hidden');

        actionsWrap.querySelector('[data-inline-confirm-yes]').addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var loadingMessage = action === 'delete' ? 'Deleting…' : 'Saving request…';
            if (isManageRejectAction(action)) {
                var reasonEl = actionsWrap.querySelector('.manage-inline-confirm__reason');
                var reason = reasonEl ? String(reasonEl.value || '').trim() : '';
                if (!reason) {
                    if (reasonEl) reasonEl.focus();
                    return;
                }
                setFormRejectionReason(form, reason);
            }
            submitManageForm(form, loadingMessage);
        });

        actionsWrap.querySelector('[data-inline-confirm-back]').addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            renderDetailActions(actionsWrap, data);
            if (typeof lucide !== 'undefined') lucide.createIcons();
        });
    }

    function manageActionConfirmMessage(data, action) {
        if (action === 'delete') {
            return 'Delete this completed request? This cannot be undone.';
        }
        return actionConfirmMessage(action, data);
    }

    function bindManageActionTriggers() {
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.manage-action-trigger');
            if (!btn) return;

            e.preventDefault();
            e.stopPropagation();

            var form = btn.closest('form.manage-detail-action-form');
            var actionsWrap = btn.closest('#modalRequestDetailActions, #requestDetailActions');
            if (!form || !actionsWrap || !actionsWrap._requestData) return;

            var action = btn.getAttribute('data-manage-action') || '';
            var data = actionsWrap._requestData;
            var msg = manageActionConfirmMessage(data, action);
            var loadingMessage = action === 'delete' ? 'Deleting…' : 'Saving request…';

            confirmManageAction(form, msg, action, loadingMessage);
        });
    }

    function buildPrintMenu(data, pairLayout) {
        var menu = document.createElement('div');
        menu.className = 'manage-print-menu manage-print-menu--detail' + (pairLayout ? ' manage-print-menu--pair' : '');

        var trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'manage-print-trigger';
        trigger.setAttribute('aria-haspopup', 'true');
        trigger.setAttribute('aria-expanded', 'false');
        trigger.innerHTML = '<i data-lucide="printer"></i><span>Print</span><i data-lucide="chevron-down" class="w-3.5 h-3.5"></i>';

        var panel = document.createElement('div');
        panel.className = 'manage-print-dropdown hidden';
        panel.setAttribute('role', 'menu');

        var certificateLink = document.createElement('a');
        certificateLink.href = data.print_url;
        certificateLink.setAttribute('role', 'menuitem');
        certificateLink.textContent = 'Certificate';
        panel.appendChild(certificateLink);

        if (data.print_certification_url) {
            var certificationLink = document.createElement('a');
            certificationLink.href = data.print_certification_url;
            certificationLink.setAttribute('role', 'menuitem');
            certificationLink.textContent = 'Certification';
            panel.appendChild(certificationLink);
        }

        menu.appendChild(trigger);
        menu.appendChild(panel);
        bindPrintMenu(menu);

        return menu;
    }

    function resetPrintDropdownPosition(panel) {
        if (!panel) return;
        panel.classList.remove('manage-print-dropdown--floating');
        panel.style.top = '';
        panel.style.left = '';
        panel.style.right = '';
        panel.style.bottom = '';
    }

    function mountPrintDropdownOnBody(panel, menu) {
        if (!panel || !menu) return;
        if (!panel._printMenuPlaceholder) {
            panel._printMenuPlaceholder = document.createComment('print-dropdown');
            menu.appendChild(panel._printMenuPlaceholder);
        }
        panel._printMenuHost = menu;
        if (panel.parentNode !== document.body) {
            document.body.appendChild(panel);
        }
    }

    function unmountPrintDropdown(panel) {
        if (!panel || !panel._printMenuHost) return;
        var menu = panel._printMenuHost;
        var placeholder = panel._printMenuPlaceholder;
        if (placeholder && placeholder.parentNode === menu) {
            menu.insertBefore(panel, placeholder);
        } else {
            menu.appendChild(panel);
        }
        delete panel._printMenuHost;
    }

    function positionPrintDropdown(trigger, panel) {
        if (!trigger || !panel) return;

        var rect = trigger.getBoundingClientRect();
        var gap = 6;
        var margin = 8;
        var panelWidth = panel.offsetWidth || 152;
        var panelHeight = panel.offsetHeight || 88;
        var left = rect.right - panelWidth;
        var top = rect.bottom + gap;

        if (left < margin) {
            left = margin;
        }
        if (left + panelWidth > window.innerWidth - margin) {
            left = Math.max(margin, window.innerWidth - panelWidth - margin);
        }
        if (top + panelHeight > window.innerHeight - margin) {
            top = rect.top - panelHeight - gap;
        }
        if (top < margin) {
            top = margin;
        }

        panel.style.left = Math.round(left) + 'px';
        panel.style.top = Math.round(top) + 'px';
    }

    function bindPrintMenu(menu) {
        if (!menu || menu.dataset.printMenuBound === '1') {
            return;
        }

        var trigger = menu.querySelector('.manage-print-trigger');
        var panel = menu._printDropdownPanel || menu.querySelector('.manage-print-dropdown');
        if (!trigger || !panel) {
            return;
        }
        menu._printDropdownPanel = panel;

        menu.dataset.printMenuBound = '1';
        trigger.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = !panel.classList.contains('hidden');
            closePrintMenus();
            if (!open) {
                mountPrintDropdownOnBody(panel, menu);
                panel.classList.remove('hidden');
                panel.classList.add('manage-print-dropdown--floating');
                trigger.setAttribute('aria-expanded', 'true');
                menu.classList.add('is-open');
                window.requestAnimationFrame(function () {
                    positionPrintDropdown(trigger, panel);
                });
            }
        });

        panel.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    }

    function closePrintMenus() {
        document.querySelectorAll('.manage-print-menu.is-open').forEach(function (menu) {
            menu.classList.remove('is-open');
        });
        document.querySelectorAll('.manage-print-dropdown').forEach(function (el) {
            el.classList.add('hidden');
            resetPrintDropdownPosition(el);
            unmountPrintDropdown(el);
        });
        document.querySelectorAll('.manage-print-trigger').forEach(function (btn) {
            btn.setAttribute('aria-expanded', 'false');
        });
    }

    function bindPrintMenus() {
        document.querySelectorAll('.manage-print-menu').forEach(bindPrintMenu);
    }

    if (!window._alcrosManageRequestPrintScrollBound) {
        window._alcrosManageRequestPrintScrollBound = true;
        window.addEventListener('scroll', function () {
            document.querySelectorAll('.manage-print-menu.is-open').forEach(function (menu) {
                var trigger = menu.querySelector('.manage-print-trigger');
                var panel = menu._printDropdownPanel;
                if (trigger && panel && !panel.classList.contains('hidden')) {
                    positionPrintDropdown(trigger, panel);
                }
            });
        }, true);
    }

    function requestLockable(data) {
        var key = data && data.status_key ? String(data.status_key) : '';
        return key === 'pending';
    }

    function requestLockReadOnly(data) {
        if (!data) return false;
        if (data._lockReadOnly) return true;
        return window.AlcrosStaffLocks && window.AlcrosStaffLocks.isBlocked(data.lock);
    }

    function renderDetailActions(actionsWrap, data) {
        if (!actionsWrap) return;

        actionsWrap._requestData = data;
        actionsWrap.innerHTML = '';
        var readOnly = requestLockReadOnly(data);
        var hasActions = !readOnly && Array.isArray(data.actions) && data.actions.length > 0;
        var canDelete = !readOnly && !!data.can_delete;
        var canPrint = !readOnly && !!data.can_print;

        if (readOnly) {
            var lockHint = document.createElement('p');
            lockHint.className = 'manage-detail-actions__hint manage-lock-readonly-hint';
            lockHint.textContent = (data.lock && data.lock.label)
                || 'This request is being handled by another staff member. View only.';
            actionsWrap.appendChild(lockHint);
            actionsWrap.classList.remove('hidden');
            return;
        }

        if (!hasActions && !canDelete && !canPrint) {
            actionsWrap.classList.add('hidden');
            return;
        }

        var hint = document.createElement('p');
        hint.className = 'manage-detail-actions__hint';
        if (canPrint) {
            hint.textContent = 'Print the certificate or certification, then mark completed when the citizen claims the document.';
        } else if (hasActions && data.status_key === 'pending') {
            hint.textContent = 'Review the citizen details and IDs above, then accept or reject.';
        } else if (hasActions) {
            hint.textContent = 'Update this request when the citizen has claimed the document.';
        } else {
            hint.textContent = 'This request is finished.';
        }
        actionsWrap.appendChild(hint);

        var group = document.createElement('div');
        group.className = 'manage-detail-actions__buttons';
        var pairLayout = isDetailActionPair(data, canPrint);

        if (pairLayout) {
            group.classList.add('manage-detail-actions__buttons--pair');
        }

        if (canPrint && data.print_url) {
            group.appendChild(buildPrintMenu(data, pairLayout));
        }

        if (hasActions) {
            var actionsList = pairLayout ? sortVerifyActionsFirst(data.actions) : data.actions;
            actionsList.forEach(function (action) {
                group.appendChild(buildStatusForm(data, action.value, action.label, pairLayout));
            });
        }

        if (canDelete) {
            group.appendChild(buildDeleteForm(data));
        }

        actionsWrap.appendChild(group);
        actionsWrap.classList.remove('hidden');
        if (window.lucide && typeof lucide.createIcons === 'function') {
            lucide.createIcons();
        }
    }

    function populateDetailView(view, data) {
        var prefix = view.prefix;

        var headerName = (data.requester_name && data.requester_name !== '-')
            ? data.requester_name
            : (data.citizen_name || 'Request');
        setText(view.title, headerName);
        setText(view.code, data.tracking_code || '');
        setText(prefix + 'view-citizen-name', data.citizen_name || '-');
        setText(prefix + 'view-dob', data.date_of_birth);
        toggleDomRow(prefix, data);
        setText(prefix + 'view-sex', data.sex);
        setText(prefix + 'view-phone', data.phone);
        setText(prefix + 'view-email', data.email);
        setText(prefix + 'view-email-verified', data.email_verified);
        setText(prefix + 'view-requester', data.requester_name || '-');
        setText(prefix + 'view-requester-relationship', data.requester_relationship_label || '-');
        setText(prefix + 'view-document-type', data.document_type);
        setText(prefix + 'view-purpose', data.purpose);
        setText(prefix + 'view-appointment', data.appointment);
        if (data.status_badge_html) {
            setHtml(prefix + 'view-status', data.status_badge_html);
        } else {
            setText(prefix + 'view-status', data.status);
        }
        setText(prefix + 'view-privacy', data.privacy_agreed);
        setText(view.submitted, data.submitted_at ? ('Submitted ' + data.submitted_at) : '');
        setText(prefix + 'view-updated', data.updated_at);

        renderIdFiles(document.getElementById(prefix + 'view-id-files'), data);
        if (window.AlcrosStaffLocks && typeof window.AlcrosStaffLocks.syncDetailLockBanner === 'function') {
            window.AlcrosStaffLocks.syncDetailLockBanner(prefix, data, 'view');
        }
        renderDetailActions(view.actions, data);

        var notesWrap = document.getElementById(prefix + 'view-notes-wrap');
        var notesEl = document.getElementById(prefix + 'view-notes');
        if (notesWrap && notesEl) {
            if (data.notes) {
                notesEl.textContent = data.notes;
                notesWrap.classList.remove('hidden');
            } else {
                notesWrap.classList.add('hidden');
            }
        }

        var rejectionWrap = document.getElementById(prefix + 'view-rejection-wrap');
        var rejectionEl = document.getElementById(prefix + 'view-rejection');
        if (rejectionWrap && rejectionEl) {
            if (data.rejection_reason) {
                rejectionEl.textContent = data.rejection_reason;
                rejectionWrap.classList.remove('hidden');
            } else {
                rejectionWrap.classList.add('hidden');
            }
        }
    }

    function openRequestView(data, row, options) {
        options = options || {};
        var openInModal = options.modal === true || !useSidePanel || !panel || !content || !emptyState;

        function showView(viewData) {
            ackNotificationForRequest(viewData);
            if (openInModal) {
                openModal(viewData, row);
            } else {
                openDetail(viewData, row);
            }
        }

        if (!requestLockable(data)) {
            data._lockReadOnly = false;
            showView(data);
            return;
        }

        var lockType = window.AlcrosStaffLocks && window.AlcrosStaffLocks.lockType();
        if (!window.AlcrosStaffLocks || !lockType) {
            data._lockReadOnly = false;
            showView(data);
            return;
        }
        window.AlcrosStaffLocks.beginOpenClaim(
            lockType,
            data.id,
            row,
            'data-request-row',
            'data-request'
        ).then(function (res) {
            if (res && res.cancelled) {
                return;
            }
            if (!res.ok) {
                if (window.AlcrosActionResult) {
                    var msg = res.error || (res.lock && res.lock.label)
                        || window.AlcrosStaffLocks.openBlockedMessage({ lock: res.lock });
                    window.AlcrosActionResult.show('error', msg);
                }
                return;
            }
            var viewData = Object.assign({}, data);
            viewData.lock = res.lock || null;
            viewData._lockReadOnly = false;
            showView(viewData);
        });
    }

    function openDetail(data, row) {
        if (!panel || !content || !emptyState) return;
        populateDetailView(panelView, data);

        emptyState.classList.add('hidden');
        content.classList.remove('hidden');
        bodyWrap.classList.add('has-detail');
        panel.classList.add('is-open');
        markSelectedRow(row || null);

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    function hideDetailPanel() {
        if (!panel || !emptyState || !content) return;
        emptyState.classList.remove('hidden');
        content.classList.add('hidden');
        bodyWrap.classList.remove('has-detail');
        panel.classList.remove('is-open');
        if (panelActionsWrap) {
            panelActionsWrap.innerHTML = '';
            panelActionsWrap.classList.add('hidden');
        }
    }

    function closeDetail() {
        if (!panel || !emptyState || !content) return;
        var detailWasOpen = panel.classList.contains('is-open') || !content.classList.contains('hidden');
        hideDetailPanel();
        markSelectedRow(null);
        if (detailWasOpen && window.AlcrosStaffLocks) {
            window.AlcrosStaffLocks.releaseActive();
        }
    }

    function openModal(data, row) {
        if (!modal) return;

        if (
            panel
            && (panel.classList.contains('is-open') || (content && !content.classList.contains('hidden')))
            && window.AlcrosStaffLocks
        ) {
            window.AlcrosStaffLocks.releaseActive();
        }
        hideDetailPanel();
        populateDetailView(modalView, data);
        modal.classList.remove('hidden');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('manage-request-modal-open');
        markSelectedRow(row || null);

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    function closeModal() {
        if (!modal) return;

        if (window.AlcrosStaffLocks) {
            window.AlcrosStaffLocks.releaseActive();
        }
        modal.classList.add('hidden');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('manage-request-modal-open');
        markSelectedRow(null);
        if (modalActionsWrap) {
            modalActionsWrap.innerHTML = '';
            modalActionsWrap.classList.add('hidden');
        }
    }

    function ackNotificationForRequest(data) {
        if (!data || !data.tracking_code) {
            return;
        }
        if (window.AlcrosNotifications && typeof window.AlcrosNotifications.ackForRequest === 'function') {
            window.AlcrosNotifications.ackForRequest(data.tracking_code);
        }
    }

    function parseRequestData(el) {
        if (!el) return null;
        var raw = el.getAttribute('data-request');
        if (!raw) return null;
        try {
            return JSON.parse(raw);
        } catch (err) {
            return null;
        }
    }

    function isInteractiveTarget(target) {
        return !!target.closest('form, button, select, option, a, input, textarea, label, .manage-bulk-col');
    }

    function fetchRequestFocus(rowId) {
        if (!rowId || !pageConfig.pollUrl) {
            return Promise.resolve(null);
        }

        var params = new URLSearchParams();
        params.set('status', pageConfig.redirectStatus || 'all');
        params.set('focus_id', String(rowId));
        if (pageConfig.redirectQ) {
            params.set('q', pageConfig.redirectQ);
        }

        var focusUrl = pageConfig.pollUrl + '?' + params.toString();
        var authToken = sessionStorage.getItem('alcros_auth') || '';
        if (authToken) {
            focusUrl += '&alcros_auth=' + encodeURIComponent(authToken);
        }

        return fetch(focusUrl, {
            credentials: 'same-origin',
            cache: 'no-store'
        })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('http_' + response.status);
                }
                return response.json();
            })
            .then(function (data) {
                return data && data.focus ? data.focus : null;
            })
            .catch(function () {
                return null;
            });
    }

    function handleViewRequestClick(btn, options) {
        if (!btn) return;
        options = options || { modal: true };

        var row = btn.closest('.manage-requests-row');
        var viewData = parseRequestData(btn) || parseRequestData(row);
        if (viewData && window.AlcrosStaffLocks && window.AlcrosStaffLocks.isOpenBlocked(viewData)) {
            if (window.AlcrosActionResult) {
                window.AlcrosActionResult.show('error', window.AlcrosStaffLocks.openBlockedMessage(viewData));
            }
            return;
        }
        if (viewData) {
            openRequestView(viewData, row, options);
            return;
        }

        var rowId = row
            ? parseInt(row.getAttribute('data-request-row') || btn.getAttribute('data-request-row'), 10)
            : parseInt(btn.getAttribute('data-request-row'), 10);
        if (!rowId) {
            if (window.AlcrosActionResult) {
                AlcrosActionResult.show('error', 'Unable to open this request. Refresh the page and try again.');
            }
            return;
        }

        dismissBlockingUi();
        if (window.AlcrosLoading) {
            AlcrosLoading.page(true, 'Loading request…');
        }

        fetchRequestFocus(rowId).then(function (focus) {
            if (window.AlcrosLoading) {
                AlcrosLoading.page(false);
            }
            if (!focus) {
                if (window.AlcrosActionResult) {
                    AlcrosActionResult.show('error', 'Unable to load request details. Refresh the page and try again.');
                }
                return;
            }

            if (row) {
                row.setAttribute('data-request', JSON.stringify(focus));
            }
            btn.setAttribute('data-request', JSON.stringify(focus));
            openRequestView(focus, row, options);
        });
    }

    function bindViewRequestButtons(root) {
        var scope = root || document;
        scope.querySelectorAll('.view-request-btn').forEach(function (btn) {
            if (btn.dataset.verifyBound === '1') {
                return;
            }
            btn.dataset.verifyBound = '1';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (btn.disabled || btn.classList.contains('is-lock-blocked')) {
                    return;
                }
                dismissBlockingUi();
                handleViewRequestClick(btn, { modal: true });
            });
        });
    }

    function bindModalClose() {
        if (!modal) return;

        modal.querySelectorAll('[data-close-request-modal]').forEach(function (el) {
            el.addEventListener('click', function (e) {
                e.preventDefault();
                closeModal();
            });
        });
    }

    document.addEventListener('click', function (e) {
        if (e.target.closest('.view-request-btn')) {
            return;
        }

        if (isInteractiveTarget(e.target)) {
            return;
        }

        var row = e.target.closest('.manage-requests-row');
        if (row) {
            if (row.classList.contains('is-lock-row-blocked')) {
                var blockedData = parseRequestData(row);
                if (window.AlcrosActionResult && window.AlcrosStaffLocks) {
                    window.AlcrosActionResult.show('error', window.AlcrosStaffLocks.openBlockedMessage(blockedData));
                }
                return;
            }
            var rowData = parseRequestData(row);
            if (rowData && window.AlcrosStaffLocks && window.AlcrosStaffLocks.isOpenBlocked(rowData)) {
                if (window.AlcrosActionResult) {
                    window.AlcrosActionResult.show('error', window.AlcrosStaffLocks.openBlockedMessage(rowData));
                }
                return;
            }
            if (rowData) openRequestView(rowData, row, { modal: false });
            return;
        }

        if (useSidePanel && e.target === bodyWrap && bodyWrap.classList.contains('has-detail')) {
            closeDetail();
        }
    });

    bindViewRequestButtons();

    if (useSidePanel) {
        document.getElementById('requestDetailClose')?.addEventListener('click', closeDetail);
    }

    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        if (document.body.classList.contains('alcros-confirm-open')) return;

        if (modal && !modal.classList.contains('hidden')) {
            closeModal();
            return;
        }

        if (useSidePanel && bodyWrap.classList.contains('has-detail')) {
            closeDetail();
        }
    });

    bindModalClose();
    bindManageActionTriggers();
    bindPrintMenus();

    document.addEventListener('click', closePrintMenus);
    window.addEventListener('resize', closePrintMenus);
    window.addEventListener('scroll', closePrintMenus, true);

    var statFieldMap = {
        all_requests: 'total',
        pending: 'pending',
        ready: 'ready',
        completed: 'completed',
        rejected: 'rejected',
        no_show: 'no_show'
    };

    function liveListSearchQuery() {
        try {
            var urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('q')) {
                return String(urlParams.get('q') || '').trim();
            }
        } catch (e) { /* ignore */ }
        return pageConfig.redirectQ || '';
    }

    function manageRequestNavParams(overrides) {
        var params = overrides || {};
        var status = pageConfig.redirectStatus || 'all';
        if (status && status !== 'all' && params.status === undefined) {
            params.status = status;
        }
        var liveQ = liveListSearchQuery();
        if (params.q === undefined && liveQ !== '') {
            params.q = liveQ;
        }
        if (liveQ === '' && !pageConfig.awaitingAllDates && params.date === undefined) {
            try {
                var urlParams = new URLSearchParams(window.location.search);
                if (urlParams.has('date')) {
                    params.date = urlParams.get('date');
                } else if (pageConfig.redirectDate) {
                    params.date = pageConfig.redirectDate;
                }
            } catch (e) {
                if (pageConfig.redirectDate) {
                    params.date = pageConfig.redirectDate;
                }
            }
        }
        return params;
    }

    function bindVisitDatePicker() {
        var picker = document.getElementById('manageRequestDatePicker');
        if (!picker) return;

        picker.addEventListener('change', function () {
            if (!picker.value) return;
            var navLabel = document.getElementById('manageRequestDateNavLabel');
            if (navLabel && window.AlcrosDateDisplay) {
                navLabel.textContent = AlcrosDateDisplay.formatLongDate(picker.value);
            }
            var params = manageRequestNavParams({ date: picker.value });
            var href = window.AlcrosPoll
                ? AlcrosPoll.buildUrl('manage_request.php', params)
                : 'manage_request.php?' + new URLSearchParams(params).toString();
            window.location.href = href;
        });
    }

    function listSignature(requests) {
        return (requests || []).map(function (r) {
            return String(r.id) + ':' + String(r.revision);
        }).join('|');
    }

    function updateStatCards(stats) {
        if (!stats) return;
        document.querySelectorAll('[data-stat-key]').forEach(function (card) {
            var key = card.getAttribute('data-stat-key') || '';
            var field = statFieldMap[key];
            if (!field || stats[field] === undefined) return;
            var valueEl = card.querySelector('.manage-stat-card__value');
            if (valueEl) valueEl.textContent = Number(stats[field]).toLocaleString();
        });
    }

    function refreshOpenDetail(focus) {
        if (!focus || !focus.id) return;

        var selected = document.querySelector('.manage-requests-row.is-selected');
        var selectedId = selected ? parseInt(selected.getAttribute('data-request-row'), 10) : 0;
        if (!selectedId || selectedId !== focus.id) return;

        var current = parseRequestData(selected) || {};
        var merged = Object.assign({}, current, focus);
        if (merged.lock && window.AlcrosStaffLocks && window.AlcrosStaffLocks.isBlocked(merged.lock)) {
            merged._lockReadOnly = true;
        }
        if (window.AlcrosStaffLocks) {
            window.AlcrosStaffLocks.updateRowBadge(focus.id, merged.lock || null);
        }

        var revisionChanged = String(current.revision || '') !== String(focus.revision || '');
        var detailOpen = (useSidePanel && bodyWrap && bodyWrap.classList.contains('has-detail'))
            || (modal && !modal.classList.contains('hidden'));

        if (detailOpen) {
            if (useSidePanel && bodyWrap.classList.contains('has-detail')) {
                populateDetailView(panelView, merged);
            }
            if (modal && !modal.classList.contains('hidden')) {
                populateDetailView(modalView, merged);
            }
        }

        if (!detailOpen && !revisionChanged && !merged.lock) {
            return;
        }

        selected.setAttribute('data-request', JSON.stringify(merged));
        var viewBtn = selected.querySelector('.view-request-btn');
        if (viewBtn) viewBtn.setAttribute('data-request', JSON.stringify(merged));
    }

    function applyListUpdate(data) {
        var requests = data.requests || [];
        if (window.AlcrosStaffLocks) {
            window.AlcrosStaffLocks.applyListLocks(requests, 'id', 'data-request-row', 'data-request');
        }
        var signature = listSignature(requests);
        if (signature !== lastListSignature) {
            lastListSignature = signature;
            updateStatCards(data.stats);

            var apiById = {};
            requests.forEach(function (item) {
                apiById[item.id] = item;
            });

            var revisionMismatch = false;

            document.querySelectorAll('.manage-requests-row').forEach(function (row) {
                var rowId = parseInt(row.getAttribute('data-request-row'), 10);
                var item = apiById[rowId];
                if (!item) {
                    if (row.classList.contains('is-selected')) {
                        if (useSidePanel) closeDetail();
                        closeModal();
                    }
                    row.remove();
                    return;
                }

                var statusCell = row.querySelector('.manage-cell-status');
                if (statusCell && item.status_badge_html) {
                    statusCell.innerHTML = item.status_badge_html;
                    var lockNote = document.createElement('p');
                    lockNote.className = 'manage-lock-badge hidden';
                    lockNote.setAttribute('data-lock-badge-for', String(rowId));
                    statusCell.appendChild(lockNote);
                    if (window.AlcrosStaffLocks) {
                        window.AlcrosStaffLocks.updateRowBadge(rowId, item.lock || null);
                    }
                }

                var existing = parseRequestData(row);
                if (existing && item.revision && item.revision !== existing.revision) {
                    revisionMismatch = true;
                }
            });

            bindViewRequestButtons();

            if (revisionMismatch) {
                window.location.reload();
                return;
            }

            var domCount = document.querySelectorAll('.manage-requests-row').length;
            if (domCount !== requests.length) {
                window.location.reload();
            }
        } else {
            updateStatCards(data.stats);
        }

        if (data.focus) {
            refreshOpenDetail(data.focus);
        }

        if (window.AlcrosAdminLive && typeof window.AlcrosAdminLive.refresh === 'function') {
            window.AlcrosAdminLive.refresh();
        }
    }

    var lastListSignature = listSignature(
        Array.prototype.map.call(
            document.querySelectorAll('.manage-requests-row'),
            function (row) {
                var parsed = parseRequestData(row);
                return {
                    id: parseInt(row.getAttribute('data-request-row'), 10),
                    revision: parsed && parsed.revision ? parsed.revision : ''
                };
            }
        )
    );

    bindVisitDatePicker();

    if (window.AlcrosPoll && pageConfig.pollUrl) {
        AlcrosPoll.pollJson(
            pageConfig.pollUrl,
            function () {
                var params = manageRequestNavParams({});
                var selected = document.querySelector('.manage-requests-row.is-selected');
                if (selected) {
                    params.focus_id = selected.getAttribute('data-request-row');
                }
                return params;
            },
            5000,
            applyListUpdate,
            function () {
                if (window.AlcrosPoll && typeof AlcrosPoll.markLiveIndicator === 'function') {
                    // keep indicator visible; stale styling handled by poll.js when failCount rises
                }
            }
        );
    }

    function initRowLocksFromDom() {
        if (!window.AlcrosStaffLocks) {
            return;
        }
        document.querySelectorAll('.manage-requests-row[data-request-row]').forEach(function (row) {
            var data = parseRequestData(row);
            if (!data || !data.id) {
                return;
            }
            window.AlcrosStaffLocks.applyListLocks([{ id: data.id, lock: data.lock || null }], 'id', 'data-request-row', 'data-request');
        });
    }
    initRowLocksFromDom();

    function syncListSignatureFromDom() {
        lastListSignature = listSignature(
            Array.prototype.map.call(
                document.querySelectorAll('.manage-requests-row'),
                function (row) {
                    var parsed = parseRequestData(row);
                    return {
                        id: parseInt(row.getAttribute('data-request-row'), 10),
                        revision: parsed && parsed.revision ? parsed.revision : ''
                    };
                }
            )
        );
    }

    document.addEventListener('alcros:manage-list-updated', function (ev) {
        var detail = ev.detail || {};
        if (detail.panelId !== 'manageRequestsListPanel') {
            return;
        }
        bindViewRequestButtons();
        bindPrintMenus();
        initRowLocksFromDom();
        syncListSignatureFromDom();
        if (window.AlcrosManageBulk && typeof window.AlcrosManageBulk.bindForms === 'function') {
            window.AlcrosManageBulk.bindForms(detail.form);
        }
        var selected = document.querySelector('.manage-requests-row.is-selected');
        if (selected && !document.getElementById('manageRequestsListPanel').contains(selected)) {
            if (useSidePanel) {
                closeDetail();
            }
            closeModal();
        }
    });

    document.addEventListener('alcros:staff-locks-updated', function (ev) {
        var detail = ev.detail || {};
        if (detail.type && detail.type !== 'document_request') {
            return;
        }
        var selected = document.querySelector('.manage-requests-row.is-selected');
        if (!selected) {
            return;
        }
        var id = parseInt(selected.getAttribute('data-request-row'), 10);
        if (!id || !detail.locks) {
            return;
        }
        var lock = detail.locks[String(id)] !== undefined ? detail.locks[String(id)] : detail.locks[id];
        if (lock === undefined) {
            return;
        }
        var current = parseRequestData(selected) || {};
        if (parseInt(current.id, 10) !== id) {
            return;
        }
        var merged = Object.assign({}, current, { lock: lock || null });
        merged._lockReadOnly = !!(window.AlcrosStaffLocks && window.AlcrosStaffLocks.isBlocked(merged.lock));
        refreshOpenDetail(merged);
    });

    if (window.AlcrosStaffLocks && typeof window.AlcrosStaffLocks.bootstrapStaffLockPage === 'function') {
        window.AlcrosStaffLocks.bootstrapStaffLockPage();
    }

    if (pageConfig.redirectQ && window.AlcrosNotifications && typeof window.AlcrosNotifications.ackForRequest === 'function') {
        window.AlcrosNotifications.ackForRequest(pageConfig.redirectQ);
    }

    window.AlcrosManageRequest = {
        verify: function (btn) {
            dismissBlockingUi();
            handleViewRequestClick(btn, { modal: true });
        },
        bindButtons: bindViewRequestButtons
    };
})();
