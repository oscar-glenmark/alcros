(function (global) {
    'use strict';

    if (global.__alcrosLoadingModule) return;
    global.__alcrosLoadingModule = true;

    var overlayEl = null;

    function spinnerMarkup(sizeClass) {
        return '<svg class="alcros-loading-spinner ' + (sizeClass || '') + '" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">' +
            '<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"></circle>' +
            '<path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" opacity="0.85"></path>' +
            '</svg>';
    }

    function dotsMarkup() {
        return '<span class="alcros-loading-dots" aria-hidden="true">' +
            '<span></span><span></span><span></span>' +
            '</span>';
    }

    function skLine(size) {
        return '<span class="alcros-sk-line' + (size ? ' alcros-sk-line--' + size : '') + '"></span>';
    }

    function skeletonList(count) {
        var rows = '';
        var i;
        count = count || 3;
        for (i = 0; i < count; i++) {
            rows += '<div class="alcros-sk-row">' +
                '<span class="alcros-sk-circle"></span>' +
                '<span class="alcros-sk-col">' + skLine('md') + skLine('sm') + '</span>' +
                '</div>';
        }
        return '<div class="alcros-sk alcros-sk--list" aria-hidden="true">' + rows + '</div>';
    }

    function skeletonDetail(count) {
        var rows = '';
        var i;
        count = count || 6;
        for (i = 0; i < count; i++) {
            rows += '<div class="alcros-sk-field">' + skLine('xs') + skLine('lg') + '</div>';
        }
        return '<div class="alcros-sk alcros-sk--detail" aria-hidden="true">' + rows + '</div>';
    }

    function skeletonTrack() {
        return '<div class="alcros-sk alcros-sk--track" aria-hidden="true">' +
            skLine('xs') + skLine('md') +
            '<div class="alcros-sk-steps">' +
            '<span class="alcros-sk-step"></span><span class="alcros-sk-step"></span>' +
            '<span class="alcros-sk-step"></span><span class="alcros-sk-step"></span>' +
            '</div>' +
            skLine('sm') +
            '</div>';
    }

    function skeletonActivity(count) {
        var cards = '';
        var i;
        count = count || 3;
        for (i = 0; i < count; i++) {
            cards += '<div class="alcros-sk-activity">' +
                '<span class="alcros-sk-square"></span>' +
                '<span class="alcros-sk-col">' + skLine('md') + skLine('sm') + skLine('xs') + '</span>' +
                '</div>';
        }
        return '<div class="alcros-sk alcros-sk--activity" aria-hidden="true">' + cards + '</div>';
    }

    function skeletonPreview() {
        return '<div class="alcros-sk alcros-sk--preview" aria-hidden="true">' +
            '<span class="alcros-sk-preview-block"></span>' +
            '<span class="alcros-sk-preview-block alcros-sk-preview-block--short"></span>' +
            '</div>';
    }

    function skeletonInline(count) {
        var lines = '';
        var i;
        count = count || 4;
        for (i = 0; i < count; i++) {
            lines += skLine(i === 0 ? 'md' : 'lg');
        }
        return '<div class="alcros-sk alcros-sk--inline" aria-hidden="true">' + lines + '</div>';
    }

    function skeleton(type, count) {
        switch (type) {
            case 'list':
            case 'schedule':
            case 'rows':
                return skeletonList(count);
            case 'detail':
                return skeletonDetail(count);
            case 'track':
                return skeletonTrack();
            case 'activity':
                return skeletonActivity(count);
            case 'preview':
                return skeletonPreview();
            case 'inline':
                return skeletonInline(count);
            default:
                return skeletonList(count || 3);
        }
    }

    function skeletonInto(el, type, count) {
        if (!el) return;
        el.innerHTML = skeleton(type, count);
        el.setAttribute('aria-busy', 'true');
        el.classList.add('alcros-skeleton-host');
    }

    function clearSkeletonHost(el) {
        if (!el) return;
        el.removeAttribute('aria-busy');
        el.classList.remove('alcros-skeleton-host');
    }

    function ensureOverlay() {
        if (overlayEl) return overlayEl;

        overlayEl = document.createElement('div');
        overlayEl.id = 'alcros-loading-overlay';
        overlayEl.className = 'alcros-loading-overlay is-hidden';
        overlayEl.setAttribute('role', 'status');
        overlayEl.setAttribute('aria-live', 'polite');
        overlayEl.setAttribute('aria-busy', 'true');
        overlayEl.innerHTML =
            '<div class="alcros-loading-overlay__panel">' +
                dotsMarkup() +
                '<p class="alcros-loading-message">Working…</p>' +
            '</div>';
        document.body.appendChild(overlayEl);
        return overlayEl;
    }

    function button(el, on, text) {
        if (!el) return;
        if (on) {
            if (!el.dataset.alcrosLoadingSaved) {
                el.dataset.alcrosLoadingSaved = '1';
                el.dataset.alcrosOrigHtml = el.innerHTML;
                el.dataset.alcrosOrigDisabled = el.disabled ? '1' : '0';
            }
            el.disabled = true;
            el.setAttribute('aria-busy', 'true');
            el.classList.add('is-loading');
            var label = text || el.dataset.loadingText || 'Please wait…';
            el.innerHTML = '<span class="alcros-loading-btn">' + spinnerMarkup() + '<span>' + label + '</span></span>';
        } else {
            el.removeAttribute('aria-busy');
            el.classList.remove('is-loading');
            if (el.dataset.alcrosOrigHtml) {
                el.innerHTML = el.dataset.alcrosOrigHtml;
            }
            el.disabled = el.dataset.alcrosOrigDisabled === '1';
            delete el.dataset.alcrosLoadingSaved;
            delete el.dataset.alcrosOrigHtml;
            delete el.dataset.alcrosOrigDisabled;
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    }

    function page(on, message) {
        var el = ensureOverlay();
        var msg = el.querySelector('.alcros-loading-message');
        if (msg) msg.textContent = message || 'Working…';
        el.classList.toggle('is-hidden', !on);
        el.classList.toggle('is-open', !!on);
        document.body.classList.toggle('alcros-loading-open', !!on);
        if (on) {
            document.body.appendChild(el);
        }
    }

    function wrap(el, promise, text) {
        button(el, true, text);
        return Promise.resolve(promise).finally(function () {
            button(el, false);
        });
    }

    function preserveSubmitterValue(form, btn) {
        if (!btn || !btn.name || btn.type !== 'submit') return;
        var input = form.querySelector('input[type="hidden"][data-alcros-submit-value="' + btn.name + '"]');
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = btn.name;
            input.setAttribute('data-alcros-submit-value', btn.name);
            form.appendChild(input);
        }
        input.value = btn.value || '';
    }

    function initForms() {
        document.addEventListener('submit', function (e) {
            var form = e.target;
            if (!(form instanceof HTMLFormElement)) return;
            if (form.dataset.noLoading !== undefined) return;
            if (form.dataset.ajax === '1') return;

            var btn = e.submitter;
            if (!btn || !(btn instanceof HTMLElement)) {
                btn = form.querySelector('button[type="submit"], input[type="submit"]');
            }
            if (!btn || btn.disabled) return;
            if (btn.name === 'action' && btn.value === 'back') return;

            preserveSubmitterValue(form, btn);

            var loadingText = btn.dataset.loadingText ||
                (btn.name === 'action' && btn.value === 'next' ? 'Saving…' : 'Working…');
            var showOverlay = form.dataset.loadingOverlay !== 'false';
            var submitEvent = e;

            queueMicrotask(function () {
                if (submitEvent.defaultPrevented) return;

                if (showOverlay) {
                    page(true, loadingText);
                }
            });
        }, false);
    }

    function initClickActions() {
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('[data-loading-click]');
            if (!btn || btn.disabled) return;
            button(btn, true, btn.dataset.loadingText || 'Working…');
        });
    }

    function init() {
        if (global.__alcrosLoadingInit) return;
        global.__alcrosLoadingInit = true;
        page(false);
        initForms();
        initClickActions();
    }

    global.AlcrosLoading = {
        button: button,
        page: page,
        wrap: wrap,
        spinner: spinnerMarkup,
        skeleton: skeleton,
        skeletonInto: skeletonInto,
        clearSkeletonHost: clearSkeletonHost,
        init: init
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', global.AlcrosLoading.init);
    } else {
        global.AlcrosLoading.init();
    }
})(window);
