(function () {
    'use strict';

    if (!window.AlcrosPoll) return;

    var purposeLabels = { walk_in: 'Walk-in', appointment: 'Appointment', document_claim: 'Claim' };

    function escapeHtml(str) {
        return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function resolveScheduleHref(href) {
        if (!href) return '#';
        if (!AlcrosPoll.buildUrl) return href;
        var parts = String(href).split('?');
        var base = parts[0];
        var params = {};
        if (parts[1]) {
            new URLSearchParams(parts[1]).forEach(function (value, key) {
                params[key] = value;
            });
        }
        return AlcrosPoll.buildUrl(base, params);
    }

    function authInputHtml() {
        var token = AlcrosPoll.authToken();
        var html = token ? '<input type="hidden" name="alcros_auth" value="' + token.replace(/"/g, '&quot;') + '">' : '';
        var csrfEl = document.querySelector('input[name="csrf_token"]');
        if (csrfEl && csrfEl.value) {
            html += '<input type="hidden" name="csrf_token" value="' + csrfEl.value.replace(/"/g, '&quot;') + '">';
        }
        return html;
    }

    function renderQueueTableColumn(purpose, cfg, group) {
        var serving = group && group.serving ? group.serving : null;
        var waiting = group && group.waiting ? group.waiting : [];
        var waitCount = waiting.length;
        var hasServing = !!serving;
        var canNext = hasServing || waitCount > 0;
        var btnLabel = !canNext ? 'No one waiting' : (hasServing && waitCount > 0 ? 'Finish & call next' : (hasServing ? 'Finish (no one waiting)' : 'Call next'));

        var section = document.querySelector('section[data-purpose="' + purpose + '"]');
        if (!section) return;

        var slot = section.querySelector('.queue-serving-slot');
        if (slot) {
            if (serving) {
                var name = serving.citizen_name ? '<p class="text-sm text-slate-500 mt-2">' + escapeHtml(serving.citizen_name) + '</p>' : '';
                slot.innerHTML = '<p class="queue-serving-number text-5xl font-black text-slate-900 leading-none">' + escapeHtml(serving.ticket_number) + '</p>' + name;
            } else {
                slot.innerHTML = '<p class="queue-serving-number text-4xl font-black text-slate-200">-</p>';
            }
        }

        var btn = section.querySelector('.queue-next-btn');
        if (btn) {
            btn.textContent = btnLabel;
            btn.disabled = !canNext;
        }

        var badge = section.querySelector('.queue-wait-badge');
        if (badge) {
            if (waitCount === 0) {
                badge.textContent = 'No one in line';
            } else {
                badge.innerHTML = '<span class="font-bold text-slate-800">' + waitCount + '</span> waiting - next: <span class="queue-next-preview font-mono font-bold text-base text-slate-900">' + escapeHtml(waiting[0].ticket_number) + '</span>';
            }
        }

        var list = section.querySelector('.queue-waiting-list');
        if (list) {
            if (waitCount > 1) {
                var rest = waiting.slice(1).map(function (t) { return t.ticket_number; }).join(', ');
                list.textContent = 'Then: ' + rest;
                list.classList.remove('hidden');
            } else {
                list.textContent = '';
                list.classList.add('hidden');
            }
        }

        var callAgainBtn = section.querySelector('.queue-call-again-btn');
        var callAgainSlot = section.querySelector('.queue-call-again-slot');
        var callAgainForm = callAgainBtn ? callAgainBtn.closest('form') : null;
        if (hasServing && !callAgainForm) {
            var callForm = document.createElement('form');
            callForm.method = 'POST';
            callForm.className = 'mb-4 queue-call-again-form';
            callForm.setAttribute('data-no-confirm', '');
            callForm.innerHTML = authInputHtml() +
                '<input type="hidden" name="purpose" value="' + purpose + '">' +
                '<input type="hidden" name="action" value="call_again">' +
                '<button type="submit" class="queue-call-again-btn w-full py-2.5 rounded-xl border-2 border-slate-200 text-slate-600 font-bold text-xs uppercase tracking-wide hover:bg-slate-50 flex items-center justify-center gap-2">' +
                '<i data-lucide="volume-2" class="w-4 h-4"></i> Call again</button>';
            var anchor = section.querySelector('.queue-no-show-form') || section.querySelector('.queue-next-form');
            if (anchor) {
                anchor.insertAdjacentElement('afterend', callForm);
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
        } else if (!hasServing && callAgainForm) {
            callAgainForm.remove();
        }

        var noShowForm = section.querySelector('.queue-no-show-form');
        var noShowSlot = section.querySelector('.queue-no-show-slot');
        var nextFormEl = section.querySelector('.queue-next-form');
        if (hasServing && !noShowForm) {
            var noShow = document.createElement('form');
            noShow.method = 'POST';
            noShow.className = 'mb-4 queue-no-show-form';
            noShow.setAttribute('data-no-confirm', '');
            noShow.innerHTML = authInputHtml() +
                '<input type="hidden" name="purpose" value="' + purpose + '">' +
                '<input type="hidden" name="action" value="no_show">' +
                '<button type="submit" class="queue-no-show-btn w-full py-2.5 rounded-xl border-2 border-rose-200 bg-rose-50 text-rose-700 font-bold text-xs uppercase tracking-wide hover:bg-rose-100 hover:border-rose-300 flex items-center justify-center gap-2" data-loading-text="Marking no-show…">' +
                '<i data-lucide="user-x" class="w-4 h-4"></i> No show</button>';
            if (nextFormEl) {
                nextFormEl.insertAdjacentElement('afterend', noShow);
            } else if (noShowSlot) {
                noShowSlot.replaceWith(noShow);
            }
            if (typeof lucide !== 'undefined') lucide.createIcons();
        } else if (!hasServing && noShowForm) {
            var placeholder = document.createElement('div');
            placeholder.className = 'queue-no-show-slot hidden mb-4';
            noShowForm.replaceWith(placeholder);
        }
    }

    function renderQueueTables(grouped, tables) {
        if (!grouped || !tables) return;
        var totalWaiting = 0;
        Object.keys(tables).forEach(function (purpose) {
            var g = grouped[purpose] || { serving: null, waiting: [] };
            totalWaiting += (g.waiting || []).length;
            renderQueueTableColumn(purpose, tables[purpose], g);
        });
        AlcrosPoll.setText('stat-queue-waiting', totalWaiting);
    }

    function queuePollInterval(ctx) {
        if (ctx.failCount > 0) return Math.min(30000, 4000 * Math.pow(2, Math.min(ctx.failCount, 3)));
        return 5000;
    }

    function queueDisplayPollInterval(ctx) {
        if (ctx.failCount > 0) return Math.min(30000, 3000 * Math.pow(2, Math.min(ctx.failCount, 3)));
        return 3000;
    }

    function initLiveQueue() {
        var idlePolls = 0;

        AlcrosPoll.pollJson('api/queue_status.php', function (revision) {
            return revision ? { since: revision } : {};
        }, queuePollInterval, function (data) {
            idlePolls = 0;
            if (document.getElementById('queue-tables') && data.grouped && data.tables) {
                renderQueueTables(data.grouped, data.tables);
            }
        }, null, {
            pollInBackground: true,
            getInterval: function (ctx) {
                if (ctx.failCount > 0) return queuePollInterval(ctx);
                if (idlePolls > 2) return 10000;
                return 5000;
            },
            onUnchanged: function () {
                idlePolls++;
            }
        });
    }

    function renderDisplayTables(tables) {
        if (!tables) return;
        Object.keys(tables).forEach(function (purpose) {
            var slot = document.querySelector('.display-table-slot[data-purpose="' + purpose + '"]');
            if (!slot) return;
            var info = tables[purpose];
            var numEl = slot.querySelector('.display-table-number');
            var waitEl = slot.querySelector('.display-table-wait');
            if (numEl) {
                numEl.textContent = info.serving || '-';
                numEl.className = 'display-table-number' + (info.serving ? '' : ' is-empty');
            }
            if (waitEl) waitEl.textContent = (info.waiting ? info.waiting.length : 0) + ' waiting';
        });
    }

    function renderDisplayServing(servingEl, serving) {
        if (!servingEl) return;
        if (serving) {
            var purpose = escapeHtml(purposeLabels[serving.purpose] || serving.purpose);
            var tableNum = escapeHtml(String(serving.window_number || 1));
            servingEl.innerHTML = '<p class="text-8xl font-black text-white mb-2">' + escapeHtml(serving.ticket_number) + '</p>' +
                '<p class="text-blue-400 text-lg font-bold uppercase">Table ' + tableNum + '</p>' +
                '<p class="text-gray-500 text-sm mt-2">' + purpose + '</p>';
        } else {
            servingEl.innerHTML = '<i data-lucide="users" class="w-16 h-16 text-gray-600 mb-4"></i><p class="text-xs font-bold text-gray-600 uppercase tracking-widest">No Active Tickets</p>';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    }

    function initQueueDisplay() {
        var idlePolls = 0;
        var announcements = window.AlcrosQueueAnnouncements
            ? AlcrosQueueAnnouncements.createProcessor()
            : null;

        if (announcements) {
            announcements.bindVoiceEvents();
        }

        AlcrosPoll.pollJson('api/queue_status.php', function (revision) {
            return { mode: 'display', since: revision || undefined };
        }, queueDisplayPollInterval, function (data) {
            idlePolls = 0;
            var servingEl = document.getElementById('display-serving');
            var waitingEl = document.getElementById('display-waiting');
            if (!servingEl || !waitingEl) return;

            var serving = data.display && data.display.serving ? data.display.serving : null;
            renderDisplayServing(servingEl, serving);
            if (announcements) {
                announcements.process(data);
            }

            if (data.display && data.display.tables) {
                renderDisplayTables(data.display.tables);
            }

            if (data.display && data.display.waiting && data.display.waiting.length) {
                waitingEl.innerHTML = data.display.waiting.map(function (n) {
                    return '<p class="text-2xl font-black text-gray-400">' + escapeHtml(n) + '</p>';
                }).join('');
            } else {
                waitingEl.innerHTML = '<p class="text-[10px] italic text-gray-700 text-center pt-8">No one in line.</p>';
            }
        }, null, {
            pollInBackground: true,
            getInterval: function (ctx) {
                if (ctx.failCount > 0) return queueDisplayPollInterval(ctx);
                if (document.hidden) return 2000;
                if (idlePolls > 2) return 12000;
                return 3000;
            },
            onUnchanged: function () {
                idlePolls++;
                if (announcements && window.AlcrosVoice && AlcrosVoice.isEnabled()) {
                    announcements.startWhenReady();
                }
            }
        });
    }

    function formatTimeAgo(datetime) {
        var ts = new Date(datetime.replace(' ', 'T'));
        if (isNaN(ts)) return datetime;
        return ts.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    }

    function initDashboard() {
        var isAdmin = document.body.dataset.admin === '1';

        function pollDashboard() {
            AlcrosPoll.pollJson('api/dashboard_stats.php', function () {
                if (window.AlcrosDashboardSchedule && window.AlcrosDashboardSchedule.rollToTodayIfNeeded) {
                    window.AlcrosDashboardSchedule.rollToTodayIfNeeded();
                }
                var state = window.AlcrosDashboardSchedule && window.AlcrosDashboardSchedule.getState
                    ? window.AlcrosDashboardSchedule.getState()
                    : {};
                return {
                    month: state.month || undefined,
                    date: state.date || undefined
                };
            }, 45000, function (data) {
            var s = data.stats;
            if (document.getElementById('stat-pending')) {
                AlcrosPoll.setText('stat-pending', s.pending_count);
                AlcrosPoll.setText('stat-queue', s.queue_count);
                AlcrosPoll.setText('stat-appts', s.today_appts);
                AlcrosPoll.setText('stat-ready', s.ready_count);
            }
            AlcrosPoll.setText('header-queue-count', s.queue_count);
            AlcrosPoll.setText('header-appts-count', s.today_appts);
            AlcrosPoll.setText('header-completed-count', s.completed_today);

            var recentEl = document.getElementById('recent-requests-list');
            if (recentEl && data.recent_requests) {
                var labels = data.document_labels || {};
                recentEl.innerHTML = data.recent_requests.length ? data.recent_requests.map(function (r) {
                    var date = (r.submitted_at || '').split(' ')[0];
                    return '<div class="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-gray-50/50"><div class="min-w-0 flex-1"><p class="text-sm font-semibold text-slate-800 truncate">' + escapeHtml(r.citizen_name) + '</p><p class="text-[11px] text-gray-400 mt-0.5">' + escapeHtml(labels[r.document_type] || r.document_type) + ' · <span class="font-mono text-blue-600">' + escapeHtml(r.tracking_code) + '</span>' + (date ? ' · ' + escapeHtml(formatDateDisplay(date)) : '') + '</p></div><span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-gray-100 text-gray-600">' + escapeHtml(r.status) + '</span></div>';
                }).join('') : '';
            }

            var recentApptEl = document.getElementById('recent-appointments-list');
            if (recentApptEl && data.recent_appointments) {
                recentApptEl.innerHTML = data.recent_appointments.length ? data.recent_appointments.map(function (a) {
                    var visitDate = (a.appointment_date || '').split(' ')[0];
                    var badge = a.status_badge_html || ('<span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-gray-100 text-gray-600">' + escapeHtml(a.status) + '</span>');
                    return '<div class="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-gray-50/50"><div class="min-w-0 flex-1"><p class="text-sm font-semibold text-slate-800 truncate">' + escapeHtml(a.citizen_name) + '</p><p class="text-[11px] text-gray-400 mt-0.5">' + escapeHtml(a.service_type) + ' · <span class="font-mono text-blue-600">' + escapeHtml(a.appointment_code) + '</span>' + (visitDate ? ' · ' + escapeHtml(formatDateDisplay(visitDate)) : '') + '</p></div>' + badge + '</div>';
                }).join('') : '';
            }

            var actEl = document.getElementById('activity-feed-list');
            if (actEl && data.activities) {
                var adminFeed = actEl.tagName === 'UL' || actEl.classList.contains('dash-admin-activity__list');
                if (!data.activities.length) {
                    actEl.innerHTML = adminFeed
                        ? ''
                        : '<div class="p-10 text-center text-gray-400 text-xs col-span-full">No activity recorded yet.</div>';
                } else if (adminFeed) {
                    actEl.innerHTML = data.activities.map(function (a) {
                        var details = a.details ? '<p class="dash-admin-activity__details">' + escapeHtml(a.details) + '</p>' : '';
                        var avatar = a.staff_avatar_html || '';
                        var name = a.staff_display_name || a.staff_id || 'System';
                        var sid = (a.staff_id || '').trim();
                        var meta = escapeHtml(name) + (sid && name !== sid ? ' · ' + escapeHtml(sid) : '') + ' · ' + escapeHtml(formatTimeAgo(a.created_at));
                        var actionLabel = a.action_display || a.action;
                        return '<li class="dash-admin-activity__item"><span class="dash-admin-activity__avatar" aria-hidden="true">' + avatar + '</span><div class="min-w-0 flex-1"><p class="dash-admin-activity__action">' + escapeHtml(actionLabel) + '</p>' + details + '<p class="dash-admin-activity__meta">' + meta + '</p></div></li>';
                    }).join('');
                } else {
                    actEl.innerHTML = data.activities.map(function (a) {
                        var details = a.details ? '<p class="text-[10px] text-gray-500 mt-0.5 line-clamp-2">' + escapeHtml(a.details) + '</p>' : '';
                        var who = isAdmin ? escapeHtml(a.staff_id || 'System') + ' · ' : '';
                        var avatar = a.staff_avatar_html || '';
                        var actionLabelStaff = a.action_display || a.action;
                        return '<div class="flex items-start gap-3 p-3 rounded-xl bg-gray-50/80 border border-gray-100"><span class="shrink-0 mt-0.5" aria-hidden="true">' + avatar + '</span><div class="min-w-0"><p class="text-xs font-bold text-slate-800">' + escapeHtml(actionLabelStaff) + '</p>' + details + '<p class="text-[10px] text-gray-400 mt-1">' + who + escapeHtml(formatTimeAgo(a.created_at)) + '</p></div></div>';
                    }).join('');
                }
                if (adminFeed && typeof lucide !== 'undefined') lucide.createIcons();
            }

            if (data.schedule && window.AlcrosDashboardSchedule && window.AlcrosDashboardSchedule.applyPoll) {
                window.AlcrosDashboardSchedule.applyPoll(data.schedule, data.today_date || '');
            } else {
                var apptEl = document.getElementById('today-appts-list');
                if (apptEl && data.today_appts) {
                    apptEl.innerHTML = data.today_appts.length ? data.today_appts.map(function (a) {
                        var d = new Date('1970-01-01T' + a.appointment_time);
                        var h = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
                        var ampm = d.toLocaleTimeString([], { hour: 'numeric', hour12: true }).split(' ')[1] || '';
                        var status = a.status ? '<span class="text-[9px] font-bold uppercase text-gray-400 shrink-0">' + escapeHtml(a.status) + '</span>' : '';
                        return '<div class="px-5 py-3 flex items-center gap-3"><div class="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex flex-col items-center justify-center shrink-0 leading-none"><span class="text-[9px] font-bold">' + escapeHtml(h.replace(/ [AP]M/i, '')) + '</span><span class="text-[8px] uppercase">' + escapeHtml(ampm) + '</span></div><div class="min-w-0 flex-1"><p class="text-sm font-semibold text-slate-800 truncate">' + escapeHtml(a.citizen_name) + '</p><p class="text-[10px] text-gray-400 truncate">' + escapeHtml(a.service_type) + '</p></div>' + status + '</div>';
                    }).join('') : '';
                    if (typeof lucide !== 'undefined') lucide.createIcons();
                }
            }

            if (data.incoming_appts) {
                var incomingList = document.getElementById('incoming-appts-list');
                var incomingEmpty = document.getElementById('incoming-appts-empty');
                var incomingCount = document.getElementById('incoming-appts-count');
                var incomingDateEl = document.getElementById('incoming-appts-date');
                var incomingOpen = document.getElementById('incoming-appts-open-link');

                if (incomingCount) incomingCount.textContent = String(data.incoming_appts.length);
                if (incomingDateEl && data.incoming_date) {
                    incomingDateEl.textContent = formatDateDisplay(data.incoming_date);
                }
                if (incomingOpen && data.incoming_date) {
                    var openUrl = new URL(incomingOpen.href, window.location.href);
                    openUrl.searchParams.set('date', data.incoming_date);
                    openUrl.searchParams.set('status', 'confirmed');
                    incomingOpen.href = openUrl.pathname + '?' + openUrl.searchParams.toString();
                }

                if (incomingList && incomingEmpty) {
                    if (!data.incoming_appts.length) {
                        incomingList.innerHTML = '';
                        incomingList.classList.add('hidden');
                        incomingEmpty.classList.remove('hidden');
                    } else {
                        incomingEmpty.classList.add('hidden');
                        incomingList.classList.remove('hidden');
                        incomingList.innerHTML = data.incoming_appts.map(function (a) {
                            var d = new Date('1970-01-01T' + a.appointment_time);
                            var h = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
                            var ampm = d.toLocaleTimeString([], { hour: 'numeric', hour12: true }).split(' ')[1] || '';
                            var status = a.status ? '<span class="text-[9px] font-bold uppercase text-gray-400 shrink-0">' + escapeHtml(a.status) + '</span>' : '';
                            var timeTone = a.schedule_kind === 'certificate'
                                ? 'bg-amber-50 text-amber-700'
                                : 'bg-violet-50 text-violet-600';
                            var rowHref = resolveScheduleHref(a.href || '');
                            return '<a href="' + escapeHtml(rowHref) + '" class="dash-schedule-row px-5 py-3 flex items-center gap-3">' +
                                '<div class="w-10 h-10 rounded-lg ' + timeTone + ' flex flex-col items-center justify-center shrink-0 leading-none">' +
                                '<span class="text-[9px] font-bold">' + escapeHtml(h.replace(/ [AP]M/i, '')) + '</span>' +
                                '<span class="text-[8px] uppercase">' + escapeHtml(ampm) + '</span></div>' +
                                '<div class="min-w-0 flex-1"><p class="text-sm font-semibold text-slate-800 truncate">' + escapeHtml(a.citizen_name) + '</p>' +
                                '<p class="text-[10px] text-gray-400 truncate">' + escapeHtml(a.service_type) + '</p></div>' + status + '</a>';
                        }).join('');
                    }
                }
            }

            AlcrosPoll.markLiveIndicator();
            });
        }

        pollDashboard();
    }

        function initTrack() {
        var code = document.body.dataset.trackingCode;
        if (!code) return;

        var lastTrackRevision = '';

        function messageClass(status, tone) {
            if (tone === 'success') return 'bg-emerald-50 text-emerald-800 border border-emerald-100';
            if (status === 'ready' || status === 'completed') return 'bg-green-50 text-green-800 border border-green-100';
            if (status === 'rejected' || status === 'cancelled' || status === 'no_show') return 'bg-red-50 text-red-800 border border-red-100';
            return 'bg-blue-50 text-blue-800 border border-blue-100';
        }

        function applyTrackUpdate(data) {
            if (!data.found) return;

            if (data.revision && data.revision === lastTrackRevision) {
                var unchangedEl = document.getElementById('track-updated-at');
                if (unchangedEl) {
                    unchangedEl.textContent = 'Status updates automatically · Last checked ' +
                        new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
                }
                AlcrosPoll.markLiveIndicator();
                return;
            }
            lastTrackRevision = data.revision || '';

            var badgeEl = document.getElementById('track-status-badge');
            if (badgeEl) badgeEl.innerHTML = data.status_html;

            var msgEl = document.getElementById('track-status-message');
            if (msgEl) {
                if (data.status_tone === 'success') {
                    msgEl.classList.add('hidden');
                    msgEl.textContent = '';
                } else if (data.status_message) {
                    msgEl.classList.remove('hidden');
                    msgEl.textContent = data.status_message;
                    var status = data.request ? data.request.status : (data.appointment ? data.appointment.status : '');
                    msgEl.className = 'rounded-xl p-4 mb-5 text-sm leading-relaxed ' + messageClass(status, data.status_tone);
                }
            }

            var entity = data.request || data.appointment || {};
            var detailMap = {
                'track-detail-name': entity.name || entity.citizen_name,
                'track-detail-code': entity.tracking_code || entity.appointment_code,
                'track-detail-document': data.document || data.service,
                'track-detail-appointment': entity.appointment_display || entity.appointment_date,
                'track-detail-updated': data.updated_at ? String(data.updated_at) : ''
            };
            Object.keys(detailMap).forEach(function (id) {
                var el = document.getElementById(id);
                if (el && detailMap[id]) el.textContent = detailMap[id];
            });

            var steps = document.querySelectorAll('[data-track-step]');
            steps.forEach(function (el, i) {
                var dot = el.querySelector('.track-step-dot');
                var label = el.querySelector('.track-step-label');
                var active = data.current_idx >= 0 && i <= data.current_idx;
                if (dot) dot.className = 'track-step-dot w-3 h-3 rounded-full mx-auto mb-1 ' + (active ? 'bg-blue-600' : 'bg-gray-200');
                if (label) label.classList.toggle('text-blue-600', active);
            });

            var updatedEl = document.getElementById('track-updated-at');
            if (updatedEl) {
                updatedEl.textContent = 'Status updates automatically · Last checked ' +
                    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }

            AlcrosPoll.markLiveIndicator();
        }

        var mode = document.body.dataset.realtime;
        var endpoint = mode === 'track-appointment' ? 'api/appointment_status.php' : 'api/request_status.php';
        AlcrosPoll.pollJson(endpoint, { code: code }, 30000, applyTrackUpdate);
    }

    function formatDateDisplay(datetime) {
        var p = (datetime || '').split(' ')[0].split('-');
        if (p.length !== 3) return datetime;
        return p[1] + '/' + p[2] + '/' + p[0];
    }

    function initHeaderStats() {
        if (!document.getElementById('header-queue-count')) return;
        AlcrosPoll.pollJson('api/dashboard_stats.php', {}, 60000, function (data) {
            var s = data.stats || {};
            AlcrosPoll.setText('header-queue-count', s.queue_count);
            AlcrosPoll.setText('header-appts-count', s.today_appts);
            AlcrosPoll.setText('header-completed-count', s.completed_today);
            AlcrosPoll.markLiveIndicator();
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initHeaderStats();
        var mode = document.body.dataset.realtime;
        if (mode === 'queue') initLiveQueue();
        if (mode === 'queue-display') initQueueDisplay();
        if (mode === 'dashboard') initDashboard();
        if (mode === 'track' || mode === 'track-appointment') initTrack();
    });
})();
