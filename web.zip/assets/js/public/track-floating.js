(function () {
    'use strict';

    var root = document.getElementById('track-floating-root');
    if (!root) return;

    var backdrop = document.getElementById('track-floating-backdrop');
    var panel = document.getElementById('track-floating-panel');
    var form = document.getElementById('track-floating-form');
    var input = document.getElementById('track-floating-input');
    var submitBtn = document.getElementById('track-floating-submit');
    var closeBtn = document.getElementById('track-floating-close');
    var loadingEl = document.getElementById('track-floating-loading');
    var errorEl = document.getElementById('track-floating-error');
    var resultEl = document.getElementById('track-floating-result');
    var pollTimer = null;
    var activeCode = '';
    var lastTrackRevision = '';
    var trackPollFails = 0;
    var lastTrackIsAppointment = false;
    var cancelInFlight = false;

    function escapeHtml(str) {
        return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function isAppointmentCode(code) {
        return /^APT-/i.test(code);
    }

    function formatDateDisplay(value) {
        if (!value) return '-';
        var raw = String(value).substring(0, 10);
        var parts = raw.split('-');
        if (parts.length !== 3) return raw;
        return parts[1] + '/' + parts[2] + '/' + parts[0];
    }

    function formatDateTimeDisplay(value) {
        if (!value) return '-';
        var d = new Date(String(value).replace(' ', 'T'));
        if (isNaN(d.getTime())) return value;
        return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) +
            ' · ' + d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    }

    function messageClass(status, tone) {
        if (tone === 'success') {
            return 'bg-emerald-50 text-emerald-800 border border-emerald-100';
        }
        if (status === 'verified' || status === 'ready' || status === 'completed') {
            return 'bg-emerald-50 text-emerald-800 border border-emerald-100';
        }
        if (status === 'rejected' || status === 'cancelled' || status === 'no_show') {
            return 'bg-red-50 text-red-800 border border-red-100';
        }
        return 'bg-amber-50 text-amber-950 border border-amber-100';
    }

    function visitStatusLabel(data, entity) {
        if (data.appointment_confirmed || entity.appointment_confirmed) {
            return 'Confirmed';
        }
        if (data.appointment_status === 'scheduled') {
            return 'Awaiting confirmation';
        }
        if (entity.status === 'verified' || entity.status === 'ready') {
            return 'Confirmed';
        }
        return '';
    }

    function showLoading(show) {
        loadingEl.classList.toggle('hidden', !show);
        if (show) {
            errorEl.classList.add('hidden');
            resultEl.classList.add('hidden');
            if (window.AlcrosLoading && typeof window.AlcrosLoading.skeletonInto === 'function') {
                window.AlcrosLoading.skeletonInto(loadingEl, 'track');
            } else {
                loadingEl.innerHTML = '<p class="text-center py-8 text-sm text-slate-400">Looking up your code…</p>';
            }
        } else if (window.AlcrosLoading && typeof window.AlcrosLoading.clearSkeletonHost === 'function') {
            window.AlcrosLoading.clearSkeletonHost(loadingEl);
        }
        submitBtn.disabled = show;
    }

    function showError(msg) {
        errorEl.textContent = msg;
        errorEl.classList.remove('hidden');
        resultEl.classList.add('hidden');
        loadingEl.classList.add('hidden');
    }

    function renderProgress(stepLabels, currentIdx, hidden) {
        if (hidden || !stepLabels || !stepLabels.length) return '';
        var html = '<div class="mb-4"><p class="text-[10px] font-bold text-slate-400 uppercase mb-3">Progress</p><div class="flex justify-between gap-1 text-[9px] font-bold uppercase text-slate-400">';
        stepLabels.forEach(function (label, i) {
            var active = currentIdx >= 0 && i <= currentIdx;
            html += '<div class="text-center flex-1 min-w-0" data-track-step>' +
                '<div class="track-step-dot w-3 h-3 rounded-full mx-auto mb-1 ' + (active ? 'is-active' : 'bg-slate-200') + '"></div>' +
                '<span class="track-step-label block leading-tight ' + (active ? 'is-active font-bold' : '') + '">' + escapeHtml(label) + '</span></div>';
        });
        return html + '</div></div>';
    }

    function renderResult(data, isAppointment) {
        var entity = isAppointment ? data.appointment : data.request;
        if (!entity) return;

        var code = isAppointment ? entity.appointment_code : entity.tracking_code;
        var status = entity.status;
        var statusTone = data.status_tone || '';
        var hideProgress = isAppointment
            ? (status === 'cancelled' || status === 'no_show')
            : (status === 'rejected');

        var details = isAppointment
            ? '<p><span class="font-bold text-slate-500">Name:</span> ' + escapeHtml(entity.citizen_name) + '</p>' +
              '<p><span class="font-bold text-slate-500">Service:</span> ' + escapeHtml(data.service || entity.service_type) + '</p>' +
              '<p><span class="font-bold text-slate-500">Visit date:</span> ' + escapeHtml(formatDateTimeDisplay(entity.appointment_date + ' ' + entity.appointment_time)) + '</p>' +
              '<p><span class="font-bold text-slate-500">Booked:</span> ' + escapeHtml(formatDateDisplay(entity.created_at)) + '</p>'
            : (function () {
                var visitLabel = visitStatusLabel(data, entity);
                var requesterLine = entity.requester_name
                    ? '<p><span class="font-bold text-slate-500">Requester:</span> ' + escapeHtml(entity.requester_name) + '</p>'
                    : '';
                return '<p><span class="font-bold text-slate-500">Name on certificate:</span> ' + escapeHtml(entity.citizen_name) + '</p>' +
                    requesterLine +
                    '<p><span class="font-bold text-slate-500">Document:</span> ' + escapeHtml(data.document || entity.document_type) + '</p>' +
                    '<p><span class="font-bold text-slate-500">Submitted:</span> ' + escapeHtml(formatDateDisplay(entity.submitted_at)) + '</p>' +
                    (entity.appointment_date ? '<p><span class="font-bold text-slate-500">Pickup visit:</span> ' + escapeHtml(formatDateTimeDisplay(entity.appointment_date + ' ' + (entity.appointment_time || ''))) + '</p>' : '') +
                    (visitLabel ? '<p><span class="font-bold text-slate-500">Visit status:</span> ' + escapeHtml(visitLabel) + '</p>' : '');
            }());

        var codeLabel = isAppointment ? 'Appointment Code' : 'Tracking Code';
        var footerNote = hideProgress && statusTone !== 'success'
            ? '<p class="text-red-600 text-sm font-semibold mb-4">Please contact the registry office for assistance.</p>'
            : '';

        var cancelBlock = '';
        if (data.can_cancel && data.cancel_type && data.cancel_label) {
            cancelBlock =
                '<div class="track-floating-cancel mb-4 pt-3 border-t border-slate-100">' +
                '<button type="button" id="track-floating-cancel-btn" class="track-floating-cancel__btn" ' +
                'data-cancel-type="' + escapeHtml(data.cancel_type) + '" data-cancel-code="' + escapeHtml(code) + '">' +
                escapeHtml(data.cancel_label) + '</button>' +
                '<p class="track-floating-cancel__hint">Only available while your submission is still awaiting staff review.</p>' +
                '</div>';
        }

        var statusMsg = String(data.status_message || '').trim();
        var statusMessageBlock = statusTone === 'success' || statusMsg === ''
            ? ''
            : '<div id="track-status-message" class="rounded-xl p-4 mb-4 text-sm leading-relaxed ' +
                messageClass(status, statusTone) + '">' + escapeHtml(statusMsg) + '</div>';

        resultEl.innerHTML =
            '<div class="rounded-xl border border-slate-100 bg-slate-50/50 p-4">' +
            '<div class="flex justify-between items-start gap-3 mb-4">' +
            '<div><p class="text-[10px] font-bold text-slate-400 uppercase">' + codeLabel + '</p>' +
            '<p class="track-floating-result__code">' + escapeHtml(code) + '</p></div>' +
            '<div id="track-status-badge">' + (data.status_html || '') + '</div></div>' +
            statusMessageBlock +
            '<div class="space-y-2 text-sm mb-4 text-slate-700">' + details + '</div>' +
            cancelBlock +
            footerNote +
            renderProgress(data.step_labels, data.current_idx, hideProgress) +
            '<p id="track-updated-at" class="text-[10px] text-slate-400 text-center">Status updates automatically · Last checked ' +
            new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) + '</p>' +
            '</div>' +
            '<p class="mt-4 text-[11px] text-slate-400 text-center">Office hours: ' + escapeHtml(root.dataset.officeHours || '') +
            (root.dataset.officePhone ? ' · Call ' + escapeHtml(root.dataset.officePhone) : '') + '</p>';

        resultEl.classList.remove('hidden');
        errorEl.classList.add('hidden');

        var cancelBtn = document.getElementById('track-floating-cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function () {
                submitCitizenCancel(cancelBtn.getAttribute('data-cancel-type'), cancelBtn.getAttribute('data-cancel-code'));
            });
        }
    }

    function csrfToken() {
        var fromRoot = root.getAttribute('data-csrf-token');
        if (fromRoot) {
            return fromRoot;
        }
        var input = document.querySelector('#citizen-success-cancel-wrap input[name="csrf_token"]')
            || document.querySelector('input[name="csrf_token"]');
        return input ? input.value : '';
    }

    function askCitizenCancelConfirm(message) {
        if (window.AlcrosConfirm && typeof window.AlcrosConfirm.ask === 'function') {
            return window.AlcrosConfirm.ask(message);
        }
        return Promise.resolve(window.confirm(message));
    }

    function showCitizenCancelSuccessModal(data) {
        if (!data || data.status_tone !== 'success') {
            return;
        }
        var text = data.status_message || data.message || 'Your cancellation is complete.';
        if (window.AlcrosActionResult && typeof window.AlcrosActionResult.show === 'function') {
            window.AlcrosActionResult.show('success', text, {
                title: 'Cancellation complete',
                badge: 'Success',
                buttonLabel: 'Done'
            });
            return;
        }
        window.alert(text);
    }

    function submitCitizenCancel(cancelType, code) {
        if (cancelInFlight || !cancelType || !code) {
            return;
        }
        var confirmMsg = cancelType === 'appointment'
            ? 'Cancel this appointment? Your time slot will be released and staff will not confirm this visit.'
            : 'Cancel this document request? Staff will stop processing it.';

        askCitizenCancelConfirm(confirmMsg).then(function (ok) {
            if (!ok) {
                return;
            }
            runCitizenCancel(cancelType, code);
        });
    }

    function runCitizenCancel(cancelType, code) {
        if (cancelInFlight) {
            return;
        }
        cancelInFlight = true;
        var cancelBtn = document.getElementById('track-floating-cancel-btn');
        if (cancelBtn) {
            cancelBtn.disabled = true;
            cancelBtn.textContent = 'Cancelling…';
        }

        var body = new FormData();
        body.append('csrf_token', csrfToken());
        body.append('type', cancelType);
        body.append('code', code);

        fetch('api/citizen_cancel.php', { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (r) {
                return r.json().then(function (data) {
                    return { ok: r.ok, data: data };
                });
            })
            .then(function (result) {
                if (!result.ok || !result.data || !result.data.ok) {
                    throw new Error((result.data && result.data.error) || 'Cancellation failed.');
                }
                var isAppointment = cancelType === 'appointment';
                lastTrackRevision = '';
                renderResult(result.data, isAppointment);
                showCitizenCancelSuccessModal(result.data);
                startPolling(code, isAppointment);
            })
            .catch(function (err) {
                showError(err.message || 'Unable to cancel. Please try again or contact the office.');
            })
            .finally(function () {
                cancelInFlight = false;
            });
    }

    function applyPollUpdate(data, isAppointment) {
        if (!data.found) return;
        if (data.revision && data.revision === lastTrackRevision) {
            var updatedEl = document.getElementById('track-updated-at');
            if (updatedEl) {
                updatedEl.textContent = 'Status updates automatically · Last checked ' +
                    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            }
            return;
        }
        lastTrackRevision = data.revision || '';
        renderResult(data, isAppointment);
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    function startPolling(code, isAppointment) {
        stopPolling();
        trackPollFails = 0;
        var endpoint = isAppointment ? 'api/appointment_status.php' : 'api/request_status.php';

        pollTimer = setInterval(function () {
            if (root.classList.contains('hidden')) return;
            fetch(endpoint + '?code=' + encodeURIComponent(code), { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) {
                    if (!r.ok) {
                        throw new Error('http_' + r.status);
                    }
                    return r.json();
                })
                .then(function (data) {
                    trackPollFails = 0;
                    if (data && data.found) {
                        applyPollUpdate(data, isAppointment);
                    }
                })
                .catch(function () {
                    trackPollFails++;
                    var updatedEl = document.getElementById('track-updated-at');
                    if (updatedEl) {
                        updatedEl.textContent = trackPollFails >= 2
                            ? 'Offline · showing last known status'
                            : 'Reconnecting…';
                    }
                });
        }, 30000);
    }

    function lookup(code) {
        code = String(code || '').trim().toUpperCase();
        if (code === '') {
            showError('Please enter your tracking code.');
            input.focus();
            return;
        }

        activeCode = code;
        lastTrackRevision = '';
        lastTrackIsAppointment = isAppointmentCode(code);
        stopPolling();
        showLoading(true);

        var isAppointment = lastTrackIsAppointment;
        var endpoint = isAppointment ? 'api/appointment_status.php' : 'api/request_status.php';

        fetch(endpoint + '?code=' + encodeURIComponent(code), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                showLoading(false);
                if (!data || data.ok === false) {
                    showError((data && data.error) || 'Unable to look up that code. Please try again.');
                    return;
                }
                if (!data.found) {
                    showError(isAppointment
                        ? 'No appointment found with that code. Please check and try again.'
                        : 'No request found with that code. Use ALR- for document requests or APT- for appointments.');
                    return;
                }
                lastTrackRevision = data.revision || '';
                renderResult(data, isAppointment);
                startPolling(code, isAppointment);

                if (window.history && window.history.replaceState) {
                    var url = new URL(window.location.href);
                    url.searchParams.set('track', code);
                    url.searchParams.delete('code');
                    window.history.replaceState({}, '', url.pathname + url.search + url.hash);
                }
            })
            .catch(function () {
                showLoading(false);
                showError('Connection error. Please check your internet and try again.');
            });
    }

    function openPanel(code) {
        root.classList.remove('hidden');
        root.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        if (code) {
            input.value = code;
            lookup(code);
        } else {
            input.value = '';
            errorEl.classList.add('hidden');
            resultEl.classList.add('hidden');
            loadingEl.classList.add('hidden');
            setTimeout(function () { input.focus(); }, 100);
        }
    }

    function closePanel() {
        root.classList.add('hidden');
        root.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        stopPolling();
        if (window.history && window.history.replaceState) {
            var url = new URL(window.location.href);
            url.searchParams.delete('track');
            url.searchParams.delete('code');
            var qs = url.searchParams.toString();
            window.history.replaceState({}, '', url.pathname + (qs ? '?' + qs : '') + url.hash);
        }
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        lookup(input.value);
    });

    closeBtn.addEventListener('click', closePanel);
    backdrop.addEventListener('click', closePanel);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !root.classList.contains('hidden')) closePanel();
    });

    document.addEventListener('click', function (e) {
        var trigger = e.target.closest('[data-open-track]');
        if (!trigger) return;
        e.preventDefault();
        var code = trigger.getAttribute('data-track-code') || '';
        openPanel(code);
    });

    window.AlcrosTrack = {
        open: openPanel,
        close: closePanel,
        lookup: lookup,
        cancel: submitCitizenCancel
    };

    var initial = root.dataset.initialCode || '';
    if (initial) {
        openPanel(initial);
    }
})();
