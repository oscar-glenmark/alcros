<?php
/**
 * Citizen appointment booking - saves to MySQL appointments table.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';

if (isMaintenanceMode()) {
    header('Location: index.php');
    exit;
}

$currentPage = basename($_SERVER['PHP_SELF']);
$citizenMobileTab = 'book';
$citizenMobileTabbarCompact = true;

$service = trim((string) ($_GET['service'] ?? $_POST['service'] ?? ''));
$serviceLabel = appointmentServiceLabel($service);
$isPsaDocumentsBooking = isPsaDocumentsAppointmentService($service);
$psaDocumentTypes = getPsaDocumentAppointmentTypes();
$appointmentServices = getAppointmentServices();
$servicePreselectedFromServices = trim((string) ($_GET['service'] ?? '')) !== '';
$showAppointmentServicePicker = !$servicePreselectedFromServices;
$success = null;
$error = null;
$appointmentCode = null;
$emailSent = false;
$smsSent = false;

$nameParts = personNamePartsFromInput($_POST);
$firstName = $nameParts['first_name'];
$middleName = $nameParts['middle_name'];
$lastName = $nameParts['last_name'];
$citizenName = formatPersonName($firstName, $middleName, $lastName);
$email       = normalizeGmail(trim($_POST['email'] ?? ''));
$phone       = trim($_POST['phone'] ?? '');
if ($isPsaDocumentsBooking) {
    $serviceType = $_SERVER['REQUEST_METHOD'] === 'POST'
        ? normalizePsaAppointmentServiceType(trim($_POST['service_type'] ?? ''))
        : '';
} elseif ($service !== '') {
    $serviceType = appointmentServiceLabel($service);
} else {
    $serviceType = '';
}
$postedPsaTypeKey = $isPsaDocumentsBooking && $_SERVER['REQUEST_METHOD'] === 'POST'
    ? trim($_POST['service_type'] ?? '')
    : '';
$date        = $_POST['appointment_date'] ?? '';
$time        = $_POST['appointment_time'] ?? '';
$notifyEmail = isset($_POST['notify_email']) && (string) $_POST['notify_email'] === '1';
$notifySms   = isset($_POST['notify_sms']) && (string) $_POST['notify_sms'] === '1';
$gmailVerified = isGmailVerifiedInSession($email);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requirePublicPostCsrf();
    if (isMaintenanceMode()) {
        $error = 'Online appointment booking is temporarily unavailable while the portal is under maintenance. Use Track on the home page to check an existing appointment.';
    } elseif (($nameError = validatePersonNameParts($nameParts)) !== null || $date === '' || $time === '') {
        $error = $nameError ?? 'Please complete all required fields.';
    } elseif ($service === '' || !isAllowedAppointmentServiceSlug($service)) {
        $error = 'Please select a service type.';
    } elseif ($serviceType === '') {
        $error = 'Please select a service type.';
    } elseif ($isPsaDocumentsBooking && !isAllowedPsaAppointmentServiceType($serviceType)) {
        $error = 'Please select a PSA document type (birth, death, or marriage certificates).';
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $error = 'Please choose a valid appointment date.';
    } elseif ($date < date('Y-m-d')) {
        $error = 'Appointment date cannot be in the past.';
    } elseif (!isValidGmail($email)) {
        $error = 'Please enter a valid Gmail address (example@gmail.com).';
    } elseif (!isGmailVerifiedInSession($email)) {
        $error = 'Please verify your Gmail is an active Google account before continuing.';
        $gmailVerified = false;
    } elseif (!isValidPhilippineMobile($phone)) {
        $error = 'Please enter a valid cellphone number (09XXXXXXXXX).';
    } elseif (empty($_FILES['id_front']['name'])) {
        $error = 'An error occurred. Please upload the required valid ID (front side).';
    } elseif (empty($_FILES['id_back']['name'])) {
        $error = 'An error occurred. Please upload the required valid ID (back side).';
    } else {
        $frontPath = saveIdUpload($_FILES['id_front'] ?? [], 'front');
        $backPath = null;
        if ($frontPath === null) {
            $error = 'An error occurred. Invalid valid ID (front). Use JPG, PNG, WEBP, or PDF.';
        } else {
            $backPath = saveIdUpload($_FILES['id_back'] ?? [], 'back');
            if ($backPath === null) {
                $error = 'An error occurred. Invalid valid ID (back). Use JPG, PNG, WEBP, or PDF.';
                deleteIdUploadFiles($frontPath);
            }
        }

        if ($error === null) {
            $slotLocked = false;
            $dayLocked = false;
            try {
                $pdo = getDB();
                ensureCitizenNotifyColumns($pdo);

                if (!acquireAppointmentDayLock($pdo, $date, 10, 'standalone')) {
                    deleteIdUploadFiles($frontPath, $backPath);
                    $error = 'This date is busy with other bookings. Please try again in a moment.';
                } elseif (!acquireAppointmentSlotLock($pdo, $date, $time, 10, 'standalone')) {
                    releaseAppointmentDayLock($pdo, $date, 'standalone');
                    deleteIdUploadFiles($frontPath, $backPath);
                    $error = 'This time slot is being booked by someone else. Please choose another time.';
                } else {
                    $dayLocked = true;
                    $slotLocked = true;
                    $pdo->beginTransaction();

                    $bookingError = validateAppointmentBooking($pdo, $date, $time, $email, true, 'standalone');
                    if ($bookingError !== null) {
                        $pdo->rollBack();
                        deleteIdUploadFiles($frontPath, $backPath);
                        $error = $bookingError;
                    } else {
                        ensureVisitSlotAvailableForWrite($pdo, $date, $time, null, null, true, 'standalone');

                        // Verified Gmail is required to book; enable email updates for this appointment.
                        $notifyEmail = true;
                        $appointmentCode = generateAppointmentCode();
                        $stmt = $pdo->prepare(
                            'INSERT INTO appointments (appointment_code, first_name, middle_name, last_name, email, phone, notify_email, notify_sms, service_type, appointment_date, appointment_time, status, source, id_front_path, id_back_path)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                        );
                        $stmt->execute([
                            $appointmentCode,
                            $firstName,
                            $middleName,
                            $lastName,
                            $email,
                            $phone,
                            $notifyEmail ? 1 : 0,
                            $notifySms ? 1 : 0,
                            $serviceType,
                            $date,
                            normalizeAppointmentTime($time),
                            'scheduled',
                            'standalone',
                            $frontPath,
                            $backPath,
                        ]);
                        $appointmentId = (int) $pdo->lastInsertId();
                        $pdo->commit();

                        require_once __DIR__ . '/includes/appointment_follow_up.php';
                        cancelPendingFollowUpsForNewBooking($pdo, $email, $phone, $appointmentId);

                        $notifyPayload = [
                            'appointment_code'  => $appointmentCode,
                            'first_name'        => $firstName,
                            'middle_name'       => $middleName,
                            'last_name'         => $lastName,
                            'email'             => $email,
                            'phone'             => $phone,
                            'service_label'     => $serviceType,
                            'service_type'      => $serviceType,
                            'appointment_date'  => $date,
                            'appointment_time'  => $time,
                            'notify_email'      => $notifyEmail ? 1 : 0,
                            'notify_sms'        => $notifySms ? 1 : 0,
                            'source'            => 'standalone',
                            'tracking_code'     => '',
                        ];
                        if ($notifyEmail) {
                            $emailSent = notifyAppointmentBooked($notifyPayload);
                        }
                        if ($notifySms) {
                            require_once __DIR__ . '/includes/sms.php';
                            $smsSent = notifyAppointmentBookedSms($notifyPayload);
                        }
                        if ($notifyEmail || $notifySms) {
                            maybeSendVisitSoonEmail($pdo, 'appointments', $appointmentId);
                        }
                        runReminderSchedulerIfDue($pdo, 60);
                        $success = true;
                    }
                }
            } catch (Throwable $e) {
                if (isset($pdo) && $pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                deleteIdUploadFiles($frontPath, $backPath);
                error_log('ALCROS book_appointment: ' . $e->getMessage());
                $error = 'Could not book appointment. ' . dbConnectionHelpMessage();
            } finally {
                if ($slotLocked) {
                    releaseAppointmentSlotLock($pdo, $date, $time, 'standalone');
                }
                if ($dayLocked) {
                    releaseAppointmentDayLock($pdo, $date, 'standalone');
                }
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>
    <?= alcrosCitizenHeadMeta() ?>
    <title>Schedule Appointment - ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
    <?= interFontTags() ?>
    <?= publicStylesheet('citizen-site') ?>
    <?= publicStylesheet('citizen-request') ?>
    <?= publicStylesheet('id-upload') ?>
    <?= publicStylesheet('back-home') ?>
</head>
<body class="citizen-site citizen-portal citizen-mobile-tabbar-compact" data-gmail-form="bookAppointmentForm">

    <header class="citizen-site-header">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between gap-4 py-3">
                <a href="index.php" class="flex items-center gap-3 min-w-0">
                    <?= alcrosFaviconImg(48, 'citizen-brand-logo shrink-0') ?>
                    <div class="site-brand-text">
                        <div class="site-brand-title">ALCROS</div>
                        <div class="site-brand-subtitle">Aloran Local Civil Registry Online System</div>
                    </div>
                </a>

                <nav class="hidden lg:flex items-center gap-1 xl:gap-2">
                    <a href="index.php" class="citizen-nav-link">Home</a>
                    <a href="services.php" class="citizen-nav-link is-active">Services</a>
                    <button type="button" data-open-track class="citizen-nav-link cursor-pointer bg-transparent border-0 border-b-2 border-transparent">Track Request</button>
                    <a href="index.php#about" class="citizen-nav-link">About</a>
                    <a href="index.php#faqs" class="citizen-nav-link">FAQs</a>
                    <a href="index.php#contact" class="citizen-nav-link">Contact Us</a>
                </nav>

                <div class="flex items-center gap-2 shrink-0">
                    <?= citizenStaffLoginHeaderLink() ?>
                    <button type="button" id="citizenMobileNavToggle" class="lg:hidden p-2 text-white" aria-label="Open menu">
                        <i data-lucide="menu" class="w-6 h-6"></i>
                    </button>
                </div>
            </div>

            <div id="citizenMobileNav" class="hidden lg:hidden pb-4 border-t border-white/10 pt-3">
                <div class="flex flex-col gap-1">
                    <a href="index.php" class="citizen-nav-link">Home</a>
                    <a href="services.php" class="citizen-nav-link is-active">Services</a>
                    <button type="button" data-open-track class="citizen-nav-link text-left cursor-pointer bg-transparent border-0">Track Request</button>
                    <a href="index.php#about" class="citizen-nav-link">About</a>
                    <a href="index.php#faqs" class="citizen-nav-link">FAQs</a>
                    <a href="index.php#contact" class="citizen-nav-link">Contact Us</a>
                </div>
            </div>
        </div>
    </header>

    <main class="citizen-site-main">
        <section class="citizen-page-hero citizen-page-hero--compact">
            <div class="max-w-2xl mx-auto">
                <h1>Schedule Appointment</h1>
                <p>Book a consultation for special civil registry services.</p>
            </div>
        </section>

        <section class="max-w-2xl mx-auto px-4 pb-12">
        <?php if ($success): ?>
        <?php
        require_once __DIR__ . '/includes/sms.php';
        $successCitizenName = $citizenName !== '' ? $citizenName : trim($firstName . ' ' . $lastName);
        $successServiceLabel = $serviceType !== '' ? $serviceType : $serviceLabel;
        $smsUpdatesAvailable = isSmsEnabled() && isSmsConfigured();
        ?>
        <div class="citizen-request-card p-4 sm:p-6 md:p-8 lg:p-10">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="check-circle" class="w-8 h-8"></i>
                </div>
                <h1 class="text-2xl font-black text-slate-900 mb-2">Appointment Booked Successfully</h1>
                <p class="text-gray-500 text-sm">
                    Thank you, <strong><?= htmlspecialchars($successCitizenName) ?></strong>.
                    Your <?= htmlspecialchars($successServiceLabel) ?> appointment was booked successfully and is <strong>awaiting confirmation</strong> from our office.
                </p>
            </div>

            <div class="bg-blue-50 border border-blue-100 rounded-xl p-6 text-center mb-6">
                <p class="text-[10px] font-bold text-blue-600 uppercase tracking-widest mb-2">Your appointment code</p>
                <p id="success-tracking-code" class="text-3xl md:text-4xl font-black text-blue-700 tracking-widest"><?= htmlspecialchars($appointmentCode) ?></p>
                <button type="button" id="copy-tracking-btn" class="mt-4 inline-flex items-center gap-2 bg-white border border-blue-200 text-blue-700 px-4 py-2 rounded-lg text-xs font-bold hover:bg-blue-100">
                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy code
                </button>
            </div>

            <div class="space-y-3 text-sm text-slate-600 mb-6">
                <?php if ($date !== ''): ?>
                <p><span class="font-bold text-slate-500">Scheduled visit:</span> <?= htmlspecialchars(formatAppointmentDisplay($date, $time)) ?></p>
                <?php endif; ?>
                <p><span class="font-bold text-slate-500">Status:</span> Awaiting confirmation - you can follow every update online.</p>
                <?php if ($notifyEmail && $emailSent): ?>
                <p class="citizen-request-notice citizen-request-notice--success">
                    <i data-lucide="mail" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>A Gmail confirmation was sent to <strong><?= htmlspecialchars($email) ?></strong>. Your visit is awaiting confirmation. After our office confirms your appointment, you will receive email reminders 5 hours, 3 hours, and 1 hour before your visit.</span>
                </p>
                <?php elseif ($notifyEmail): ?>
                <p class="citizen-request-notice citizen-request-notice--warn">
                    <i data-lucide="alert-circle" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>We could not send the Gmail confirmation right now. Please save your appointment code and use <strong>Track</strong>. Staff can still email updates once Gmail sending is configured.</span>
                </p>
                <?php else: ?>
                <p class="citizen-request-notice citizen-request-notice--warn">
                    <i data-lucide="alert-circle" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>Gmail notifications were not enabled for this booking, so confirmation and visit reminders will not be emailed. Please save your appointment code and use <strong>Track</strong> to follow your status.</span>
                </p>
                <?php endif; ?>
                <?php if ($notifySms && $smsSent): ?>
                <p class="citizen-request-notice citizen-request-notice--success">
                    <i data-lucide="message-square" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>A text confirmation was sent to <strong><?= htmlspecialchars($phone) ?></strong> (awaiting confirmation). You will also receive a text when staff confirm your appointment and a reminder 1 hour before your visit.</span>
                </p>
                <?php elseif ($notifySms && $smsUpdatesAvailable): ?>
                <p class="citizen-request-notice citizen-request-notice--warn">
                    <i data-lucide="message-square" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>We could not send the text confirmation right now. Please save your appointment code and use <strong>Track</strong>. You can still receive texts when staff confirms and before your visit.</span>
                </p>
                <?php elseif ($notifySms): ?>
                <p class="citizen-request-notice citizen-request-notice--warn">
                    <i data-lucide="message-square" class="w-4 h-4 shrink-0 mt-0.5"></i>
                    <span>You opted in to SMS updates, but text messaging is not fully set up for this office yet. Please save your appointment code and use <strong>Track</strong> for updates.</span>
                </p>
                <?php endif; ?>
            </div>

            <div id="citizen-success-cancel-wrap" class="citizen-success-cancel citizen-success-cancel--actions"
                 data-cancel-type="appointment"
                 data-cancel-code="<?= htmlspecialchars($appointmentCode, ENT_QUOTES) ?>"
                 data-cancel-label="Cancel Appointment">
                <?= publicCsrfField() ?>
                <div class="flex flex-col sm:flex-row justify-center gap-3">
                    <button type="button" id="citizen-success-cancel-btn" class="citizen-success-cancel__btn citizen-success-cancel__btn--action">Cancel Appointment</button>
                    <button type="button" data-open-track data-track-code="<?= htmlspecialchars($appointmentCode, ENT_QUOTES) ?>" class="citizen-btn-gold px-6 py-3 rounded-full text-xs text-center">Track My Appointment</button>
                </div>
            </div>
        </div>
        <?= pageConfigJson([
            'trackingCode' => $appointmentCode,
            'cancelType'   => 'appointment',
            'canCancel'    => true,
        ], 'request-success-config') ?>
        <?= scriptTag('core/page-config.js') ?>
        <?= scriptTag('public/request-success.js') ?>
        <?php else: ?>
        <?php $idUploadErrors = citizenIdUploadInlineErrors($error); ?>
        <form method="POST" enctype="multipart/form-data" class="citizen-request-card p-4 sm:p-6 md:p-8 space-y-4" id="bookAppointmentForm" data-slot-type="standalone">
            <?= publicCsrfField() ?>
            <?php if ($service !== ''): ?>
            <input type="hidden" name="service" value="<?= htmlspecialchars($service) ?>">
            <?php endif; ?>
            <input type="hidden" name="email_verified" id="emailVerified" value="<?= $gmailVerified ? '1' : '0' ?>">
            <input type="hidden" name="notify_email" id="notifyEmailHidden" value="<?= $notifyEmail ? '1' : '0' ?>">
            <input type="hidden" name="notify_sms" id="notifySmsHidden" value="<?= $notifySms ? '1' : '0' ?>">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <label class="block text-[11px] font-bold mb-1">First Name *</label>
                    <input type="text" name="first_name" required placeholder="First name" value="<?= htmlspecialchars($firstName) ?>" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                </div>
                <div>
                    <label class="block text-[11px] font-bold mb-1">Middle Name</label>
                    <input type="text" name="middle_name" placeholder="Middle name(Optional)" value="<?= htmlspecialchars((string) ($middleName ?? '')) ?>" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                </div>
                <div>
                    <label class="block text-[11px] font-bold mb-1">Last Name *</label>
                    <input type="text" name="last_name" required placeholder="Last name" value="<?= htmlspecialchars($lastName) ?>" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                </div>
            </div>
            <div>
                <?php
                $serviceFieldLabel = ($isPsaDocumentsBooking && !$showAppointmentServicePicker)
                    ? 'Select Certificate Type *'
                    : 'Service Type *';
                ?>
                <label class="block text-[11px] font-bold mb-1"><?= htmlspecialchars($serviceFieldLabel) ?></label>
                <?php if ($showAppointmentServicePicker): ?>
                <select name="service" id="appointmentServiceSelect" required class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                    <option value="" disabled <?= $service === '' ? 'selected' : '' ?>>Select a service</option>
                    <?php foreach ($appointmentServices as $svc): ?>
                    <option value="<?= htmlspecialchars($svc['slug']) ?>" <?= $service === $svc['slug'] ? 'selected' : '' ?>><?= htmlspecialchars($svc['label']) ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="text-[10px] text-gray-500 mt-1">Choose the special civil registry service you need to book.</p>
                <div id="psaDocumentTypeWrap" class="hidden mt-3">
                    <label class="block text-[11px] font-bold mb-1">Select Certificate Type *</label>
                    <select name="service_type" id="psaDocumentTypeSelect" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                        <option value="" disabled <?= $serviceType === '' && $postedPsaTypeKey === '' ? 'selected' : '' ?>>Select PSA document</option>
                        <?php foreach ($psaDocumentTypes as $typeKey => $typeLabel): ?>
                        <?php
                        $typeSelected = $postedPsaTypeKey === $typeKey
                            || ($postedPsaTypeKey === '' && $serviceType === $typeLabel);
                        ?>
                        <option value="<?= htmlspecialchars($typeKey) ?>" <?= $typeSelected ? 'selected' : '' ?>><?= htmlspecialchars($typeLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="text-[10px] text-gray-500 mt-1">Request PSA Documents - choose birth, death, or marriage certificates.</p>
                </div>
                <?php elseif ($isPsaDocumentsBooking): ?>
                <select name="service_type" required class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                    <option value="" disabled <?= $serviceType === '' && $postedPsaTypeKey === '' ? 'selected' : '' ?>>Select PSA document</option>
                    <?php foreach ($psaDocumentTypes as $typeKey => $typeLabel): ?>
                    <?php
                    $typeSelected = $postedPsaTypeKey === $typeKey
                        || ($postedPsaTypeKey === '' && $serviceType === $typeLabel);
                    ?>
                    <option value="<?= htmlspecialchars($typeKey) ?>" <?= $typeSelected ? 'selected' : '' ?>><?= htmlspecialchars($typeLabel) ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="text-[10px] text-gray-500 mt-1">Request PSA Documents - choose birth, death, or marriage certificates.</p>
                <?php else: ?>
                <p class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 font-semibold"><?= htmlspecialchars($serviceLabel !== '' ? $serviceLabel : $serviceType) ?></p>
                <?php endif; ?>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-[11px] font-bold mb-1">Choose Visit Date *</label>
                    <input type="date" id="appointmentDateInput" name="appointment_date" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($date) ?>" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                </div>
                <div>
                    <label class="block text-[11px] font-bold mb-1">Time *</label>
                    <select id="appointmentTimeInput" name="appointment_time" required
                            class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm" disabled>
                        <option value="" disabled <?= $time === '' ? 'selected' : '' ?>>Select a time slot</option>
                        <?php if ($time !== ''): ?>
                        <option value="<?= htmlspecialchars(substr(normalizeAppointmentTime($time), 0, 5)) ?>" selected>
                            <?= htmlspecialchars(formatAppointmentSlotLabel($time)) ?>
                        </option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <p class="text-[10px] text-gray-500">Special service appointments: Monday to Friday only, excluding holidays. Morning 8:00 AM–12:00 NN and afternoon 1:00–5:00 PM, every 20 minutes. Lunch break 12:00–1:00 PM. One booking per slot.</p>
            <p id="slotAvailabilityStatus" class="hidden text-xs mt-2"></p>
            <div>
                <label class="flex items-center gap-2 text-[11px] font-bold mb-1">
                    <i data-lucide="mail" class="w-3.5 h-3.5 text-blue-500"></i> Active Gmail Account *
                </label>
                <div class="flex gap-2">
                    <input type="email" id="gmailInput" name="email" required placeholder="example@gmail.com"
                           value="<?= htmlspecialchars($email) ?>"
                           class="flex-1 bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
                    <button type="button" id="verifyGmailBtn" class="citizen-btn-navy px-4 py-2.5 rounded-xl text-xs whitespace-nowrap shrink-0<?= $gmailVerified ? ' opacity-80 cursor-default' : '' ?>"<?= $gmailVerified ? ' disabled aria-disabled="true"' : '' ?>>
                        <?= $gmailVerified ? 'Verified' : 'Verify Gmail' ?>
                    </button>
                </div>
                <p class="text-[10px] text-gray-500 mt-1">We check that your @gmail.com account is active. If you agree to notifications, status updates are sent to this Gmail.</p>
                <p id="gmailStatus" class="text-xs mt-2 <?= $gmailVerified ? 'font-semibold text-green-600' : 'hidden' ?>"><?= $gmailVerified ? 'Gmail verified - this is an active Google account.' : '' ?></p>
            </div>
            <div>
                <label class="block text-[11px] font-bold mb-1">Phone *</label>
                <input type="tel" name="phone" required placeholder="09XXXXXXXXX" pattern="09[0-9]{9}" value="<?= htmlspecialchars($phone) ?>" class="w-full bg-gray-50 border rounded-xl px-4 py-2.5 text-sm">
            </div>
            <div>
                <label class="text-[11px] font-bold mb-2 block">Upload Valid IDs (National ID / Driver's License) *</label>
                <div class="grid grid-cols-2 gap-4">
                    <label class="citizen-id-upload" data-id-upload>
                        <input type="file" name="id_front" accept="image/*,.pdf" class="hidden<?= !empty($idUploadErrors['front']) ? ' is-invalid' : '' ?>" id="idFront" required<?= !empty($idUploadErrors['front']) ? ' aria-invalid="true"' : '' ?>>
                        <div class="citizen-id-upload__empty" data-id-upload-empty>
                            <i data-lucide="upload" class="w-6 h-6 text-gray-300 mx-auto mb-2"></i>
                            <p class="text-xs font-bold text-gray-600">Front Side</p>
                            <p class="text-[10px] text-gray-400 mt-1" id="idFrontLabel">Click to upload ID</p>
                        </div>
                        <div class="citizen-id-upload__preview hidden" data-id-upload-preview>
                            <span class="citizen-id-upload__side">Front</span>
                            <img class="citizen-id-upload__image hidden" data-id-upload-image alt="Front ID preview">
                            <div class="citizen-id-upload__pdf hidden" data-id-upload-pdf>
                                <i data-lucide="file-text" class="w-8 h-8 mx-auto mb-2 opacity-60"></i>
                                <span>PDF uploaded</span>
                            </div>
                            <p class="citizen-id-upload__caption" data-id-upload-caption></p>
                        </div>
                        <?php if (!empty($idUploadErrors['front'])): ?>
                        <p class="citizen-field-error" role="alert"><?= htmlspecialchars($idUploadErrors['front']) ?></p>
                        <?php endif; ?>
                    </label>
                    <label class="citizen-id-upload" data-id-upload>
                        <input type="file" name="id_back" accept="image/*,.pdf" class="hidden<?= !empty($idUploadErrors['back']) ? ' is-invalid' : '' ?>" id="idBack" required<?= !empty($idUploadErrors['back']) ? ' aria-invalid="true"' : '' ?>>
                        <div class="citizen-id-upload__empty" data-id-upload-empty>
                            <i data-lucide="upload" class="w-6 h-6 text-gray-300 mx-auto mb-2"></i>
                            <p class="text-xs font-bold text-gray-600">Back Side</p>
                            <p class="text-[10px] text-gray-400 mt-1" id="idBackLabel">Click to upload ID</p>
                        </div>
                        <div class="citizen-id-upload__preview hidden" data-id-upload-preview>
                            <span class="citizen-id-upload__side">Back</span>
                            <img class="citizen-id-upload__image hidden" data-id-upload-image alt="Back ID preview">
                            <div class="citizen-id-upload__pdf hidden" data-id-upload-pdf>
                                <i data-lucide="file-text" class="w-8 h-8 mx-auto mb-2 opacity-60"></i>
                                <span>PDF uploaded</span>
                            </div>
                            <p class="citizen-id-upload__caption" data-id-upload-caption></p>
                        </div>
                        <?php if (!empty($idUploadErrors['back'])): ?>
                        <p class="citizen-field-error" role="alert"><?= htmlspecialchars($idUploadErrors['back']) ?></p>
                        <?php endif; ?>
                    </label>
                </div>
            </div>
            <div class="citizen-form-actions pt-2">
                <a href="services.php" class="back-home back-home--step">
                    <i data-lucide="chevron-left" class="back-home__icon w-4 h-4"></i>
                    <span>Back</span>
                </a>
                <div class="citizen-form-actions__forward w-full sm:w-auto">
                    <button type="submit" id="bookSubmitBtn" class="citizen-btn-gold w-full sm:w-auto sm:min-w-[12rem] rounded-xl py-3 text-sm" data-loading-text="Booking…">Book Appointment</button>
                </div>
            </div>
        </form>
        <?php endif; ?>
        </section>
    </main>
    <?= actionCoreScripts() ?>
    <?= actionResultScript($error ? ['error', $error] : null) ?>
    <?= scriptTag('public/citizen-site.js') ?>
    <script type="application/json" id="alcrosOfficeHolidayConfig"><?= json_encode(officeHolidayClientConfig(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?></script>
    <?= scriptTag('public/appointment-slots.js') ?>
    <?= scriptTag('public/forms.js') ?>
    <?php require __DIR__ . '/includes/citizen_mobile_tabbar.php'; ?>
    <?php require __DIR__ . '/includes/track_floating.php'; ?>
    <?= scriptTag('public/track-floating.js') ?>
    <?php require __DIR__ . '/includes/maintenance_announcement.php'; ?>
    <?php require __DIR__ . '/includes/privacy_agreement.php'; ?>
    <?php require __DIR__ . '/includes/notification_consent.php'; ?>
    <?= lucideInitScript() ?>
</body>
</html>
