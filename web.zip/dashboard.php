<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/api_helpers.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/analytics_dashboard.php';
requireStaffLogin();
requirePageAccess('dashboard.php');
releaseSessionLock();

$activePage = 'dashboard.php';
$alcrosAdminRealtime = true;
$pdo = getDB();
ensureCitizenNotifyColumns($pdo);
ensureSoftDeleteColumns($pdo);
$isAdminUser = isAdmin();
$staffDisplayName = staffName();
$staffRole = staffRole();
$todayLabel = date('l, F j, Y');

$pageTitle = 'Dashboard';
$pageSubtitle = $isAdminUser
    ? 'Registry oversight, reports, and system configuration.'
    : 'Your daily queue, requests, and appointment summary.';

$todayDate = alcrosTodayDate();
$adminAnalytics = null;
$recentRequests = [];
$recentAppointments = [];
$scheduleMonth = date('Y-m');
$scheduleDate = $todayDate;
$scheduleCalendar = ['appointments' => [], 'dates' => []];
$incomingDate = incomingAppointmentsDate();
$incomingAppointments = [];

if ($isAdminUser) {
    $adminAnalytics = fetchAnalyticsDashboard($pdo);
    $activities = enrichActivityLogsForDisplay($pdo, $pdo->query(
        "SELECT staff_id, action, details, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 6"
    )->fetchAll());
} else {
    $recentRequests = enrichCitizenNameRows($pdo->query(
        "SELECT tracking_code, first_name, middle_name, last_name, document_type, status, rejection_reason, submitted_at
         FROM document_requests ORDER BY submitted_at DESC LIMIT 6"
    )->fetchAll());
    $recentAppointments = fetchRecentStandaloneAppointments($pdo, 6);
    $activityStmt = $pdo->prepare(
        "SELECT staff_id, action, details, created_at FROM activity_logs WHERE staff_id = ? ORDER BY created_at DESC LIMIT 6"
    );
    $activityStmt->execute([staffId()]);
    $activities = enrichActivityLogsForDisplay($pdo, $activityStmt->fetchAll());
    $scheduleCalendar = fetchDashboardSchedule($pdo, $scheduleDate, $scheduleMonth);
    $incomingAppointments = fetchIncomingAppointments($pdo, 8);
}

$quickActions = [];
if ($isAdminUser) {
    $quickActions = [
        ['href' => 'records.php', 'label' => 'Civil Records', 'desc' => 'Manage life event data', 'icon' => 'book-open', 'color' => 'bg-orange-50 text-orange-600'],
        ['href' => 'report.php', 'label' => 'Reports', 'desc' => 'Summaries, charts & Excel export', 'icon' => 'bar-chart-2', 'color' => 'bg-violet-50 text-violet-600'],
        ['href' => 'analytics.php', 'label' => 'Analytics', 'desc' => 'Office charts, trends & queue', 'icon' => 'trending-up', 'color' => 'bg-blue-50 text-blue-600'],
        ['href' => 'system_settings.php', 'label' => 'Settings', 'desc' => 'System configuration', 'icon' => 'settings', 'color' => 'bg-slate-100 text-slate-600'],
    ];
}

function dashboardCountBetween(PDO $pdo, string $sql, string $start, string $end): int
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$start, $end]);

    return (int) $stmt->fetchColumn();
}

function dashboardTrendPercent(int $current, int $previous): array
{
    if ($current === 0 && $previous === 0) {
        return ['pct' => 0, 'up' => true];
    }
    if ($previous === 0) {
        return ['pct' => 100, 'up' => $current > 0];
    }

    $change = (($current - $previous) / $previous) * 100;

    return ['pct' => max(0, (int) round(abs($change))), 'up' => $change >= 0];
}

$statCards = [];
if (!$isAdminUser) {
    $periodCurStart = date('Y-m-d 00:00:00', strtotime('-7 days'));
    $periodCurEnd = date('Y-m-d 00:00:00', strtotime('+1 day'));
    $periodPrevStart = date('Y-m-d 00:00:00', strtotime('-14 days'));
    $periodPrevEnd = $periodCurStart;
    $weekAgoDate = date('Y-m-d', strtotime($todayDate . ' -7 days'));

    $reqActive = documentRequestActiveSql();
    $pendingCount = (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status IN ('pending','verified')")->fetchColumn();
    $queueCount = (int) $pdo->query("SELECT COUNT(*) FROM queue_tickets WHERE status = 'waiting' AND DATE(created_at) = CURDATE()")->fetchColumn();
    $todayAppts = countTodaySpecialAppointments($pdo);
    $readyCount = (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'ready'")->fetchColumn();

    $statCards = [
        [
            'id' => 'stat-pending',
            'label' => 'Pending Request',
            'value' => $pendingCount,
            'icon' => 'clipboard-list',
            'tone' => 'amber',
            'page' => 'manage_request.php',
            'query' => ['status' => 'pending'],
            'trend' => dashboardTrendPercent(
                dashboardCountBetween($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND submitted_at >= ? AND submitted_at < ?", $periodCurStart, $periodCurEnd),
                dashboardCountBetween($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND submitted_at >= ? AND submitted_at < ?", $periodPrevStart, $periodPrevEnd)
            ),
        ],
        [
            'id' => 'stat-queue',
            'label' => 'Queue Waiting',
            'value' => $queueCount,
            'icon' => 'users',
            'tone' => 'blue',
            'page' => 'live-queue.php',
            'query' => [],
            'trend' => dashboardTrendPercent(
                dashboardCountBetween($pdo, 'SELECT COUNT(*) FROM queue_tickets WHERE created_at >= ? AND created_at < ?', $periodCurStart, $periodCurEnd),
                dashboardCountBetween($pdo, 'SELECT COUNT(*) FROM queue_tickets WHERE created_at >= ? AND created_at < ?', $periodPrevStart, $periodPrevEnd)
            ),
        ],
        [
            'id' => 'stat-appts',
            'label' => "Today's Appointments",
            'value' => $todayAppts,
            'icon' => 'calendar',
            'tone' => 'violet',
            'page' => 'appointment.php',
            'query' => ['date' => $todayDate, 'status' => 'all_appointments'],
            'trend' => dashboardTrendPercent($todayAppts, countSpecialAppointmentsOnDate($pdo, $weekAgoDate)),
        ],
        [
            'id' => 'stat-ready',
            'label' => 'Ready for Pickup',
            'value' => $readyCount,
            'icon' => 'package',
            'tone' => 'emerald',
            'page' => 'manage_request.php',
            'query' => ['status' => 'ready'],
            'trend' => dashboardTrendPercent(
                dashboardCountBetween($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'ready' AND updated_at >= ? AND updated_at < ?", $periodCurStart, $periodCurEnd),
                dashboardCountBetween($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'ready' AND updated_at >= ? AND updated_at < ?", $periodPrevStart, $periodPrevEnd)
            ),
        ],
    ];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title>Dashboard - ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= adminLayoutHeadStyles('dashboard') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
    <?php if ($isAdminUser): ?>
    <?= vendorScriptTag('chart.umd.min.js') ?>
    <?php endif; ?>
</head>
<body class="flex min-h-screen" data-realtime="dashboard" data-admin="<?= $isAdminUser ? '1' : '0' ?>">

    <?php require __DIR__ . '/includes/admin_sidebar.php'; ?>

    <main class="admin-main flex flex-col bg-[#f8fafc]">
        <?php require __DIR__ . '/includes/admin_header.php'; ?>

        <div class="admin-content p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto admin-page-wrap space-y-6">

            <!-- Welcome -->
            <div class="dash-welcome<?= $isAdminUser ? ' dash-welcome--admin' : '' ?>">
                <div class="dash-welcome__brand">
                    <?= renderStaffAvatar(staffPhotoPath(), $staffDisplayName, 'dash-brand-logo shrink-0 text-xl', 'rounded-2xl') ?>
                    <div class="dash-welcome__text">
                        <p class="dash-welcome__role"><?= $isAdminUser ? 'Registry Admin' : 'Registry Staff' ?></p>
                        <h1 class="dash-welcome__greeting">Good day, <?= htmlspecialchars(explode(' ', $staffDisplayName)[0]) ?>!</h1>
                        <p class="dash-welcome__meta"><?= htmlspecialchars(staffId()) ?> · <?= htmlspecialchars($staffRole) ?> · <?= htmlspecialchars($todayLabel) ?></p>
                    </div>
                </div>
            </div>

            <?php if (!$isAdminUser && $statCards !== []): ?>
            <!-- Stats (Staff operational counters) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                <?php foreach ($statCards as $card): ?>
                <?php $trend = $card['trend']; ?>
                <a href="<?= htmlspecialchars(buildStaffOperationalUrl($card['page'], $card['query'])) ?>"
                   class="dash-stat-card dash-stat-card--<?= htmlspecialchars($card['tone']) ?>">
                    <div class="dash-stat-card__head">
                        <span class="dash-stat-card__icon">
                            <i data-lucide="<?= htmlspecialchars($card['icon']) ?>" class="w-4 h-4"></i>
                        </span>
                        <span class="dash-stat-card__label"><?= htmlspecialchars($card['label']) ?></span>
                    </div>
                    <p id="<?= htmlspecialchars($card['id']) ?>" class="dash-stat-card__value"><?= number_format($card['value']) ?></p>
                    <p class="dash-stat-card__trend">
                        <span class="dash-stat-card__trend-value dash-stat-card__trend-value--<?= $trend['up'] ? 'up' : 'down' ?>">
                            <?= $trend['up'] ? '↑' : '↓' ?> <?= (int) $trend['pct'] ?>%
                        </span>
                        <span class="dash-stat-card__trend-note">vs. last 7 days</span>
                    </p>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($isAdminUser): ?>
            <section class="dash-admin-quick-wrap" aria-labelledby="dash-admin-quick-heading">
                <p id="dash-admin-quick-heading" class="dash-admin-analytics__kicker">Quick access</p>
            <div class="dash-admin-quick grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mt-2">
                <?php foreach ($quickActions as $action): ?>
                <a href="<?= htmlspecialchars(buildAuthUrl($action['href'], $action['query'] ?? [])) ?>" class="dash-admin-quick__card dash-card bg-white rounded-xl border border-gray-100 hover:border-blue-200 flex items-start">
                    <div class="dash-admin-quick__icon rounded-lg shrink-0 <?= htmlspecialchars($action['color']) ?>">
                        <i data-lucide="<?= htmlspecialchars($action['icon']) ?>" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="dash-admin-quick__title font-bold text-slate-800 truncate"><?= htmlspecialchars($action['label']) ?></p>
                        <p class="dash-admin-quick__desc text-gray-400"><?= htmlspecialchars($action['desc']) ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            </section>

            <?php
            $adminCalendarToday = $todayDate;
            require __DIR__ . '/includes/admin_dashboard_analytics.php';
            ?>

            <?php else: ?>

            <!-- Row 1: Today's schedule 40% · Incoming 60%. Row 2: Recent requests · appointments · activity (3 columns). -->
            <div class="space-y-6">
            <div class="grid grid-cols-1 xl:grid-cols-10 gap-6">

                <!-- Today's schedule -->
                <div class="xl:col-span-4 bg-white rounded-2xl border border-gray-100 dash-card overflow-hidden dash-panel-pair">
                    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between">
                        <div>
                            <h2 class="font-bold text-sm text-slate-900">Today's Schedule</h2>
                            <p class="text-[10px] text-gray-400 mt-0.5"><span id="dash-schedule-count"><?= count($scheduleCalendar['appointments']) ?></span> scheduled visit(s) · <span id="dash-schedule-date-label"><?= formatDateDisplay($scheduleDate) ?></span></p>
                        </div>
                        <a id="dash-schedule-open-link" href="<?= htmlspecialchars(buildStaffOperationalUrl('appointment.php', ['date' => $scheduleDate])) ?>" class="text-blue-600 text-[10px] font-bold uppercase hover:underline">Open</a>
                    </div>

                    <div class="px-4 pt-4 pb-3 border-b border-gray-50 xl:border-b-0 xl:pb-4">
                        <div class="dash-schedule-calendar max-w-md xl:max-w-sm" id="dashScheduleCalendar">
                            <div class="dash-cal-head">
                                <button type="button" id="dashCalPrev" class="dash-cal-nav" aria-label="Previous month">
                                    <i data-lucide="chevron-left" class="w-4 h-4"></i>
                                </button>
                                <p id="dashCalMonthLabel" class="dash-cal-month"></p>
                                <button type="button" id="dashCalNext" class="dash-cal-nav" aria-label="Next month">
                                    <i data-lucide="chevron-right" class="w-4 h-4"></i>
                                </button>
                            </div>
                            <div class="dash-cal-weekdays">
                                <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
                            </div>
                            <div id="dashCalGrid" class="dash-cal-grid" role="grid" aria-label="Appointment calendar"></div>
                        </div>
                    </div>

                    <?php if (empty($scheduleCalendar['appointments'])): ?>
                    <div id="dash-schedule-empty" class="p-10 text-center border-t border-gray-50 xl:border-t-0">
                        <i data-lucide="calendar-off" class="w-8 h-8 text-gray-200 mx-auto mb-2"></i>
                        <p class="text-xs text-gray-400">No visits scheduled for this date.</p>
                    </div>
                    <div id="today-appts-list" class="divide-y divide-gray-50 max-h-[240px] overflow-y-auto hidden"></div>
                    <?php else: ?>
                    <div id="dash-schedule-empty" class="p-10 text-center hidden border-t border-gray-50 xl:border-t-0">
                        <i data-lucide="calendar-off" class="w-8 h-8 text-gray-200 mx-auto mb-2"></i>
                        <p class="text-xs text-gray-400">No visits scheduled for this date.</p>
                    </div>
                    <div id="today-appts-list" class="divide-y divide-gray-50 max-h-[240px] overflow-y-auto border-t border-gray-50">
                        <?php foreach ($scheduleCalendar['appointments'] as $ap): ?>
                        <?php
                        $isCertificate = ($ap['schedule_kind'] ?? '') === 'certificate';
                        [$visitPath, $visitQuery] = resolveStaffOperationalNav(...scheduleVisitLinkParams($ap, $scheduleDate));
                        ?>
                        <a href="<?= htmlspecialchars(buildAuthUrl($visitPath, $visitQuery)) ?>" class="dash-schedule-row px-5 py-3 flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg <?= $isCertificate ? 'bg-amber-50 text-amber-700' : 'bg-blue-50 text-blue-600' ?> flex flex-col items-center justify-center shrink-0 leading-none">
                                <span class="text-[9px] font-bold"><?= date('g:i', strtotime($ap['appointment_time'])) ?></span>
                                <span class="text-[8px] uppercase"><?= date('A', strtotime($ap['appointment_time'])) ?></span>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($ap['citizen_name']) ?></p>
                                <p class="text-[10px] text-gray-400 truncate"><?= htmlspecialchars($ap['service_type']) ?></p>
                            </div>
                            <span class="text-[9px] font-bold uppercase text-gray-400 shrink-0"><?= htmlspecialchars($ap['status']) ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Incoming appointments (60%) - same row as schedule -->
                <div class="xl:col-span-6 bg-white rounded-2xl border border-gray-100 dash-card overflow-hidden dash-panel-pair">
                    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between">
                        <div>
                            <h2 class="font-bold text-sm text-slate-900">Incoming Appointments</h2>
                            <p class="text-[10px] text-gray-400 mt-0.5"><span id="incoming-appts-count"><?= count($incomingAppointments) ?></span> appointment(s) · Tomorrow · <span id="incoming-appts-date"><?= formatDateDisplay($incomingDate) ?></span></p>
                        </div>
                        <a id="incoming-appts-open-link" href="<?= htmlspecialchars(buildStaffOperationalUrl('appointment.php', ['date' => $incomingDate, 'status' => 'confirmed'])) ?>" class="text-blue-600 text-[10px] font-bold uppercase hover:underline">Open</a>
                    </div>

                    <?php if (empty($incomingAppointments)): ?>
                    <div id="incoming-appts-empty" class="p-8 text-center">
                        <i data-lucide="calendar-clock" class="w-8 h-8 text-gray-200 mx-auto mb-2"></i>
                        <p class="text-xs text-gray-400">No confirmed appointments for tomorrow.</p>
                    </div>
                    <div id="incoming-appts-list" class="divide-y divide-gray-50 max-h-[280px] xl:max-h-none overflow-y-auto hidden"></div>
                    <?php else: ?>
                    <div id="incoming-appts-empty" class="p-8 text-center hidden">
                        <i data-lucide="calendar-clock" class="w-8 h-8 text-gray-200 mx-auto mb-2"></i>
                        <p class="text-xs text-gray-400">No confirmed appointments for tomorrow.</p>
                    </div>
                    <div id="incoming-appts-list" class="divide-y divide-gray-50 max-h-[280px] xl:max-h-none overflow-y-auto">
                        <?php foreach ($incomingAppointments as $ap): ?>
                        <?php
                        $isCertificate = ($ap['schedule_kind'] ?? '') === 'certificate';
                        [$visitPath, $visitQuery] = resolveStaffOperationalNav(...scheduleVisitLinkParams($ap, $incomingDate));
                        ?>
                        <a href="<?= htmlspecialchars(buildAuthUrl($visitPath, $visitQuery)) ?>" class="dash-schedule-row px-5 py-3 flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg <?= $isCertificate ? 'bg-amber-50 text-amber-700' : 'bg-violet-50 text-violet-600' ?> flex flex-col items-center justify-center shrink-0 leading-none">
                                <span class="text-[9px] font-bold"><?= date('g:i', strtotime($ap['appointment_time'])) ?></span>
                                <span class="text-[8px] uppercase"><?= date('A', strtotime($ap['appointment_time'])) ?></span>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($ap['citizen_name']) ?></p>
                                <p class="text-[10px] text-gray-400 truncate"><?= htmlspecialchars($ap['service_type']) ?></p>
                            </div>
                            <span class="text-[9px] font-bold uppercase text-gray-400 shrink-0"><?= htmlspecialchars($ap['status']) ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

            </div>

            <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 dash-staff-recents-row">
                <div class="bg-white rounded-2xl border border-gray-100 dash-card overflow-hidden dash-panel-pair min-w-0">
                    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between">
                        <div>
                            <h2 class="font-bold text-sm text-slate-900">Recent Requests</h2>
                            <p class="text-[10px] text-gray-400 mt-0.5">Latest citizen document submissions</p>
                        </div>
                        <a href="<?= htmlspecialchars(buildStaffOperationalUrl('manage_request.php')) ?>" class="text-blue-600 text-[10px] font-bold uppercase hover:underline">View all</a>
                    </div>
                    <?php if (empty($recentRequests)): ?>
                    <div class="p-12 text-center">
                        <div class="bg-gray-50 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3">
                            <i data-lucide="inbox" class="w-6 h-6 text-gray-300"></i>
                        </div>
                        <p class="text-sm font-semibold text-slate-700">No requests yet</p>
                        <p class="text-xs text-gray-400 mt-1">New submissions will appear here.</p>
                    </div>
                    <?php else: ?>
                    <div id="recent-requests-list" class="divide-y divide-gray-50">
                        <?php foreach ($recentRequests as $req): ?>
                        <div class="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-gray-50/50">
                            <div class="min-w-0 flex-1">
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($req['citizen_name']) ?></p>
                                <p class="text-[11px] text-gray-400 mt-0.5">
                                    <?= htmlspecialchars(documentTypeLabel($req['document_type'])) ?>
                                    · <span class="font-mono text-blue-600"><?= htmlspecialchars($req['tracking_code']) ?></span>
                                    · <?= formatRecordDate(substr($req['submitted_at'], 0, 10)) ?>
                                </p>
                            </div>
                            <?= requestStatusBadge($req['status'], $req['rejection_reason'] ?? null) ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bg-white rounded-2xl border border-gray-100 dash-card overflow-hidden dash-panel-pair min-w-0">
                    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between">
                        <div>
                            <h2 class="font-bold text-sm text-slate-900">Recent Appointments</h2>
                            <p class="text-[10px] text-gray-400 mt-0.5">Latest standalone appointment bookings</p>
                        </div>
                        <a href="<?= htmlspecialchars(buildStaffOperationalUrl('appointment.php', ['date' => $todayDate, 'status' => 'all_appointments'])) ?>" class="text-blue-600 text-[10px] font-bold uppercase hover:underline">View all</a>
                    </div>
                    <?php if (empty($recentAppointments)): ?>
                    <div class="p-10 text-center">
                        <div class="bg-gray-50 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3">
                            <i data-lucide="calendar-plus" class="w-6 h-6 text-gray-300"></i>
                        </div>
                        <p class="text-sm font-semibold text-slate-700">No appointments yet</p>
                        <p class="text-xs text-gray-400 mt-1">New bookings will appear here.</p>
                    </div>
                    <?php else: ?>
                    <div id="recent-appointments-list" class="divide-y divide-gray-50">
                        <?php foreach ($recentAppointments as $ap): ?>
                        <div class="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-gray-50/50">
                            <div class="min-w-0 flex-1">
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($ap['citizen_name']) ?></p>
                                <p class="text-[11px] text-gray-400 mt-0.5">
                                    <?= htmlspecialchars($ap['service_type']) ?>
                                    · <span class="font-mono text-blue-600"><?= htmlspecialchars($ap['appointment_code']) ?></span>
                                    · <?= formatRecordDate(substr((string) ($ap['appointment_date'] ?? ''), 0, 10)) ?>
                                </p>
                            </div>
                            <?= $ap['status_badge_html'] ?? appointmentStatusBadge($ap['status'], $ap['rejection_reason'] ?? null) ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bg-white rounded-2xl border border-gray-100 dash-card overflow-hidden dash-panel-pair min-w-0">
                    <div class="px-5 py-4 border-b border-gray-50 flex items-center justify-between">
                        <div>
                            <h2 class="font-bold text-sm text-slate-900">My Recent Activity</h2>
                            <p class="text-[10px] text-gray-400 mt-0.5">Your recent actions in the portal</p>
                        </div>
                    </div>
                    <?php if (empty($activities)): ?>
                    <div class="p-10 text-center text-gray-400 text-xs">No activity recorded yet.</div>
                    <?php else: ?>
                    <div id="activity-feed-list" class="grid grid-cols-1 gap-3 p-4 max-h-[420px] xl:max-h-none overflow-y-auto">
                        <?php foreach ($activities as $act): ?>
                        <div class="flex items-start gap-3 p-3 rounded-xl bg-gray-50/80 border border-gray-100">
                            <span class="shrink-0 mt-0.5" aria-hidden="true">
                                <?= $act['staff_avatar_html'] ?? renderStaffAvatar(
                                    $act['staff_photo_path'] ?? null,
                                    (string) ($act['staff_display_name'] ?? (staffId() ?: 'Staff')),
                                    'w-9 h-9 text-xs'
                                ) ?>
                            </span>
                            <div class="min-w-0">
                                <p class="text-xs font-bold text-slate-800"><?= htmlspecialchars($act['action_display'] ?? activityLogDisplayAction((string) ($act['action'] ?? ''))) ?></p>
                                <?php if (!empty($act['details'])): ?>
                                <p class="text-[10px] text-gray-500 mt-0.5 line-clamp-2"><?= htmlspecialchars($act['details']) ?></p>
                                <?php endif; ?>
                                <p class="text-[10px] text-gray-400 mt-1"><?= formatTimeAgo($act['created_at']) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            </div>

            <?php endif; ?>

        </div>
    </main>

    <?= scriptTag('core/page-config.js') ?>
    <?php if ($isAdminUser && $adminAnalytics !== null): ?>
    <?= pageConfigJson($adminAnalytics['chartPayload'], 'analytics-config') ?>
    <?= scriptTag('admin/analytics.js') ?>
    <?= scriptTag('admin/admin-simple-calendar.js') ?>
    <?php else: ?>
    <?= pageConfigJson([
        'scheduleMonth'     => $scheduleMonth,
        'scheduleDate'      => $scheduleDate,
        'todayDate'         => $todayDate,
        'appointmentDates'  => $scheduleCalendar['dates'],
        'appointmentPage'   => buildStaffOperationalUrl('appointment.php'),
    ], 'dashboard-schedule-config') ?>
    <?= scriptTag('admin/dashboard.js') ?>
    <?php endif; ?>
    <?= lucideInitScript() ?>
</body>
</html>
