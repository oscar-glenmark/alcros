<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/printing.php';
require_once __DIR__ . '/includes/print_fill_controls.php';
require_once __DIR__ . '/includes/civil_record_schema.php';
require_once __DIR__ . '/includes/certification_print.php';
requireStaffLogin();
requirePageAccess('documents.php');

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$activePage = 'documents.php';
$pdo = getDB();
@set_time_limit(120);
try {
    ensurePrintTables($pdo);
} catch (Throwable $e) {
    // Continue if tables already exist.
}

$certificateType = (string) ($_GET['type'] ?? 'birth');
if (!in_array($certificateType, printCertificateTypes(), true)) {
    $certificateType = 'birth';
}
$documentKind = normalizePrintDocumentKind($_GET['kind'] ?? 'certificate');
$isCertification = $documentKind === 'certification';

if ($isCertification) {
    seedCertificationPrintTemplates($pdo);
}

$docQueryParams = static function (array $extra = []) use ($certificateType, $isCertification): array {
    $params = ['type' => $certificateType];
    if ($isCertification) {
        $params['kind'] = 'certification';
    }

    return array_merge($params, $extra);
};

$frontTemplate = getPrintTemplate($pdo, $certificateType, 'front', $documentKind);
$printError = null;
if (!$frontTemplate) {
    $printError = 'Print template not found for this document. Ask an administrator to set up print templates.';
} else {
    $fillEditorFields = printDocumentsFillEditorFields($pdo, $certificateType, $documentKind);
    if ($isCertification) {
        $certPaper = certificationPaperSize($certificateType);
        $paperW = (float) $certPaper['paper_width_mm'];
        $paperH = (float) $certPaper['paper_height_mm'];
    } else {
        $paperW = (float) ($frontTemplate['paper_width_mm'] ?? printOfficialPaperWidthMm());
        $paperH = (float) ($frontTemplate['paper_height_mm'] ?? printOfficialPaperHeightMm());
    }
}

$pageTitle = 'Documents';
$pageSubtitle = 'Blank certificate and certification forms for manual entry';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title><?= htmlspecialchars($pageTitle) ?> · ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= adminLayoutHeadStyles('print-certificate') ?>
    <?= adminPageStyles('print-calibration') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
</head>
<body class="flex min-h-screen print-page--<?= htmlspecialchars($certificateType) ?><?= $isCertification ? ' print-page--certification' : '' ?>">
<?php require __DIR__ . '/includes/admin_sidebar.php'; ?>
<main class="admin-main">
    <?php require __DIR__ . '/includes/admin_header.php'; ?>

    <div class="admin-content print-certificate-page">
        <?php if ($printError): ?>
            <div class="print-cert-alert print-cert-alert--error">
                <i data-lucide="alert-circle"></i>
                <div>
                    <strong>Cannot open document form</strong>
                    <p><?= htmlspecialchars($printError) ?></p>
                </div>
            </div>
        <?php else: ?>
            <div class="print-cal-toolbar no-print">
                <div class="print-cal-toolbar-top">
                    <div class="print-cal-cert-tabs" role="tablist" aria-label="Document kind">
                        <a href="<?= htmlspecialchars(buildAuthUrl('documents.php', ['type' => $certificateType])) ?>"
                           class="print-cal-cert-tab<?= !$isCertification ? ' is-active' : '' ?>">Certificate</a>
                        <a href="<?= htmlspecialchars(buildAuthUrl('documents.php', ['type' => $certificateType, 'kind' => 'certification'])) ?>"
                           class="print-cal-cert-tab<?= $isCertification ? ' is-active' : '' ?>">Certification</a>
                    </div>
                    <div class="print-cal-cert-tabs" role="tablist" aria-label="Document type">
                        <?php foreach (printCertificateTypes() as $type): ?>
                            <a href="<?= htmlspecialchars(buildAuthUrl('documents.php', $docQueryParams(['type' => $type]))) ?>"
                               class="print-cal-cert-tab<?= $certificateType === $type ? ' is-active' : '' ?>">
                                <?= htmlspecialchars(ucfirst($type)) ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <?php if (!$isCertification): ?>
            <section class="print-cert-options no-print" id="backPageOptions" hidden>
                <div class="print-cert-options__inner">
                    <h2 class="print-cert-section-title">Back Page Options</h2>
                    <div class="print-cert-checks">
                        <?php if ($certificateType === 'birth'): ?>
                            <label><input type="checkbox" id="optPaternity" checked> Paternity affidavit</label>
                            <label><input type="checkbox" id="optDelayedBirth"> Delayed birth affidavit</label>
                        <?php elseif ($certificateType === 'marriage'): ?>
                            <label><input type="checkbox" id="optDelayedMarriage" checked> Delayed marriage affidavit</label>
                        <?php elseif ($certificateType === 'death'): ?>
                            <label><input type="checkbox" id="optInfantSection" checked> Infant 0–7 days</label>
                            <label><input type="checkbox" id="optPostmortem"> Postmortem (autopsy)</label>
                            <label><input type="checkbox" id="optDelayedDeath"> Delayed death affidavit</label>
                        <?php endif; ?>
                    </div>
                </div>
                <p class="print-cert-hint print-cert-hint--compact">Affidavit sections fill only when checked. Signatures are never auto-generated.</p>
            </section>
            <?php else: ?>
            <section class="print-cert-options no-print">
                <div class="print-cert-options__inner">
                    <h2 class="print-cert-section-title">Print Options</h2>
                    <div class="print-cert-checks">
                        <label><input type="checkbox" id="optShowBackground" checked> Show background</label>
                    </div>
                </div>
                <p class="print-cert-hint print-cert-hint--compact">When checked, the form background is included in the preview and print. When unchecked, only the filled-in data is printed - load blank A4 certification paper.</p>
            </section>
            <?php endif; ?>
            <div class="print-cert-workspace">
            <section class="print-cert-fill no-print">
                <div class="print-cert-fill-chrome">
                    <div class="print-cert-fill-chrome__top">
                        <h2 class="print-cert-fill-chrome__title">Fill-in Data</h2>
                        <div class="print-cert-fill-chrome__actions">
                            <?php if (!$isCertification): ?>
                            <button type="button" class="print-cert-btn print-cert-btn--primary print-cert-fill-chrome__btn" id="addRecordFromDocument">Add to records</button>
                            <?php endif; ?>
                            <button type="button" class="print-cert-btn print-cert-btn--ghost print-cert-fill-chrome__btn" id="resetFillData">Clear all fields</button>
                        </div>
                    </div>
                    <?php if ($isCertification): ?>
                    <div class="print-cert-fill-chrome__body">
                        <p class="print-cert-hint print-cert-fill-chrome__hint">Type values manually. You can also click text directly in the preview on the right.</p>
                    </div>
                    <?php else: ?>
                    <div class="print-cert-fill-chrome__body">
                        <?php $primarySection = printFillPrimaryRequiredSectionLabel($certificateType); ?>
                        <p class="print-cert-hint print-cert-fill-chrome__hint"><strong><?= htmlspecialchars($primarySection) ?></strong> section must be complete to add a record (middle names optional). Other sections are optional.</p>
                    </div>
                    <?php endif; ?>
                    <?php if (!$isCertification): ?>
                    <div class="print-cert-fill-chrome__footer">
                        <div class="print-cert-fill-tabs print-cert-fill-tabs--page" role="tablist" aria-label="Fill-in page">
                            <button type="button" class="print-cert-fill-tab is-active" data-fill-tab="front" role="tab" aria-selected="true">Front page</button>
                            <button type="button" class="print-cert-fill-tab" data-fill-tab="back" role="tab" aria-selected="false">Back page</button>
                        </div>
                        <button type="button" class="print-cert-fill-tab print-cert-fill-tab--both print-cert-fill-chrome__both" id="previewViewBoth" data-preview-view="both">Both pages</button>
                    </div>
                    <?php endif; ?>
                </div>
                <?php
                $printFillGrouped = groupPrintFillFieldsForEntryForm($certificateType, $fillEditorFields);
                printFillSetDocumentWorkspaceContext($pdo, $certificateType);
                ?>
                <?php foreach ($isCertification ? ['front'] : ['front', 'back'] as $fillSide): ?>
                <div class="print-cert-fill-grid<?= $isCertification ? '' : ' print-cert-fill-grid--sectioned' ?>" id="fillFields<?= ucfirst($fillSide) ?>" data-fill-panel="<?= $fillSide ?>" role="tabpanel"<?= $fillSide === 'back' ? ' hidden' : '' ?>>
                    <?php if ($isCertification): ?>
                        <?php renderPrintFillWorkspaceClassicList($fillEditorFields, $fillSide); ?>
                    <?php else: ?>
                        <?php renderPrintFillGroupedSectionPanels($certificateType, $printFillGrouped, $fillSide, 'workspace'); ?>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
                <?php printFillEntryFormSetContext([]); ?>
            </section>

            <section class="print-cert-previews print-cert-previews--local"
                     data-preview-view="front"
                     data-paper-w="<?= htmlspecialchars((string) $paperW) ?>"
                     data-paper-h="<?= htmlspecialchars((string) $paperH) ?>">
                <div class="print-cert-preview-block" data-preview-side="front">
                    <div class="print-cert-preview-head">
                        <h2>Front Preview</h2>
                        <div class="print-cert-preview-actions no-print">
                            <button type="button" class="print-cert-btn print-cert-btn--ghost" data-print-side="front" data-test="1">Test Print Front</button>
                            <button type="button" class="print-cert-btn print-cert-btn--primary" data-print-side="front">Print Front</button>
                        </div>
                    </div>
                    <div class="print-cert-preview-viewport" data-preview-viewport="front">
                        <div class="print-cert-preview-scaler" data-preview-scaler="front">
                            <iframe id="previewFront" class="print-cert-frame print-cert-frame--local" title="Front preview" scrolling="no"></iframe>
                        </div>
                    </div>
                </div>
                <?php if (!$isCertification): ?>
                <div class="print-cert-preview-block" data-preview-side="back">
                    <div class="print-cert-preview-head">
                        <h2>Back Preview</h2>
                        <div class="print-cert-preview-actions no-print">
                            <button type="button" class="print-cert-btn print-cert-btn--ghost" data-print-side="back" data-test="1">Test Print Back</button>
                            <button type="button" class="print-cert-btn print-cert-btn--primary" data-print-side="back">Print Back</button>
                        </div>
                    </div>
                    <div class="print-cert-preview-viewport" data-preview-viewport="back">
                        <div class="print-cert-preview-scaler" data-preview-scaler="back">
                            <iframe id="previewBack" class="print-cert-frame print-cert-frame--local" title="Back preview" scrolling="no"></iframe>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </section>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php if (!$printError): ?>
<?= csrfField() ?>
<?= pageConfigJson([
    'manualMode' => true,
    'certificateType' => $certificateType,
    'documentKind' => $documentKind,
    'createRecordApiUrl' => !$isCertification ? buildAuthUrl('api/documents.php') : '',
    'locationsApiUrl' => buildAuthUrl('api/locations.php'),
    'printAuthUrl' => buildAuthUrl('print_render.php'),
    'apiPrintUrl' => buildAuthUrl('api/print.php'),
    'paperWidthMm' => $paperW,
    'paperHeightMm' => $paperH,
    'calibrationRev' => printCalibrationRevision(),
    'initialFillValues' => array_column($fillEditorFields, 'value', 'field_name'),
    'calibrationUrl' => buildAuthUrl('print_calibration.php', $docQueryParams(['page' => 'front'])),
    'manualEntryRequiredFields' => !$isCertification ? civilRecordManualEntryRequiredFieldsForJs() : [],
]) ?>
<?= scriptTag('admin/print-fit-text.js') ?>
<?= scriptTag('core/page-config.js') ?>
<?= scriptTag('core/cascading-location.js') ?>
<?= scriptTag('admin/civil-record-entry-validation.js') ?>
<?= scriptTag('admin/print-certificate.js') ?>
<?php endif; ?>
<?= lucideInitScript() ?>
</body>
</html>
