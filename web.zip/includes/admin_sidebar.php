<?php
/** @var string $activePage current page filename e.g. dashboard.php */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/scripts.php';
require_once __DIR__ . '/lucide_icons.php';

if (!isAdmin()) {
    try {
        runReminderSchedulerIfDue(getDB());
    } catch (Throwable $e) {
        // Non-fatal when reminders cannot run.
    }
}

$activePage = $activePage ?? basename($_SERVER['PHP_SELF']);

function sidebarLink(string $page, string $label, string $icon, string $active, bool $liveBadge = false, ?string $countBadgeId = null, array $query = []): string
{
    $isActive = ($page === $active);
    $class = $isActive ? 'active-nav' : 'sidebar-item';
    $badge = $liveBadge
        ? '<span class="bg-white text-blue-600 text-[10px] px-1.5 py-0.5 rounded font-bold">LIVE</span>'
        : '';
    $countBadge = $countBadgeId
        ? '<span id="' . htmlspecialchars($countBadgeId) . '" class="hidden ml-auto min-w-[18px] h-5 px-1.5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center leading-none">0</span>'
        : '';
    $hasTrailing = $liveBadge || $countBadgeId;
    $justify = $hasTrailing ? ' justify-between' : '';
    $href = buildAuthUrl($page, $query);

    $iconHtml = lucideSvg($icon, 'admin-sidebar-icon w-4 h-4 mr-3 shrink-0 inline-block align-middle');

    if ($liveBadge) {
        $inner = '<div class="flex items-center min-w-0 flex-1">' . $iconHtml . '<span class="sidebar-link-label">' . htmlspecialchars($label) . '</span></div>' . $badge;
    } elseif ($countBadgeId) {
        $inner = '<div class="flex items-center min-w-0 flex-1">' . $iconHtml . '<span class="sidebar-link-label">' . htmlspecialchars($label) . '</span></div>' . $countBadge;
    } else {
        $inner = $iconHtml . '<span class="sidebar-link-label">' . htmlspecialchars($label) . '</span>';
    }

    return '<a href="' . htmlspecialchars($href) . '" data-sidebar-tip="' . htmlspecialchars($label) . '" class="' . $class . ' flex items-center min-w-0 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-150' . $justify . '">'
        . $inner
        . '</a>';
}

function sidebarSectionLabel(string $label): string
{
    return '<p class="sidebar-section-label">' . htmlspecialchars($label) . '</p>';
}

function mobileTabLink(
    string $page,
    string $label,
    string $icon,
    string $active,
    ?string $badgeId = null,
    array $query = [],
    ?string $title = null
): string {
    $isActive = ($page === $active);
    $class = 'admin-mobile-tab' . ($isActive ? ' is-active' : '');
    $href = buildAuthUrl($page, $query);
    $badge = $badgeId
        ? '<span id="' . htmlspecialchars($badgeId) . '" class="admin-mobile-tab__badge hidden" aria-hidden="true">0</span>'
        : '';
    $iconHtml = lucideSvg($icon, 'pointer-events-none');
    $titleAttr = $title !== null && $title !== ''
        ? ' title="' . htmlspecialchars($title) . '" aria-label="' . htmlspecialchars($title) . '"'
        : '';

    return '<a href="' . htmlspecialchars($href) . '" class="' . $class . '" data-mobile-tab="1"' . $titleAttr . '>'
        . $iconHtml
        . '<span>' . htmlspecialchars($label) . '</span>'
        . $badge
        . '</a>';
}

function mobileMoreMenuLink(
    string $page,
    string $label,
    string $icon,
    string $active,
    ?string $badgeId = null,
    bool $liveBadge = false
): string {
    $isActive = ($page === $active);
    $class = 'admin-mobile-more-item' . ($isActive ? ' is-active' : '');
    $href = buildAuthUrl($page);
    $badge = $badgeId
        ? '<span id="' . htmlspecialchars($badgeId) . '" class="admin-mobile-more-item__badge hidden" aria-hidden="true">0</span>'
        : '';
    $live = $liveBadge
        ? '<span class="admin-mobile-more-item__live">LIVE</span>'
        : '';
    $iconHtml = lucideSvg($icon, 'admin-mobile-more-item__icon pointer-events-none');

    return '<a href="' . htmlspecialchars($href) . '" class="' . $class . '" role="menuitem">'
        . $iconHtml
        . '<span class="admin-mobile-more-item__label">' . htmlspecialchars($label) . '</span>'
        . $live
        . $badge
        . '</a>';
}

function mobileMoreSectionLabel(string $label): string
{
    return '<p class="admin-mobile-more-section">' . htmlspecialchars($label) . '</p>';
}

$mobilePrimaryPages = isAdmin()
    ? ['dashboard.php', 'records.php', 'analytics.php', 'report.php', 'notifications.php']
    : ['dashboard.php', 'manage_request.php', 'appointment.php', 'live-queue.php', 'notifications.php'];
$mobileMoreActive = !in_array($activePage, $mobilePrimaryPages, true);

?>
<script>(function(){try{document.body.classList.add('admin-portal');if(sessionStorage.getItem('admin_sidebar_minimized')==='1'){document.body.classList.add('admin-sidebar-minimized');}}catch(e){}})();</script>
<aside class="admin-sidebar" aria-label="Admin navigation">
    <div class="admin-sidebar-brand p-4 sm:p-5 flex items-start justify-between gap-3">
        <a href="<?= htmlspecialchars(buildAuthUrl('dashboard.php')) ?>" data-sidebar-tip="Dashboard" class="flex items-center gap-3 min-w-0 flex-1 transition hover:opacity-90">
            <?= alcrosFaviconImg(52, 'gov-brand-logo shrink-0') ?>
            <div class="min-w-0">
                <div class="gov-brand-title">Municipality of Aloran Misamis Occidental</div>
                <div class="gov-brand-subtitle">ALCROS</div>
            </div>
        </a>
    </div>
    <nav class="admin-sidebar-nav px-4 py-4 space-y-1" id="sidebarNavScroll">
        <?= sidebarSectionLabel('Operations') ?>
        <?= sidebarLink('dashboard.php', 'Dashboard', 'layout-dashboard', $activePage) ?>
        <?= sidebarLink('notifications.php', staffPortalInboxLabel(), 'bell', $activePage, false, 'sidebar-notif-badge') ?>
        <?php if (!isAdmin()): ?>
        <?= sidebarLink('manage_request.php', 'Manage Requests', 'file-text', $activePage, false, 'sidebar-request-badge') ?>
        <?= sidebarLink('appointment.php', 'Manage Appointments', 'calendar', $activePage, false, 'sidebar-appt-badge') ?>
        <?php endif; ?>
        <?= sidebarLink('records.php', 'Records', 'book-open', $activePage) ?>
        <?php if (isAdmin()): ?>
        <?= sidebarLink('analytics.php', 'Analytics', 'trending-up', $activePage) ?>
        <?= sidebarLink('report.php', 'Reports', 'bar-chart-2', $activePage) ?>
        <?php endif; ?>
        <?php if (!isAdmin()): ?>
        <?= sidebarLink('live-queue.php', 'Manage live queue', 'users', $activePage, true) ?>
        <?php endif; ?>
        <?php if (!isAdmin()): ?>
        <?= sidebarLink('documents.php', 'Documents', 'files', $activePage) ?>
        <?php endif; ?>
        <?php if (isAdmin()): ?>
        <?= sidebarSectionLabel('Administration') ?>
        <?= sidebarLink('print_calibration.php', 'Print calibration', 'crosshair', $activePage) ?>
        <?= sidebarLink('activity-log.php', 'Activity log', 'scroll-text', $activePage) ?>
        <?= sidebarLink('system_settings.php', 'Settings', 'settings', $activePage) ?>
        <?php else: ?>
        <?= sidebarSectionLabel('Account') ?>
        <?= sidebarLink('system_settings.php', 'Settings', 'settings', $activePage) ?>
        <?php endif; ?>
    </nav>
</aside>

<div class="admin-mobile-shell no-print">
    <div id="adminMobileMoreBackdrop" class="admin-mobile-more-backdrop hidden" aria-hidden="true"></div>
    <div id="adminMobileMoreDropup" class="admin-mobile-more-dropup hidden" role="menu" aria-label="More navigation">
        <?php if (isAdmin()): ?>
            <?= mobileMoreSectionLabel('Administration') ?>
            <?= mobileMoreMenuLink('print_calibration.php', 'Print calibration', 'crosshair', $activePage) ?>
            <?= mobileMoreMenuLink('activity-log.php', 'Activity log', 'scroll-text', $activePage) ?>
            <?= mobileMoreMenuLink('system_settings.php', 'Settings', 'settings', $activePage) ?>
        <?php else: ?>
            <?= mobileMoreSectionLabel('Operations') ?>
            <?= mobileMoreMenuLink('records.php', 'Records', 'book-open', $activePage) ?>
            <?= mobileMoreMenuLink('documents.php', 'Documents', 'files', $activePage) ?>
            <?= mobileMoreSectionLabel('Account') ?>
            <?= mobileMoreMenuLink('system_settings.php', 'Settings', 'settings', $activePage) ?>
        <?php endif; ?>
    </div>
    <nav class="admin-mobile-tabbar<?= isAdmin() ? ' admin-mobile-tabbar--admin' : ' admin-mobile-tabbar--staff' ?>" aria-label="Quick navigation">
        <?php if (isAdmin()): ?>
            <?= mobileTabLink('dashboard.php', 'Home', 'layout-dashboard', $activePage) ?>
            <?= mobileTabLink('records.php', 'Records', 'book-open', $activePage) ?>
            <?= mobileTabLink('analytics.php', 'Analytics', 'trending-up', $activePage) ?>
            <?= mobileTabLink('report.php', 'Reports', 'bar-chart-2', $activePage) ?>
            <?= mobileTabLink('notifications.php', 'Alerts', 'bell', $activePage, 'mobile-tab-notif-badge', [], staffPortalInboxLabel()) ?>
        <?php else: ?>
            <?= mobileTabLink('dashboard.php', 'Home', 'layout-dashboard', $activePage) ?>
            <?= mobileTabLink('manage_request.php', 'Requests', 'file-text', $activePage, 'mobile-tab-request-badge') ?>
            <?= mobileTabLink('appointment.php', 'Appts', 'calendar', $activePage, 'mobile-tab-appt-badge', [], 'Manage Appointments') ?>
            <?= mobileTabLink('live-queue.php', 'Queue', 'users', $activePage) ?>
            <?= mobileTabLink('notifications.php', 'Inbox', 'bell', $activePage, 'mobile-tab-notif-badge') ?>
        <?php endif; ?>
        <button
            type="button"
            class="admin-mobile-tab<?= $mobileMoreActive ? ' is-active' : '' ?>"
            id="adminMobileMoreTab"
            aria-label="More pages"
            aria-expanded="false"
            aria-controls="adminMobileMoreDropup"
            aria-haspopup="menu"
        >
            <?= lucideSvg('ellipsis', 'pointer-events-none') ?>
            <span>More</span>
        </button>
    </nav>
</div>

<div id="logoutConfirmModal" class="alcros-confirm-modal alcros-logout-modal is-hidden" role="dialog" aria-modal="true" aria-labelledby="logoutConfirmTitle">
    <div class="alcros-confirm-modal__panel">
        <button type="button" class="alcros-modal-close" id="logoutCloseBtn" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
        <div class="alcros-confirm-modal__hero">
            <div class="alcros-confirm-modal__icon-wrap alcros-logout-modal__icon-wrap" aria-hidden="true">
                <div class="alcros-confirm-modal__icon alcros-logout-modal__icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                </div>
            </div>
            <p class="alcros-modal-badge alcros-modal-badge--logout">Sign out</p>
            <h3 id="logoutConfirmTitle" class="alcros-confirm-modal__title">Confirm Logout</h3>
            <p class="alcros-confirm-modal__message">Are you sure you want to logout?</p>
        </div>
        <div class="alcros-confirm-modal__actions">
            <button type="button" id="logoutCancelBtn" class="alcros-confirm-modal__btn alcros-confirm-modal__btn--cancel">Cancel</button>
            <a href="<?= htmlspecialchars(buildAuthUrl('logout.php')) ?>" id="logoutConfirmBtn" class="alcros-confirm-modal__btn alcros-confirm-modal__btn--danger">Logout</a>
        </div>
    </div>
</div>

<div class="hidden" aria-hidden="true" id="alcros-staff-csrf"><?= csrfField() ?></div>
<?php
$staffSyncToken = staffAuthToken();
if ($staffSyncToken !== null && $staffSyncToken !== '') {
    echo pageConfigJson([
        'staffAuthToken' => $staffSyncToken,
        'staffId'        => staffId(),
        'sessionStaffId' => (string) (getStaffFromSession()['staff_id'] ?? ''),
    ], 'alcros-staff-auth-sync');
}
echo scriptTag('core/page-config.js');
?>
<?= adminCoreScripts() ?>
