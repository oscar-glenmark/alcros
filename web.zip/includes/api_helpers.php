<?php

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/queue_announcements.php';

function apiJsonResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    if (!isset($data['ok'])) {
        $data['ok'] = true;
    }
    if (!isset($data['updated_at'])) {
        $data['updated_at'] = date('c');
    }
    echo json_encode($data);
    exit;
}

function apiError(string $message, int $code = 400): void
{
    apiJsonResponse(['ok' => false, 'error' => $message], $code);
}

function queuePurposeLabels(): array
{
    $labels = [];
    foreach (queuePurposeConfig() as $key => $cfg) {
        $labels[$key] = $cfg['label'];
    }
    return $labels;
}

function fetchTodayQueueActiveRows(PDO $pdo): array
{
    static $cache = null;
    static $cachePdo = null;
    if ($cache !== null && $cachePdo === $pdo) {
        return $cache;
    }

    ensureQueuePerformanceIndexes($pdo);
    $stmt = $pdo->query(
        "SELECT id, ticket_number, purpose, status, window_number, first_name, middle_name, last_name, reference_code, created_at, called_at
         FROM queue_tickets
         WHERE created_at >= CURDATE() AND created_at < CURDATE() + INTERVAL 1 DAY
           AND status IN ('waiting', 'serving')
         ORDER BY FIELD(purpose,'walk_in','appointment','document_claim'), FIELD(status,'serving','waiting'), created_at ASC"
    );
    $cache = enrichCitizenNameRows($stmt ? $stmt->fetchAll() : []);
    $cachePdo = $pdo;

    return $cache;
}

function queueStateRevision(array $rows): string
{
    $maxTs = 0;
    $active = 0;
    foreach ($rows as $row) {
        if (($row['status'] ?? '') === 'waiting' || ($row['status'] ?? '') === 'serving') {
            $active++;
        }
        foreach (['called_at', 'created_at'] as $column) {
            if (empty($row[$column])) {
                continue;
            }
            $ts = strtotime((string) $row[$column]);
            if ($ts !== false && $ts > $maxTs) {
                $maxTs = $ts;
            }
        }
    }

    return $maxTs . ':' . $active;
}

function buildQueueGroupedFromRows(array $rows): array
{
    $grouped = [];
    foreach (array_keys(queuePurposeConfig()) as $purpose) {
        $grouped[$purpose] = [
            'serving' => null,
            'waiting' => [],
        ];
    }

    foreach ($rows as $row) {
        $purpose = (string) ($row['purpose'] ?? '');
        if (!isset($grouped[$purpose])) {
            continue;
        }
        if (($row['status'] ?? '') === 'serving' && $grouped[$purpose]['serving'] === null) {
            $grouped[$purpose]['serving'] = $row;
        } elseif (($row['status'] ?? '') === 'waiting') {
            $grouped[$purpose]['waiting'][] = $row;
        }
    }

    return $grouped;
}

function fetchQueueTicketsGrouped(PDO $pdo): array
{
    return buildQueueGroupedFromRows(fetchTodayQueueActiveRows($pdo));
}

function fetchPublicQueueDisplay(PDO $pdo): array
{
    $rows = fetchTodayQueueActiveRows($pdo);
    $grouped = buildQueueGroupedFromRows($rows);
    $announcement = queueFetchAnnouncementSnapshot($pdo);

    $serving = null;
    if (!empty($announcement['active'])) {
        $active = $announcement['active'];
        $serving = [
            'ticket_number'   => $active['ticket_number'],
            'window_number'   => $active['window_number'],
            'purpose'         => $active['purpose'],
            'called_at'       => $active['started_at'] ?: $active['requested_at'],
            'announcement_id' => $active['id'],
        ];
    } else {
        $nextPending = queueFetchFirstPendingAnnouncement($pdo);
        if ($nextPending) {
            $serving = [
                'ticket_number'   => $nextPending['ticket_number'],
                'window_number'   => $nextPending['window_number'],
                'purpose'         => $nextPending['purpose'],
                'called_at'       => $nextPending['requested_at'],
                'announcement_id' => $nextPending['id'],
            ];
        } else {
            foreach ($rows as $row) {
                if (($row['status'] ?? '') !== 'serving') {
                    continue;
                }
                if ($serving === null || (string) ($row['called_at'] ?? '') > (string) ($serving['called_at'] ?? '')) {
                    $serving = $row;
                }
            }
            if ($serving) {
                $serving = [
                    'ticket_number'   => $serving['ticket_number'],
                    'window_number'   => $serving['window_number'],
                    'purpose'         => $serving['purpose'],
                    'called_at'       => $serving['called_at'] ?? null,
                    'announcement_id' => null,
                ];
            }
        }
    }

    $tables = [];
    foreach (queuePurposeConfig() as $purpose => $cfg) {
        $slot = $grouped[$purpose];
        $tables[$purpose] = [
            'table'   => $cfg['table'],
            'label'   => $cfg['label'],
            'serving' => $slot['serving'] ? $slot['serving']['ticket_number'] : null,
            'waiting' => array_column($slot['waiting'], 'ticket_number'),
        ];
    }

    $waiting = [];
    foreach ($rows as $row) {
        if (($row['status'] ?? '') === 'waiting') {
            $waiting[] = $row['ticket_number'];
            if (count($waiting) >= 8) {
                break;
            }
        }
    }

    return [
        'serving' => $serving ? [
            'ticket_number'   => $serving['ticket_number'],
            'window_number'   => $serving['window_number'],
            'purpose'         => $serving['purpose'],
            'called_at'       => $serving['called_at'] ?? null,
            'announcement_id' => $serving['announcement_id'] ?? null,
        ] : null,
        'waiting' => $waiting,
        'tables'  => $tables,
        'announcement' => $announcement,
    ];
}

function fetchQueueSnapshot(PDO $pdo, string $mode = 'full'): array
{
    $rows = fetchTodayQueueActiveRows($pdo);
    $revision = queueStateRevision($rows) . '|' . queueAnnouncementRevision($pdo);
    $payload = [
        'revision' => $revision,
    ];

    if ($mode === 'display') {
        $payload['display'] = fetchPublicQueueDisplay($pdo);
        return $payload;
    }

    $payload['grouped'] = buildQueueGroupedFromRows($rows);
    $payload['tables'] = queuePurposeConfig();

    return $payload;
}

function fetchDashboardStats(PDO $pdo, bool $isAdmin, string $staffId): array
{
    $todayDate = alcrosTodayDate();
    $reqActive = documentRequestActiveSql();
    $stats = [
        'pending_count'   => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status IN ('pending','verified')")->fetchColumn(),
        'queue_count'     => (int) $pdo->query("SELECT COUNT(*) FROM queue_tickets WHERE status = 'waiting' AND DATE(created_at) = CURDATE()")->fetchColumn(),
        'today_appts'     => countTodaySpecialAppointments($pdo),
        'pipeline_count'  => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'verified'")->fetchColumn(),
        'ready_count'     => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'ready'")->fetchColumn(),
        'completed_today' => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$reqActive} AND status = 'completed' AND DATE(updated_at) = CURDATE()")->fetchColumn(),
    ];

    $recentRequests = enrichCitizenNameRows($pdo->query(
        "SELECT tracking_code, first_name, middle_name, last_name, document_type, status, submitted_at
         FROM document_requests WHERE {$reqActive} ORDER BY submitted_at DESC LIMIT 5"
    )->fetchAll());

    if ($isAdmin) {
        $activities = $pdo->query(
            "SELECT staff_id, action, details, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 4"
        )->fetchAll();
    } else {
        $stmt = $pdo->prepare(
            "SELECT staff_id, action, details, created_at FROM activity_logs WHERE staff_id = ? ORDER BY created_at DESC LIMIT 4"
        );
        $stmt->execute([$staffId]);
        $activities = $stmt->fetchAll();
    }
    $activities = enrichActivityLogsForDisplay($pdo, $activities, 'w-9 h-9 text-xs');

    $todayAppts = enrichCitizenNameRows($pdo->query(
        "SELECT first_name, middle_name, last_name, appointment_time, service_type, status FROM appointments
         WHERE deleted_at IS NULL AND appointment_date = CURDATE() AND status NOT IN ('cancelled', 'no_show')
         ORDER BY appointment_time ASC LIMIT 8"
    )->fetchAll());

    $recentAppointments = $isAdmin ? [] : fetchRecentStandaloneAppointments($pdo, 6);

    return [
        'stats'               => $stats,
        'recent_requests'     => $recentRequests,
        'recent_appointments' => $recentAppointments,
        'activities'          => $activities,
        'today_appts'         => $todayAppts,
        'incoming_appts'      => fetchIncomingAppointments($pdo, 8),
        'incoming_date'       => incomingAppointmentsDate(),
        'today_date'          => $todayDate,
    ];
}

function fetchScheduleDatesInMonth(PDO $pdo, string $yearMonth): array
{
    if (!preg_match('/^\d{4}-\d{2}$/', $yearMonth)) {
        $yearMonth = date('Y-m');
    }

    $start = $yearMonth . '-01';
    $end = date('Y-m-t', strtotime($start));
    $buckets = [];

    $stmt = $pdo->prepare(
        "SELECT a.appointment_date, a.status, dr.status AS request_status
         FROM appointments a
         LEFT JOIN document_requests dr ON dr.tracking_code = a.tracking_code AND dr.deleted_at IS NULL
         WHERE a.appointment_date BETWEEN ? AND ?
           AND " . scheduleCalendarAppointmentSql('a') . "
           AND a.deleted_at IS NULL"
    );
    $stmt->execute([$start, $end]);
    foreach ($stmt->fetchAll() as $row) {
        $date = substr((string) ($row['appointment_date'] ?? ''), 0, 10);
        $tone = scheduleVisitCalendarToneForAppointment($row);
        if ($date === '' || $tone === null) {
            continue;
        }
        if (!isset($buckets[$date])) {
            $buckets[$date] = ['awaiting' => 0, 'confirmed' => 0, 'completed' => 0];
        }
        $buckets[$date][$tone]++;
    }

    $stmt = $pdo->prepare(
        "SELECT dr.appointment_date, dr.status
         FROM document_requests dr
         WHERE dr.appointment_date BETWEEN ? AND ?
           AND dr.appointment_time IS NOT NULL
           AND dr.appointment_time != ''
           AND " . documentRequestHoldsVisitSlotSql('dr') . "
           "
    );
    $stmt->execute([$start, $end]);
    foreach ($stmt->fetchAll() as $row) {
        $date = substr((string) ($row['appointment_date'] ?? ''), 0, 10);
        $tone = scheduleVisitCalendarToneForRequest($row);
        if ($date === '' || $tone === null) {
            continue;
        }
        if (!isset($buckets[$date])) {
            $buckets[$date] = ['awaiting' => 0, 'confirmed' => 0, 'completed' => 0];
        }
        $buckets[$date][$tone]++;
    }

    return finalizeScheduleCalendarDateMarkers($buckets);
}

function scheduleVisitManageRequestStatus(array $row): string
{
    $raw = (string) ($row['request_status'] ?? '');
    if ($raw === '') {
        return 'all_requests';
    }

    return match (normalizeRequestStatus($raw)) {
        'ready'     => 'ready',
        'completed' => 'completed',
        'rejected'  => 'rejected',
        'pending'   => 'pending',
        default     => 'all_requests',
    };
}

function scheduleVisitAppointmentStatus(array $row): string
{
    $raw = (string) ($row['appointment_status'] ?? $row['status'] ?? 'scheduled');

    return match ($raw) {
        'scheduled' => 'scheduled',
        'confirmed' => 'confirmed',
        'completed' => 'completed',
        'no_show'   => 'no_show',
        'cancelled' => 'cancelled',
        default     => 'all_appointments',
    };
}

function enrichScheduleVisitRow(array $row): array
{
    if (!empty($row['tracking_code']) || ($row['source'] ?? '') === 'document_request') {
        $row['schedule_kind'] = 'certificate';
        $row['appointment_status'] = (string) ($row['status'] ?? 'scheduled');
        if (!empty($row['request_status'])) {
            $row['request_status'] = normalizeRequestStatus((string) $row['request_status']);
        } elseif ($row['appointment_status'] === 'confirmed') {
            $row['request_status'] = 'ready';
        } else {
            $row['request_status'] = 'pending';
        }
        $row['service_type'] = trim(appointmentServiceLabel((string) ($row['service_type'] ?? '')));
        if ($row['service_type'] === '') {
            $row['service_type'] = 'Certificate';
        }
        if (!str_contains($row['service_type'], 'Pickup')) {
            $row['service_type'] .= ' · Pickup';
        }
        if (!empty($row['request_status'])) {
            $row['status'] = requestStatusLabel(
                normalizeRequestStatus((string) $row['request_status']),
                $row['request_rejection_reason'] ?? null
            );
        } else {
            $row['status'] = appointmentDisplayStatusLabel($row);
        }
    } else {
        $row['schedule_kind'] = 'appointment';
        $row['appointment_status'] = (string) ($row['status'] ?? 'scheduled');
        $row['service_type'] = appointmentServiceLabel((string) ($row['service_type'] ?? ''));
        $row['status'] = appointmentStatusLabel($row['appointment_status'], $row['rejection_reason'] ?? null);
    }

    return $row;
}

function scheduleVisitLinkParams(array $row, string $scheduleDate): array
{
    if (($row['schedule_kind'] ?? '') === 'certificate' || !empty($row['tracking_code'])) {
        $code = trim((string) ($row['tracking_code'] ?? ''));
        if ($code !== '') {
            return ['manage_request.php', [
                'q'      => $code,
                'status' => scheduleVisitManageRequestStatus($row),
            ]];
        }
    }

    $code = trim((string) ($row['appointment_code'] ?? ''));
    $date = (string) ($row['appointment_date'] ?? $scheduleDate);
    $query = [
        'date'   => $date,
        'status' => scheduleVisitAppointmentStatus($row),
    ];
    if ($code !== '') {
        $query['q'] = $code;
    }

    return ['appointment.php', $query];
}

function scheduleVisitHref(array $row, string $scheduleDate): string
{
    [$path, $query] = scheduleVisitLinkParams($row, $scheduleDate);

    return $path . '?' . http_build_query($query);
}

function attachScheduleVisitMeta(array $row, string $scheduleDate): array
{
    [$path, $query] = scheduleVisitLinkParams($row, $scheduleDate);
    if (function_exists('resolveStaffOperationalNav')) {
        [$path, $query] = resolveStaffOperationalNav($path, $query);
    }
    $row['href'] = $path . '?' . http_build_query($query);

    return $row;
}

function staffOperationalNotificationHref(string $href): string
{
    if (!function_exists('isAdmin') || !isAdmin()) {
        return $href;
    }

    $path = strtok($href, '?') ?: $href;
    if (function_exists('isStaffOperationalPage') && isStaffOperationalPage($path)) {
        [$reportPath, $query] = staffOperationalReportTarget($path);

        return $reportPath . ($query !== [] ? '?' . http_build_query($query) : '');
    }

    return $href;
}

/** Staff bell links - open the filtered Manage Requests / Appointments view for each alert type. */
function staffPortalNotificationHref(string $type, array $context = []): string
{
    $page = 'dashboard.php';
    $query = [];

    switch ($type) {
        case 'pending_request':
            $page = 'manage_request.php';
            $query['status'] = 'pending';
            break;
        case 'ready_pickup':
            $page = 'manage_request.php';
            $query['status'] = 'ready';
            break;
        case 'queue':
            $page = 'live-queue.php';
            break;
        case 'appointment':
            $page = 'appointment.php';
            $date = (string) ($context['appointment_date'] ?? '');
            if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                $date = date('Y-m-d');
            }
            $query['date'] = $date;
            $apptStatus = strtolower(trim((string) ($context['appointment_status'] ?? 'scheduled')));
            $query['status'] = $apptStatus === 'confirmed' ? 'confirmed' : 'scheduled';
            break;
        default:
            $fallback = trim((string) ($context['href'] ?? ''));
            if ($fallback !== '') {
                return staffOperationalNotificationHref($fallback);
            }
            if (function_exists('buildAuthUrl')) {
                return buildAuthUrl('dashboard.php');
            }

            return 'dashboard.php';
    }

    $tracking = trim((string) ($context['tracking_code'] ?? ''));
    if ($tracking !== '' && in_array($type, ['pending_request', 'ready_pickup'], true)) {
        $query['q'] = $tracking;
    }

    $apptCode = trim((string) ($context['appointment_code'] ?? ''));
    if ($apptCode !== '' && $type === 'appointment') {
        $query['q'] = $apptCode;
    }

    if (function_exists('buildStaffOperationalUrl')) {
        return buildStaffOperationalUrl($page, $query);
    }

    $relative = $page . ($query !== [] ? '?' . http_build_query($query) : '');

    return function_exists('buildAuthUrl')
        ? buildAuthUrl($page, $query)
        : staffOperationalNotificationHref($relative);
}

function staffPortalNotificationHrefForItem(array $item): string
{
    $type = (string) ($item['type'] ?? '');
    if ($type === 'system') {
        $href = trim((string) ($item['href'] ?? ''));

        return $href !== ''
            ? staffOperationalNotificationHref($href)
            : (function_exists('buildAuthUrl') ? buildAuthUrl('dashboard.php') : 'dashboard.php');
    }

    return staffPortalNotificationHref($type, [
        'tracking_code'      => (string) ($item['detail'] ?? ''),
        'appointment_date'   => (string) ($item['appointment_date'] ?? ''),
        'appointment_code'   => (string) ($item['detail'] ?? ''),
        'appointment_status' => (string) ($item['appointment_status'] ?? ''),
        'href'               => (string) ($item['href'] ?? ''),
    ]);
}

/** Clear labels for bell / Notifications page (Staff vs Administrator). */
function enrichStaffPortalNotification(array $item): array
{
    $type = (string) ($item['type'] ?? '');
    $isAdmin = function_exists('isAdmin') && isAdmin();

    if (!$isAdmin) {
        $item['href'] = staffPortalNotificationHrefForItem($item);
    }

    if ($isAdmin) {
        $item['link_label'] = match ($type) {
            'pending_request' => 'View in Reports → Requests',
            'ready_pickup'    => 'View in Reports → Requests',
            'queue'           => 'View in Reports → Queue',
            'appointment'     => 'View in Reports → Appointments',
            'system'          => 'Open Settings or Activity log',
            default           => 'View in Reports',
        };
        $item['role_note'] = match ($type) {
            'pending_request' => 'Not processed yet - Staff must review this in Manage Requests.',
            'ready_pickup'    => 'Ready for pickup - Staff completes handoff in Manage Requests.',
            'queue'           => 'Still waiting - Staff call the next ticket in Live queue.',
            'appointment'     => 'Staff update appointment status when the citizen arrives.',
            'system'          => 'Administrator action may be required in Settings.',
            default           => 'Staff handle day-to-day processing; you can monitor in Reports.',
        };

        if ($type === 'pending_request') {
            $item['title'] = 'Pending document request';
            $item['detail'] = trim(($item['detail'] ?? '') . ' · Awaiting staff action');
        } elseif ($type === 'ready_pickup') {
            $item['title'] = 'Document ready for pickup';
            $item['detail'] = trim(($item['detail'] ?? '') . ' · Awaiting citizen handoff');
        } elseif ($type === 'queue') {
            $item['title'] = 'Citizens waiting in line';
            $item['detail'] = 'No staff action yet today until someone is called';
        } elseif ($type === 'appointment') {
            $item['detail'] = trim(($item['detail'] ?? '') . ' · Upcoming or newly booked');
        }
    } else {
        $item['link_label'] = match ($type) {
            'pending_request' => 'Open Manage Requests →',
            'ready_pickup'    => 'Open Manage Requests →',
            'queue'           => 'Open Live queue →',
            'appointment'     => 'Open Appointments →',
            'system'          => 'View details →',
            default           => 'Open →',
        };
        $item['role_note'] = '';
    }

    return $item;
}

function fetchScheduleVisits(
    PDO $pdo,
    string $date,
    int $limit = 8,
    bool $upcomingOnly = false,
    bool $confirmedIncomingOnly = false
): array {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $date = date('Y-m-d');
    }

    $rows = [];
    if ($confirmedIncomingOnly) {
        $appointmentFilter = scheduleIncomingAppointmentSql('a');
    } else {
        $appointmentFilter = $upcomingOnly ? scheduleVisitAppointmentSql('a') : scheduleCalendarAppointmentSql('a');
    }

    $stmt = $pdo->prepare(
        "SELECT a.appointment_code, a.appointment_date, a.first_name, a.middle_name, a.last_name,
                a.appointment_time, a.service_type, a.status, a.source, a.tracking_code, a.rejection_reason,
                dr.status AS request_status, dr.rejection_reason AS request_rejection_reason
         FROM appointments a
         LEFT JOIN document_requests dr ON dr.tracking_code = a.tracking_code AND dr.deleted_at IS NULL
         WHERE a.appointment_date = ?
           AND {$appointmentFilter}
           AND a.deleted_at IS NULL
         ORDER BY a.appointment_time ASC"
    );
    $stmt->execute([$date]);
    foreach (enrichCitizenNameRows($stmt->fetchAll()) as $row) {
        $rows[] = attachScheduleVisitMeta(enrichScheduleVisitRow($row), $date);
    }

    if ($confirmedIncomingOnly) {
        usort($rows, static function (array $a, array $b): int {
            return strcmp((string) ($a['appointment_time'] ?? ''), (string) ($b['appointment_time'] ?? ''));
        });

        return array_slice($rows, 0, max(0, $limit));
    }

    $stmt = $pdo->prepare(
        "SELECT dr.tracking_code, dr.first_name, dr.middle_name, dr.last_name,
                dr.appointment_date, dr.appointment_time, dr.document_type, dr.status, dr.rejection_reason
         FROM document_requests dr
         WHERE dr.appointment_date = ?
           AND dr.appointment_time IS NOT NULL
           AND dr.appointment_time != ''
           AND " . documentRequestHoldsVisitSlotSql('dr') . "
         ORDER BY dr.appointment_time ASC"
    );
    $stmt->execute([$date]);
    foreach (enrichCitizenNameRows($stmt->fetchAll()) as $req) {
        $requestStatus = normalizeRequestStatus((string) ($req['status'] ?? 'pending'));
        $rows[] = attachScheduleVisitMeta(enrichScheduleVisitRow([
            'citizen_name'     => $req['citizen_name'],
            'appointment_time' => $req['appointment_time'],
            'appointment_date' => $req['appointment_date'],
            'service_type'     => documentTypeLabel((string) ($req['document_type'] ?? '')) . ' · Pickup',
            'request_status'              => $requestStatus,
            'request_rejection_reason'    => $req['rejection_reason'] ?? null,
            'status'                      => 'scheduled',
            'schedule_kind'               => 'certificate',
            'tracking_code'               => $req['tracking_code'] ?? '',
        ]), $date);
    }

    usort($rows, static function (array $a, array $b): int {
        return strcmp((string) ($a['appointment_time'] ?? ''), (string) ($b['appointment_time'] ?? ''));
    });

    return array_slice($rows, 0, max(0, $limit));
}

function fetchDashboardSchedule(PDO $pdo, string $scheduleDate, string $calendarMonth): array
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $scheduleDate)) {
        $scheduleDate = date('Y-m-d');
    }
    if (!preg_match('/^\d{4}-\d{2}$/', $calendarMonth)) {
        $calendarMonth = date('Y-m', strtotime($scheduleDate));
    }

    return [
        'month'         => $calendarMonth,
        'dates'         => fetchScheduleDatesInMonth($pdo, $calendarMonth),
        'schedule_date' => $scheduleDate,
        'appointments'  => fetchScheduleVisits($pdo, $scheduleDate, 8),
    ];
}

function fetchAppointments(PDO $pdo, string $date): array
{
    $stmt = $pdo->prepare(
        "SELECT a.id, a.appointment_code, a.first_name, a.middle_name, a.last_name, a.service_type,
                a.appointment_time, a.status
         FROM appointments a
         WHERE a.appointment_date = ?
           AND a.status NOT IN ('cancelled', 'no_show')
           AND " . appointmentStandaloneSql('a') . "
           AND " . appointmentActiveSql('a') . "
         ORDER BY a.appointment_time ASC"
    );
    $stmt->execute([$date]);
    return enrichCitizenNameRows($stmt->fetchAll());
}

function fetchIncomingAppointments(PDO $pdo, int $limit = 8): array
{
    return fetchScheduleVisits($pdo, incomingAppointmentsDate(), $limit, false, true);
}

/** Latest standalone appointment bookings (excludes certificate pickup visits). */
function fetchRecentStandaloneAppointments(PDO $pdo, int $limit = 6): array
{
    $limit = max(1, min(20, $limit));
    $standaloneSql = appointmentStandaloneSql('a');
    $activeSql = appointmentActiveSql('a');
    $stmt = $pdo->prepare(
        "SELECT a.appointment_code, a.first_name, a.middle_name, a.last_name, a.service_type,
                a.status, a.rejection_reason, a.appointment_date, a.created_at
         FROM appointments a
         WHERE {$activeSql} AND {$standaloneSql}
         ORDER BY a.created_at DESC
         LIMIT {$limit}"
    );
    $stmt->execute();
    $rows = enrichCitizenNameRows($stmt->fetchAll());
    foreach ($rows as &$row) {
        $row['status_badge_html'] = appointmentStatusBadge(
            (string) ($row['status'] ?? ''),
            isset($row['rejection_reason']) ? (string) $row['rejection_reason'] : null
        );
    }
    unset($row);

    return $rows;
}

function incomingAppointmentsDate(): string
{
    return date('Y-m-d', strtotime(alcrosTodayDate() . ' +1 day'));
}

function documentTypeLabelsMap(): array
{
    return [
        'birth'    => 'Birth Certificate',
        'death'    => 'Death Certificate',
        'marriage' => 'Marriage Certificate',
        'cenomar'  => 'CENOMAR',
    ];
}

/** Citizen operations - Staff inbox only (not email/SMS/cron system alerts). */
function staffPortalOperationalNotificationTypes(): array
{
    return ['pending_request', 'ready_pickup', 'queue', 'appointment'];
}

function staffPortalNotificationIsSystemAlert(array $item): bool
{
    $type = (string) ($item['type'] ?? '');

    return $type === 'system' || trim((string) ($item['error_key'] ?? '')) !== '';
}

/** Administrators see system/maintenance alerts; Staff see operational citizen alerts only. */
function staffPortalNotificationAllowedForRole(array $item, bool $forAdministrator): bool
{
    $isSystemAlert = staffPortalNotificationIsSystemAlert($item);

    if ($forAdministrator) {
        return $isSystemAlert;
    }

    if ($isSystemAlert) {
        return false;
    }

    $type = (string) ($item['type'] ?? '');

    return in_array($type, staffPortalOperationalNotificationTypes(), true);
}

/** @param list<array<string, mixed>> $items */
function filterStaffPortalNotifications(array $items, ?bool $forAdministrator = null): array
{
    if ($forAdministrator === null) {
        $forAdministrator = function_exists('isAdmin') && isAdmin();
    }

    return array_values(array_filter(
        $items,
        static fn (array $item): bool => staffPortalNotificationAllowedForRole($item, $forAdministrator)
    ));
}

function fetchNotifications(PDO $pdo, int $limit = 20): array
{
    ensureSoftDeleteColumns($pdo);
    ensureCitizenNotifyColumns($pdo);

    $items = [];
    $viewerIsAdmin = function_exists('isAdmin') && isAdmin();

    try {
        if ($viewerIsAdmin) {
            if (function_exists('systemErrorsAsNotifications')) {
                $items = array_merge($items, systemErrorsAsNotifications($pdo));
            }
        } elseif (function_exists('syncSystemErrors')) {
            // Record system issues for admins without showing maintenance alerts to Staff.
            syncSystemErrors($pdo);
        }
    } catch (Throwable $e) {
        // Non-fatal if system error sync fails.
    }

    if ($viewerIsAdmin) {
        $items = filterStaffPortalNotifications($items, true);
        usort($items, static function (array $a, array $b): int {
            return strtotime($b['created_at']) <=> strtotime($a['created_at']);
        });
        $items = array_map('enrichStaffPortalNotification', $items);

        return array_slice($items, 0, $limit);
    }

    $docLabels = documentTypeLabelsMap();
    $activeSql = documentRequestActiveSql();

    $pending = enrichCitizenNameRows($pdo->query(
        "SELECT tracking_code, first_name, middle_name, last_name, document_type, submitted_at
         FROM document_requests
         WHERE {$activeSql} AND status = 'pending'
         ORDER BY submitted_at DESC LIMIT 5"
    )->fetchAll());
    foreach ($pending as $row) {
        $items[] = [
            'id'         => 'req-pending-' . $row['tracking_code'],
            'type'       => 'pending_request',
            'title'      => 'Pending request',
            'message'    => $row['citizen_name'] . ' · ' . ($docLabels[$row['document_type']] ?? $row['document_type']),
            'detail'     => $row['tracking_code'],
            'created_at' => $row['submitted_at'],
            'href'       => staffPortalNotificationHref('pending_request', [
                'tracking_code' => (string) $row['tracking_code'],
            ]),
        ];
    }

    $readyForPickup = enrichCitizenNameRows($pdo->query(
        "SELECT tracking_code, first_name, middle_name, last_name, document_type, updated_at
         FROM document_requests
         WHERE {$activeSql} AND status = 'ready'
         ORDER BY updated_at DESC LIMIT 5"
    )->fetchAll());
    foreach ($readyForPickup as $row) {
        $items[] = [
            'id'         => 'req-ready-' . $row['tracking_code'],
            'type'       => 'ready_pickup',
            'title'      => 'Ready for pickup',
            'message'    => $row['citizen_name'] . ' · ' . ($docLabels[$row['document_type']] ?? $row['document_type']),
            'detail'     => $row['tracking_code'],
            'created_at' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
            'href'       => staffPortalNotificationHref('ready_pickup', [
                'tracking_code' => (string) $row['tracking_code'],
            ]),
        ];
    }

    $queuePurposes = queuePurposeConfig();
    $waitingQueue = $pdo->query(
        "SELECT id, ticket_number, purpose, first_name, middle_name, last_name, created_at
         FROM queue_tickets
         WHERE status = 'waiting'
           AND created_at >= CURDATE() AND created_at < CURDATE() + INTERVAL 1 DAY
         ORDER BY created_at DESC
         LIMIT 5"
    )->fetchAll();
    foreach ($waitingQueue as $row) {
        $purposeKey = (string) ($row['purpose'] ?? 'walk_in');
        $purposeLabel = $queuePurposes[$purposeKey]['label'] ?? $purposeKey;
        $name = personNameFromRow($row);
        $message = (string) $row['ticket_number'] . ' · ' . $purposeLabel;
        if ($name !== '') {
            $message .= ' · ' . $name;
        }
        $items[] = [
            'id'         => 'queue-ticket-' . (int) $row['id'],
            'type'       => 'queue',
            'title'      => 'Queue alert',
            'message'    => $message,
            'detail'     => (string) $row['ticket_number'],
            'created_at' => $row['created_at'] ?? date('Y-m-d H:i:s'),
            'href'       => staffOperationalNotificationHref('live-queue.php'),
        ];
    }

    $standaloneApptSql = appointmentStandaloneSql('a');
    $appts = enrichCitizenNameRows($pdo->query(
        "SELECT a.appointment_code, a.first_name, a.middle_name, a.last_name, a.service_type,
                a.appointment_time, a.appointment_date, a.status, a.created_at
         FROM appointments a
         WHERE a.status = 'scheduled'
           AND {$standaloneApptSql}
           AND a.deleted_at IS NULL
         ORDER BY a.created_at DESC
         LIMIT 10"
    )->fetchAll());
    foreach ($appts as $row) {
        $timeLabel = date('g:i A', strtotime($row['appointment_time']));
        $dateLabel = formatDateDisplay($row['appointment_date']);
        $isRecent = strtotime($row['created_at']) >= strtotime('-48 hours');
        $isToday = $row['appointment_date'] === date('Y-m-d');
        $items[] = [
            'id'                  => 'appt-' . $row['appointment_code'],
            'type'                => 'appointment',
            'title'               => $isRecent ? 'New appointment booked' : ($isToday ? 'Today\'s appointment' : 'Upcoming appointment'),
            'message'             => $row['citizen_name'] . ' · ' . appointmentServiceLabel($row['service_type']) . ' · ' . $dateLabel . ' ' . $timeLabel,
            'detail'              => $row['appointment_code'],
            'appointment_date'    => (string) $row['appointment_date'],
            'appointment_status'  => (string) ($row['status'] ?? 'scheduled'),
            'created_at'          => $row['created_at'],
            'href'                => staffPortalNotificationHref('appointment', [
                'appointment_date'   => (string) $row['appointment_date'],
                'appointment_code'   => (string) $row['appointment_code'],
                'appointment_status' => (string) ($row['status'] ?? 'scheduled'),
            ]),
        ];
    }

    $items = filterStaffPortalNotifications($items, false);

    usort($items, static function (array $a, array $b): int {
        return strtotime($b['created_at']) <=> strtotime($a['created_at']);
    });

    $items = array_map('enrichStaffPortalNotification', $items);

    return array_slice($items, 0, $limit);
}

function fetchSidebarActionCounts(PDO $pdo): array
{
    return [
        'pending_requests'     => countPendingDocumentRequests($pdo),
        'pending_appointments' => countPendingAppointments($pdo),
    ];
}
