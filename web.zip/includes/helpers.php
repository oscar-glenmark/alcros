<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/security.php';
bootstrapSecurity();

if (function_exists('alcrosApplyOfficeTimezone')) {
    alcrosApplyOfficeTimezone();
} elseif (!ini_get('date.timezone')) {
    date_default_timezone_set('Asia/Manila');
}

function alcrosTodayDate(): string
{
    return date('Y-m-d');
}

function generateCode(string $prefix, int $length = 6): string
{
    return $prefix . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, $length));
}

function generateTrackingCode(): string
{
    return generateCode('ALR', 8);
}

function generateAppointmentCode(): string
{
    return generateCode('APT', 6);
}

function createQueueTicket(PDO $pdo, string $purpose = 'walk_in'): array
{
    if (!isset(queuePurposeConfig()[$purpose])) {
        throw new InvalidArgumentException('Invalid queue purpose.');
    }

    $prefix = match ($purpose) {
        'walk_in'        => 'W',
        'appointment'    => 'A',
        'document_claim' => 'C',
        default          => 'Q',
    };

    ensureQueuePerformanceIndexes($pdo);
    $tableNum = queueTableForPurpose($purpose);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            "SELECT ticket_number FROM queue_tickets
             WHERE created_at >= CURDATE() AND created_at < CURDATE() + INTERVAL 1 DAY AND purpose = ?
             ORDER BY id DESC LIMIT 1 FOR UPDATE"
        );
        $stmt->execute([$purpose]);
        $last = (string) ($stmt->fetchColumn() ?: '');
        $next = 1;
        if ($last !== '' && preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $last, $m)) {
            $next = (int) $m[1] + 1;
        }
        $ticketNumber = $prefix . str_pad((string) $next, 3, '0', STR_PAD_LEFT);
        $pdo->prepare(
            'INSERT INTO queue_tickets (ticket_number, purpose, status, window_number) VALUES (?, ?, ?, ?)'
        )->execute([$ticketNumber, $purpose, 'waiting', $tableNum]);
        $ticketId = (int) $pdo->lastInsertId();
        $purposeLabel = queuePurposeConfig()[$purpose]['label'];
        $pdo->commit();

        return [
            'id'     => $ticketId,
            'number' => $ticketNumber,
            'table'  => $tableNum,
            'label'  => $purposeLabel,
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function queueTodaySql(string $column = 'created_at'): string
{
    return "DATE($column) = CURDATE()";
}

/** Call next waiting ticket; completes current serving ticket under row lock. */
function queueAdvanceNext(PDO $pdo, string $purpose, int $tableNum, string $staffId): array
{
    if (!isset(queuePurposeConfig()[$purpose])) {
        throw new InvalidArgumentException('Invalid queue purpose.');
    }

    ensureQueueTicketTimingColumns($pdo);

    $day = queueTodaySql('created_at');
    $pdo->beginTransaction();
    try {
        $servingStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'serving' AND $day
             LIMIT 1 FOR UPDATE"
        );
        $servingStmt->execute([$purpose]);
        $servingRow = $servingStmt->fetch(PDO::FETCH_ASSOC);
        if ($servingRow) {
            $pdo->prepare("UPDATE queue_tickets SET status = 'completed' WHERE id = ?")
                ->execute([(int) $servingRow['id']]);
        }

        $nextStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'waiting' AND $day
             ORDER BY created_at ASC LIMIT 1 FOR UPDATE"
        );
        $nextStmt->execute([$purpose]);
        $nextRow = $nextStmt->fetch(PDO::FETCH_ASSOC);

        $calledTicket = null;
        if ($nextRow) {
            $pdo->prepare(
                "UPDATE queue_tickets
                 SET status = 'serving',
                     called_at = NOW(),
                     first_called_at = COALESCE(first_called_at, NOW()),
                     window_number = ?
                 WHERE id = ?"
            )->execute([$tableNum, (int) $nextRow['id']]);
            $calledTicket = (string) $nextRow['ticket_number'];
            logActivity($staffId, 'Queue', "Table $tableNum: called {$nextRow['ticket_number']}");
        }

        $pdo->commit();

        if ($calledTicket !== null) {
            require_once __DIR__ . '/queue_announcements.php';
            queueEnqueueAnnouncement($pdo, $purpose, $calledTicket, $tableNum);
        }

        return [
            'called_ticket' => $calledTicket,
            'had_serving'   => (bool) $servingRow,
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function queueCallAgain(PDO $pdo, string $purpose, int $tableNum, string $staffId): ?string
{
    if (!isset(queuePurposeConfig()[$purpose])) {
        throw new InvalidArgumentException('Invalid queue purpose.');
    }

    $day = queueTodaySql('created_at');
    $pdo->beginTransaction();
    try {
        $servingStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'serving' AND $day
             LIMIT 1 FOR UPDATE"
        );
        $servingStmt->execute([$purpose]);
        $row = $servingStmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            $pdo->commit();
            return null;
        }

        $pdo->prepare('UPDATE queue_tickets SET called_at = NOW(), window_number = ? WHERE id = ?')
            ->execute([$tableNum, (int) $row['id']]);
        $pdo->commit();
        logActivity($staffId, 'Queue', "Table $tableNum: called again {$row['ticket_number']}");

        require_once __DIR__ . '/queue_announcements.php';
        queueEnqueueAnnouncement($pdo, $purpose, (string) $row['ticket_number'], $tableNum, true);

        return (string) $row['ticket_number'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function queueSkipServing(PDO $pdo, string $purpose, string $staffId): ?string
{
    if (!isset(queuePurposeConfig()[$purpose])) {
        throw new InvalidArgumentException('Invalid queue purpose.');
    }

    $day = queueTodaySql('created_at');
    $pdo->beginTransaction();
    try {
        $servingStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'serving' AND $day
             LIMIT 1 FOR UPDATE"
        );
        $servingStmt->execute([$purpose]);
        $row = $servingStmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            $pdo->commit();
            return null;
        }

        $pdo->prepare("UPDATE queue_tickets SET status = 'skipped' WHERE id = ?")
            ->execute([(int) $row['id']]);
        $pdo->commit();
        logActivity($staffId, 'Queue', "Skipped {$row['ticket_number']}");

        return (string) $row['ticket_number'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/** Mark current serving ticket as no-show (skipped), then call the next waiting ticket. */
function queueNoShowAndAdvance(PDO $pdo, string $purpose, int $tableNum, string $staffId): array
{
    if (!isset(queuePurposeConfig()[$purpose])) {
        throw new InvalidArgumentException('Invalid queue purpose.');
    }

    ensureQueueTicketTimingColumns($pdo);

    $day = queueTodaySql('created_at');
    $pdo->beginTransaction();
    try {
        $servingStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'serving' AND $day
             LIMIT 1 FOR UPDATE"
        );
        $servingStmt->execute([$purpose]);
        $servingRow = $servingStmt->fetch(PDO::FETCH_ASSOC);
        if (!$servingRow) {
            $pdo->commit();

            return [
                'no_show_ticket' => null,
                'called_ticket'  => null,
            ];
        }

        $pdo->prepare("UPDATE queue_tickets SET status = 'skipped' WHERE id = ?")
            ->execute([(int) $servingRow['id']]);
        $noShowTicket = (string) $servingRow['ticket_number'];
        logActivity($staffId, 'Queue', "No-show $noShowTicket at Table $tableNum");

        $nextStmt = $pdo->prepare(
            "SELECT id, ticket_number FROM queue_tickets
             WHERE purpose = ? AND status = 'waiting' AND $day
             ORDER BY created_at ASC LIMIT 1 FOR UPDATE"
        );
        $nextStmt->execute([$purpose]);
        $nextRow = $nextStmt->fetch(PDO::FETCH_ASSOC);

        $calledTicket = null;
        if ($nextRow) {
            $pdo->prepare(
                "UPDATE queue_tickets
                 SET status = 'serving',
                     called_at = NOW(),
                     first_called_at = COALESCE(first_called_at, NOW()),
                     window_number = ?
                 WHERE id = ?"
            )->execute([$tableNum, (int) $nextRow['id']]);
            $calledTicket = (string) $nextRow['ticket_number'];
            logActivity($staffId, 'Queue', "Table $tableNum: called {$nextRow['ticket_number']}");
        }

        $pdo->commit();

        if ($calledTicket !== null) {
            require_once __DIR__ . '/queue_announcements.php';
            queueEnqueueAnnouncement($pdo, $purpose, $calledTicket, $tableNum);
        }

        return [
            'no_show_ticket' => $noShowTicket,
            'called_ticket'  => $calledTicket,
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function queueTicketIsNoShow(array $row): bool
{
    return strtolower(trim((string) ($row['status'] ?? ''))) === 'skipped';
}

function queueTicketStatusLabel(string $status): string
{
    return match (strtolower(trim($status))) {
        'skipped' => 'No show',
        'waiting' => 'Waiting',
        'serving' => 'Serving',
        'completed' => 'Completed',
        default     => ucfirst($status),
    };
}

function queuePurposeConfig(): array
{
    return [
        'walk_in' => [
            'label'       => 'Walk-in',
            'table'       => 1,
            'description' => 'General inquiries & new requests',
            'icon'        => 'users',
            'color'       => 'orange',
            'border'      => 'border-orange-400',
            'bg'          => 'bg-orange-50',
            'text'        => 'text-orange-600',
            'btn'         => 'bg-orange-600 hover:bg-orange-700',
        ],
        'appointment' => [
            'label'       => 'Appointment',
            'table'       => 2,
            'description' => 'Scheduled visits & consultations',
            'icon'        => 'calendar-days',
            'color'       => 'blue',
            'border'      => 'border-blue-400',
            'bg'          => 'bg-blue-50',
            'text'        => 'text-blue-600',
            'btn'         => 'bg-blue-600 hover:bg-blue-700',
        ],
        'document_claim' => [
            'label'       => 'Claim',
            'table'       => 3,
            'description' => 'Document pickup & release',
            'icon'        => 'package',
            'color'       => 'emerald',
            'border'      => 'border-emerald-400',
            'bg'          => 'bg-emerald-50',
            'text'        => 'text-emerald-600',
            'btn'         => 'bg-emerald-600 hover:bg-emerald-700',
        ],
    ];
}

function queueTableForPurpose(string $purpose): int
{
    return queuePurposeConfig()[$purpose]['table'] ?? 1;
}

function ensureQueuePerformanceIndexes(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $pdo->query('SELECT 1 FROM queue_tickets USE INDEX (idx_queue_day_status) LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE queue_tickets ADD INDEX idx_queue_day_status (status, created_at, purpose)');
        } catch (Throwable $ignored) {
        }
    }

    ensureQueueTicketTimingColumns($pdo);
}

/** First call time (unchanged by “Call again”); used for wait-before-called reports. */
function ensureQueueTicketTimingColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $pdo->query('SELECT first_called_at FROM queue_tickets LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE queue_tickets ADD COLUMN first_called_at TIMESTAMP NULL DEFAULT NULL AFTER called_at');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->exec(
            'UPDATE queue_tickets SET first_called_at = called_at
             WHERE first_called_at IS NULL AND called_at IS NOT NULL'
        );
    } catch (Throwable $ignored) {
    }
}

/** Seconds from ticket issue until first call; null if never called. */
function queueWaitSecondsBeforeFirstCall(?string $createdAt, ?string $firstCalledAt, ?string $calledAtFallback = null): ?int
{
    $called = trim((string) ($firstCalledAt ?? ''));
    if ($called === '') {
        $called = trim((string) ($calledAtFallback ?? ''));
    }
    if ($called === '') {
        return null;
    }

    $created = trim((string) ($createdAt ?? ''));
    if ($created === '') {
        return null;
    }

    $start = strtotime($created);
    $end = strtotime($called);
    if ($start === false || $end === false || $end < $start) {
        return null;
    }

    return $end - $start;
}

function formatQueueWaitDuration(?int $seconds): string
{
    if ($seconds === null) {
        return '-';
    }
    if ($seconds < 0) {
        return '-';
    }
    if ($seconds < 60) {
        return $seconds . ' sec';
    }
    if ($seconds < 3600) {
        $mins = (int) round($seconds / 60);

        return $mins . ' min';
    }

    $hours = intdiv($seconds, 3600);
    $mins = (int) round(($seconds % 3600) / 60);
    if ($mins === 0) {
        return $hours . 'h';
    }

    return $hours . 'h ' . $mins . ' min';
}

/** @param list<array<string, mixed>> $rows */
function enrichQueueTicketsWithWaitMetrics(array $rows): array
{
    $enriched = [];
    foreach ($rows as $row) {
        $waitSeconds = queueWaitSecondsBeforeFirstCall(
            $row['created_at'] ?? null,
            $row['first_called_at'] ?? null,
            $row['called_at'] ?? null
        );
        $row['wait_seconds'] = $waitSeconds;
        $row['wait_label'] = formatQueueWaitDuration($waitSeconds);
        $enriched[] = $row;
    }

    return $enriched;
}

/** @param list<array<string, mixed>> $rows */
function buildQueueWaitSummary(array $rows): array
{
    $byPurpose = [];
    $allWaits = [];

    foreach ($rows as $row) {
        $wait = $row['wait_seconds'] ?? null;
        if ($wait === null) {
            continue;
        }
        $allWaits[] = (int) $wait;
        $purpose = (string) ($row['purpose'] ?? 'unknown');
        if (!isset($byPurpose[$purpose])) {
            $byPurpose[$purpose] = [];
        }
        $byPurpose[$purpose][] = (int) $wait;
    }

    $avg = static function (array $values): ?int {
        if ($values === []) {
            return null;
        }

        return (int) round(array_sum($values) / count($values));
    };

    $purposeSummary = [];
    foreach ($byPurpose as $purpose => $values) {
        $purposeSummary[$purpose] = [
            'called_count' => count($values),
            'avg_seconds'  => $avg($values),
        ];
    }

    return [
        'called_count' => count($allWaits),
        'avg_seconds'  => $avg($allWaits),
        'by_purpose'   => $purposeSummary,
    ];
}

/**
 * Chart.js payload for Reports → Queue wait-time graphs.
 *
 * @param list<array<string, mixed>> $queueTickets
 * @param array<string, string> $purposeLabels
 */
function buildQueueWaitChartPayload(array $queueTickets, array $purposeLabels, string $from, string $to): array
{
    $summary = buildQueueWaitSummary($queueTickets);
    $purposeOrder = ['walk_in', 'appointment', 'document_claim'];
    $purposeColors = [
        'walk_in'        => 'rgba(37, 99, 235, 0.88)',
        'appointment'    => 'rgba(124, 58, 237, 0.88)',
        'document_claim' => 'rgba(20, 184, 166, 0.88)',
    ];

    $byPurposeLabels = [];
    $byPurposeMinutes = [];
    $byPurposeColors = [];
    foreach ($purposeOrder as $purposeKey) {
        $stats = $summary['by_purpose'][$purposeKey] ?? null;
        if ($stats === null || ($stats['avg_seconds'] ?? null) === null) {
            continue;
        }
        $byPurposeLabels[] = $purposeLabels[$purposeKey] ?? ucfirst(str_replace('_', ' ', $purposeKey));
        $byPurposeMinutes[] = round(((int) $stats['avg_seconds']) / 60, 1);
        $byPurposeColors[] = $purposeColors[$purposeKey] ?? 'rgba(100, 116, 139, 0.88)';
    }

    $dailyBuckets = [];
    foreach ($queueTickets as $row) {
        $wait = $row['wait_seconds'] ?? null;
        if ($wait === null) {
            continue;
        }
        $created = (string) ($row['created_at'] ?? '');
        $day = strlen($created) >= 10 ? substr($created, 0, 10) : '';
        if ($day === '') {
            continue;
        }
        if (!isset($dailyBuckets[$day])) {
            $dailyBuckets[$day] = [];
        }
        $dailyBuckets[$day][] = (int) $wait;
    }
    ksort($dailyBuckets);

    $dailyLabels = [];
    $dailyMinutes = [];
    foreach ($dailyBuckets as $day => $waits) {
        $ts = strtotime($day);
        $dailyLabels[] = $ts ? date('M j', $ts) : $day;
        $dailyMinutes[] = round(array_sum($waits) / count($waits) / 60, 1);
    }

    $showDailyTrend = $from !== $to && count($dailyMinutes) > 1;

    return [
        'hasData' => (int) ($summary['called_count'] ?? 0) > 0,
        'byPurpose' => [
            'labels'  => $byPurposeLabels,
            'minutes' => $byPurposeMinutes,
            'colors'  => $byPurposeColors,
        ],
        'daily' => $showDailyTrend ? [
            'labels'  => $dailyLabels,
            'minutes' => $dailyMinutes,
        ] : null,
    ];
}

/** Queue wait charts for analytics (default: last 7 calendar days). */
function fetchQueueWaitChartAnalytics(PDO $pdo, int $days = 7): array
{
    $days = max(1, $days);
    $to = date('Y-m-d');
    $from = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));

    ensureQueueTicketTimingColumns($pdo);

    $stmt = $pdo->prepare(
        "SELECT ticket_number, purpose, status, first_name, middle_name, last_name, reference_code, window_number,
                created_at, called_at, first_called_at
         FROM queue_tickets
         WHERE DATE(created_at) BETWEEN ? AND ?"
    );
    $stmt->execute([$from, $to]);
    $tickets = enrichQueueTicketsWithWaitMetrics($stmt->fetchAll());

    return buildQueueWaitChartPayload($tickets, [
        'walk_in' => 'Walk-in',
        'appointment' => 'Appointment',
        'document_claim' => 'Document claim',
    ], $from, $to);
}

function logActivity(?string $staffId, string $action, string $details = ''): void
{
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO activity_logs (staff_id, action, details) VALUES (?, ?, ?)');
        $stmt->execute([$staffId, $action, $details]);
    } catch (PDOException $e) {
        // Non-fatal if logging fails
    }
}

function ensureExtendedSchema(PDO $pdo): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }
    $ensured = true;

    if (is_file(__DIR__ . '/schema_reorganization.php')) {
        require_once __DIR__ . '/schema_reorganization.php';
        alcrosEnsureDeliveryLogsTable($pdo);
    }

    try {
        $pdo->query('SELECT 1 FROM request_status_history LIMIT 1');
    } catch (PDOException) {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS request_status_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                request_id INT NOT NULL,
                tracking_code VARCHAR(20) NOT NULL,
                old_status VARCHAR(20) DEFAULT NULL,
                new_status VARCHAR(20) NOT NULL,
                changed_by VARCHAR(50) DEFAULT NULL,
                notes TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_request (request_id),
                INDEX idx_tracking (tracking_code),
                INDEX idx_created (created_at),
                CONSTRAINT fk_status_history_request
                    FOREIGN KEY (request_id) REFERENCES document_requests(id) ON DELETE CASCADE
            ) ENGINE=InnoDB"
        );
    }

    try {
        $pdo->exec("UPDATE staff SET role = 'Administrator' WHERE role = 'Registrar'");
    } catch (PDOException $e) {
        // Non-fatal if migration fails
    }

    if (is_file(__DIR__ . '/schema_reorganization.php')) {
        require_once __DIR__ . '/schema_reorganization.php';
        ensureAlcrosSchemaReorganization($pdo);
    }
}

function logEmailDelivery(
    string $recipient,
    string $subject,
    string $emailType = 'general',
    ?string $referenceCode = null,
    bool $success = true,
    ?string $errorMessage = null
): void {
    try {
        ensureExtendedSchema(getDB());
        $stmt = getDB()->prepare(
            'INSERT INTO delivery_logs (channel, recipient, subject, body, delivery_type, reference_code, success, error_message)
             VALUES (\'email\', ?, ?, \'\', ?, ?, ?, ?)'
        );
        $stmt->execute([
            $recipient,
            $subject,
            $emailType,
            $referenceCode,
            $success ? 1 : 0,
            $errorMessage,
        ]);
    } catch (PDOException $e) {
        // Non-fatal if logging fails
    }
}

function logRequestStatusChange(
    PDO $pdo,
    int $requestId,
    string $trackingCode,
    ?string $oldStatus,
    string $newStatus,
    ?string $changedBy = null,
    ?string $notes = null
): void {
    try {
        ensureExtendedSchema($pdo);
        $stmt = $pdo->prepare(
            'INSERT INTO request_status_history (request_id, tracking_code, old_status, new_status, changed_by, notes)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$requestId, $trackingCode, $oldStatus, $newStatus, $changedBy, $notes]);
    } catch (PDOException $e) {
        // Non-fatal if logging fails
    }
}

/** @return array<string, string> */
function &settingsCacheStore(): array
{
    static $cache = [];

    return $cache;
}

function ensureSettingsLoaded(): void
{
    $cache = &settingsCacheStore();
    if (array_key_exists('__all_loaded__', $cache)) {
        return;
    }

    try {
        $pdo = getDB();
        $stmt = $pdo->query('SELECT setting_key, setting_value FROM system_settings');
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $cache[(string) $row['setting_key']] = (string) $row['setting_value'];
        }
    } catch (PDOException $e) {
        // Fall back to per-key lookups below.
    }

    $cache['__all_loaded__'] = '1';
}

function getSetting(string $key, string $default = ''): string
{
    $cache = &settingsCacheStore();

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    ensureSettingsLoaded();
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT setting_value FROM system_settings WHERE setting_key = ?');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        $cache[$key] = $row ? (string) $row['setting_value'] : $default;
    } catch (PDOException $e) {
        $cache[$key] = $default;
    }

    return $cache[$key];
}

function setSetting(string $key, string $value): void
{
    $pdo = getDB();
    $stmt = $pdo->prepare(
        'INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    );
    $stmt->execute([$key, $value]);

    settingsCacheStore()[$key] = $value;
}

/** @return bool True when the stored value changed. */
function setSettingIfChanged(string $key, string $value, string $default = ''): bool
{
    if (getSetting($key, $default) === $value) {
        return false;
    }
    setSetting($key, $value);

    return true;
}

function getSiteSettings(): array
{
    ensureSettingsLoaded();

    return [
        'name'               => getSetting('site_name', 'ALCROS'),
        'office'             => getSetting('office_name', 'Local Civil Registrar Office (LCRO) of Aloran'),
        'address'            => getSetting('office_address', 'Municipal Hall, Aloran, Misamis Occidental, Philippines'),
        'phone'              => getSetting('office_phone', '+639473212350'),
        'email'              => getSetting('office_email', 'aloran@gov.ph'),
        'head'               => getSetting('office_head', 'ATTY. LOCAL CIVIL REGISTRAR'),
        'hours'              => getSetting('office_hours', '8:00 AM - 5:00 PM (Monday to Friday)'),
        'facebook_url'       => getSetting('social_facebook_url', 'https://www.facebook.com/aloranmisamis.occidental.9'),
        'instagram_url'      => getSetting('social_instagram_url', ''),
        'overview'           => getSetting('overview_text', 'This guide covers the requirements, steps, and fees for all core civil registration services handled by the <strong>{office}</strong>.'),
    ];
}

/** Latest announcement card on the citizen home page (About section). */
function getHomeLatestAnnouncement(): array
{
    ensureSettingsLoaded();

    $hours = getSetting('office_hours', '8:00 AM - 5:00 PM (Monday to Friday)');
    $note = trim(getSetting('home_announcement_note', ''));
    if ($note === '') {
        $note = 'Walk-in clients and online request claimants are served during these hours.';
    }
    $body = rtrim($hours, '. ') . '. ' . $note;

    $title = trim(getSetting('home_announcement_title', ''));
    if ($title === '') {
        $title = 'Office Schedule';
    }

    $dateStored = trim(getSetting('home_announcement_date', ''));
    if ($dateStored !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStored)) {
        $dateLabel = formatDateEmailDisplay($dateStored);
    } elseif ($dateStored !== '') {
        $dateLabel = $dateStored;
    } else {
        $dateLabel = formatDateEmailDisplay(date('Y-m-d'));
    }

    return [
        'date'  => $dateLabel,
        'title' => $title,
        'body'  => $body,
    ];
}

function renderOverviewText(string $template, string $officeName): string
{
    $text = str_replace('{office}', htmlspecialchars($officeName), $template);
    if (strpos($text, '<') === false) {
        return nl2br(htmlspecialchars($text));
    }

    return sanitizeOverviewHtml($text);
}

function documentTypeLabel(string $type): string
{
    $labels = [
        'birth'    => 'Birth Certificate',
        'death'    => 'Death Certificate',
        'marriage' => 'Marriage Certificate',
        'cenomar'  => 'CENOMAR',
    ];
    return $labels[$type] ?? ucfirst($type);
}

function requestStatusWorkflow(): array
{
    return ['pending', 'verified', 'ready', 'completed'];
}

/** Staff actions available for the current request status. */
function requestStatusActionsFor(string $status): array
{
    return match (normalizeRequestStatus($status)) {
        'pending'       => ['verified', 'rejected'],
        'processing'    => ['ready', 'completed', 'rejected'],
        'printing',
        'printed',
        'quality_check' => ['ready', 'completed', 'rejected'],
        'ready'         => ['completed'],
        default         => [],
    };
}

function requestStatusActionLabel(string $action): string
{
    return match ($action) {
        'verified'      => 'Accept Request',
        'rejected'      => 'Reject request',
        'processing'    => 'Mark Processing',
        'printing'      => 'Mark Printing',
        'printed'       => 'Mark Printed',
        'quality_check' => 'Pass Quality Check',
        'ready'         => 'Ready for Pickup',
        'completed'     => 'Completed - claimed',
        default         => requestStatusLabel($action),
    };
}

function normalizeRequestStatus(string $status): string
{
    return match ($status) {
        'processing' => 'processing',
        'printing'   => 'printing',
        'printed'    => 'printed',
        'quality_check' => 'quality_check',
        default      => $status === 'processing' ? 'verified' : $status,
    };
}

function isAllowedRequestStatusTransition(string $fromStatus, string $action): bool
{
    return in_array($action, requestStatusActionsFor($fromStatus), true);
}

function requestStatusProgressIndex(string $status): int|false
{
    if ($status === 'rejected') {
        return false;
    }
    $status = normalizeRequestStatus($status);

    return match ($status) {
        'pending' => 0,
        'verified', 'processing', 'printing', 'printed', 'quality_check' => 1,
        'ready' => 2,
        'completed' => 3,
        default => false,
    };
}

function migrateLegacyProcessingStatus(PDO $pdo): void
{
    static $migrated = false;
    if ($migrated) {
        return;
    }
    $migrated = true;

    try {
        $pdo->exec("UPDATE document_requests SET status = 'ready' WHERE status = 'verified'");
    } catch (Throwable $e) {
        // ignore if migration cannot run
    }
}

function ensureCitizenNotifyColumns(PDO $pdo): void
{
    ensurePersonNamePartColumns($pdo);
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $pdo->query('SELECT notify_email FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN notify_email TINYINT(1) NOT NULL DEFAULT 0 AFTER privacy_agreed');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT reminder_sent_at FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN reminder_sent_at TIMESTAMP NULL DEFAULT NULL AFTER notify_email');
        } catch (Throwable $ignored) {
        }
    }

    ensureReminderLeadColumns($pdo, 'document_requests');

    try {
        $pdo->query('SELECT notify_sms FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN notify_sms TINYINT(1) NOT NULL DEFAULT 0 AFTER notify_email');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT sms_reminder_3h_sent_at FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN sms_reminder_3h_sent_at TIMESTAMP NULL DEFAULT NULL AFTER reminder_1h_sent_at');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT sms_reminder_1h_sent_at FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN sms_reminder_1h_sent_at TIMESTAMP NULL DEFAULT NULL AFTER sms_reminder_3h_sent_at');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT date_of_marriage FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN date_of_marriage DATE DEFAULT NULL AFTER date_of_birth');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT date_of_death FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE document_requests ADD COLUMN date_of_death DATE DEFAULT NULL AFTER date_of_marriage');
        } catch (Throwable $ignored) {
        }
    }

    ensureDocumentRequestRequesterColumns($pdo);

    try {
        $pdo->query('SELECT notify_email FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN notify_email TINYINT(1) NOT NULL DEFAULT 0 AFTER phone');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT reminder_sent_at FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN reminder_sent_at TIMESTAMP NULL DEFAULT NULL AFTER notify_email');
        } catch (Throwable $ignored) {
        }
    }

    ensureReminderLeadColumns($pdo, 'appointments');

    try {
        $pdo->query('SELECT notify_sms FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN notify_sms TINYINT(1) NOT NULL DEFAULT 0 AFTER notify_email');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT sms_reminder_3h_sent_at FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN sms_reminder_3h_sent_at TIMESTAMP NULL DEFAULT NULL AFTER reminder_1h_sent_at');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT sms_reminder_1h_sent_at FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN sms_reminder_1h_sent_at TIMESTAMP NULL DEFAULT NULL AFTER sms_reminder_3h_sent_at');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT source FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec("ALTER TABLE appointments ADD COLUMN source VARCHAR(32) NOT NULL DEFAULT 'standalone' AFTER status");
            $pdo->exec('ALTER TABLE appointments ADD COLUMN tracking_code VARCHAR(20) DEFAULT NULL AFTER source');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT id_front_path FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE appointments ADD COLUMN id_front_path VARCHAR(255) DEFAULT NULL AFTER tracking_code');
            $pdo->exec('ALTER TABLE appointments ADD COLUMN id_back_path VARCHAR(255) DEFAULT NULL AFTER id_front_path');
        } catch (Throwable $ignored) {
        }
    }

    ensureSoftDeleteColumns($pdo);
    repairAppointmentsMislinkedBySlotMerge($pdo);
}

/** Undo legacy merge that tagged standalone visits as document requests when date/time/email matched. */
function repairAppointmentsMislinkedBySlotMerge(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        ensureSoftDeleteColumns($pdo);
        $pdo->exec(
            "UPDATE appointments a
             INNER JOIN document_requests r
                ON r.tracking_code = a.tracking_code AND r.deleted_at IS NULL
             SET a.source = 'standalone', a.tracking_code = NULL
             WHERE a.source = 'document_request'
               AND a.status = 'scheduled'
               AND r.status IN ('pending', 'verified', 'ready', 'processing', 'printing', 'printed', 'quality_check')"
        );
    } catch (Throwable $ignored) {
    }
}

function ensureSoftDeleteColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $tables = [
        'document_requests' => 'updated_at',
        'appointments'      => 'created_at',
    ];

    foreach ($tables as $table => $afterColumn) {
        try {
            $pdo->query("SELECT deleted_at FROM `$table` LIMIT 1");
        } catch (Throwable $e) {
            try {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL AFTER `$afterColumn`");
                $pdo->exec("ALTER TABLE `$table` ADD INDEX idx_deleted_at (deleted_at)");
            } catch (Throwable $ignored) {
            }
        }
    }
}

function ensureAppointmentUpdatedColumn(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $pdo->query('SELECT updated_at FROM appointments LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec(
                'ALTER TABLE appointments ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at'
            );
            $pdo->exec('UPDATE appointments SET updated_at = created_at WHERE updated_at IS NULL');
        } catch (Throwable $ignored) {
        }
    }
}

function ensureRejectionReasonColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    foreach (['document_requests', 'appointments'] as $table) {
        try {
            $pdo->query("SELECT rejection_reason FROM `$table` LIMIT 1");
        } catch (Throwable $e) {
            try {
                $pdo->exec(
                    "ALTER TABLE `$table` ADD COLUMN rejection_reason TEXT NULL DEFAULT NULL AFTER notes"
                );
            } catch (Throwable $ignored) {
            }
        }
    }
}

function normalizeStaffRejectionReason(?string $reason): ?string
{
    $reason = trim((string) $reason);
    if ($reason === '') {
        return null;
    }
    if (function_exists('mb_strlen') && mb_strlen($reason) > 2000) {
        return mb_substr($reason, 0, 2000);
    }
    if (strlen($reason) > 2000) {
        return substr($reason, 0, 2000);
    }

    return $reason;
}

function citizenStatusMessageWithRejectionReason(string $base, ?string $rejectionReason): string
{
    $reason = normalizeStaffRejectionReason($rejectionReason);
    if ($reason === null) {
        return $base;
    }

    return $base . ' Reason: ' . $reason;
}

function documentRequestActiveSql(string $alias = ''): string
{
    $prefix = $alias !== '' ? $alias . '.' : '';

    return $prefix . 'deleted_at IS NULL';
}

function appointmentActiveSql(string $alias = 'a'): string
{
    return $alias . '.deleted_at IS NULL';
}

function documentRequestIsDeletable(array $row): bool
{
    return normalizeRequestStatus((string) ($row['status'] ?? '')) === 'completed';
}

function appointmentIsDeletable(array $row): bool
{
    return in_array((string) ($row['status'] ?? ''), ['completed', 'cancelled', 'no_show'], true);
}

function softDeleteDocumentRequest(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare(
        'SELECT id, tracking_code, status FROM document_requests WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row || !documentRequestIsDeletable($row)) {
        return false;
    }

    $pdo->prepare('UPDATE document_requests SET deleted_at = NOW() WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Request Deleted', 'Moved completed request ' . $row['tracking_code'] . ' to recently deleted');

    return true;
}

function softDeleteDocumentRequests(PDO $pdo, array $ids): int
{
    $deleted = 0;
    foreach ($ids as $id) {
        if (softDeleteDocumentRequest($pdo, (int) $id)) {
            $deleted++;
        }
    }

    return $deleted;
}

function softDeleteAllDeletableDocumentRequests(PDO $pdo): int
{
    $stmt = $pdo->query(
        "SELECT id FROM document_requests WHERE status = 'completed' AND deleted_at IS NULL ORDER BY updated_at DESC"
    );
    $ids = array_map(static fn ($row) => (int) $row['id'], $stmt->fetchAll() ?: []);

    return softDeleteDocumentRequests($pdo, $ids);
}

function restoreDocumentRequest(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare('SELECT tracking_code FROM document_requests WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }

    $pdo->prepare('UPDATE document_requests SET deleted_at = NULL WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Request Restored', 'Restored request ' . $row['tracking_code'] . ' from recently deleted');

    return true;
}

function restoreDocumentRequests(PDO $pdo, array $ids): int
{
    $restored = 0;
    foreach ($ids as $id) {
        if (restoreDocumentRequest($pdo, (int) $id)) {
            $restored++;
        }
    }

    return $restored;
}

function purgeDocumentRequest(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare(
        'SELECT tracking_code, id_front_path, id_back_path FROM document_requests WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }

    deleteIdUploadFiles($row['id_front_path'] ?? null, $row['id_back_path'] ?? null);
    $pdo->prepare('DELETE FROM document_requests WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Request Purged', 'Permanently deleted request ' . $row['tracking_code']);

    return true;
}

function purgeDocumentRequests(PDO $pdo, array $ids): int
{
    $purged = 0;
    foreach ($ids as $id) {
        if (purgeDocumentRequest($pdo, (int) $id)) {
            $purged++;
        }
    }

    return $purged;
}

function softDeleteAppointment(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare(
        'SELECT id, appointment_code, status, id_front_path, id_back_path FROM appointments WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row || !appointmentIsDeletable($row)) {
        return false;
    }

    $pdo->prepare('UPDATE appointments SET deleted_at = NOW() WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Appointment Deleted', 'Moved appointment ' . $row['appointment_code'] . ' to recently deleted');

    return true;
}

function softDeleteAppointments(PDO $pdo, array $ids): int
{
    $deleted = 0;
    foreach ($ids as $id) {
        if (softDeleteAppointment($pdo, (int) $id)) {
            $deleted++;
        }
    }

    return $deleted;
}

function softDeleteAllDeletableAppointments(PDO $pdo, string $date): int
{
    $stmt = $pdo->prepare(
        "SELECT id FROM appointments
         WHERE appointment_date = ?
           AND deleted_at IS NULL
           AND status IN ('completed', 'cancelled', 'no_show')
           AND " . appointmentStandaloneSql('appointments') . "
         ORDER BY appointment_time ASC"
    );
    $stmt->execute([$date]);
    $ids = array_map(static fn ($row) => (int) $row['id'], $stmt->fetchAll() ?: []);

    return softDeleteAppointments($pdo, $ids);
}

function restoreAppointment(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare('SELECT appointment_code FROM appointments WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }

    $pdo->prepare('UPDATE appointments SET deleted_at = NULL WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Appointment Restored', 'Restored appointment ' . $row['appointment_code'] . ' from recently deleted');

    return true;
}

function restoreAppointments(PDO $pdo, array $ids): int
{
    $restored = 0;
    foreach ($ids as $id) {
        if (restoreAppointment($pdo, (int) $id)) {
            $restored++;
        }
    }

    return $restored;
}

function purgeAppointment(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare(
        'SELECT appointment_code, id_front_path, id_back_path FROM appointments WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }

    deleteIdUploadFiles($row['id_front_path'] ?? null, $row['id_back_path'] ?? null);
    $pdo->prepare('DELETE FROM appointments WHERE id = ?')->execute([$id]);
    logActivity(staffId(), 'Appointment Purged', 'Permanently deleted appointment ' . $row['appointment_code']);

    return true;
}

function purgeAppointments(PDO $pdo, array $ids): int
{
    $purged = 0;
    foreach ($ids as $id) {
        if (purgeAppointment($pdo, (int) $id)) {
            $purged++;
        }
    }

    return $purged;
}

function parseBulkIdsFromPost(): array
{
    $ids = $_POST['bulk_ids'] ?? [];
    if (!is_array($ids)) {
        return [];
    }

    $parsed = [];
    foreach ($ids as $id) {
        $id = (int) $id;
        if ($id > 0) {
            $parsed[] = $id;
        }
    }

    return array_values(array_unique($parsed));
}

function deleteIdUploadFiles(?string ...$paths): void
{
    foreach ($paths as $rel) {
        $rel = trim((string) $rel);
        if ($rel === '') {
            continue;
        }
        $path = __DIR__ . '/../' . ltrim($rel, '/');
        if (is_file($path)) {
            @unlink($path);
        }
    }
}

function deleteCompletedDocumentRequest(PDO $pdo, int $id): bool
{
    return softDeleteDocumentRequest($pdo, $id);
}

function requestStatusBadge(string $status, ?string $rejectionReason = null): string
{
    $status = normalizeRequestStatus($status);
    $citizenCancelled = $status === 'rejected' && isCitizenCancellationReason($rejectionReason);
    $classes = [
        'pending'       => 'bg-yellow-100 text-yellow-700',
        'processing'    => 'bg-sky-100 text-sky-700',
        'printing'      => 'bg-indigo-100 text-indigo-700',
        'printed'       => 'bg-violet-100 text-violet-700',
        'quality_check' => 'bg-teal-100 text-teal-700',
        'verified'      => 'bg-blue-100 text-blue-700',
        'ready'         => 'bg-green-100 text-green-700',
        'completed'     => 'bg-gray-100 text-gray-600',
        'rejected'      => $citizenCancelled ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-700',
    ];
    $class = $classes[$status] ?? 'bg-gray-100 text-gray-600';
    $label = requestStatusLabel($status, $rejectionReason);

    return '<span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase ' . $class . '">' . htmlspecialchars($label) . '</span>';
}

function formatTimeAgo(string $datetime): string
{
    $ts = strtotime($datetime);
    if ($ts === false) {
        return $datetime;
    }
    return date('g:i A', $ts);
}

function formatDateDisplay(string $date): string
{
    $ts = strtotime($date);
    return $ts ? date('m/d/Y', $ts) : $date;
}

/** Citizen email dates (e.g. September 12, 2026). */
function formatDateEmailDisplay(string $date): string
{
    $dateOnly = trim($date);
    if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $dateOnly, $match)) {
        $dateOnly = $match[1];
    }
    $ts = strtotime($dateOnly);

    return $ts ? date('F j, Y', $ts) : $date;
}

function formatAppointmentEmailDisplay(?string $date, ?string $time): string
{
    if (!$date) {
        return '';
    }
    $out = formatDateEmailDisplay($date);
    if ($time) {
        $ts = strtotime(trim($time));
        $out .= $ts ? ' · ' . date('g:i A', $ts) : '';
    }

    return $out;
}

/** @return list<string> */
function getDocumentCertificateFeeNotes(): array
{
    require_once __DIR__ . '/office_fees.php';

    return getOfficeFeeLines('document_certificate');
}

function documentCertificateFeesSummary(): string
{
    $notes = getDocumentCertificateFeeNotes();

    return $notes !== [] ? implode("\n", $notes) : '';
}

/** @param array<string, mixed> $mail */
function citizenMailWithCertificateFees(array $mail): array
{
    $fees = documentCertificateFeesSummary();
    if ($fees !== '') {
        $mail['fees_summary'] = $fees;
    }

    return $mail;
}

function getDocumentTypes(): array
{
    return [
        ['slug' => 'birth',    'label' => 'Birth Certificate',    'desc' => 'Request your official birth certificate document online.',    'icon' => 'users',     'iconBg' => 'bg-blue-100 text-blue-600'],
        ['slug' => 'death',    'label' => 'Death Certificate',    'desc' => 'Request your official death certificate document online.',    'icon' => 'activity',  'iconBg' => 'bg-teal-100 text-teal-600'],
        ['slug' => 'marriage', 'label' => 'Marriage Certificate', 'desc' => 'Request your official marriage certificate document online.', 'icon' => 'heart',     'iconBg' => 'bg-pink-100 text-pink-500'],
    ];
}

function getAppointmentServices(): array
{
    return [
        ['slug' => 'supplemental-report', 'label' => 'Supplemental Report', 'desc' => 'Add missing birth/death details to existing records.',       'icon' => 'file-signature', 'iconBg' => 'bg-orange-100 text-orange-500'],
        ['slug' => 'report-correction',   'label' => 'Report Correction',   'desc' => 'Correct clerical errors in names, dates, or typos.',          'icon' => 'search',         'iconBg' => 'bg-purple-100 text-purple-500'],
        ['slug' => 'legitimation',        'label' => 'Legitimation',        'desc' => 'Update child status to legitimate after parents marry.',     'icon' => 'users',          'iconBg' => 'bg-blue-100 text-blue-500'],
        ['slug' => 'acknowledgement',     'label' => 'Acknowledgement',     'desc' => 'Official parent acknowledgement of a child.',                'icon' => 'shield-check',   'iconBg' => 'bg-teal-100 text-teal-500'],
        ['slug' => 'delayed-registration-birth', 'label' => 'Delayed Registration of Birth', 'desc' => 'Register a birth beyond the standard reporting period with required affidavit and documents.', 'icon' => 'baby', 'iconBg' => 'bg-sky-100 text-sky-600'],
        ['slug' => 'cenomar',             'label' => 'CENOMAR',             'desc' => 'Certificate of No Marriage - schedule an appointment.',        'icon' => 'file-text',      'iconBg' => 'bg-green-100 text-green-600'],
        ['slug' => 'request-psa-documents', 'label' => 'Request PSA Documents', 'desc' => 'Schedule an appointment to request PSA birth, death, or marriage certificates.', 'icon' => 'file-badge', 'iconBg' => 'bg-indigo-100 text-indigo-600'],
    ];
}

function isAllowedAppointmentServiceSlug(string $slug): bool
{
    $slug = trim($slug);
    if ($slug === '') {
        return false;
    }
    foreach (getAppointmentServices() as $svc) {
        if (($svc['slug'] ?? '') === $slug) {
            return true;
        }
    }

    return false;
}

/** @return array<string, string> option value => label stored on appointments.service_type */
function getPsaDocumentAppointmentTypes(): array
{
    return [
        'psa-birth'    => 'PSA Birth Certificate',
        'psa-death'    => 'PSA Death Certificate',
        'psa-marriage' => 'PSA Marriage Certificate',
    ];
}

function isPsaDocumentsAppointmentService(string $serviceSlug): bool
{
    return trim($serviceSlug) === 'request-psa-documents';
}

function normalizePsaAppointmentServiceType(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    foreach (getPsaDocumentAppointmentTypes() as $key => $label) {
        if ($value === $key || strcasecmp($label, $value) === 0) {
            return $label;
        }
    }

    static $legacyPsaLabels = [
        'PSA Birth'                => 'PSA Birth Certificate',
        'PSA Death'                => 'PSA Death Certificate',
        'PSA Marriage Certificates' => 'PSA Marriage Certificate',
    ];
    if (isset($legacyPsaLabels[$value])) {
        return $legacyPsaLabels[$value];
    }

    return $value;
}

function isAllowedPsaAppointmentServiceType(string $label): bool
{
    return in_array($label, array_values(getPsaDocumentAppointmentTypes()), true);
}

function appointmentServiceLabel(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    static $legacyLabels = [
        'certified-true-copy' => 'Delayed Registration of Birth',
        'Certified True Copy' => 'Delayed Registration of Birth',
    ];
    if (isset($legacyLabels[$value])) {
        return $legacyLabels[$value];
    }

    $psaNormalized = normalizePsaAppointmentServiceType($value);
    if ($psaNormalized !== $value && $psaNormalized !== '') {
        return $psaNormalized;
    }
    foreach (getPsaDocumentAppointmentTypes() as $psaLabel) {
        if ($value === $psaLabel || strcasecmp($value, $psaLabel) === 0) {
            return $psaLabel;
        }
    }

    foreach (getAppointmentServices() as $svc) {
        if ($svc['slug'] === $value || strcasecmp($svc['label'], $value) === 0) {
            return $svc['label'];
        }
    }

    return ucwords(str_replace('-', ' ', $value));
}

function isDocumentRequestAppointment(array $row): bool
{
    return (($row['source'] ?? '') === 'document_request') || !empty($row['tracking_code']);
}

function appointmentStandaloneSql(string $alias = 'a'): string
{
    return "NOT (
        ({$alias}.source = 'document_request' OR ({$alias}.tracking_code IS NOT NULL AND {$alias}.tracking_code != ''))
    )";
}

/**
 * Manage Appointments default date: explicit ?date= wins; otherwise the nearest date
 * with awaiting (scheduled) standalone visits, then today when it has other visits,
 * or the nearest future date with scheduled/confirmed bookings.
 */
function resolveAppointmentsManageDate(PDO $pdo, ?string $requestedDate = null): string
{
    if ($requestedDate !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $requestedDate)) {
        return $requestedDate;
    }

    return appointmentsManageSuggestedDate($pdo, alcrosTodayDate());
}

/** Which overview stat card should show is-active (matches list filter / search results). */
function resolveAppointmentOverviewCardHighlight(
    string $filterStatus,
    string $search,
    array $appointmentRows,
    bool $isFollowUpsView = false
): string {
    if ($isFollowUpsView || $filterStatus === 'follow_ups') {
        return 'follow_ups';
    }
    if ($filterStatus === 'recently_deleted') {
        return 'recently_deleted';
    }

    $search = trim($search);
    if ($search !== '') {
        if (!in_array($filterStatus, ['all', '', 'all_appointments'], true)) {
            return $filterStatus;
        }

        $statusKeys = ['scheduled', 'confirmed', 'completed', 'no_show', 'cancelled'];
        $seen = [];
        foreach ($appointmentRows as $row) {
            $status = (string) ($row['status'] ?? '');
            if ($status !== '') {
                $seen[$status] = true;
            }
        }
        $unique = array_keys($seen);
        if (count($unique) === 1 && in_array($unique[0], $statusKeys, true)) {
            return $unique[0];
        }

        return 'all_appointments';
    }

    if ($filterStatus === 'all' || $filterStatus === '') {
        return 'scheduled';
    }

    return $filterStatus;
}

/** Standalone appointments awaiting staff confirmation on a given date. */
function countAwaitingAppointmentsOnDate(PDO $pdo, string $date): int
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $date = alcrosTodayDate();
    }

    ensureSoftDeleteColumns($pdo);
    $standaloneSql = appointmentStandaloneSql('a');
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM appointments a
         WHERE a.appointment_date = ?
           AND a.status = 'scheduled'
           AND a.deleted_at IS NULL
           AND {$standaloneSql}"
    );
    $stmt->execute([$date]);

    return (int) $stmt->fetchColumn();
}

/** Earliest manage date with awaiting appointments (today/future first, then overdue). */
function nearestAwaitingAppointmentManageDate(PDO $pdo, string $fromDate): ?string
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fromDate)) {
        $fromDate = alcrosTodayDate();
    }

    ensureSoftDeleteColumns($pdo);
    $standaloneSql = appointmentStandaloneSql('a');

    $stmt = $pdo->prepare(
        "SELECT MIN(a.appointment_date) FROM appointments a
         WHERE a.appointment_date >= ?
           AND a.status = 'scheduled'
           AND a.deleted_at IS NULL
           AND {$standaloneSql}"
    );
    $stmt->execute([$fromDate]);
    $next = $stmt->fetchColumn();
    if (is_string($next) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $next)) {
        return $next;
    }

    $stmt = $pdo->prepare(
        "SELECT MIN(a.appointment_date) FROM appointments a
         WHERE a.appointment_date < ?
           AND a.status = 'scheduled'
           AND a.deleted_at IS NULL
           AND {$standaloneSql}"
    );
    $stmt->execute([$fromDate]);
    $past = $stmt->fetchColumn();
    if (is_string($past) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $past)) {
        return $past;
    }

    return null;
}

function appointmentsManageSuggestedDate(PDO $pdo, string $today): string
{
    ensureSoftDeleteColumns($pdo);

    if (countAwaitingAppointmentsOnDate($pdo, $today) > 0) {
        return $today;
    }

    $awaitingDate = nearestAwaitingAppointmentManageDate($pdo, $today);
    if ($awaitingDate !== null) {
        return $awaitingDate;
    }

    if (countSpecialAppointmentsOnDate($pdo, $today) > 0) {
        return $today;
    }

    $standaloneSql = appointmentStandaloneSql('a');
    $stmt = $pdo->prepare(
        "SELECT MIN(a.appointment_date) FROM appointments a
         WHERE a.appointment_date >= ?
           AND a.status IN ('scheduled', 'confirmed')
           AND a.deleted_at IS NULL
           AND {$standaloneSql}"
    );
    $stmt->execute([$today]);
    $next = $stmt->fetchColumn();
    if (is_string($next) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $next)) {
        return $next;
    }

    return $today;
}

/** Appointments that still belong on the dashboard schedule (excludes finished visits). */
function scheduleVisitAppointmentSql(string $alias = 'a'): string
{
    return "{$alias}.status NOT IN ('cancelled', 'no_show', 'completed')
        AND NOT EXISTS (
            SELECT 1 FROM document_requests dr
            WHERE dr.tracking_code = {$alias}.tracking_code
              AND dr.deleted_at IS NULL
              AND dr.status = 'completed'
              AND dr.tracking_code IS NOT NULL
              AND dr.tracking_code != ''
        )";
}

/** Calendar day markers - any non-cancelled visit (includes completed; matches Manage Appointments day view). */
function scheduleCalendarAppointmentSql(string $alias = 'a'): string
{
    return "{$alias}.status NOT IN ('cancelled', 'no_show')";
}

/** Dashboard “Incoming appointments” (tomorrow) - confirmed visits only, not awaiting confirmation. */
function scheduleIncomingAppointmentSql(string $alias = 'a'): string
{
    return "{$alias}.status = 'confirmed'";
}

/** @return 'awaiting'|'confirmed'|'completed'|null */
function scheduleVisitCalendarToneForAppointment(array $row): ?string
{
    $status = (string) ($row['status'] ?? '');
    if (in_array($status, ['cancelled', 'no_show'], true)) {
        return null;
    }

    if (!empty($row['request_status'])) {
        $requestStatus = normalizeRequestStatus((string) $row['request_status']);
        if ($requestStatus === 'completed') {
            return 'completed';
        }
    }

    if ($status === 'completed') {
        return 'completed';
    }

    if ($status === 'confirmed') {
        return 'confirmed';
    }

    return 'awaiting';
}

/** @return 'awaiting'|'confirmed'|'completed'|null */
function scheduleVisitCalendarToneForRequest(array $row): ?string
{
    $status = normalizeRequestStatus((string) ($row['status'] ?? ''));
    if ($status === 'rejected') {
        return null;
    }

    if ($status === 'completed') {
        return 'completed';
    }

    if ($status === 'ready') {
        return 'confirmed';
    }

    return 'awaiting';
}

/**
 * @param array<string, array{awaiting?: int, confirmed?: int, completed?: int}> $buckets
 * @return array<string, array{tone: string, count: int}>
 */
function finalizeScheduleCalendarDateMarkers(array $buckets): array
{
    $map = [];
    foreach ($buckets as $date => $counts) {
        $awaiting = (int) ($counts['awaiting'] ?? 0);
        $confirmed = (int) ($counts['confirmed'] ?? 0);
        $completed = (int) ($counts['completed'] ?? 0);
        $total = $awaiting + $confirmed + $completed;
        if ($total === 0) {
            continue;
        }

        $tone = 'completed';
        if ($awaiting > 0) {
            $tone = 'awaiting';
        } elseif ($confirmed > 0) {
            $tone = 'confirmed';
        }

        $map[$date] = [
            'tone'  => $tone,
            'count' => $total,
        ];
    }

    return $map;
}

/** Active special-service appointments on a date (matches appointment.php list). */
function countSpecialAppointmentsOnDate(PDO $pdo, string $date): int
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $date = date('Y-m-d');
    }

    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM appointments a
         WHERE a.appointment_date = ?
           AND ' . scheduleVisitAppointmentSql('a') . '
           AND ' . appointmentStandaloneSql('a') . '
           AND a.deleted_at IS NULL'
    );
    $stmt->execute([$date]);

    return (int) $stmt->fetchColumn();
}

function countTodaySpecialAppointments(PDO $pdo): int
{
    return countSpecialAppointmentsOnDate($pdo, date('Y-m-d'));
}

function isCitizenCancellationReason(?string $reason): bool
{
    $reason = trim((string) $reason);

    return $reason !== '' && str_starts_with($reason, 'Cancelled by the applicant');
}

function citizenCancelledStatusLabel(): string
{
    return 'Cancelled by citizen';
}

function appointmentDisplayStatusLabel(array $row): string
{
    if (isDocumentRequestAppointment($row) && ($row['status'] ?? '') === 'confirmed') {
        return 'Ready for Pickup';
    }

    return appointmentStatusLabel(
        (string) ($row['status'] ?? 'scheduled'),
        $row['rejection_reason'] ?? null
    );
}

function appointmentStatusWorkflow(): array
{
    return ['scheduled', 'confirmed', 'completed'];
}

/** Staff actions available for the current appointment status. */
function appointmentStatusActionsFor(string $status): array
{
    return match ($status) {
        'scheduled' => ['confirmed', 'cancelled'],
        'confirmed' => ['completed', 'no_show'],
        default     => [],
    };
}

function isAllowedAppointmentStatusTransition(string $fromStatus, string $action): bool
{
    return in_array($action, appointmentStatusActionsFor($fromStatus), true);
}

function appointmentStatusActionLabel(string $action): string
{
    return match ($action) {
        'confirmed' => 'Confirm Appointment',
        'completed' => 'Mark Completed',
        'cancelled' => 'Reject Appointment',
        'no_show'   => 'Mark No-Show',
        default     => appointmentStatusLabel($action),
    };
}

function appointmentStatusLabel(string $status, ?string $rejectionReason = null): string
{
    if ($status === 'cancelled' && isCitizenCancellationReason($rejectionReason)) {
        return citizenCancelledStatusLabel();
    }

    return match ($status) {
        'scheduled' => 'Awaiting confirmation',
        'confirmed' => 'Confirmed',
        'completed' => 'Completed',
        'cancelled' => 'Rejected',
        'no_show'   => 'No Show',
        default     => ucfirst(str_replace('_', ' ', $status)),
    };
}

function appointmentStatusMessage(string $status, ?string $rejectionReason = null): string
{
    $message = match ($status) {
        'scheduled' => 'Your appointment request was received. Our office will confirm your visit - this is not yet a confirmed schedule.',
        'confirmed' => 'Your appointment has been confirmed by our office. Please arrive on time with a valid ID.',
        'completed' => 'This appointment has been completed. Thank you for visiting ALCROS.',
        'cancelled' => 'This appointment was rejected. Contact the office to reschedule.',
        'no_show'   => 'You were marked as a no-show. Please contact the office to reschedule.',
        default     => 'Track your appointment status below.',
    };

    if ($status === 'cancelled') {
        return citizenStatusMessageWithRejectionReason($message, $rejectionReason);
    }

    return $message;
}

function activeAppointmentSlotStatuses(): array
{
    return ['scheduled', 'confirmed'];
}

function normalizeAppointmentTime(string $time): string
{
    $time = trim($time);
    if ($time === '') {
        return '';
    }
    $ts = strtotime('1970-01-01 ' . $time);
    if ($ts === false) {
        return '';
    }

    return date('H:i:s', $ts);
}

function maxDailyAppointmentsLimit(): int
{
    return max(1, (int) getSetting('max_daily_appointments', '20'));
}

function appointmentSlotIntervalMinutes(string $bookingType = 'standalone'): int
{
    return $bookingType === 'certificate' ? 10 : 20;
}

function normalizeAppointmentBookingType(string $bookingType): string
{
    return $bookingType === 'certificate' ? 'certificate' : 'standalone';
}

function recurringOfficeHolidaySuffixes(): array
{
    return [
        '-01-01',
        '-04-09',
        '-05-01',
        '-06-12',
        '-08-21',
        '-11-01',
        '-11-02',
        '-11-30',
        '-12-25',
        '-12-30',
        '-12-31',
    ];
}

function officeHolidayDatesFromSettings(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cache = [];
    $raw = trim(getSetting('office_holidays', ''));
    if ($raw === '') {
        return $cache;
    }

    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        foreach ($decoded as $date) {
            if (is_string($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                $cache[] = $date;
            }
        }
    } else {
        foreach (preg_split('/[\s,;]+/', $raw) ?: [] as $date) {
            $date = trim($date);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                $cache[] = $date;
            }
        }
    }

    $cache = array_values(array_unique($cache));

    return $cache;
}

function philippineNationalHeroesDayDate(int $year): string
{
    $cursor = new DateTimeImmutable(sprintf('%d-08-31', $year));
    while ((int) $cursor->format('N') !== 1) {
        $cursor = $cursor->modify('-1 day');
    }

    return $cursor->format('Y-m-d');
}

/** Movable regular holidays (Maundy Thursday, Good Friday, National Heroes Day). */
function philippineMovableHolidayDates(int $year): array
{
    static $cache = [];

    if (isset($cache[$year])) {
        return $cache[$year];
    }

    $dates = [philippineNationalHeroesDayDate($year)];

    if (function_exists('easter_days')) {
        try {
            $easter = (new DateTimeImmutable(sprintf('%d-03-21', $year)))->modify('+' . easter_days($year) . ' days');
            $dates[] = $easter->modify('-3 days')->format('Y-m-d');
            $dates[] = $easter->modify('-2 days')->format('Y-m-d');
        } catch (Throwable $e) {
            // Non-fatal when date math fails.
        }
    }

    $cache[$year] = array_values(array_unique($dates));

    return $cache[$year];
}

function isOfficeHoliday(string $date): bool
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return false;
    }

    if (in_array($date, officeHolidayDatesFromSettings(), true)) {
        return true;
    }

    if (in_array($date, philippineMovableHolidayDates((int) substr($date, 0, 4)), true)) {
        return true;
    }

    return in_array(substr($date, 4), recurringOfficeHolidaySuffixes(), true);
}

/** Holiday rules for citizen date pickers (matches server `officeDateBlockReason`). */
function officeHolidayClientConfig(int $yearsAhead = 2): array
{
    $year = (int) date('Y');
    $extraDates = officeHolidayDatesFromSettings();
    for ($y = $year; $y <= $year + max(0, $yearsAhead); $y++) {
        $extraDates = array_merge($extraDates, philippineMovableHolidayDates($y));
    }

    return [
        'recurring' => recurringOfficeHolidaySuffixes(),
        'dates'     => array_values(array_unique($extraDates)),
        'today'     => date('Y-m-d'),
    ];
}

function officeDateBlockReason(string $date): ?string
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return 'invalid';
    }
    if ($date < date('Y-m-d')) {
        return 'past';
    }

    $dow = (int) date('N', strtotime($date));
    if ($dow >= 6) {
        return 'weekend';
    }
    if (isOfficeHoliday($date)) {
        return 'holiday';
    }

    return null;
}

function appointmentTimeSlotOptions(int $intervalMinutes): array
{
    $intervalMinutes = max(1, $intervalMinutes);
    $slots = [];

    foreach ([['08:00', '12:00'], ['13:00', '17:00']] as $window) {
        $cursor = strtotime('1970-01-01 ' . $window[0] . ':00');
        $end = strtotime('1970-01-01 ' . $window[1] . ':00');
        while ($cursor + ($intervalMinutes * 60) <= $end) {
            $slots[] = date('H:i', $cursor);
            $cursor += $intervalMinutes * 60;
        }
    }

    return $slots;
}

function formatAppointmentSlotLabel(string $time): string
{
    $normalized = normalizeAppointmentTime($time);
    if ($normalized === '') {
        return $time;
    }

    return date('g:i A', strtotime('1970-01-01 ' . $normalized));
}

function isValidAppointmentSlot(string $time, string $bookingType = 'standalone'): bool
{
    $normalized = normalizeAppointmentTime($time);
    if ($normalized === '') {
        return false;
    }

    $slot = substr($normalized, 0, 5);
    $interval = appointmentSlotIntervalMinutes(normalizeAppointmentBookingType($bookingType));

    return in_array($slot, appointmentTimeSlotOptions($interval), true);
}

/** @return list<string> HH:MM slot labels for one public booking calendar. */
function normalizeVisitSlotTimeList(array $times): array
{
    $times = array_values(array_unique(array_map(
        static fn (string $time): string => substr(normalizeAppointmentTime($time), 0, 5),
        array_filter($times, static fn ($time) => is_string($time) && $time !== '')
    )));
    sort($times);

    return $times;
}

/** Certificate pickup visits (document requests) - separate from standalone appointments. */
function getBookedVisitTimesForCalendar(PDO $pdo, string $date, string $bookingType): array
{
    $bookingType = normalizeAppointmentBookingType($bookingType);

    if ($bookingType === 'certificate') {
        $reqStmt = $pdo->prepare(
            "SELECT TIME_FORMAT(dr.appointment_time, '%H:%i') AS slot_time
             FROM document_requests dr
             WHERE dr.appointment_date = ?
               AND dr.appointment_time IS NOT NULL
               AND dr.appointment_time != ''
               AND " . documentRequestHoldsVisitSlotSql('dr') . '
             ORDER BY dr.appointment_time ASC'
        );
        $reqStmt->execute([$date]);

        return normalizeVisitSlotTimeList(array_column($reqStmt->fetchAll(), 'slot_time'));
    }

    $statuses = activeAppointmentSlotStatuses();
    $placeholders = implode(',', array_fill(0, count($statuses), '?'));
    $standaloneSql = appointmentStandaloneSql('appointments');
    $stmt = $pdo->prepare(
        "SELECT TIME_FORMAT(appointment_time, '%H:%i') AS slot_time
         FROM appointments
         WHERE appointment_date = ?
           AND status IN ($placeholders)
           AND deleted_at IS NULL
           AND $standaloneSql
         ORDER BY appointment_time ASC"
    );
    $stmt->execute(array_merge([$date], $statuses));

    return normalizeVisitSlotTimeList(array_column($stmt->fetchAll(), 'slot_time'));
}

function countActiveAppointmentsOnDate(PDO $pdo, string $date): int
{
    $statuses = activeAppointmentSlotStatuses();
    $placeholders = implode(',', array_fill(0, count($statuses), '?'));
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM appointments WHERE appointment_date = ? AND status IN ($placeholders) AND deleted_at IS NULL"
    );
    $stmt->execute(array_merge([$date], $statuses));

    return (int) $stmt->fetchColumn();
}

/** Distinct visit times occupied on a date for one public booking calendar. */
function countOccupiedVisitSlotsOnDate(PDO $pdo, string $date, string $bookingType = 'standalone'): int
{
    return count(getBookedVisitTimesForCalendar($pdo, $date, $bookingType));
}

function appointmentSlotTimeMatchesSql(string $column): string
{
    return "TIME_FORMAT($column, '%H:%i:%s') = ?";
}

/**
 * Linked appointment on the same visit date/time as the request (any resolved visit row).
 * When true, the document_requests row must not hold the slot - active visits use appointments;
 * cancelled / no_show / completed rows release the slot.
 */
function documentRequestVisitSlotCoveredByLinkedAppointmentSql(string $drAlias = 'dr', string $aAlias = 'a'): string
{
    $statuses = ['scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'];
    $quoted = implode(', ', array_map(
        static fn (string $status): string => "'" . str_replace("'", "''", $status) . "'",
        $statuses
    ));

    return "EXISTS (
        SELECT 1 FROM appointments $aAlias
        WHERE $aAlias.tracking_code = $drAlias.tracking_code
          AND $aAlias.deleted_at IS NULL
          AND $aAlias.appointment_date = $drAlias.appointment_date
          AND TIME_FORMAT($aAlias.appointment_time, '%H:%i:%s') = TIME_FORMAT($drAlias.appointment_time, '%H:%i:%s')
          AND $aAlias.status IN ($quoted)
    )";
}

/** SQL condition: document_requests row still reserves a visit slot. */
function documentRequestHoldsVisitSlotSql(string $drAlias = 'dr'): string
{
    $covered = documentRequestVisitSlotCoveredByLinkedAppointmentSql($drAlias);

    return "$drAlias.deleted_at IS NULL
           AND $drAlias.status NOT IN ('rejected', 'completed')
           AND NOT ($covered)";
}

/**
 * Whether another booking already holds this date/time.
 *
 * @param ?string $excludeTrackingCode Ignore holds tied to this document request tracking code
 * @param ?int    $excludeAppointmentId Ignore this appointment row (e.g. when re-confirming the same visit)
 */
function appointmentSlotIsTaken(
    PDO $pdo,
    string $date,
    string $time,
    ?string $excludeTrackingCode = null,
    ?int $excludeAppointmentId = null,
    bool $lockRows = false,
    string $bookingType = 'standalone'
): bool {
    $normalized = normalizeAppointmentTime($time);
    if ($normalized === '') {
        return true;
    }

    ensureSoftDeleteColumns($pdo);
    $bookingType = normalizeAppointmentBookingType($bookingType);
    $lock = $lockRows ? ' FOR UPDATE' : '';

    if ($bookingType === 'certificate') {
        $reqSql = 'SELECT COUNT(*) FROM document_requests dr
             WHERE dr.appointment_date = ?
               AND ' . appointmentSlotTimeMatchesSql('dr.appointment_time') . '
               AND ' . documentRequestHoldsVisitSlotSql('dr');
        $reqParams = [$date, $normalized];
        if ($excludeTrackingCode !== null && $excludeTrackingCode !== '') {
            $reqSql .= ' AND dr.tracking_code != ?';
            $reqParams[] = $excludeTrackingCode;
        }
        $reqSql .= $lock;

        $reqStmt = $pdo->prepare($reqSql);
        $reqStmt->execute($reqParams);

        return (int) $reqStmt->fetchColumn() > 0;
    }

    $statuses = activeAppointmentSlotStatuses();
    $placeholders = implode(',', array_fill(0, count($statuses), '?'));
    $standaloneSql = appointmentStandaloneSql('appointments');
    $apptSql = "SELECT COUNT(*) FROM appointments
            WHERE appointment_date = ?
              AND " . appointmentSlotTimeMatchesSql('appointment_time') . "
              AND status IN ($placeholders)
              AND deleted_at IS NULL
              AND $standaloneSql";
    $apptParams = array_merge([$date, $normalized], $statuses);
    if ($excludeAppointmentId !== null && $excludeAppointmentId > 0) {
        $apptSql .= ' AND id != ?';
        $apptParams[] = $excludeAppointmentId;
    }
    $apptSql .= $lock;

    $apptStmt = $pdo->prepare($apptSql);
    $apptStmt->execute($apptParams);

    return (int) $apptStmt->fetchColumn() > 0;
}

function isAppointmentSlotTaken(
    PDO $pdo,
    string $date,
    string $time,
    ?int $excludeId = null,
    string $bookingType = 'standalone'
): bool {
    return appointmentSlotIsTaken($pdo, $date, $time, null, $excludeId, false, $bookingType);
}

/**
 * @throws RuntimeException when another booking holds the slot
 */
function ensureVisitSlotAvailableForWrite(
    PDO $pdo,
    string $date,
    string $time,
    ?string $excludeTrackingCode = null,
    ?int $excludeAppointmentId = null,
    bool $lockRows = false,
    string $bookingType = 'standalone'
): void {
    if (appointmentSlotIsTaken($pdo, $date, $time, $excludeTrackingCode, $excludeAppointmentId, $lockRows, $bookingType)) {
        throw new RuntimeException('Visit slot conflict: another booking already uses this date and time.');
    }
}

function appointmentDayLockKey(string $date, string $bookingType = 'standalone'): string
{
    $bookingType = normalizeAppointmentBookingType($bookingType);

    return 'alcros_visit_day:' . $bookingType . ':' . $date;
}

function acquireAppointmentDayLock(PDO $pdo, string $date, int $timeoutSeconds = 10, string $bookingType = 'standalone'): bool
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return false;
    }

    $stmt = $pdo->prepare('SELECT GET_LOCK(?, ?)');
    $stmt->execute([appointmentDayLockKey($date, $bookingType), max(1, $timeoutSeconds)]);

    return (int) $stmt->fetchColumn() === 1;
}

function releaseAppointmentDayLock(PDO $pdo, string $date, string $bookingType = 'standalone'): void
{
    $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)');
    $stmt->execute([appointmentDayLockKey($date, $bookingType)]);
}

function buildAppointmentAvailability(PDO $pdo, string $date, string $bookingType = 'standalone'): array
{
    ensureSoftDeleteColumns($pdo);

    $bookingType = normalizeAppointmentBookingType($bookingType);
    $interval = appointmentSlotIntervalMinutes($bookingType);
    $blockReason = officeDateBlockReason($date);
    $bookedTimes = $blockReason === null ? getBookedVisitTimesForCalendar($pdo, $date, $bookingType) : [];
    $bookedLookup = array_fill_keys($bookedTimes, true);
    $count = $blockReason === null ? count($bookedTimes) : 0;
    $maxDaily = maxDailyAppointmentsLimit();
    $dateFull = $blockReason === null && $count >= $maxDaily;

    if ($dateFull) {
        $blockReason = 'full';
    }

    $morningSlots = [];
    $afternoonSlots = [];
    $today = date('Y-m-d');
    $nowSlot = date('H:i');

    foreach (appointmentTimeSlotOptions($interval) as $slot) {
        $isBooked = isset($bookedLookup[$slot]);
        $isPastToday = $date === $today && $slot <= $nowSlot;
        $available = $blockReason === null && !$isBooked && !$isPastToday;

        if ($available) {
            $status = 'available';
        } elseif ($blockReason !== null) {
            $status = 'unavailable';
        } elseif ($isPastToday) {
            $status = 'past';
        } elseif ($isBooked) {
            $status = 'booked';
        } else {
            $status = 'unavailable';
        }

        $entry = [
            'value'     => $slot,
            'label'     => formatAppointmentSlotLabel($slot),
            'available' => $available,
            'status'    => $status,
        ];

        if ((int) substr($slot, 0, 2) < 12) {
            $morningSlots[] = $entry;
        } else {
            $afternoonSlots[] = $entry;
        }
    }

    return [
        'date'              => $date,
        'booking_type'      => $bookingType,
        'interval_minutes'  => $interval,
        'bookable'          => $blockReason === null && !$dateFull,
        'blocked_reason'    => $blockReason,
        'date_full'         => $dateFull,
        'office_weekday'    => $blockReason !== 'weekend',
        'booked_times'      => $bookedTimes,
        'count'             => $count,
        'max_daily'         => $maxDaily,
        'morning_slots'     => $morningSlots,
        'afternoon_slots'   => $afternoonSlots,
    ];
}

function validateAppointmentBooking(
    PDO $pdo,
    string $date,
    string $time,
    ?string $email = null,
    bool $lockRows = false,
    string $bookingType = 'standalone'
): ?string {
    $bookingType = normalizeAppointmentBookingType($bookingType);

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return 'Please choose a valid appointment date.';
    }
    if ($date < date('Y-m-d')) {
        return 'Appointment date cannot be in the past.';
    }

    $blockReason = officeDateBlockReason($date);
    if ($blockReason === 'weekend') {
        return 'Appointments are available Monday to Friday only.';
    }
    if ($blockReason === 'holiday') {
        return 'This date is a non-working holiday. Please choose another day.';
    }
    if ($blockReason !== null) {
        return 'Please choose a valid appointment date.';
    }

    if (!isValidAppointmentSlot($time, $bookingType)) {
        $interval = appointmentSlotIntervalMinutes($bookingType);
        return $bookingType === 'certificate'
            ? "Please choose a valid pickup time slot (every {$interval} minutes, 8:00 AM–12:00 NN and 1:00–5:00 PM)."
            : "Please choose a valid appointment time slot (every {$interval} minutes, 8:00 AM–12:00 NN and 1:00–5:00 PM).";
    }

    $normalized = normalizeAppointmentTime($time);
    if ($normalized === '') {
        return 'Please choose a valid appointment time.';
    }

    if ($date === date('Y-m-d') && substr($normalized, 0, 5) <= date('H:i')) {
        return 'Please choose a future time slot today, or select another date.';
    }

    if (appointmentSlotIsTaken($pdo, $date, $normalized, null, null, $lockRows, $bookingType)) {
        return 'This time slot is already booked. Please choose another date or time.';
    }

    $maxDaily = maxDailyAppointmentsLimit();
    if (countOccupiedVisitSlotsOnDate($pdo, $date, $bookingType) >= $maxDaily) {
        return 'No appointment slots remain on this date. Please choose another day.';
    }

    if ($email !== null && $email !== '') {
        $normalizedEmail = normalizeGmail($email);
        if ($bookingType === 'certificate') {
            ensureSoftDeleteColumns($pdo);
            $reqEmailStmt = $pdo->prepare(
                'SELECT tracking_code FROM document_requests
                 WHERE appointment_date = ? AND ' . appointmentSlotTimeMatchesSql('appointment_time') . ' AND email = ?
                   AND deleted_at IS NULL AND status NOT IN (\'rejected\', \'completed\') LIMIT 1'
            );
            $reqEmailStmt->execute([$date, $normalized, $normalizedEmail]);
            if ($reqEmailStmt->fetchColumn()) {
                return 'You already have a request at this date and time.';
            }
        } else {
            $statuses = activeAppointmentSlotStatuses();
            $statusList = "'" . implode("','", $statuses) . "'";
            $standaloneSql = appointmentStandaloneSql('appointments');
            $emailStmt = $pdo->prepare(
                "SELECT appointment_code FROM appointments
                 WHERE appointment_date = ? AND " . appointmentSlotTimeMatchesSql('appointment_time') . ' AND email = ?
                   AND status IN (' . $statusList . ') AND deleted_at IS NULL AND ' . $standaloneSql . ' LIMIT 1'
            );
            $emailStmt->execute([$date, $normalized, $normalizedEmail]);
            if ($emailStmt->fetchColumn()) {
                return 'You already have an appointment at this date and time.';
            }
        }
    }

    return null;
}

function appointmentSlotLockKey(string $date, string $time, string $bookingType = 'standalone'): string
{
    $normalized = normalizeAppointmentTime($time);
    $bookingType = normalizeAppointmentBookingType($bookingType);

    return 'alcros_slot:' . $bookingType . ':' . $date . ':' . ($normalized !== '' ? $normalized : $time);
}

function acquireAppointmentSlotLock(
    PDO $pdo,
    string $date,
    string $time,
    int $timeoutSeconds = 10,
    string $bookingType = 'standalone'
): bool {
    $key = appointmentSlotLockKey($date, $time, $bookingType);
    $stmt = $pdo->prepare('SELECT GET_LOCK(?, ?)');
    $stmt->execute([$key, max(1, $timeoutSeconds)]);

    return (int) $stmt->fetchColumn() === 1;
}

function releaseAppointmentSlotLock(PDO $pdo, string $date, string $time, string $bookingType = 'standalone'): void
{
    $key = appointmentSlotLockKey($date, $time, $bookingType);
    $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)');
    $stmt->execute([$key]);
}

function appointmentStatusBadge(string $status, ?string $rejectionReason = null): string
{
    $citizenCancelled = $status === 'cancelled' && isCitizenCancellationReason($rejectionReason);
    $classes = [
        'scheduled' => 'bg-blue-100 text-blue-700',
        'confirmed' => 'bg-purple-100 text-purple-700',
        'completed' => 'bg-gray-100 text-gray-600',
        'cancelled' => $citizenCancelled ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-700',
        'no_show'   => 'bg-amber-100 text-amber-700',
    ];
    $class = $classes[$status] ?? 'bg-gray-100 text-gray-600';

    return '<span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase ' . $class . '">'
        . htmlspecialchars(appointmentStatusLabel($status, $rejectionReason)) . '</span>';
}

function appointmentStatusProgressIndex(string $status): int|false
{
    if (in_array($status, ['cancelled', 'no_show'], true)) {
        return false;
    }
    $idx = array_search($status, appointmentStatusWorkflow(), true);

    return $idx === false ? false : (int) $idx;
}

function getPurposeOptions(): array
{
    return [
        'passport'      => 'Passport Application',
        'employment'    => 'Employment Requirement',
        'school'        => 'School Enrollment',
        'legal'         => 'Legal Proceedings',
        'insurance'     => 'Insurance Claim',
        'travel'        => 'Travel Abroad',
        'personal'      => 'Personal Record',
        'other'         => 'Other',
    ];
}

function isValidPhilippineMobile(string $phone): bool
{
    return (bool) preg_match('/^09\d{9}$/', $phone);
}

function isValidGmail(string $email): bool
{
    return (bool) preg_match('/^[a-zA-Z0-9._%+-]+@gmail\.com$/i', $email);
}

function normalizeGmail(string $email): string
{
    return strtolower(trim($email));
}

function markGmailVerified(string $email): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['alcros_email_verified'] = [
        'email'   => normalizeGmail($email),
        'expires' => time() + 7200,
    ];
}

function getFirebaseWebApiKey(): string
{
    $configFile = __DIR__ . '/../config/google.php';
    if (is_file($configFile) && !defined('FIREBASE_WEB_API_KEY')) {
        require_once $configFile;
    }
    return defined('FIREBASE_WEB_API_KEY') ? trim((string) FIREBASE_WEB_API_KEY) : '';
}

/** Same check Google uses on the signup form - username taken means Gmail is active. */
function gmailExistsViaSignupValidator(string $email): ?bool
{
    if (!function_exists('curl_init')) {
        return null;
    }

    $username = explode('@', normalizeGmail($email))[0];
    if ($username === '') {
        return false;
    }

    $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    $signupUrl = 'https://accounts.google.com/signup/v2/createaccount?flowName=GlifWebSignIn&flowEntry=SignUp&hl=en';

    $ch = curl_init($signupUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_HEADER         => true,
        CURLOPT_USERAGENT      => $userAgent,
    ]);
    $page = curl_exec($ch);
    curl_close($ch);

    if ($page === false) {
        return null;
    }

    preg_match_all('/^Set-Cookie:\s*([^;\r\n]+)/mi', $page, $cookieMatches);
    $cookieHeader = implode('; ', $cookieMatches[1] ?? []);
    if ($cookieHeader === '') {
        return null;
    }

    $payload = json_encode([
        'input01' => [
            'Input'        => 'GmailAddress',
            'GmailAddress' => $username,
            'FirstName'    => '',
            'LastName'     => '',
        ],
        'Locale' => 'en',
    ]);

    $ch = curl_init('https://accounts.google.com/InputValidator?resource=SignUp');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Origin: https://accounts.google.com',
            'Referer: ' . $signupUrl,
            'User-Agent: ' . $userAgent,
            'Cookie: ' . $cookieHeader,
        ],
    ]);
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false || $httpCode !== 200) {
        return null;
    }

    $data = json_decode($response, true);
    if (!is_array($data) || !isset($data['input01']['Valid'])) {
        return null;
    }

    $valid = $data['input01']['Valid'];
    // Signup API: Valid=false → username already taken → active Gmail.
    if ($valid === false || $valid === 'false') {
        return true;
    }
    if ($valid === true || $valid === 'true') {
        return false;
    }

    return null;
}

/** Gmail MX servers used for SMTP verification. */
function gmailMxHosts(): array
{
    $hosts = [];
    if (getmxrr('gmail.com', $hosts) && $hosts !== []) {
        return $hosts;
    }
    return ['gmail-smtp-in.l.google.com'];
}

/**
 * Check mailbox via SMTP RCPT (no email is sent to the user).
 * Returns true = exists, false = not found, null = could not check.
 */
function smtpRcptCheck(string $host, string $email): ?bool
{
    $errno = 0;
    $errstr = '';
    $fp = @stream_socket_client('tcp://' . $host . ':25', $errno, $errstr, 10);
    if (!$fp) {
        return null;
    }

    stream_set_timeout($fp, 10);

    $read = static function () use ($fp): string {
        $data = '';
        while ($line = fgets($fp, 512)) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return $data;
    };

    $write = static function (string $cmd) use ($fp): void {
        fwrite($fp, $cmd . "\r\n");
    };

    $banner = $read();
    if ($banner === '' || (int) substr($banner, 0, 3) !== 220) {
        fclose($fp);
        return null;
    }

    $write('EHLO alcros.local');
    if ((int) substr($read(), 0, 3) !== 250) {
        fclose($fp);
        return null;
    }

    $write('MAIL FROM:<>');
    if ((int) substr($read(), 0, 3) !== 250) {
        fclose($fp);
        return null;
    }

    $write('RCPT TO:<' . $email . '>');
    $rcpt = $read();
    $write('QUIT');
    fclose($fp);

    $code = (int) substr($rcpt, 0, 3);
    if (in_array($code, [250, 251], true)) {
        return true;
    }
    if (in_array($code, [550, 551, 552, 553, 554], true)) {
        return false;
    }

    return null;
}

function gmailExistsViaSmtp(string $email): ?bool
{
    foreach (gmailMxHosts() as $host) {
        $result = smtpRcptCheck($host, $email);
        if ($result !== null) {
            return $result;
        }
    }
    return null;
}

/** HTTPS check - works on localhost where port 25 is often blocked. */
function gmailExistsViaHttp(string $email): ?bool
{
    if (!function_exists('curl_init')) {
        return null;
    }

    $url = 'https://mail.google.com/mail/gxlu?email=' . urlencode($email);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_NOBODY         => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; ALCROS/1.0)',
        CURLOPT_HEADER         => true,
    ]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    curl_close($ch);

    if ($response === false || $errno !== 0) {
        return null;
    }

    if (preg_match('/^set-cookie:/im', $response)) {
        return true;
    }

    // Google no longer sends Set-Cookie on this endpoint - result is inconclusive, not "not found".
    if (preg_match('/^HTTP\/[\d.]+ 204/m', $response)) {
        return null;
    }

    if (preg_match('/^HTTP\/[\d.]+ (\d+)/m', $response, $match)) {
        $status = (int) $match[1];
        if ($status >= 200 && $status < 400) {
            return null;
        }
    }

    return null;
}

/** Firebase Identity Toolkit - reliable HTTPS check (works on XAMPP). */
function gmailExistsViaFirebase(string $email): ?bool
{
    $apiKey = getFirebaseWebApiKey();
    if ($apiKey === '') {
        return null;
    }

    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scheme = function_exists('alcrosRequestScheme') ? alcrosRequestScheme() : (((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'));
    $continueUri = $scheme . '://' . $host . '/';

    $url = 'https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=' . urlencode($apiKey);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode([
            'identifier'  => $email,
            'continueUri' => $continueUri,
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === false) {
        return null;
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return null;
    }
    if (array_key_exists('registered', $data)) {
        return (bool) $data['registered'];
    }
    if (isset($data['error'])) {
        return null;
    }

    return null;
}

/** Returns true if active, false if not found, null if check failed. */
function gmailAccountIsActive(string $email): ?bool
{
    foreach ([
        'gmailExistsViaSignupValidator',
        'gmailExistsViaFirebase',
        'gmailExistsViaSmtp',
        'gmailExistsViaHttp',
    ] as $checker) {
        $result = $checker($email);
        if ($result !== null) {
            return $result;
        }
    }

    return null;
}

/** Verify typed Gmail for the request form - no Google Sign-In required. */
function verifyActiveGmailAccount(string $email): array
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $email = normalizeGmail($email);
    if (!isValidGmail($email)) {
        return ['ok' => false, 'error' => 'Please enter a valid @gmail.com address.'];
    }

    $active = gmailAccountIsActive($email);

    if ($active === true) {
        markGmailVerified($email);
        return [
            'ok'      => true,
            'email'   => $email,
            'message' => 'Gmail verified - this is an active Google account.',
        ];
    }

    if ($active === false) {
        return [
            'ok'    => false,
            'error' => 'This Gmail is not an active Google account. Check the spelling or try another Gmail.',
        ];
    }

    return [
        'ok'    => false,
        'error' => 'Could not verify right now. Check your internet connection and try again in a moment.',
    ];
}

function isGmailVerifiedInSession(string $email): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $email = normalizeGmail($email);
    $verified = $_SESSION['alcros_email_verified'] ?? null;
    if (!$verified || ($verified['email'] ?? '') !== $email) {
        return false;
    }
    if (time() > (int) ($verified['expires'] ?? 0)) {
        unset($_SESSION['alcros_email_verified']);
        return false;
    }
    return true;
}

function formatPersonName(?string $first, ?string $middle = null, ?string $last = null): string
{
    $parts = array_filter([
        trim((string) $first),
        trim((string) ($middle ?? '')),
        trim((string) ($last ?? '')),
    ], static fn ($part) => $part !== '');

    return implode(' ', $parts);
}

function personNamePartsFromInput(array $input, string $prefix = ''): array
{
    return [
        'first_name'  => trim((string) ($input[$prefix . 'first_name'] ?? '')),
        'middle_name' => trim((string) ($input[$prefix . 'middle_name'] ?? '')) ?: null,
        'last_name'   => trim((string) ($input[$prefix . 'last_name'] ?? '')),
    ];
}

function validatePersonNameParts(array $parts): ?string
{
    $parts = normalizeCitizenNameParts($parts);
    if ($parts['first_name'] === '' || $parts['last_name'] === '') {
        return 'First and last name are required. Middle name is optional.';
    }

    return null;
}

/** Match registry name to citizen input; middle name is optional when the citizen leaves it blank. */
function personNamePartsMatchOptionalMiddle(
    string $inputFirst,
    ?string $inputMiddle,
    string $inputLast,
    string $recordFirst,
    ?string $recordMiddle,
    string $recordLast
): bool {
    $inputFirst = trim($inputFirst);
    $inputLast = trim($inputLast);
    $recordFirst = trim($recordFirst);
    $recordLast = trim($recordLast);
    if ($inputFirst === '' || $inputLast === '' || $recordFirst === '' || $recordLast === '') {
        return false;
    }

    if (normalizePersonName($inputFirst) !== normalizePersonName($recordFirst)) {
        return false;
    }
    if (normalizePersonName($inputLast) !== normalizePersonName($recordLast)) {
        return false;
    }

    $inputMiddle = trim((string) ($inputMiddle ?? ''));
    $recordMiddle = trim((string) ($recordMiddle ?? ''));
    if ($inputMiddle === '') {
        return true;
    }

    return normalizePersonName($inputMiddle) === normalizePersonName($recordMiddle);
}

function normalizeCitizenNameParts(array $parts): array
{
    return [
        'first_name'  => trim((string) ($parts['first_name'] ?? '')),
        'middle_name' => trim((string) ($parts['middle_name'] ?? '')) ?: null,
        'last_name'   => trim((string) ($parts['last_name'] ?? '')),
    ];
}

function verifiedSessionNameMatches(string $verifiedNormalized, array $parts): bool
{
    $parts = normalizeCitizenNameParts($parts);
    $full = normalizePersonName(formatPersonName($parts['first_name'], $parts['middle_name'], $parts['last_name']));
    if ($full === $verifiedNormalized) {
        return true;
    }
    if (trim((string) ($parts['middle_name'] ?? '')) === '') {
        $withoutMiddle = normalizePersonName(formatPersonName($parts['first_name'], null, $parts['last_name']));

        return $withoutMiddle === $verifiedNormalized;
    }

    return false;
}

function personNameFromRow(array $row): string
{
    if (isset($row['first_name']) || isset($row['middle_name']) || isset($row['last_name'])) {
        return formatPersonName(
            (string) ($row['first_name'] ?? ''),
            $row['middle_name'] ?? null,
            (string) ($row['last_name'] ?? '')
        );
    }

    return trim((string) ($row['citizen_name'] ?? $row['person_name'] ?? ''));
}

/**
 * Official name from the matched LCRO civil registry record (not the identification form input).
 */
function documentRequestNameOnRecord(array $row, ?PDO $pdo = null): string
{
    if ($pdo === null) {
        try {
            $pdo = getDB();
        } catch (Throwable $e) {
            return '-';
        }
    }

    if (!function_exists('resolveCivilRecordForRequest')) {
        require_once __DIR__ . '/printing.php';
    }

    $record = resolveCivilRecordForRequest($pdo, $row);
    if ($record === null || empty($record['id']) || (($record['_print_source'] ?? '') === 'request')) {
        return '-';
    }

    $display = civilRecordDisplayName($record);

    return ($display !== '' && $display !== '-') ? $display : '-';
}

/** Person who submitted the certificate request (distinct from name on the certificate). */
function personRequesterNameFromRow(array $row): string
{
    if (!array_key_exists('requester_first_name', $row)
        && !array_key_exists('requester_middle_name', $row)
        && !array_key_exists('requester_last_name', $row)) {
        return '';
    }

    return formatPersonName(
        (string) ($row['requester_first_name'] ?? ''),
        $row['requester_middle_name'] ?? null,
        (string) ($row['requester_last_name'] ?? '')
    );
}

/** Salutation name for citizen email/SMS (requester on document requests when set). */
function citizenNotifyPersonName(array $row): string
{
    $requester = personRequesterNameFromRow($row);
    if ($requester !== '') {
        return $requester;
    }

    return personNameFromRow($row);
}

function ensureDocumentRequestRequesterColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $pdo->query('SELECT requester_first_name FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec(
                'ALTER TABLE document_requests
                 ADD COLUMN requester_first_name VARCHAR(80) DEFAULT NULL AFTER last_name,
                 ADD COLUMN requester_middle_name VARCHAR(80) DEFAULT NULL AFTER requester_first_name,
                 ADD COLUMN requester_last_name VARCHAR(80) DEFAULT NULL AFTER requester_middle_name'
            );
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT requester_relationship FROM document_requests LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec(
                'ALTER TABLE document_requests
                 ADD COLUMN requester_relationship VARCHAR(40) DEFAULT NULL AFTER requester_last_name'
            );
        } catch (Throwable $ignored) {
        }
    }
}

function civilRecordDisplayName(array $row): string
{
    if (($row['record_type'] ?? '') === 'marriage') {
        $husband = trim((string) ($row['husband_name'] ?? ''));
        $wife = trim((string) ($row['wife_name'] ?? ''));
        if ($husband !== '' && $wife !== '') {
            return $husband . ' & ' . $wife;
        }
    }

    $name = personNameFromRow($row);

    return $name !== '' ? $name : '-';
}

function parsePersonNameToParts(string $full): array
{
    $full = trim($full);
    if ($full === '') {
        return ['first_name' => '', 'middle_name' => null, 'last_name' => ''];
    }

    if (str_contains($full, ',')) {
        [$last, $rest] = array_map('trim', explode(',', $full, 2));
        $restParts = preg_split('/\s+/', trim($rest)) ?: [];

        return [
            'first_name'  => $restParts[0] ?? '',
            'middle_name' => count($restParts) > 1 ? implode(' ', array_slice($restParts, 1)) : null,
            'last_name'   => $last,
        ];
    }

    $parts = preg_split('/\s+/', $full) ?: [];
    if (count($parts) === 1) {
        return ['first_name' => $parts[0], 'middle_name' => null, 'last_name' => ''];
    }
    if (count($parts) === 2) {
        return ['first_name' => $parts[0], 'middle_name' => null, 'last_name' => $parts[1]];
    }

    return [
        'first_name'  => $parts[0],
        'middle_name' => implode(' ', array_slice($parts, 1, -1)),
        'last_name'   => $parts[count($parts) - 1],
    ];
}

function normalizePersonNameParts(?string $first, ?string $middle, ?string $last): string
{
    return normalizePersonName(formatPersonName($first, $middle, $last));
}

function citizenNameFromPost(array $post): string
{
    if (trim((string) ($post['citizen_name'] ?? '')) !== '') {
        return trim((string) $post['citizen_name']);
    }

    $parts = personNamePartsFromInput($post);

    return formatPersonName($parts['first_name'], $parts['middle_name'], $parts['last_name']);
}

function ensurePersonNamePartColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $requiredTables = [
        'document_requests' => true,
        'appointments'      => true,
        'queue_tickets'     => false,
        'civil_records'     => false,
        'staff'             => true,
    ];

    foreach ($requiredTables as $table => $namesRequired) {
        migrateTablePersonNameParts($pdo, $table, $namesRequired);
    }
}

function legacyNameColumnForTable(string $table): string
{
    return match ($table) {
        'civil_records' => 'person_name',
        'staff'         => 'name',
        default         => 'citizen_name',
    };
}

function migrateTablePersonNameParts(PDO $pdo, string $table, bool $namesRequired): void
{
    $legacyColumn = legacyNameColumnForTable($table);
    $hasParts = true;

    try {
        $pdo->query("SELECT first_name FROM `$table` LIMIT 1");
    } catch (Throwable $e) {
        $hasParts = false;
    }

    if (!$hasParts) {
        try {
            if ($table === 'civil_records') {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN first_name VARCHAR(80) NULL AFTER registry_number");
            } elseif ($table === 'staff') {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN first_name VARCHAR(80) NULL AFTER staff_id");
            } elseif ($table === 'document_requests') {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN first_name VARCHAR(80) NULL AFTER tracking_code");
            } elseif ($table === 'appointments') {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN first_name VARCHAR(80) NULL AFTER appointment_code");
            } else {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN first_name VARCHAR(80) NULL AFTER ticket_number");
            }
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN middle_name VARCHAR(80) NULL AFTER first_name");
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN last_name VARCHAR(80) NULL AFTER middle_name");
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query("SELECT `$legacyColumn` FROM `$table` LIMIT 1");
        $stmt = $pdo->query("SELECT * FROM `$table` WHERE (`$legacyColumn` IS NOT NULL AND `$legacyColumn` != '') AND (first_name IS NULL OR first_name = '')");
        while ($row = $stmt->fetch()) {
            $parts = parsePersonNameToParts((string) $row[$legacyColumn]);
            $update = $pdo->prepare("UPDATE `$table` SET first_name = ?, middle_name = ?, last_name = ? WHERE id = ?");
            $update->execute([
                $parts['first_name'] !== '' ? $parts['first_name'] : 'Unknown',
                $parts['middle_name'],
                $parts['last_name'],
                $row['id'],
            ]);
        }

        if ($namesRequired) {
            $pdo->exec("UPDATE `$table` SET first_name = 'Unknown' WHERE first_name IS NULL OR first_name = ''");
            $pdo->exec("UPDATE `$table` SET last_name = '' WHERE last_name IS NULL");
            $pdo->exec("ALTER TABLE `$table` MODIFY first_name VARCHAR(80) NOT NULL");
            $pdo->exec("ALTER TABLE `$table` MODIFY last_name VARCHAR(80) NOT NULL");
        }

        try {
            $pdo->exec("ALTER TABLE `$table` DROP INDEX idx_citizen");
        } catch (Throwable $ignored) {
        }
        try {
            $pdo->exec("ALTER TABLE `$table` DROP INDEX idx_person");
        } catch (Throwable $ignored) {
        }

        $pdo->exec("ALTER TABLE `$table` DROP COLUMN `$legacyColumn`");

        if ($table !== 'civil_records') {
            try {
                $pdo->exec("CREATE INDEX idx_citizen_name ON `$table` (last_name, first_name)");
            } catch (Throwable $ignored) {
            }
        } else {
            try {
                $pdo->exec('CREATE INDEX idx_person_name ON civil_records (last_name, first_name)');
            } catch (Throwable $ignored) {
            }
        }
    } catch (Throwable $ignored) {
    }
}

function enrichCitizenNameRow(array $row): array
{
    $row['citizen_name'] = personNameFromRow($row);

    return $row;
}

function enrichCitizenNameRows(array $rows): array
{
    return array_map('enrichCitizenNameRow', $rows);
}

function normalizePersonName(string $name): string
{
    $name = strtolower(trim($name));
    $name = preg_replace('/[.,]+/', ' ', $name);
    $name = preg_replace('/\s+/', ' ', $name);

    return $name;
}

function findMarriageCivilRecordMatch(PDO $pdo, array $nameParts, string $dateOfBirth, ?string $dateOfMarriage = null): ?array
{
    $nameParts = normalizeCitizenNameParts($nameParts);
    if ($nameParts['first_name'] === '' || $nameParts['last_name'] === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfBirth)) {
        return null;
    }

    if (!function_exists('splitFullName')) {
        require_once __DIR__ . '/printing.php';
    }
    if (!function_exists('fetchMarriageCivilRecordsForLookup')) {
        require_once __DIR__ . '/civil_record_schema.php';
    }

    $dom = ($dateOfMarriage !== null && $dateOfMarriage !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfMarriage))
        ? $dateOfMarriage
        : null;

    foreach (fetchMarriageCivilRecordsForLookup($pdo, $dom) as $row) {
        $husbandDob = (string) ($row['husband_birth_date'] ?? '');
        $wifeDob = (string) ($row['wife_birth_date'] ?? '');

        $husband = splitFullName((string) ($row['husband_name'] ?? ''));
        if ($dateOfBirth === $husbandDob && personNamePartsMatchOptionalMiddle(
            $nameParts['first_name'],
            $nameParts['middle_name'],
            $nameParts['last_name'],
            $husband['first'],
            $husband['middle'] !== '' ? $husband['middle'] : null,
            $husband['last']
        )) {
            $row['matched_sex'] = 'male';

            return $row;
        }

        $wife = splitFullName((string) ($row['wife_name'] ?? ''));
        if ($dateOfBirth === $wifeDob && personNamePartsMatchOptionalMiddle(
            $nameParts['first_name'],
            $nameParts['middle_name'],
            $nameParts['last_name'],
            $wife['first'],
            $wife['middle'] !== '' ? $wife['middle'] : null,
            $wife['last']
        )) {
            $row['matched_sex'] = 'female';

            return $row;
        }
    }

    return null;
}

function findMarriageCivilRecordMatchByCouple(PDO $pdo, array $husbandParts, array $wifeParts, string $dateOfMarriage): ?array
{
    $husbandParts = normalizeCitizenNameParts($husbandParts);
    $wifeParts = normalizeCitizenNameParts($wifeParts);
    if ($husbandParts['first_name'] === '' || $husbandParts['last_name'] === ''
        || $wifeParts['first_name'] === '' || $wifeParts['last_name'] === ''
        || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfMarriage)) {
        return null;
    }

    if (!function_exists('splitFullName')) {
        require_once __DIR__ . '/printing.php';
    }
    if (!function_exists('fetchMarriageCivilRecordsForLookup')) {
        require_once __DIR__ . '/civil_record_schema.php';
    }

    foreach (fetchMarriageCivilRecordsForLookup($pdo, $dateOfMarriage) as $row) {
        $husband = splitFullName((string) ($row['husband_name'] ?? ''));
        $wife = splitFullName((string) ($row['wife_name'] ?? ''));
        if (!personNamePartsMatchOptionalMiddle(
            $husbandParts['first_name'],
            $husbandParts['middle_name'],
            $husbandParts['last_name'],
            $husband['first'],
            $husband['middle'] !== '' ? $husband['middle'] : null,
            $husband['last']
        )) {
            continue;
        }
        if (!personNamePartsMatchOptionalMiddle(
            $wifeParts['first_name'],
            $wifeParts['middle_name'],
            $wifeParts['last_name'],
            $wife['first'],
            $wife['middle'] !== '' ? $wife['middle'] : null,
            $wife['last']
        )) {
            continue;
        }

        return $row;
    }

    return null;
}

function findDeathCivilRecordMatch(PDO $pdo, array $nameParts, string $dateOfDeath): ?array
{
    $nameParts = normalizeCitizenNameParts($nameParts);
    if ($nameParts['first_name'] === '' || $nameParts['last_name'] === ''
        || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfDeath)) {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT id, record_type, first_name, middle_name, last_name, birth_date, event_date, registry_number
         FROM civil_records
         WHERE deleted_at IS NULL AND record_type = \'death\' AND event_date = ?
         ORDER BY last_name ASC, first_name ASC'
    );
    $stmt->execute([$dateOfDeath]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (!personNamePartsMatchOptionalMiddle(
            $nameParts['first_name'],
            $nameParts['middle_name'],
            $nameParts['last_name'],
            (string) ($row['first_name'] ?? ''),
            $row['middle_name'] ?? null,
            (string) ($row['last_name'] ?? '')
        )) {
            continue;
        }
        if (!function_exists('hydrateCivilRecordRow')) {
            require_once __DIR__ . '/civil_record_schema.php';
        }
        ensureCivilRecordTypeTables($pdo);

        return hydrateCivilRecordRow($pdo, $row);
    }

    return null;
}

/**
 * @param array<string, mixed>|string $citizenNameOrParts Name parts array, or legacy full-name string
 */
function findCivilRecordMatch(PDO $pdo, array|string $citizenNameOrParts, string $dateOfBirth, string $documentType = '', ?string $dateOfMarriage = null, ?string $dateOfDeath = null): ?array
{
    $nameParts = is_array($citizenNameOrParts)
        ? normalizeCitizenNameParts($citizenNameOrParts)
        : normalizeCitizenNameParts(parsePersonNameToParts(trim((string) $citizenNameOrParts)));

    if ($documentType === 'marriage') {
        return findMarriageCivilRecordMatch($pdo, $nameParts, $dateOfBirth, $dateOfMarriage);
    }

    if ($documentType === 'death' && $dateOfDeath !== null && $dateOfDeath !== '') {
        return findDeathCivilRecordMatch($pdo, $nameParts, $dateOfDeath);
    }

    if ($nameParts['first_name'] === '' || $nameParts['last_name'] === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfBirth)) {
        return null;
    }

    $sql = 'SELECT id, record_type, first_name, middle_name, last_name, birth_date, registry_number
         FROM civil_records
         WHERE deleted_at IS NULL AND birth_date = ?';
    $params = [$dateOfBirth];

    if ($documentType !== '' && in_array($documentType, ['birth', 'death'], true)) {
        $sql .= ' AND record_type = ?';
        $params[] = $documentType;
    } else {
        $sql .= ' AND record_type IN (\'birth\', \'death\')';
    }

    $sql .= ' ORDER BY last_name ASC, first_name ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (!personNamePartsMatchOptionalMiddle(
            $nameParts['first_name'],
            $nameParts['middle_name'],
            $nameParts['last_name'],
            (string) ($row['first_name'] ?? ''),
            $row['middle_name'] ?? null,
            (string) ($row['last_name'] ?? '')
        )) {
            continue;
        }
        if (!function_exists('hydrateCivilRecordRow')) {
            require_once __DIR__ . '/civil_record_schema.php';
        }
        ensureCivilRecordTypeTables($pdo);

        return hydrateCivilRecordRow($pdo, $row);
    }

    return null;
}

function civilRecordSexForRequest(?array $row): ?string
{
    if (!$row) {
        return null;
    }

    $matched = strtolower(trim((string) ($row['matched_sex'] ?? '')));
    if (in_array($matched, ['male', 'female'], true)) {
        return $matched;
    }

    $raw = strtolower(trim((string) ($row['sex'] ?? '')));
    if (in_array($raw, ['male', 'female'], true)) {
        return $raw;
    }
    if ($raw === 'm') {
        return 'male';
    }
    if ($raw === 'f') {
        return 'female';
    }

    return null;
}

function markCivilRecordVerified(
    string $citizenName,
    string $dateOfBirth,
    string $documentType = '',
    ?string $dateOfMarriage = null,
    ?string $sex = null
): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['alcros_civil_record_verified'] = [
        'name'              => normalizePersonName($citizenName),
        'dob'               => $dateOfBirth,
        'document_type'     => $documentType,
        'date_of_marriage'  => $dateOfMarriage ?? '',
        'sex'               => in_array($sex, ['male', 'female'], true) ? $sex : null,
        'expires'           => time() + 7200,
    ];
}

function markMarriageCoupleCivilRecordVerified(array $husbandParts, array $wifeParts, string $dateOfMarriage, ?string $sex = null): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $husbandParts = normalizeCitizenNameParts($husbandParts);
    $wifeParts = normalizeCitizenNameParts($wifeParts);
    $_SESSION['alcros_civil_record_verified'] = [
        'document_type'        => 'marriage',
        'date_of_marriage'     => $dateOfMarriage,
        'husband_first_name'   => $husbandParts['first_name'],
        'husband_middle_name'  => $husbandParts['middle_name'] ?? '',
        'husband_last_name'    => $husbandParts['last_name'],
        'wife_first_name'      => $wifeParts['first_name'],
        'wife_middle_name'     => $wifeParts['middle_name'] ?? '',
        'wife_last_name'       => $wifeParts['last_name'],
        'sex'                  => in_array($sex, ['male', 'female'], true) ? $sex : null,
        'expires'              => time() + 7200,
    ];
}

function markDeathCivilRecordVerified(array $nameParts, string $dateOfDeath): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $nameParts = normalizeCitizenNameParts($nameParts);
    $_SESSION['alcros_civil_record_verified'] = [
        'document_type'    => 'death',
        'date_of_death'    => $dateOfDeath,
        'first_name'       => $nameParts['first_name'],
        'middle_name'      => $nameParts['middle_name'] ?? '',
        'last_name'        => $nameParts['last_name'],
        'expires'          => time() + 7200,
    ];
}

function personNamePartsFromDraftRow(array $row, string $prefix = ''): array
{
    return [
        'first_name'  => trim((string) ($row[$prefix . 'first_name'] ?? '')),
        'middle_name' => trim((string) ($row[$prefix . 'middle_name'] ?? '')) ?: null,
        'last_name'   => trim((string) ($row[$prefix . 'last_name'] ?? '')),
    ];
}

function verifiedSessionNamePartsMatch(array $verified, array $inputParts, string $prefix = ''): bool
{
    $firstKey = $prefix === '' ? 'first_name' : $prefix . 'first_name';
    $middleKey = $prefix === '' ? 'middle_name' : $prefix . 'middle_name';
    $lastKey = $prefix === '' ? 'last_name' : $prefix . 'last_name';

    return personNamePartsMatchOptionalMiddle(
        $inputParts['first_name'],
        $inputParts['middle_name'],
        $inputParts['last_name'],
        (string) ($verified[$firstKey] ?? ''),
        ($verified[$middleKey] ?? '') !== '' ? (string) $verified[$middleKey] : null,
        (string) ($verified[$lastKey] ?? '')
    );
}

function isMarriageIdentificationVerifiedInSession(array $husbandParts, array $wifeParts, string $dateOfMarriage): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if ($dateOfMarriage === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfMarriage)) {
        return false;
    }

    $verified = $_SESSION['alcros_civil_record_verified'] ?? null;
    if (!$verified || ($verified['document_type'] ?? '') !== 'marriage') {
        return false;
    }
    if ($dateOfMarriage !== ($verified['date_of_marriage'] ?? '')) {
        return false;
    }
    if (!verifiedSessionNamePartsMatch($verified, normalizeCitizenNameParts($husbandParts), 'husband_')
        || !verifiedSessionNamePartsMatch($verified, normalizeCitizenNameParts($wifeParts), 'wife_')) {
        return false;
    }
    if (time() > (int) ($verified['expires'] ?? 0)) {
        unset($_SESSION['alcros_civil_record_verified']);

        return false;
    }

    return true;
}

function isDeathIdentificationVerifiedInSession(array $nameParts, string $dateOfDeath): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if ($dateOfDeath === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfDeath)) {
        return false;
    }

    $verified = $_SESSION['alcros_civil_record_verified'] ?? null;
    if (!$verified || ($verified['document_type'] ?? '') !== 'death') {
        return false;
    }
    if ($dateOfDeath !== ($verified['date_of_death'] ?? '')) {
        return false;
    }
    if (!verifiedSessionNamePartsMatch($verified, normalizeCitizenNameParts($nameParts))) {
        return false;
    }
    if (time() > (int) ($verified['expires'] ?? 0)) {
        unset($_SESSION['alcros_civil_record_verified']);

        return false;
    }

    return true;
}

function isRequestDraftIdentificationVerified(array $draft): bool
{
    $documentType = (string) ($draft['document_type'] ?? '');
    if ($documentType === 'marriage') {
        return isMarriageIdentificationVerifiedInSession(
            personNamePartsFromDraftRow($draft, 'husband_'),
            personNamePartsFromDraftRow($draft, 'wife_'),
            (string) ($draft['date_of_marriage'] ?? '')
        );
    }
    if ($documentType === 'death') {
        return isDeathIdentificationVerifiedInSession(
            personNamePartsFromDraftRow($draft),
            (string) ($draft['date_of_death'] ?? '')
        );
    }

    $citizenName = personNameFromRow($draft);
    $dateOfBirth = (string) ($draft['date_of_birth'] ?? '');

    return isCivilRecordVerifiedInSession(
        $citizenName,
        $dateOfBirth,
        $documentType,
        !empty($draft['date_of_marriage']) ? (string) $draft['date_of_marriage'] : null
    );
}

function verifiedCivilRecordSexFromSession(): ?string
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $sex = $_SESSION['alcros_civil_record_verified']['sex'] ?? null;

    return in_array($sex, ['male', 'female'], true) ? $sex : null;
}

function isCivilRecordVerifiedInSession(string $citizenName, string $dateOfBirth, string $documentType = '', ?string $dateOfMarriage = null): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if ($citizenName === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfBirth)) {
        return false;
    }

    $verified = $_SESSION['alcros_civil_record_verified'] ?? null;
    if (!$verified) {
        return false;
    }
    $parts = parsePersonNameToParts($citizenName);
    if (!verifiedSessionNameMatches((string) ($verified['name'] ?? ''), $parts)
        || $dateOfBirth !== ($verified['dob'] ?? '')) {
        return false;
    }
    if (($verified['document_type'] ?? '') !== $documentType) {
        return false;
    }
    if ($documentType === 'marriage') {
        $expectedDom = $dateOfMarriage ?? '';
        if ($expectedDom !== ($verified['date_of_marriage'] ?? '')) {
            return false;
        }
    }
    if (time() > (int) ($verified['expires'] ?? 0)) {
        unset($_SESSION['alcros_civil_record_verified']);
        return false;
    }

    return true;
}

function verifyCitizenCivilRecord(PDO $pdo, array $nameParts, string $dateOfBirth, string $documentType = '', ?string $dateOfMarriage = null): array
{
    $nameParts = normalizeCitizenNameParts($nameParts);
    if ($nameParts['first_name'] === '' || $nameParts['last_name'] === '') {
        return ['ok' => false, 'error' => 'Enter your first name and last name on record first.'];
    }
    $citizenName = formatPersonName($nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name']);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfBirth)) {
        return ['ok' => false, 'error' => 'Enter your date of birth first.'];
    }
    if ($documentType === 'marriage') {
        if ($dateOfMarriage === null || $dateOfMarriage === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfMarriage)) {
            return ['ok' => false, 'error' => 'Enter your date of marriage first.'];
        }
    }

    $row = findCivilRecordMatch($pdo, $nameParts, $dateOfBirth, $documentType, $dateOfMarriage);
    if ($row) {
        markCivilRecordVerified(
            $citizenName,
            $dateOfBirth,
            $documentType,
            $dateOfMarriage,
            civilRecordSexForRequest($row)
        );
        return [
            'ok'          => true,
            'message'     => 'Record found - you are registered with the Local Civil Registry Office.',
            'record_type' => civilRecordTypeLabel((string) ($row['record_type'] ?? $documentType)),
        ];
    }

    if ($documentType === 'marriage') {
        return [
            'ok'    => false,
            'error' => 'No marriage record was found for this name, date of birth, and date of marriage. Please visit the Local Civil Registry Office (LCRO) in person.',
        ];
    }

    return [
        'ok'    => false,
        'error' => 'No civil registry record was found for this name and date of birth. Please visit the Local Civil Registry Office (LCRO) in person to register before submitting an online request.',
    ];
}

function verifyCitizenCivilRecordFromInput(PDO $pdo, array $input): array
{
    $documentType = trim((string) ($input['document_type'] ?? ''));

    if ($documentType === 'marriage') {
        $husbandParts = personNamePartsFromInput($input, 'husband_');
        $wifeParts = personNamePartsFromInput($input, 'wife_');
        $dateOfMarriage = trim((string) ($input['date_of_marriage'] ?? ''));

        if (($husbandErr = validatePersonNameParts($husbandParts)) !== null) {
            return ['ok' => false, 'error' => 'Enter the husband\'s first and last name on record.'];
        }
        if (($wifeErr = validatePersonNameParts($wifeParts)) !== null) {
            return ['ok' => false, 'error' => 'Enter the wife\'s first and last name on record.'];
        }
        if ($dateOfMarriage === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfMarriage)) {
            return ['ok' => false, 'error' => 'Enter your date of marriage first.'];
        }

        $row = findMarriageCivilRecordMatchByCouple($pdo, $husbandParts, $wifeParts, $dateOfMarriage);
        if ($row) {
            markMarriageCoupleCivilRecordVerified($husbandParts, $wifeParts, $dateOfMarriage, civilRecordSexForRequest($row));

            return [
                'ok'          => true,
                'message'     => 'Record found - you are registered with the Local Civil Registry Office.',
                'record_type' => civilRecordTypeLabel('marriage'),
            ];
        }

        return [
            'ok'    => false,
            'error' => 'No marriage record was found for these names and date of marriage. Please visit the Local Civil Registry Office (LCRO) in person.',
        ];
    }

    if ($documentType === 'death') {
        $nameParts = personNamePartsFromInput($input);
        $dateOfDeath = trim((string) ($input['date_of_death'] ?? ''));

        if (($nameError = validatePersonNameParts($nameParts)) !== null) {
            return ['ok' => false, 'error' => 'Enter the deceased first and last name on record.'];
        }
        if ($dateOfDeath === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateOfDeath)) {
            return ['ok' => false, 'error' => 'Enter the date of death first.'];
        }

        $row = findDeathCivilRecordMatch($pdo, $nameParts, $dateOfDeath);
        if ($row) {
            markDeathCivilRecordVerified($nameParts, $dateOfDeath);

            return [
                'ok'          => true,
                'message'     => 'Record found - you are registered with the Local Civil Registry Office.',
                'record_type' => civilRecordTypeLabel('death'),
            ];
        }

        return [
            'ok'    => false,
            'error' => 'No death record was found for this name and date of death. Please visit the Local Civil Registry Office (LCRO) in person.',
        ];
    }

    $dateOfBirth = trim((string) ($input['date_of_birth'] ?? ''));
    $dateOfMarriage = trim((string) ($input['date_of_marriage'] ?? ''));

    return verifyCitizenCivilRecord(
        $pdo,
        personNamePartsFromInput($input),
        $dateOfBirth,
        $documentType,
        $dateOfMarriage !== '' ? $dateOfMarriage : null
    );
}

/** @return array{front: ?string, back: ?string} Map citizen valid-ID errors to upload fields for inline display. */
function citizenIdUploadInlineErrors(?string $error): array
{
    $out = ['front' => null, 'back' => null];
    if ($error === null || $error === '') {
        return $out;
    }
    if (!preg_match('/valid ID|ID (front|back)/i', $error)) {
        return $out;
    }
    if (preg_match('/\bback\b/i', $error)) {
        $out['back'] = $error;
    } elseif (preg_match('/\bfront\b/i', $error)) {
        $out['front'] = $error;
    }

    return $out;
}

function saveIdUpload(array $file, string $prefix): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $maxBytes = 5 * 1024 * 1024;
    if (($file['size'] ?? 0) > $maxBytes) {
        return null;
    }

    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    $mime = mime_content_type($file['tmp_name']);
    if (!in_array($mime, $allowed, true)) {
        return null;
    }

    $ext = match ($mime) {
        'image/jpeg'        => 'jpg',
        'image/png'         => 'png',
        'image/webp'        => 'webp',
        'application/pdf'   => 'pdf',
        default             => 'bin',
    };

    $dir = __DIR__ . '/../uploads/ids';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $filename = $prefix . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return null;
    }

    return 'uploads/ids/' . $filename;
}

function ensureStaffProfileColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    ensurePersonNamePartColumns($pdo);

    try {
        $pdo->query('SELECT profile_photo_path FROM staff LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE staff ADD COLUMN profile_photo_path VARCHAR(255) DEFAULT NULL AFTER role');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT email FROM staff LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE staff ADD COLUMN email VARCHAR(150) DEFAULT NULL AFTER last_name');
        } catch (Throwable $ignored) {
        }
    }

    try {
        $pdo->query('SELECT recovery_gmail_2sv_confirmed FROM staff LIMIT 1');
    } catch (Throwable $e) {
        try {
            $pdo->exec('ALTER TABLE staff ADD COLUMN recovery_gmail_2sv_confirmed TINYINT(1) NOT NULL DEFAULT 0 AFTER email');
        } catch (Throwable $ignored) {
        }
    }

}

function staffRowUsesLegacyNameColumn(PDO $pdo): bool
{
    static $legacy = null;
    if ($legacy !== null) {
        return $legacy;
    }
    try {
        $pdo->query('SELECT first_name FROM staff LIMIT 1');
        $legacy = false;
    } catch (Throwable) {
        $legacy = true;
    }

    return $legacy;
}

function staffRowById(PDO $pdo, string $staffId): ?array
{
    ensureStaffProfileColumns($pdo);
    $staffId = strtoupper(trim($staffId));

    if (staffRowUsesLegacyNameColumn($pdo)) {
        $stmt = $pdo->prepare(
            'SELECT staff_id, name, role, password_hash, created_at FROM staff WHERE staff_id = ? LIMIT 1'
        );
        $stmt->execute([$staffId]);
        $row = $stmt->fetch();
        if (!$row) {
            return null;
        }
        $parts = parsePersonNameToParts((string) ($row['name'] ?? ''));
        $row['first_name'] = $parts['first_name'];
        $row['middle_name'] = $parts['middle_name'];
        $row['last_name'] = $parts['last_name'];
        $row['email'] = null;
        $row['recovery_gmail_2sv_confirmed'] = 0;
        $row['profile_photo_path'] = null;

        return $row;
    }

    $stmt = $pdo->prepare(
        'SELECT staff_id, first_name, middle_name, last_name, email, recovery_gmail_2sv_confirmed, role, password_hash, profile_photo_path, created_at FROM staff WHERE staff_id = ? LIMIT 1'
    );
    $stmt->execute([$staffId]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function normalizeStaffEmail(string $email): string
{
    return normalizeGmail($email);
}

function validateStaffEmail(string $email): ?string
{
    $email = normalizeStaffEmail($email);
    if ($email === '') {
        return 'Gmail address is required for password recovery.';
    }
    if (!isValidGmail($email)) {
        return 'Please enter a valid Gmail address (example@gmail.com).';
    }

    return null;
}

function staffRecoveryGmailNeeds2svConfirmation(?array $existingStaff, string $newEmail): bool
{
    if (!$existingStaff) {
        return true;
    }

    $oldEmail = normalizeStaffEmail((string) ($existingStaff['email'] ?? ''));
    $newEmail = normalizeStaffEmail($newEmail);
    $confirmed = (int) ($existingStaff['recovery_gmail_2sv_confirmed'] ?? 0) === 1;

    if ($newEmail !== $oldEmail) {
        return true;
    }

    return !$confirmed;
}

function validateStaffRecoveryGmail2sv(bool $confirmed): ?string
{
    if (!$confirmed) {
        return 'You must confirm that this Gmail account already has Google 2-Step Verification enabled. Enable it at myaccount.google.com/signinoptions/two-step-verification, then try again.';
    }

    return null;
}

function staffRecoveryGmail2svConfirmedValue(?array $existingStaff, string $newEmail, bool $checkboxConfirmed): int
{
    if (staffRecoveryGmailNeeds2svConfirmation($existingStaff, $newEmail)) {
        return $checkboxConfirmed ? 1 : 0;
    }

    return (int) ($existingStaff['recovery_gmail_2sv_confirmed'] ?? 0);
}

function staffProfileFieldNorm(mixed $value): string
{
    return trim((string) ($value ?? ''));
}

/**
 * @return list<string> Human-readable labels for staff profile fields that changed.
 */
function staffProfileChangedFieldLabels(
    array $existing,
    array $nameParts,
    string $email,
    int $confirmedValue,
    ?string $newRole = null
): array {
    $labels = [];

    if (staffProfileFieldNorm($existing['first_name'] ?? null) !== staffProfileFieldNorm($nameParts['first_name'] ?? null)) {
        $labels[] = 'first name';
    }
    if (staffProfileFieldNorm($existing['middle_name'] ?? null) !== staffProfileFieldNorm($nameParts['middle_name'] ?? null)) {
        $labels[] = 'middle name';
    }
    if (staffProfileFieldNorm($existing['last_name'] ?? null) !== staffProfileFieldNorm($nameParts['last_name'] ?? null)) {
        $labels[] = 'last name';
    }

    $oldEmail = normalizeStaffEmail((string) ($existing['email'] ?? ''));
    $newEmail = normalizeStaffEmail($email);
    if ($oldEmail !== $newEmail) {
        $labels[] = 'recovery Gmail';
    }

    if ((int) ($existing['recovery_gmail_2sv_confirmed'] ?? 0) !== $confirmedValue) {
        $labels[] = '2-Step Verification confirmation';
    }

    if ($newRole !== null) {
        $oldRole = (string) ($existing['role'] ?? 'Staff');
        if ($newRole !== $oldRole) {
            $labels[] = 'role';
        }
    }

    return $labels;
}

function staffProfileChangeActivityDetails(array $changedLabels): string
{
    if ($changedLabels === []) {
        return 'No profile changes detected';
    }

    return 'Updated ' . implode(', ', $changedLabels);
}

function staffEmailInUse(PDO $pdo, string $email, ?string $exceptStaffId = null): bool
{
    ensureStaffProfileColumns($pdo);
    $email = normalizeStaffEmail($email);
    if ($email === '') {
        return false;
    }
    $sql = 'SELECT COUNT(*) FROM staff WHERE email = ?';
    $params = [$email];
    if ($exceptStaffId !== null && $exceptStaffId !== '') {
        $sql .= ' AND staff_id <> ?';
        $params[] = strtoupper(trim($exceptStaffId));
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return (int) $stmt->fetchColumn() > 0;
}

function maskEmailAddress(string $email): string
{
    $email = normalizeStaffEmail($email);
    if ($email === '' || !str_contains($email, '@')) {
        return '';
    }
    [$local, $domain] = explode('@', $email, 2);
    $visible = substr($local, 0, 1);
    $maskedLocal = $visible . str_repeat('*', max(1, strlen($local) - 1));

    return $maskedLocal . '@' . $domain;
}

function staffPasswordOtpTtlMinutes(): int
{
    return 15;
}

function ensureStaffPasswordResetOtpColumns(PDO $pdo): void
{
    ensureStaffProfileColumns($pdo);
    ensureExtendedSchema($pdo);
}

function purgeExpiredStaffOtps(PDO $pdo): void
{
    ensureStaffPasswordResetOtpColumns($pdo);
    $pdo->exec(
        'UPDATE staff SET password_reset_otp_hash = NULL, password_reset_otp_expires_at = NULL, password_reset_otp_attempts = 0
         WHERE password_reset_otp_expires_at IS NOT NULL AND password_reset_otp_expires_at <= NOW()'
    );
}

function sendStaffPasswordOtp(PDO $pdo, string $staffId): array
{
    ensureExtendedSchema($pdo);
    purgeExpiredStaffOtps($pdo);

    $staff = staffRowById($pdo, $staffId);
    if (!$staff) {
        return ['ok' => true, 'message' => 'If that Staff ID is registered with a Gmail address, a verification code was sent.'];
    }

    $email = normalizeStaffEmail((string) ($staff['email'] ?? ''));
    if ($email === '') {
        return [
            'ok' => false,
            'message' => 'No Gmail is registered for this account. Ask an administrator to add your Gmail under System Settings → Staff Members, or set it in My Settings if you can still sign in.',
        ];
    }

    if ((int) ($staff['recovery_gmail_2sv_confirmed'] ?? 0) !== 1) {
        return [
            'ok' => false,
            'message' => 'Password recovery is not enabled for this account because the recovery Gmail has not been confirmed with Google 2-Step Verification. Sign in and update Recovery Gmail in System Settings, or ask an administrator.',
        ];
    }

    $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $ttlMinutes = staffPasswordOtpTtlMinutes();

    $pdo->prepare(
        'UPDATE staff SET password_reset_otp_hash = ?, password_reset_otp_expires_at = DATE_ADD(NOW(), INTERVAL '
        . $ttlMinutes . ' MINUTE), password_reset_otp_attempts = 0 WHERE staff_id = ?'
    )->execute([password_hash($otp, PASSWORD_DEFAULT), $staff['staff_id']]);

    $site = getSiteSettings()['name'];
    $subject = $site . ' - Staff password reset code';
    $displayName = personNameFromRow($staff);
    $plain = "Hello {$displayName},\n\n"
        . "Your ALCROS staff portal password reset code is: {$otp}\n\n"
        . "Staff ID: {$staff['staff_id']}\n"
        . "This code expires in {$ttlMinutes} minutes.\n\n"
        . "If you did not request this, ignore this email and contact your administrator.";
    $html = '<p>Hello <strong>' . htmlspecialchars($displayName) . '</strong>,</p>'
        . '<p>Your staff portal password reset code is:</p>'
        . '<p style="font-size:28px;font-weight:800;letter-spacing:6px;color:#2563eb;">' . htmlspecialchars($otp) . '</p>'
        . '<p>Staff ID: <strong>' . htmlspecialchars($staff['staff_id']) . '</strong><br>'
        . 'This code expires in <strong>' . $ttlMinutes . ' minutes</strong>.</p>'
        . '<p style="color:#64748b;font-size:13px;">If you did not request this, ignore this email and contact your administrator.</p>';

    if (!sendCitizenEmail($email, $subject, $plain, $html)) {
        $pdo->prepare(
            'UPDATE staff SET password_reset_otp_hash = NULL, password_reset_otp_expires_at = NULL, password_reset_otp_attempts = 0 WHERE staff_id = ?'
        )->execute([$staff['staff_id']]);

        return [
            'ok' => false,
            'message' => 'Could not send the verification email. Confirm Gmail SMTP is configured in System Settings, then try again.',
        ];
    }

    logEmailDelivery($email, $subject, 'staff_password_otp', $staff['staff_id'], true);

    return [
        'ok' => true,
        'message' => 'A 6-digit verification code was sent to ' . maskEmailAddress($email) . '.',
        'staff_id' => $staff['staff_id'],
        'email_hint' => maskEmailAddress($email),
    ];
}

function sendStaffLoginLockoutAlert(PDO $pdo, string $staffId, int $windowSeconds = 900, ?string $sourceIp = null): bool
{
    ensureExtendedSchema($pdo);
    $staff = staffRowById($pdo, $staffId);
    if (!$staff) {
        return false;
    }

    $email = normalizeStaffEmail((string) ($staff['email'] ?? ''));
    if ($email === '') {
        return false;
    }

    if ((int) ($staff['recovery_gmail_2sv_confirmed'] ?? 0) !== 1) {
        return false;
    }

    $site = getSiteSettings()['name'];
    $displayName = personNameFromRow($staff);
    $staffIdDisplay = (string) $staff['staff_id'];
    $when = date('F j, Y \a\t g:i A');
    $ip = formatClientIpAddress($sourceIp);
    $resetUrl = appBaseUrl() . '/forgot_password.php';
    $windowMinutes = (int) max(1, round($windowSeconds / 60));

    $subject = $site . ' - Sign-in attempts on your staff account';
    $plain = "Hello {$displayName},\n\n"
        . "Someone tried to sign in to the ALCROS staff portal using your Staff ID ({$staffIdDisplay}) "
        . "with an incorrect password 3 times.\n\n"
        . "When: {$when}\n"
        . "Source IP: {$ip}\n"
        . "Sign-in for this Staff ID was temporarily paused for about {$windowMinutes} minutes.\n\n"
        . "If this was you, wait for the pause to end or reset your password:\n{$resetUrl}\n\n"
        . "If this was not you, contact your administrator immediately and consider resetting your password.";
    $html = '<p>Hello <strong>' . htmlspecialchars($displayName) . '</strong>,</p>'
        . '<p>Someone tried to sign in to the ALCROS staff portal using your Staff ID '
        . '(<strong>' . htmlspecialchars($staffIdDisplay) . '</strong>) with an incorrect password 3 times.</p>'
        . '<p><strong>When:</strong> ' . htmlspecialchars($when) . '<br>'
        . '<strong>Source IP:</strong> ' . htmlspecialchars($ip) . '<br>'
        . 'Sign-in for this Staff ID was temporarily paused for about <strong>' . $windowMinutes . ' minutes</strong>.</p>'
        . '<p>If this was you, wait for the pause to end or <a href="' . htmlspecialchars($resetUrl) . '">reset your password</a>.</p>'
        . '<p style="color:#64748b;font-size:13px;">If this was not you, contact your administrator immediately and consider resetting your password.</p>';

    if (!sendCitizenEmail($email, $subject, $plain, $html)) {
        logEmailDelivery($email, $subject, 'staff_login_lockout_alert', $staffIdDisplay, false, citizenEmailFailureReason());

        return false;
    }

    logEmailDelivery($email, $subject, 'staff_login_lockout_alert', $staffIdDisplay, true);
    logActivity(
        $staffIdDisplay,
        'Login lockout alert',
        'Recovery email sent after repeated failed sign-in attempts (IP ' . $ip . ')'
    );

    return true;
}

function notifyAdminLoginLockoutInAppIfNeeded(
    PDO $pdo,
    string $staffId,
    string $rateLimitKey,
    int $maxAttempts,
    int $windowSeconds,
    bool $staffRegistered
): void {
    $staffId = strtoupper(trim($staffId));
    if ($staffId === '' || $rateLimitKey === '') {
        return;
    }

    if (!rateLimitIsBlocked($rateLimitKey, $maxAttempts, $windowSeconds)) {
        return;
    }

    if (rateLimitAdminInboxLockoutAlreadySent($rateLimitKey, $windowSeconds)) {
        return;
    }

    $state = rateLimitReadState($rateLimitKey, $windowSeconds);
    $sourceIp = ($state['last_ip'] ?? '') !== '' ? (string) $state['last_ip'] : null;
    $ip = formatClientIpAddress($sourceIp);

    if ($staffRegistered) {
        $logDetail = 'Administrator inbox: registered Staff ID locked after repeated failed sign-in (IP ' . $ip . ')';
    } else {
        $logDetail = 'Administrator inbox: unrecognized Staff ID locked after repeated failed sign-in (IP ' . $ip . ')';
    }

    try {
        logActivity($staffId, 'Login lockout alert', $logDetail);
        rateLimitMarkAdminInboxLockoutSent($rateLimitKey, $windowSeconds);
    } catch (Throwable $e) {
        // Non-fatal - email lockout paths remain unchanged.
    }
}

function notifyStaffLoginLockoutIfNeeded(
    PDO $pdo,
    string $staffId,
    string $rateLimitKey,
    int $maxAttempts,
    int $windowSeconds
): void {
    $staffId = strtoupper(trim($staffId));
    if ($staffId === '' || $rateLimitKey === '') {
        return;
    }

    if (!rateLimitIsBlocked($rateLimitKey, $maxAttempts, $windowSeconds)) {
        return;
    }

    notifyAdminLoginLockoutInAppIfNeeded($pdo, $staffId, $rateLimitKey, $maxAttempts, $windowSeconds, true);

    if (rateLimitLockoutAlertAlreadySent($rateLimitKey, $windowSeconds)) {
        return;
    }

    $state = rateLimitReadState($rateLimitKey, $windowSeconds);
    $sourceIp = ($state['last_ip'] ?? '') !== '' ? (string) $state['last_ip'] : null;

    if (!sendStaffLoginLockoutAlert($pdo, $staffId, $windowSeconds, $sourceIp)) {
        return;
    }

    rateLimitMarkLockoutAlertSent($rateLimitKey, $windowSeconds);
}

function adminAlertInboxEmail(): string
{
    $office = trim(getSetting('office_email', ''));
    if ($office !== '' && filter_var($office, FILTER_VALIDATE_EMAIL)) {
        return $office;
    }

    $notification = trim(getSetting('notification_email', ''));
    if ($notification !== '' && filter_var($notification, FILTER_VALIDATE_EMAIL)) {
        return $notification;
    }

    return 'aloran@gov.ph';
}

function sendUnknownStaffLoginLockoutAlertToAdmin(
    string $attemptedStaffId,
    int $windowSeconds = 900,
    ?string $sourceIp = null
): bool {
    $email = adminAlertInboxEmail();
    if ($email === '') {
        return false;
    }

    $site = getSiteSettings()['name'];
    $staffIdDisplay = strtoupper(trim($attemptedStaffId));
    $when = date('F j, Y \a\t g:i A');
    $ip = formatClientIpAddress($sourceIp);
    $windowMinutes = (int) max(1, round($windowSeconds / 60));

    $subject = $site . ' - Staff portal lockout (unrecognized Staff ID)';
    $plain = "ALCROS staff portal security notice\n\n"
        . "Someone attempted to sign in 3 times using the Staff ID \"{$staffIdDisplay}\", which is not registered in the system.\n\n"
        . "When: {$when}\n"
        . "Source IP: {$ip}\n"
        . "Sign-in for that Staff ID entry was temporarily paused for about {$windowMinutes} minutes.\n\n"
        . "Review your staff accounts and sign-in activity if this was unexpected.";
    $html = '<p><strong>ALCROS staff portal security notice</strong></p>'
        . '<p>Someone attempted to sign in 3 times using the Staff ID '
        . '<strong>' . htmlspecialchars($staffIdDisplay) . '</strong>, which is <strong>not registered</strong> in the system.</p>'
        . '<p><strong>When:</strong> ' . htmlspecialchars($when) . '<br>'
        . '<strong>Source IP:</strong> ' . htmlspecialchars($ip) . '<br>'
        . 'Sign-in for that Staff ID entry was temporarily paused for about <strong>' . $windowMinutes . ' minutes</strong>.</p>'
        . '<p style="color:#64748b;font-size:13px;">Review staff accounts and recent sign-in activity if this was unexpected.</p>';

    if (!sendCitizenEmail($email, $subject, $plain, $html)) {
        logEmailDelivery($email, $subject, 'unknown_staff_login_lockout_alert', $staffIdDisplay, false, citizenEmailFailureReason());

        return false;
    }

    logEmailDelivery($email, $subject, 'unknown_staff_login_lockout_alert', $staffIdDisplay, true);
    logActivity(
        $staffIdDisplay,
        'Login lockout alert',
        'Admin notified: unrecognized Staff ID locked after repeated failed sign-in attempts (IP ' . $ip . ')'
    );

    return true;
}

function notifyUnknownStaffLoginLockoutIfNeeded(
    PDO $pdo,
    string $staffId,
    string $rateLimitKey,
    int $maxAttempts,
    int $windowSeconds
): void {
    $staffId = strtoupper(trim($staffId));
    if ($staffId === '' || $rateLimitKey === '') {
        return;
    }

    if (!rateLimitIsBlocked($rateLimitKey, $maxAttempts, $windowSeconds)) {
        return;
    }

    notifyAdminLoginLockoutInAppIfNeeded($pdo, $staffId, $rateLimitKey, $maxAttempts, $windowSeconds, false);

    if (rateLimitLockoutAlertAlreadySent($rateLimitKey, $windowSeconds)) {
        return;
    }

    $state = rateLimitReadState($rateLimitKey, $windowSeconds);
    $sourceIp = ($state['last_ip'] ?? '') !== '' ? (string) $state['last_ip'] : null;

    if (!sendUnknownStaffLoginLockoutAlertToAdmin($staffId, $windowSeconds, $sourceIp)) {
        return;
    }

    rateLimitMarkLockoutAlertSent($rateLimitKey, $windowSeconds);
}

function resetStaffPasswordWithOtp(PDO $pdo, string $staffId, string $otp, string $newPassword): array
{
    ensureExtendedSchema($pdo);
    purgeExpiredStaffOtps($pdo);

    $staffId = strtoupper(trim($staffId));
    $otp = trim($otp);
    if ($staffId === '' || $otp === '') {
        return ['ok' => false, 'message' => 'Staff ID and verification code are required.'];
    }
    if ($passwordError = validatePasswordStrength($newPassword)) {
        return ['ok' => false, 'message' => $passwordError];
    }

    $stmt = $pdo->prepare(
        'SELECT password_reset_otp_hash AS otp_hash, password_reset_otp_attempts AS attempts,
                (password_reset_otp_expires_at > NOW()) AS is_fresh
         FROM staff
         WHERE staff_id = ? AND password_reset_otp_hash IS NOT NULL
         LIMIT 1'
    );
    $stmt->execute([$staffId]);
    $row = $stmt->fetch();
    if (!$row) {
        return ['ok' => false, 'message' => 'No active verification code found. Request a new code.'];
    }
    if ((int) ($row['attempts'] ?? 0) >= 5) {
        return ['ok' => false, 'message' => 'Too many incorrect attempts. Request a new verification code.'];
    }
    if ((int) ($row['is_fresh'] ?? 0) !== 1) {
        $pdo->prepare(
            'UPDATE staff SET password_reset_otp_hash = NULL, password_reset_otp_expires_at = NULL, password_reset_otp_attempts = 0 WHERE staff_id = ?'
        )->execute([$staffId]);

        return ['ok' => false, 'message' => 'Verification code expired. Request a new code.'];
    }

    if (!password_verify($otp, (string) $row['otp_hash'])) {
        $pdo->prepare('UPDATE staff SET password_reset_otp_attempts = password_reset_otp_attempts + 1 WHERE staff_id = ?')
            ->execute([$staffId]);

        return ['ok' => false, 'message' => 'Incorrect verification code.'];
    }

    $pdo->prepare(
        'UPDATE staff SET password_hash = ?, password_reset_otp_hash = NULL, password_reset_otp_expires_at = NULL, password_reset_otp_attempts = 0 WHERE staff_id = ?'
    )->execute([password_hash($newPassword, PASSWORD_DEFAULT), $staffId]);
    if (function_exists('staffRememberMeRevokeAllForStaff')) {
        staffRememberMeRevokeAllForStaff($pdo, $staffId);
    }
    logActivity($staffId, 'Password Reset', 'Password reset via Gmail OTP');

    return ['ok' => true, 'message' => 'Password updated successfully. You can now sign in.'];
}

function saveStaffPhotoUpload(array $file, string $staffId): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $maxBytes = 2 * 1024 * 1024;
    if (($file['size'] ?? 0) > $maxBytes) {
        return null;
    }

    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/pjpeg', 'image/x-png'];
    $mime = mime_content_type($file['tmp_name']);
    if (!is_string($mime) || $mime === '') {
        $mime = (string) ($file['type'] ?? '');
    }
    if (!in_array($mime, $allowed, true)) {
        return null;
    }

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        default      => 'bin',
    };

    $dir = __DIR__ . '/../uploads/staff';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $safeId = preg_replace('/[^A-Z0-9\-]/', '', strtoupper($staffId));
    $filename = 'staff_' . ($safeId !== '' ? $safeId : 'USER') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return null;
    }

    return 'uploads/staff/' . $filename;
}

function deleteStaffPhotoFile(?string $path): void
{
    deleteIdUploadFiles($path);
}

function staffInitial(string $name): string
{
    $name = trim($name);
    return $name !== '' ? strtoupper(substr($name, 0, 1)) : 'U';
}

function staffPhotoExists(?string $photoPath): bool
{
    $photoPath = trim((string) $photoPath);
    if ($photoPath === '') {
        return false;
    }

    return is_file(__DIR__ . '/../' . ltrim($photoPath, '/'));
}

/** Cache-busted web path to images/favicon.png (tab icon + in-app logo). */
function alcrosFaviconVersionQuery(): string
{
    $full = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'favicon.png';

    return is_file($full) ? ('?v=' . filemtime($full)) : '?v=2';
}

/**
 * URL for images/favicon.png - root-relative from the ALCROS folder (/alcros/images/… under XAMPP).
 * Avoids plain "images/…" (breaks on some URLs) and "/images/…" (hits htdocs root → XAMPP icon).
 */
function alcrosFaviconAssetUrl(): string
{
    static $url = null;
    if ($url !== null) {
        return $url;
    }

    $base = alcrosWebBasePath();
    $prefix = ($base === '' || $base === '/') ? '' : rtrim($base, '/');
    $url = ($prefix !== '' ? $prefix : '') . '/images/favicon.png' . alcrosFaviconVersionQuery();

    return $url;
}

/** HTML link tags so browser tabs use images/favicon.png. */
function faviconLinkTag(): string
{
    $href = htmlspecialchars(alcrosFaviconAssetUrl(), ENT_QUOTES, 'UTF-8');

    return '<link rel="icon" type="image/png" href="' . $href . '">';
}

function alcrosFaviconImg(int $sizePx = 20, string $extraClass = ''): string
{
    $size = max(16, min(72, $sizePx));
    $class = trim('object-cover shrink-0 rounded-full bg-white ' . $extraClass);

    return sprintf(
        '<img src="%s" alt="ALCROS" class="%s" width="%d" height="%d">',
        htmlspecialchars(alcrosFaviconAssetUrl(), ENT_QUOTES, 'UTF-8'),
        htmlspecialchars($class, ENT_QUOTES, 'UTF-8'),
        $size,
        $size
    );
}

/** Staff login in citizen header - desktop (lg+) only; mobile uses More menu / footer. */
function citizenStaffLoginHeaderLink(string $label = 'Staff Login'): string
{
    return '<a href="login.php" class="citizen-btn-login hidden lg:inline-block shrink-0">'
        . htmlspecialchars($label, ENT_QUOTES, 'UTF-8')
        . '</a>';
}

function renderStaffAvatar(?string $photoPath, string $name, string $classes = 'w-8 h-8', string $rounded = 'rounded-full'): string
{
    $initial = staffInitial($name);
    $shellClass = 'staff-avatar-shell inline-flex shrink-0 items-center justify-center overflow-hidden border border-gray-200 '
        . htmlspecialchars($classes, ENT_QUOTES, 'UTF-8') . ' '
        . htmlspecialchars($rounded, ENT_QUOTES, 'UTF-8');

    if (staffPhotoExists($photoPath)) {
        $src = protectedUploadUrl($photoPath);
        if ($src === null) {
            return '<span class="' . $shellClass . ' bg-gray-100 font-bold text-gray-500">'
                . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>';
        }

        return '<span class="' . $shellClass . '">'
            . '<img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="" class="staff-avatar-shell__img" loading="lazy" decoding="async">'
            . '</span>';
    }

    return '<span class="' . $shellClass . ' bg-gray-100 font-bold text-gray-500">'
        . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>';
}

/**
 * Human-readable activity action for UI/export (entries in activity_logs are successful outcomes).
 */
function activityLogDisplayAction(string $action): string
{
    $action = trim($action);
    if ($action === '') {
        return 'Activity';
    }

    if (preg_match('/^(Successful|Failed|Unsuccessful)\b/i', $action)) {
        return $action;
    }

    static $labels = [
        'Staff Login'         => 'Successful Login',
        'Staff Logout'        => 'Successful Logout',
        'Login lockout alert' => 'Sign-in lockout alert',
    ];
    if (isset($labels[$action])) {
        return $labels[$action];
    }

    if (preg_match('/\b(Login|Logout|Created|Updated|Added|Removed|Deleted|Restored|Purged|Saved|Printed|Cleared|Fixed|Cancelled|Canceled|Exported|Imported|Changed|Reset)\b/i', $action)) {
        $trimmed = preg_replace('/^Staff\s+/i', '', $action) ?? $action;

        return 'Successful ' . $trimmed;
    }

    return $action;
}

/** @param list<array<string, mixed>> $activities */
function enrichActivityLogsForDisplay(PDO $pdo, array $activities, string $avatarClasses = 'w-9 h-9 text-xs'): array
{
    if ($activities === []) {
        return [];
    }

    ensureStaffProfileColumns($pdo);
    $staffIds = array_values(array_unique(array_filter(array_map(
        static fn (array $row): string => trim((string) ($row['staff_id'] ?? '')),
        $activities
    ))));
    $staffById = [];
    if ($staffIds !== []) {
        $placeholders = implode(',', array_fill(0, count($staffIds), '?'));
        $stmt = $pdo->prepare(
            "SELECT staff_id, first_name, middle_name, last_name, profile_photo_path
             FROM staff WHERE staff_id IN ($placeholders)"
        );
        $stmt->execute($staffIds);
        foreach ($stmt->fetchAll() as $staffRow) {
            $staffById[(string) $staffRow['staff_id']] = $staffRow;
        }
    }

    $enriched = [];
    foreach ($activities as $activity) {
        $staffId = trim((string) ($activity['staff_id'] ?? ''));
        $staffRow = $staffId !== '' ? ($staffById[$staffId] ?? null) : null;
        $displayName = $staffRow
            ? personNameFromRow($staffRow)
            : ($staffId !== '' ? $staffId : 'System');
        $photoPath = $staffRow['profile_photo_path'] ?? null;

        $activity['staff_display_name'] = $displayName;
        $activity['staff_photo_path'] = $photoPath;
        $activity['staff_avatar_html'] = renderStaffAvatar($photoPath, $displayName, $avatarClasses);
        $activity['action_display'] = activityLogDisplayAction((string) ($activity['action'] ?? ''));

        $enriched[] = $activity;
    }

    return $enriched;
}

function civilRecordTypeLabel(string $type): string
{
    return match ($type) {
        'birth'    => 'Birth',
        'death'    => 'Death',
        'marriage' => 'Marriage',
        default    => ucfirst($type),
    };
}

function formatRecordDate(?string $date): string
{
    if ($date === null || $date === '') {
        return '-';
    }
    $ts = strtotime($date);
    return $ts ? date('M j, Y', $ts) : $date;
}

function consumeSessionFlash(string $key): ?array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $flash = $_SESSION[$key] ?? null;
    unset($_SESSION[$key]);

    return is_array($flash) ? $flash : null;
}

function recordsFlashSet(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['records_flash'] = [$type, $message];
}

function recordsFlashGet(): ?array
{
    return consumeSessionFlash('records_flash');
}

function settingsFlashSet(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['settings_flash'] = [$type, $message];
}

function settingsFlashGet(): ?array
{
    return consumeSessionFlash('settings_flash');
}

function manageRequestsFlashSet(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['manage_requests_flash'] = [$type, $message];
}

function manageRequestsFlashGet(): ?array
{
    return consumeSessionFlash('manage_requests_flash');
}

function appointmentFlashSet(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['appointment_flash'] = [$type, $message];
}

function appointmentFlashGet(): ?array
{
    return consumeSessionFlash('appointment_flash');
}

function queueFlashSet(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['queue_flash'] = [$type, $message];
}

function queueFlashGet(): ?array
{
    return consumeSessionFlash('queue_flash');
}

function documentRequestRevision(array $row): string
{
    return sha1(
        (string) ($row['id'] ?? '')
        . '|' . normalizeRequestStatus((string) ($row['status'] ?? ''))
        . '|' . (string) ($row['updated_at'] ?? '')
        . '|' . (string) ($row['deleted_at'] ?? '')
        . '|' . (string) ($row['rejection_reason'] ?? '')
    );
}

function documentRequestVisitNoShowExistsSql(string $tableAlias = 'document_requests'): string
{
    $trackingColumn = $tableAlias . '.tracking_code';

    return " AND (
        SELECT a.status FROM appointments a
        WHERE a.tracking_code = {$trackingColumn} AND a.deleted_at IS NULL
        ORDER BY a.updated_at DESC, a.id DESC
        LIMIT 1
    ) = 'no_show'";
}

function countDocumentRequestVisitNoShows(PDO $pdo): int
{
    ensureSoftDeleteColumns($pdo);
    $activeSql = documentRequestActiveSql();

    return (int) $pdo->query(
        'SELECT COUNT(*) FROM document_requests WHERE ' . $activeSql . documentRequestVisitNoShowExistsSql('document_requests')
    )->fetchColumn();
}

/** Pending-style views list every matching request (all visit dates). */
function manageRequestManageAwaitingAllDates(array $filters): bool
{
    if (trim((string) ($filters['q'] ?? '')) !== '') {
        return false;
    }

    $status = (string) ($filters['status'] ?? 'all');
    if ($status === 'all_requests') {
        return !($filters['date_explicit'] ?? false);
    }

    return in_array($status, ['all', '', 'pending', 'rejected', 'recently_deleted'], true);
}

function manageRequestListUsesVisitDate(array $filters): bool
{
    if (!manageRequestManageAwaitingAllDates($filters)) {
        return true;
    }

    return ($filters['status'] ?? '') === 'all_requests' && ($filters['date_explicit'] ?? false);
}

function manageRequestsListFilters(array $input, ?PDO $pdo = null): array
{
    $status = (string) ($input['status'] ?? 'all');
    if (!in_array($status, ['all', 'pending', 'ready', 'rejected', 'completed', 'no_show', 'all_requests', 'recently_deleted'], true)) {
        $status = 'all';
    }

    $rawDate = array_key_exists('date', $input) ? trim((string) $input['date']) : null;
    if ($rawDate === '') {
        $rawDate = null;
    }

    if ($pdo !== null) {
        $date = resolveAppointmentsManageDate($pdo, $rawDate);
    } elseif ($rawDate !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $rawDate)) {
        $date = $rawDate;
    } else {
        $date = alcrosTodayDate();
    }

    return [
        'status'        => $status,
        'date'          => $date,
        'date_explicit' => $rawDate !== null,
        'q'             => trim((string) ($input['q'] ?? '')),
    ];
}

function adminSearchNormalizeWhitespace(string $search): string
{
    return trim(preg_replace('/\s+/u', ' ', $search));
}

function adminSearchNameExpr(string $firstCol, string $middleCol, string $lastCol): string
{
    return "TRIM(CONCAT_WS(' ', $firstCol, NULLIF($middleCol, ''), $lastCol))";
}

function adminSearchParseDate(string $search): ?string
{
    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return null;
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $search, $m)) {
        return checkdate((int) $m[2], (int) $m[3], (int) $m[1]) ? $search : null;
    }
    if (preg_match('/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/', $search, $m)) {
        $year = (int) $m[3];
        $month = (int) $m[1];
        $day = (int) $m[2];

        return checkdate($month, $day, $year)
            ? sprintf('%04d-%02d-%02d', $year, $month, $day)
            : null;
    }

    return null;
}

function adminSearchLooksLikeDate(string $search): bool
{
    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return false;
    }
    if (adminSearchParseDate($search) !== null) {
        return true;
    }
    if (preg_match('/^\d{4}$/', $search)) {
        return true;
    }

    return (bool) preg_match('/^\d[\d\/\-\.\s]*$/', $search);
}

/** @return array{0:string, 1:string} */
function adminSearchSplitNameAndDate(string $search): array
{
    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return ['', ''];
    }
    if (adminSearchParseDate($search) !== null || adminSearchLooksLikeDate($search)) {
        return ['', $search];
    }

    $nameTokens = [];
    $dateTokens = [];
    foreach (explode(' ', $search) as $token) {
        if ($token === '') {
            continue;
        }
        if (adminSearchParseDate($token) !== null || adminSearchLooksLikeDate($token)) {
            $dateTokens[] = $token;
        } else {
            $nameTokens[] = $token;
        }
    }

    if ($dateTokens === []) {
        return [$search, ''];
    }

    return [implode(' ', $nameTokens), implode(' ', $dateTokens)];
}

/** @return array{0:list<string>, 1:list<string>} */
function adminSearchNameLikeClauses(string $search, string $firstCol, string $middleCol, string $lastCol): array
{
    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return [[], []];
    }

    $fullExpr = adminSearchNameExpr($firstCol, $middleCol, $lastCol);
    $fullTerm = '%' . $search . '%';
    $tokens = explode(' ', $search);
    $clauses = [
        "$firstCol LIKE ?",
        "$middleCol LIKE ?",
        "$lastCol LIKE ?",
        "$fullExpr LIKE ?",
    ];
    $params = [$fullTerm, $fullTerm, $fullTerm, $fullTerm];

    if (count($tokens) > 1) {
        $tokenGroups = [];
        foreach ($tokens as $token) {
            if ($token === '') {
                continue;
            }
            $term = '%' . $token . '%';
            $tokenGroups[] = "($firstCol LIKE ? OR $middleCol LIKE ? OR $lastCol LIKE ? OR $fullExpr LIKE ?)";
            array_push($params, $term, $term, $term, $term);
        }
        if ($tokenGroups !== []) {
            $clauses[] = '(' . implode(' AND ', $tokenGroups) . ')';
        }
    }

    return [$clauses, $params];
}

function adminSearchDateColumnGroup(string $column): string
{
    return '('
        . "DATE_FORMAT($column, '%Y-%m-%d') LIKE ?"
        . " OR DATE_FORMAT($column, '%m/%d/%Y') LIKE ?"
        . " OR DATE_FORMAT($column, '%c/%e/%Y') LIKE ?"
        . ')';
}

/** @return array{0:list<string>, 1:list<string>} */
function adminSearchDateClausesForColumns(string $search, array $columns): array
{
    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '' || $columns === []) {
        return [[], []];
    }

    $iso = adminSearchParseDate($search);
    if ($iso !== null) {
        $clauses = [];
        $params = [];
        foreach ($columns as $column) {
            $clauses[] = "$column = ?";
            $params[] = $iso;
        }

        return [$clauses, $params];
    }

    if (preg_match('/^\d{4}$/', $search)) {
        $year = (int) $search;
        $clauses = [];
        $params = [];
        foreach ($columns as $column) {
            $clauses[] = "YEAR($column) = ?";
            $params[] = $year;
        }

        return [$clauses, $params];
    }

    $term = '%' . $search . '%';
    $clauses = [];
    $params = [];
    foreach ($columns as $column) {
        $clauses[] = adminSearchDateColumnGroup($column);
        array_push($params, $term, $term, $term);
    }

    return [$clauses, $params];
}

/** @return array{0:string, 1:list<mixed>} */
function adminSearchDateMatchExpr(string $column, string $search): array
{
    [$clauses, $params] = adminSearchDateClausesForColumns($search, [$column]);
    if ($clauses === []) {
        return ['1=0', []];
    }

    return [$clauses[0], $params];
}

function ensureAdminSearchIndexes(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $definitions = [
        'document_requests' => [
            'idx_dob'        => 'date_of_birth',
            'idx_dom'        => 'date_of_marriage',
        ],
        'civil_records' => [
            'idx_birth_date' => 'birth_date',
            'idx_event_date' => 'event_date',
        ],
    ];

    foreach ($definitions as $table => $indexes) {
        foreach ($indexes as $indexName => $column) {
            try {
                $pdo->query("SELECT 1 FROM `$table` USE INDEX ($indexName) LIMIT 1");
            } catch (Throwable $e) {
                try {
                    $pdo->exec("ALTER TABLE `$table` ADD INDEX $indexName (`$column`)");
                } catch (Throwable $ignored) {
                }
            }
        }
    }
}

/** @return list<string> */
function adminSearchDateBlobVariants(?string $date): array
{
    if ($date === null || trim($date) === '') {
        return [];
    }

    $date = trim($date);
    $variants = [$date];
    $ts = strtotime($date);
    if ($ts) {
        $variants[] = date('Y-m-d', $ts);
        $variants[] = date('m/d/Y', $ts);
        $variants[] = date('n/j/Y', $ts);
        $variants[] = formatRecordDate($date);
        $variants[] = formatDateDisplay($date);
    }

    return array_values(array_unique(array_filter(
        $variants,
        static fn ($value) => trim((string) $value) !== '' && $value !== '-'
    )));
}

function documentRequestSearchClause(string $search): array
{
    ensureAdminSearchIndexes(getDB());

    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return ['', []];
    }

    [$nameSearch, $dateSearch] = adminSearchSplitNameAndDate($search);
    if ($nameSearch === '' && $dateSearch === '') {
        $nameSearch = $search;
    }

    $term = '%' . $search . '%';
    $clauses = [];
    $params = [];

    if ($nameSearch !== '') {
        [$nameClauses, $nameParams] = adminSearchNameLikeClauses($nameSearch, 'first_name', 'middle_name', 'last_name');
        $clauses = array_merge($clauses, $nameClauses);
        $params = array_merge($params, $nameParams);
        [$requesterClauses, $requesterParams] = adminSearchNameLikeClauses(
            $nameSearch,
            'requester_first_name',
            'requester_middle_name',
            'requester_last_name'
        );
        $clauses = array_merge($clauses, $requesterClauses);
        $params = array_merge($params, $requesterParams);
    }

    foreach (['tracking_code', 'email', 'phone', 'purpose', 'notes', 'document_type'] as $field) {
        $clauses[] = "$field LIKE ?";
        $params[] = $term;
    }
    $clauses[] = 'CAST(id AS CHAR) LIKE ?';
    $params[] = $term;

    $dateQuery = $dateSearch !== '' ? $dateSearch : (adminSearchLooksLikeDate($search) ? $search : '');
    if ($dateQuery !== '') {
        [$dateClauses, $dateParams] = adminSearchDateClausesForColumns($dateQuery, [
            'date_of_birth',
            'date_of_marriage',
        ]);
        $clauses = array_merge($clauses, $dateClauses);
        $params = array_merge($params, $dateParams);
    }

    return [
        ' AND (' . implode(' OR ', $clauses) . ')',
        $params,
    ];
}

function manageRequestsListSql(array $filters): array
{
    $sql = 'SELECT * FROM document_requests WHERE 1=1';
    $params = [];
    $status = $filters['status'];
    $search = $filters['q'];

    if ($status === 'recently_deleted') {
        $sql .= ' AND deleted_at IS NOT NULL';
    } else {
        $sql .= ' AND deleted_at IS NULL';
    }
    if ($search !== '') {
        if ($status === 'no_show') {
            $sql .= documentRequestVisitNoShowExistsSql('document_requests');
        } elseif ($status !== 'all' && $status !== '' && $status !== 'all_requests' && $status !== 'recently_deleted') {
            $sql .= ' AND status = ?';
            $params[] = $status;
        }
    } elseif ($status === 'all_requests') {
        // all active
    } elseif ($status === 'recently_deleted') {
        // deleted only
    } elseif ($status === 'no_show') {
        $sql .= documentRequestVisitNoShowExistsSql('document_requests');
    } elseif ($status === 'all' || $status === '') {
        $sql .= " AND status = 'pending'";
    } elseif ($status !== 'all' && $status !== '') {
        $sql .= ' AND status = ?';
        $params[] = $status;
    }

    if (manageRequestListUsesVisitDate($filters)) {
        $sql .= ' AND appointment_date = ?';
        $params[] = $filters['date'];
    }

    [$searchSql, $searchParams] = documentRequestSearchClause($search);
    $sql .= $searchSql;
    $params = array_merge($params, $searchParams);
    $sql .= $status === 'recently_deleted' ? ' ORDER BY deleted_at DESC' : ' ORDER BY submitted_at DESC';

    return [$sql, $params];
}

/** Status counts for requests scheduled on a single pickup visit date. */
function fetchManageRequestVisitDateStats(PDO $pdo, string $viewDate): array
{
    ensureSoftDeleteColumns($pdo);
    $activeSql = documentRequestActiveSql();

    $stmt = $pdo->prepare(
        "SELECT status, COUNT(*) AS cnt FROM document_requests
         WHERE {$activeSql} AND appointment_date = ?
         GROUP BY status"
    );
    $stmt->execute([$viewDate]);
    $byStatus = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $byStatus[(string) $row['status']] = (int) $row['cnt'];
    }

    $noShowStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM document_requests dr
         WHERE ' . documentRequestActiveSql('dr') . '
           AND dr.appointment_date = ?'
        . documentRequestVisitNoShowExistsSql('dr')
    );
    $noShowStmt->execute([$viewDate]);
    $noShow = (int) $noShowStmt->fetchColumn();

    $visitTotal = array_sum($byStatus);

    return [
        'visit_total' => $visitTotal,
        'ready'       => (int) ($byStatus['ready'] ?? 0),
        'completed'   => (int) ($byStatus['completed'] ?? 0),
        'no_show'     => $noShow,
        'pending'     => (int) ($byStatus['pending'] ?? 0),
    ];
}

function fetchManageRequestStats(PDO $pdo): array
{
    ensureSoftDeleteColumns($pdo);
    $activeSql = documentRequestActiveSql();

    return [
        'total'            => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$activeSql}")->fetchColumn(),
        'pending'          => countPendingDocumentRequests($pdo),
        'ready'            => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$activeSql} AND status = 'ready'")->fetchColumn(),
        'completed'        => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$activeSql} AND status = 'completed'")->fetchColumn(),
        'no_show'          => countDocumentRequestVisitNoShows($pdo),
        'rejected'         => (int) $pdo->query("SELECT COUNT(*) FROM document_requests WHERE {$activeSql} AND status = 'rejected'")->fetchColumn(),
        'recently_deleted' => (int) $pdo->query('SELECT COUNT(*) FROM document_requests WHERE deleted_at IS NOT NULL')->fetchColumn(),
    ];
}

function countPendingDocumentRequests(PDO $pdo): int
{
    ensureSoftDeleteColumns($pdo);
    $activeSql = documentRequestActiveSql();

    return (int) $pdo->query(
        "SELECT COUNT(*) FROM document_requests WHERE {$activeSql} AND status = 'pending'"
    )->fetchColumn();
}

function countPendingAppointments(PDO $pdo): int
{
    ensureCitizenNotifyColumns($pdo);
    ensureSoftDeleteColumns($pdo);
    $standaloneSql = appointmentStandaloneSql('a');

    return (int) $pdo->query(
        "SELECT COUNT(*) FROM appointments a
         WHERE a.status = 'scheduled'
           AND {$standaloneSql}
           AND a.deleted_at IS NULL"
    )->fetchColumn();
}

/** Awaiting views list every scheduled standalone visit (all dates), not a single calendar day. */
function appointmentManageAwaitingAllDates(array $filters): bool
{
    if (trim((string) ($filters['q'] ?? '')) !== '') {
        return false;
    }

    $status = (string) ($filters['status'] ?? 'all');

    return $status === 'all' || $status === '' || $status === 'scheduled';
}

function appointmentRevision(array $row, ?array $followUpPending = null): string
{
    $followUpPart = '';
    if ($followUpPending) {
        $followUpPart = '|fu:'
            . (int) ($followUpPending['id'] ?? 0)
            . '|' . (string) ($followUpPending['updated_at'] ?? '')
            . '|' . (string) ($followUpPending['follow_up_date'] ?? '')
            . '|' . (string) ($followUpPending['status'] ?? '');
    }

    return sha1(
        (string) ($row['id'] ?? '')
        . '|' . (string) ($row['status'] ?? '')
        . '|' . (string) ($row['updated_at'] ?? '')
        . '|' . (string) ($row['deleted_at'] ?? '')
        . $followUpPart
    );
}

function appointmentsListFilters(array $input, ?PDO $pdo = null): array
{
    $status = (string) ($input['status'] ?? 'all');
    if (!in_array($status, ['all', 'scheduled', 'confirmed', 'completed', 'no_show', 'cancelled', 'all_appointments', 'recently_deleted', 'follow_ups'], true)) {
        $status = 'all';
    }

    $rawDate = array_key_exists('date', $input) ? trim((string) $input['date']) : null;
    if ($rawDate === '') {
        $rawDate = null;
    }

    if ($pdo !== null) {
        $date = resolveAppointmentsManageDate($pdo, $rawDate);
    } elseif ($rawDate !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $rawDate)) {
        $date = $rawDate;
    } else {
        $date = alcrosTodayDate();
    }

    return [
        'status' => $status,
        'date'   => $date,
        'q'      => trim((string) ($input['q'] ?? '')),
    ];
}

function fetchAppointmentDayStats(PDO $pdo, string $viewDate): array
{
    ensureCitizenNotifyColumns($pdo);
    ensureSoftDeleteColumns($pdo);
    ensureAppointmentUpdatedColumn($pdo);
    $standaloneSql = appointmentStandaloneSql('a');

    $statsStmt = $pdo->prepare(
        "SELECT status, COUNT(*) AS cnt FROM appointments a
         WHERE a.appointment_date = ? AND {$standaloneSql} AND a.deleted_at IS NULL
         GROUP BY status"
    );
    $statsStmt->execute([$viewDate]);
    $statusCounts = [];
    foreach ($statsStmt->fetchAll(PDO::FETCH_ASSOC) as $statRow) {
        $statusCounts[(string) $statRow['status']] = (int) $statRow['cnt'];
    }

    $recentlyDeletedStmt = $pdo->prepare(
        "SELECT COUNT(*) FROM appointments a
         WHERE a.appointment_date = ? AND {$standaloneSql} AND a.deleted_at IS NOT NULL"
    );
    $recentlyDeletedStmt->execute([$viewDate]);

    require_once __DIR__ . '/appointment_follow_up.php';

    return [
        'total'            => array_sum($statusCounts),
        'scheduled'        => (int) ($statusCounts['scheduled'] ?? 0),
        'confirmed'        => (int) ($statusCounts['confirmed'] ?? 0),
        'completed'        => countCompletedAppointmentsWithoutPendingFollowUp($pdo, $viewDate),
        'no_show'          => (int) ($statusCounts['no_show'] ?? 0),
        'cancelled'        => (int) ($statusCounts['cancelled'] ?? 0),
        'recently_deleted' => (int) $recentlyDeletedStmt->fetchColumn(),
        'follow_ups'       => countPendingAppointmentFollowUps($pdo),
    ];
}

/** @return array<int, array<string, mixed>> */
function fetchAppointmentsManageList(PDO $pdo, array $filters): array
{
    ensureCitizenNotifyColumns($pdo);
    ensureSoftDeleteColumns($pdo);
    ensureAppointmentUpdatedColumn($pdo);

    if (($filters['status'] ?? '') === 'follow_ups') {
        return [];
    }

    $viewDate = $filters['date'];
    $filterStatus = $filters['status'];
    $search = $filters['q'];
    $isSearchMode = $search !== '';
    $awaitingAllDates = appointmentManageAwaitingAllDates($filters);
    $standaloneSql = appointmentStandaloneSql('a');

    $sql = "SELECT a.*, dr.date_of_birth, dr.date_of_marriage, dr.sex, dr.document_type AS request_document_type
            FROM appointments a
            LEFT JOIN document_requests dr ON dr.tracking_code = a.tracking_code AND dr.deleted_at IS NULL
            WHERE {$standaloneSql}";
    $params = [];

    if ($isSearchMode) {
        if ($filterStatus === 'recently_deleted') {
            $sql .= ' AND a.deleted_at IS NOT NULL';
        } else {
            $sql .= ' AND a.deleted_at IS NULL';
        }
    } elseif ($filterStatus === 'recently_deleted') {
        $sql .= ' AND a.appointment_date = ? AND a.deleted_at IS NOT NULL';
        $params[] = $viewDate;
    } elseif ($awaitingAllDates) {
        $sql .= ' AND a.deleted_at IS NULL';
    } else {
        $sql .= ' AND a.appointment_date = ? AND a.deleted_at IS NULL';
        $params[] = $viewDate;
    }

    if ($search !== '') {
        if ($filterStatus !== 'all' && $filterStatus !== '' && $filterStatus !== 'all_appointments') {
            $sql .= ' AND a.status = ?';
            $params[] = $filterStatus;
            if ($filterStatus === 'completed') {
                $sql .= ' AND ' . appointmentSqlExcludePendingFollowUp('a');
            }
        }
    } elseif ($filterStatus === 'all_appointments') {
        // All active statuses for this date.
    } elseif ($filterStatus === 'recently_deleted') {
        // Deleted items only for this date.
    } elseif ($filterStatus === 'all' || $filterStatus === '') {
        $sql .= " AND a.status = 'scheduled'";
    } else {
        $sql .= ' AND a.status = ?';
        $params[] = $filterStatus;
        if ($filterStatus === 'completed') {
            $sql .= ' AND ' . appointmentSqlExcludePendingFollowUp('a');
        }
    }

    [$searchSql, $searchParams] = appointmentSearchClause($search, 'a');
    $sql .= $searchSql;
    $params = array_merge($params, $searchParams);

    if ($isSearchMode) {
        $sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time ASC LIMIT 100';
    } elseif ($awaitingAllDates) {
        $sql .= ' ORDER BY a.appointment_date ASC, a.appointment_time ASC';
    } else {
        $sql .= $filterStatus === 'recently_deleted' ? ' ORDER BY a.deleted_at DESC' : ' ORDER BY a.appointment_time ASC';
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/** @return array<int, array<string, mixed>> */
function fetchManageRequestsList(PDO $pdo, array $filters): array
{
    ensureSoftDeleteColumns($pdo);
    migrateLegacyProcessingStatus($pdo);
    [$sql, $params] = manageRequestsListSql($filters);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function fetchDocumentRequestById(PDO $pdo, int $id, bool $includeDeleted = false): ?array
{
    if ($id <= 0) {
        return null;
    }

    ensureSoftDeleteColumns($pdo);
    $sql = 'SELECT * FROM document_requests WHERE id = ?';
    if (!$includeDeleted) {
        $sql .= ' AND deleted_at IS NULL';
    }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

function publicTrackingRevision(array $requestRow, ?array $appointmentRow = null): string
{
    $parts = [
        documentRequestRevision($requestRow),
        (string) ($appointmentRow['status'] ?? ''),
        (string) ($appointmentRow['appointment_date'] ?? ''),
        (string) ($appointmentRow['appointment_time'] ?? ''),
        (string) ($appointmentRow['updated_at'] ?? $appointmentRow['created_at'] ?? ''),
    ];

    return sha1(implode('|', $parts));
}

function documentRequestViewData(array $row): array
{
    // can_print comes from printing.php, which API callers do not always load.
    if (!function_exists('canPrintRequestStatus')) {
        require_once __DIR__ . '/printing.php';
    }
    if (!function_exists('documentRequestRelationshipLabel')) {
        require_once __DIR__ . '/document_request_relationship_requirements.php';
    }

    $appointment = formatAppointmentDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
    $statusKey = normalizeRequestStatus((string) ($row['status'] ?? 'pending'));
    $actions = requestStatusActionsFor($statusKey);
    $actionOptions = [];
    foreach ($actions as $action) {
        $actionOptions[] = [
            'value' => $action,
            'label' => requestStatusActionLabel($action),
        ];
    }

    return [
        'id'             => (int) ($row['id'] ?? 0),
        'tracking_code'  => (string) ($row['tracking_code'] ?? ''),
        'citizen_name'   => documentRequestNameOnRecord($row),
        'requester_name' => ($rn = personRequesterNameFromRow($row)) !== '' ? $rn : '-',
        'requester_relationship'      => (string) ($row['requester_relationship'] ?? ''),
        'requester_relationship_label' => ($rr = documentRequestRelationshipLabel(
            (string) ($row['document_type'] ?? ''),
            (string) ($row['requester_relationship'] ?? '')
        )) !== '' ? $rr : '-',
        'first_name'     => (string) ($row['first_name'] ?? ''),
        'middle_name'    => (string) ($row['middle_name'] ?? ''),
        'last_name'      => (string) ($row['last_name'] ?? ''),
        'date_of_birth'      => !empty($row['date_of_birth']) ? formatDateDisplay($row['date_of_birth']) : '-',
        'date_of_marriage'   => !empty($row['date_of_marriage']) ? formatDateDisplay($row['date_of_marriage']) : '-',
        'document_type_key'  => (string) ($row['document_type'] ?? ''),
        'sex'                => !empty($row['sex']) ? ucfirst((string) $row['sex']) : '-',
        'email'          => !empty($row['email']) ? (string) $row['email'] : '-',
        'email_verified' => !empty($row['email_verified']) ? 'Yes' : 'No',
        'phone'          => !empty($row['phone']) ? (string) $row['phone'] : '-',
        'document_type'  => documentTypeLabel((string) ($row['document_type'] ?? '')),
        'purpose'        => !empty($row['purpose']) ? (string) $row['purpose'] : '-',
        'id_front_path'  => protectedUploadUrl(!empty($row['id_front_path']) ? (string) $row['id_front_path'] : null),
        'id_back_path'   => protectedUploadUrl(!empty($row['id_back_path']) ? (string) $row['id_back_path'] : null),
        'appointment'    => $appointment !== '' ? $appointment : '-',
        'status'         => requestStatusLabel($statusKey, $row['rejection_reason'] ?? null),
        'status_key'     => $statusKey,
        'status_badge_html' => requestStatusBadge($statusKey, $row['rejection_reason'] ?? null),
        'can_delete'     => documentRequestIsDeletable($row),
        'can_print'      => canPrintRequestStatus($statusKey)
            && ($row['document_type'] ?? '') !== 'cenomar',
        'print_url'              => buildAuthUrl('print_certificate.php', ['request_id' => (int) ($row['id'] ?? 0)]),
        'print_certification_url'=> buildAuthUrl('print_certificate.php', [
            'request_id' => (int) ($row['id'] ?? 0),
            'kind'         => 'certification',
        ]),
        'actions'        => $actionOptions,
        'privacy_agreed' => !empty($row['privacy_agreed']) ? 'Yes' : 'No',
        'submitted_at'   => !empty($row['submitted_at']) ? formatDateDisplay($row['submitted_at']) : '-',
        'updated_at'     => !empty($row['updated_at']) ? formatDateDisplay($row['updated_at']) : '-',
        'updated_at_iso' => (string) ($row['updated_at'] ?? ''),
        'revision'         => documentRequestRevision($row),
        'notes'            => !empty($row['notes']) ? (string) $row['notes'] : null,
        'rejection_reason' => !empty($row['rejection_reason']) ? (string) $row['rejection_reason'] : null,
    ];
}

function appointmentViewData(array $row, ?PDO $pdo = null): array
{
    $isRequest = (($row['source'] ?? '') === 'document_request') || !empty($row['tracking_code']);
    $statusKey = (string) ($row['status'] ?? 'scheduled');
    $actions = appointmentStatusActionsFor($statusKey);
    $actionOptions = [];
    foreach ($actions as $action) {
        $actionOptions[] = [
            'value' => $action,
            'label' => appointmentStatusActionLabel($action),
        ];
    }

    $view = [
        'id'               => (int) ($row['id'] ?? 0),
        'appointment_code' => (string) ($row['appointment_code'] ?? ''),
        'citizen_name'     => personNameFromRow($row),
        'first_name'       => (string) ($row['first_name'] ?? ''),
        'middle_name'      => (string) ($row['middle_name'] ?? ''),
        'last_name'          => (string) ($row['last_name'] ?? ''),
        'date_of_birth'      => !empty($row['date_of_birth']) ? formatDateDisplay($row['date_of_birth']) : '-',
        'date_of_marriage'   => !empty($row['date_of_marriage']) ? formatDateDisplay($row['date_of_marriage']) : '-',
        'sex'                => !empty($row['sex']) ? ucfirst((string) $row['sex']) : '-',
        'document_type_key'  => (string) ($row['request_document_type'] ?? ''),
        'email'              => !empty($row['email']) ? (string) $row['email'] : '-',
        'phone'              => !empty($row['phone']) ? (string) $row['phone'] : '-',
        'service_type'       => appointmentServiceLabel((string) ($row['service_type'] ?? '')),
        'schedule'         => formatAppointmentDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null) ?: '-',
        'status'           => appointmentDisplayStatusLabel($row),
        'status_key'       => $statusKey,
        'status_badge_html' => appointmentStatusBadge($statusKey, $row['rejection_reason'] ?? null),
        'source'           => $isRequest ? 'Document request visit' : 'Special service appointment',
        'tracking_code'    => !empty($row['tracking_code']) ? (string) $row['tracking_code'] : '',
        'notify_email'     => !empty($row['notify_email']) ? 'Yes' : 'No',
        'id_front_path'    => protectedUploadUrl(!empty($row['id_front_path']) ? (string) $row['id_front_path'] : null),
        'id_back_path'     => protectedUploadUrl(!empty($row['id_back_path']) ? (string) $row['id_back_path'] : null),
        'created_at'       => !empty($row['created_at']) ? formatReportDateTime($row['created_at']) : '-',
        'can_delete'       => (string) ($row['status'] ?? '') === 'completed',
        'actions'          => $actionOptions,
        'notes'              => !empty($row['notes']) ? (string) $row['notes'] : null,
        'rejection_reason'   => !empty($row['rejection_reason']) ? (string) $row['rejection_reason'] : null,
        'can_schedule_follow_up' => false,
        'follow_up'        => null,
        'follow_up_log'    => [],
    ];

    $pendingFollowUp = null;
    if ($pdo !== null && appointmentAllowsFollowUp($row)) {
        require_once __DIR__ . '/appointment_follow_up.php';
        ensureAppointmentFollowUpsTable($pdo);
        $view['can_schedule_follow_up'] = $statusKey === 'completed';
        $pendingFollowUp = fetchPendingFollowUpByAppointmentId($pdo, (int) ($row['id'] ?? 0));
        $view['follow_up'] = appointmentFollowUpViewData($pendingFollowUp);
        $view['follow_up_log'] = array_map(
            static fn (array $entry) => appointmentFollowUpLogEntryViewData($entry),
            fetchFollowUpLogByAppointmentId($pdo, (int) ($row['id'] ?? 0))
        );
    }

    $view['revision'] = appointmentRevision($row, $pendingFollowUp);

    return $view;
}

function appointmentSearchClause(string $search, string $alias = 'a', ?string $requestAlias = 'dr'): array
{
    ensureAdminSearchIndexes(getDB());

    $search = adminSearchNormalizeWhitespace($search);
    if ($search === '') {
        return ['', []];
    }

    [$nameSearch, $dateSearch] = adminSearchSplitNameAndDate($search);
    if ($nameSearch === '' && $dateSearch === '') {
        $nameSearch = $search;
    }

    $term = '%' . $search . '%';
    $col = static fn (string $field) => $alias . '.' . $field;
    $clauses = [];
    $params = [];

    if ($nameSearch !== '') {
        [$nameClauses, $nameParams] = adminSearchNameLikeClauses(
            $nameSearch,
            $col('first_name'),
            $col('middle_name'),
            $col('last_name')
        );
        $clauses = array_merge($clauses, $nameClauses);
        $params = array_merge($params, $nameParams);
    }

    foreach (['appointment_code', 'tracking_code', 'phone', 'email', 'service_type'] as $field) {
        $clauses[] = $col($field) . ' LIKE ?';
        $params[] = $term;
    }
    $clauses[] = 'CAST(' . $col('id') . ' AS CHAR) LIKE ?';
    $params[] = $term;

    if ($requestAlias !== null && $requestAlias !== '') {
        $reqCol = static fn (string $field) => $requestAlias . '.' . $field;
        $clauses[] = $reqCol('document_type') . ' LIKE ?';
        $params[] = $term;

        $dateQuery = $dateSearch !== '' ? $dateSearch : (adminSearchLooksLikeDate($search) ? $search : '');
        if ($dateQuery !== '') {
            [$dateClauses, $dateParams] = adminSearchDateClausesForColumns($dateQuery, [
                $reqCol('date_of_birth'),
                $reqCol('date_of_marriage'),
            ]);
            $clauses = array_merge($clauses, $dateClauses);
            $params = array_merge($params, $dateParams);
        }
    }

    return [
        ' AND (' . implode(' OR ', $clauses) . ')',
        $params,
    ];
}

function requestStatusLabel(string $status, ?string $rejectionReason = null): string
{
    $status = normalizeRequestStatus($status);
    if ($status === 'rejected' && isCitizenCancellationReason($rejectionReason)) {
        return citizenCancelledStatusLabel();
    }

    return match ($status) {
        'pending'       => 'Pending',
        'processing'    => 'Processing',
        'printing'      => 'Printing',
        'printed'       => 'Printed',
        'quality_check' => 'Quality Check',
        'verified'      => 'Verified',
        'ready'         => 'Ready for Pickup',
        'completed'     => 'Completed',
        'rejected'      => 'Rejected',
        default         => ucfirst($status),
    };
}

function requestStatusMessage(string $status): string
{
    return match (normalizeRequestStatus($status)) {
        'pending'       => 'We received your request. Staff will review your documents soon.',
        'processing'    => 'Your request has been accepted and is being processed by the registry office.',
        'printing'      => 'Your certificate is currently being printed.',
        'printed'       => 'Your certificate has been printed and is awaiting quality inspection.',
        'quality_check' => 'Your certificate passed quality check and will be prepared for pickup soon.',
        'verified'      => 'Your request has been verified. The civil registry office is now processing your document.',
        'ready'         => 'Your document is ready for pickup! Visit the office with your tracking code and valid ID.',
        'completed'     => 'This request is complete. Thank you for using ALCROS.',
        'rejected'      => 'This request could not be approved. Please contact the registry office for help.',
        default         => 'Track your request status below.',
    };
}

function fetchDocumentRequestAppointment(PDO $pdo, string $trackingCode): ?array
{
    $trackingCode = trim($trackingCode);
    if ($trackingCode === '') {
        return null;
    }

    ensureSoftDeleteColumns($pdo);
    ensureAppointmentUpdatedColumn($pdo);

    $stmt = $pdo->prepare(
        "SELECT appointment_code, status, appointment_date, appointment_time, updated_at, created_at
         FROM appointments
         WHERE tracking_code = ? AND deleted_at IS NULL
         ORDER BY updated_at DESC, id DESC
         LIMIT 1"
    );
    $stmt->execute([$trackingCode]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

function publicRequestStatusLabel(string $status): string
{
    return match (normalizeRequestStatus($status)) {
        'verified'  => 'Confirmed · Ready for Pickup',
        'ready'     => 'Ready for Pickup',
        default     => requestStatusLabel($status),
    };
}

function publicRequestStatusMessage(
    string $status,
    ?array $appointment = null,
    bool $emailDateFormat = false,
    ?string $rejectionReason = null
): string {
    $status = normalizeRequestStatus($status);

    if ($status === 'verified' || $status === 'ready') {
        $visit = '';
        if ($appointment && !empty($appointment['appointment_date'])) {
            $schedule = $emailDateFormat
                ? formatAppointmentEmailDisplay($appointment['appointment_date'], $appointment['appointment_time'] ?? null)
                : formatAppointmentDisplay($appointment['appointment_date'], $appointment['appointment_time'] ?? null);
            $visit = ' Your confirmed visit is on '
                . $schedule
                . '.';
        }

        return 'Your request has been verified, your pickup visit is confirmed, and your document is ready for pickup.'
            . $visit
            . ' Please visit the Local Civil Registrar Office with your tracking code and a valid ID.';
    }

    $message = requestStatusMessage($status);
    if ($status === 'rejected') {
        return citizenStatusMessageWithRejectionReason($message, $rejectionReason);
    }

    return $message;
}

function publicRequestStatusProgressIndex(string $status): int|false
{
    return requestStatusProgressIndex($status);
}

function publicRequestStatusBadge(string $status): string
{
    $status = normalizeRequestStatus($status);
    $classes = [
        'pending'   => 'bg-yellow-100 text-yellow-700',
        'verified'  => 'bg-green-100 text-green-700',
        'ready'     => 'bg-green-100 text-green-700',
        'completed' => 'bg-gray-100 text-gray-600',
        'rejected'  => 'bg-red-100 text-red-700',
    ];
    $class = $classes[$status] ?? 'bg-gray-100 text-gray-600';

    return '<span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase ' . $class . '">'
        . htmlspecialchars(publicRequestStatusLabel($status))
        . '</span>';
}

/** Web path prefix for ALCROS (e.g. `/alcros`), derived from the project folder under the docroot. */
function alcrosWebBasePath(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }

    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    $projectRoot = realpath(dirname(__DIR__));
    if ($docRoot !== false && $projectRoot !== false) {
        $docNorm = str_replace('\\', '/', $docRoot);
        $projNorm = str_replace('\\', '/', $projectRoot);
        if (str_starts_with($projNorm, $docNorm)) {
            $base = rtrim(substr($projNorm, strlen($docNorm)), '/');

            return $base;
        }
    }

    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    $dir = rtrim(dirname($script), '/\\');
    if (str_ends_with($dir, '/api')) {
        $dir = substr($dir, 0, -4);
    }
    if ($dir === '' || $dir === '.' || $dir === '/') {
        $base = '';
    } else {
        $base = $dir;
    }

    return $base;
}

/** Root-relative URL to a portal page (safe from scripts under /api/). */
function alcrosPortalUrl(string $path, array $query = []): string
{
    $path = ltrim(str_replace('\\', '/', $path), '/');
    $base = alcrosWebBasePath();
    $url = ($base !== '' ? rtrim($base, '/') . '/' : '/') . $path;
    if ($query !== []) {
        $url .= '?' . http_build_query($query);
    }

    return $url;
}

function appBaseUrl(): string
{
    $scheme = function_exists('alcrosRequestScheme') ? alcrosRequestScheme() : (((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'));
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path   = alcrosWebBasePath();
    if ($path === '') {
        return $scheme . '://' . $host;
    }

    return $scheme . '://' . $host . $path;
}

function trackRequestUrl(string $trackingCode): string
{
    return appBaseUrl() . '/index.php?track=' . urlencode($trackingCode);
}

function citizenWantsEmailNotify(?array $row): bool
{
    if (!$row) {
        return false;
    }
    $email = trim((string) ($row['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    return !empty($row['notify_email']);
}

function smtpRead($fp): string
{
    $data = '';
    while (!feof($fp)) {
        $line = fgets($fp, 515);
        if ($line === false) {
            break;
        }
        $data .= $line;
        if (isset($line[3]) && $line[3] === ' ') {
            break;
        }
    }
    return $data;
}

function smtpCommand($fp, string $command, string $expectPrefix): bool
{
    fwrite($fp, $command . "\r\n");
    $response = smtpRead($fp);
    return str_starts_with($response, $expectPrefix);
}

function citizenEmailText(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function citizenEmailPlain(array $mail): string
{
    $lines = [];
    $lines[] = mb_strtoupper(trim((string) ($mail['heading'] ?? 'Update from ALCROS')), 'UTF-8');
    $lines[] = '';
    $name = trim((string) ($mail['name'] ?? ''));
    $lines[] = $name !== '' ? 'Dear ' . $name . ',' : 'Hello,';
    $lines[] = '';
    $lines[] = trim((string) ($mail['intro'] ?? ''));
    $lines[] = '';
    $feesSummary = trim((string) ($mail['fees_summary'] ?? ''));
    if ($feesSummary !== '') {
        $lines[] = 'Office fees:';
        foreach (preg_split('/\R/u', $feesSummary) ?: [] as $feeLine) {
            $feeLine = trim($feeLine);
            if ($feeLine !== '') {
                $lines[] = $feeLine;
            }
        }
        $lines[] = '';
    }
    if (!empty($mail['code'])) {
        $lines[] = ($mail['code_label'] ?? 'Code') . ': ' . $mail['code'];
    }
    foreach ($mail['details'] ?? [] as $label => $value) {
        $value = trim((string) $value);
        if ($value === '') {
            continue;
        }
        $lines[] = $label . ': ' . $value;
    }
    $lines[] = '';
    if (!empty($mail['requirements_plain'])) {
        $lines[] = trim((string) $mail['requirements_plain']);
        $lines[] = '';
    }
    if (!empty($mail['note'])) {
        $lines[] = trim((string) $mail['note']);
        $lines[] = '';
    }
    if (!empty($mail['button_url'])) {
        $lines[] = ($mail['button_label'] ?? 'Open link') . ':';
        $lines[] = (string) $mail['button_url'];
        $lines[] = '';
    }
    $office = getSetting('office_name', 'Local Civil Registrar Office');
    $lines[] = 'DO NOT REPLY. This is an automated message from ALCROS.';
    $lines[] = '- ALCROS, ' . $office;

    return implode("\n", $lines);
}

function citizenEmailHtml(array $mail): string
{
    $site    = getSetting('site_name', 'ALCROS');
    $office  = getSetting('office_name', 'Local Civil Registrar Office');
    $phone   = getSetting('office_phone', '');
    $hours   = getSetting('office_hours', '');
    $accent  = (string) ($mail['accent'] ?? '#2563eb');
    $heading = (string) ($mail['heading'] ?? 'Update from ALCROS');
    $name    = trim((string) ($mail['name'] ?? ''));
    $intro   = trim((string) ($mail['intro'] ?? ''));
    $note    = trim((string) ($mail['note'] ?? ''));
    $code    = trim((string) ($mail['code'] ?? ''));
    $feesSummary = trim((string) ($mail['fees_summary'] ?? ''));
    $preheader = trim((string) ($mail['preheader'] ?? ''));
    if ($preheader === '') {
        if ($feesSummary !== '') {
            $feesInline = preg_replace('/\R/u', ' · ', $feesSummary) ?? $feesSummary;
            $preheader = 'Office fees: ' . $feesInline;
            if ($intro !== '') {
                $preheader .= ' · ' . $intro;
            }
        } else {
            $preheader = $intro !== '' ? $intro : $heading;
        }
    }
    if (mb_strlen($preheader) > 200) {
        $preheader = mb_substr($preheader, 0, 197) . '…';
    }

    $feesHtml = '';
    if ($feesSummary !== '') {
        $feesHtml = '<div style="margin:0 0 20px;padding:14px 16px;background:#fffbeb;border:1px solid #fcd34d;border-radius:10px;">'
            . '<p style="margin:0 0 6px;font-size:10px;font-weight:bold;letter-spacing:.08em;text-transform:uppercase;color:#b45309;">Office fees</p>'
            . '<p style="margin:0;font-size:14px;font-weight:700;line-height:1.6;color:#92400e;">'
            . nl2br(citizenEmailText($feesSummary), false)
            . '</p></div>';
    }

    $detailRows = '';
    foreach ($mail['details'] ?? [] as $label => $value) {
        $value = trim((string) $value);
        if ($value === '') {
            continue;
        }
        $detailRows .= '<tr>'
            . '<td style="padding:8px 0;font-size:11px;font-weight:bold;letter-spacing:.04em;text-transform:uppercase;color:#94a3b8;width:38%;vertical-align:top;">'
            . citizenEmailText((string) $label) . '</td>'
            . '<td style="padding:8px 0;font-size:14px;color:#0f172a;font-weight:600;">'
            . citizenEmailText($value) . '</td>'
            . '</tr>';
    }

    $codeBlock = '';
    if ($code !== '') {
        $codeBlock = '<p style="margin:0 0 4px;font-size:11px;font-weight:bold;letter-spacing:.08em;text-transform:uppercase;color:#94a3b8;">'
            . citizenEmailText((string) ($mail['code_label'] ?? 'Code')) . '</p>'
            . '<p style="margin:0 0 16px;font-size:22px;letter-spacing:.12em;font-weight:800;color:' . citizenEmailText($accent) . ';font-family:Consolas,\'Courier New\',monospace;">'
            . citizenEmailText($code) . '</p>';
    }

    $button = '';
    if (!empty($mail['button_url'])) {
        $label = citizenEmailText((string) ($mail['button_label'] ?? 'View details'));
        $url   = citizenEmailText((string) $mail['button_url']);
        $button = '<table cellpadding="0" cellspacing="0" border="0" style="margin:4px 0 8px;">'
            . '<tr><td style="background:' . citizenEmailText($accent) . ';border-radius:8px;">'
            . '<a href="' . $url . '" style="display:inline-block;padding:12px 22px;color:#ffffff;text-decoration:none;font-size:13px;font-weight:bold;font-family:Arial,Helvetica,sans-serif;">'
            . $label . '</a></td></tr></table>';
    }

    $introHtml = $intro !== ''
        ? '<p style="margin:0 0 20px;font-size:14px;line-height:1.65;color:#475569;">' . nl2br(citizenEmailText($intro)) . '</p>'
        : '';
    $noteHtml = $note !== ''
        ? '<p style="margin:18px 0 20px;font-size:14px;line-height:1.65;color:#475569;">' . nl2br(citizenEmailText($note)) . '</p>'
        : '';
    $hello = $name !== '' ? 'Hello, ' . $name : 'Hello';
    $footerBits = array_filter([$hours !== '' ? 'Office hours: ' . $hours : '', $phone !== '' ? 'Contact: ' . $phone : '']);
    $footer = implode(' · ', $footerBits);

    $titleBlock = '<h1 style="margin:0 0 12px;font-size:28px;line-height:1.25;font-weight:800;color:#0f172a;text-transform:uppercase;letter-spacing:.04em;">'
        . citizenEmailText($heading) . '</h1>'
        . '<p style="margin:0 0 16px;font-size:16px;line-height:1.4;color:#334155;font-weight:600;">'
        . citizenEmailText($hello) . '</p>';

    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"></head>'
        . '<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">'
        . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">' . citizenEmailText($preheader) . '</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f1f5f9;padding:24px 12px;">'
        . '<tr><td align="center">'
        . '<table role="presentation" width="560" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;">'
        . '<tr><td style="background:' . citizenEmailText($accent) . ';padding:22px 28px;">'
        . '<p style="margin:0;color:#ffffff;font-size:11px;letter-spacing:.18em;font-weight:bold;">' . citizenEmailText($site) . '</p>'
        . '<p style="margin:6px 0 0;color:#ffffff;font-size:13px;opacity:.9;">' . citizenEmailText($office) . '</p>'
        . '</td></tr>'
        . '<tr><td style="padding:28px;">'
        . $titleBlock
        . $introHtml
        . $feesHtml
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;">'
        . '<tr><td style="padding:18px 20px;">' . $codeBlock
        . ($detailRows !== '' ? '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $detailRows . '</table>' : '')
        . '</td></tr></table>'
        . ($mail['requirements_html'] ?? '')
        . $noteHtml
        . $button
        . '</td></tr>'
        . '<tr><td style="padding:16px 28px 24px;border-top:1px solid #e2e8f0;">'
        . '<p style="margin:0;font-size:12px;line-height:1.6;color:#94a3b8;">'
        . citizenEmailText($footer) . ($footer !== '' ? '<br>' : '')
        . '<strong style="color:#64748b;">DO NOT REPLY.</strong> This is an automated message from ALCROS.'
        . '</p></td></tr>'
        . '</table></td></tr></table></body></html>';
}

function sendCitizenNotice(string $to, string $subject, array $mail, string $emailType = 'general'): bool
{
    $ok = sendCitizenEmail($to, $subject, citizenEmailPlain($mail), citizenEmailHtml($mail));
    logEmailDelivery(
        $to,
        $subject,
        $emailType,
        isset($mail['code']) ? (string) $mail['code'] : null,
        $ok,
        $ok ? null : citizenEmailFailureReason()
    );
    return $ok;
}

function buildEmailMime(string $fromName, string $fromEmail, string $body, ?string $html = null): array
{
    $fromHeader = 'From: "' . addcslashes($fromName, '"') . '" <' . $fromEmail . '>';
    $headers = $fromHeader . "\r\n"
        . 'Reply-To: ' . $fromEmail . "\r\n"
        . "MIME-Version: 1.0\r\n";

    $plain = str_replace(["\r\n", "\r"], "\n", $body);
    if ($html === null || $html === '') {
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n"
            . "Content-Transfer-Encoding: 8bit\r\n";
        return [$headers, $plain];
    }

    $boundary = 'alcros_' . bin2hex(random_bytes(8));
    $headers .= 'Content-Type: multipart/alternative; boundary="' . $boundary . "\"\r\n";
    $htmlNorm = str_replace(["\r\n", "\r"], "\n", $html);
    $mime = "--{$boundary}\n"
        . "Content-Type: text/plain; charset=UTF-8\n"
        . "Content-Transfer-Encoding: 8bit\n\n"
        . $plain . "\n\n"
        . "--{$boundary}\n"
        . "Content-Type: text/html; charset=UTF-8\n"
        . "Content-Transfer-Encoding: 8bit\n\n"
        . $htmlNorm . "\n\n"
        . "--{$boundary}--";

    return [$headers, $mime];
}

function sendSmtpEmailAttempt(
    string $to,
    string $subject,
    string $payload,
    string $host,
    int $port,
    string $user,
    string $pass
): bool {
    $errno = 0;
    $errstr = '';
    $remote = ($port === 465 ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $fp = @stream_socket_client($remote, $errno, $errstr, 20, STREAM_CLIENT_CONNECT);
    if (!$fp) {
        return false;
    }
    stream_set_timeout($fp, 20);

    if (!str_starts_with(smtpRead($fp), '220')) {
        fclose($fp);
        return false;
    }

    $ehloHost = $_SERVER['SERVER_NAME'] ?? 'localhost';
    if (!smtpCommand($fp, 'EHLO ' . $ehloHost, '250')) {
        fclose($fp);
        return false;
    }

    if ($port !== 465) {
        if (!smtpCommand($fp, 'STARTTLS', '220')) {
            fclose($fp);
            return false;
        }
        if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($fp);
            return false;
        }
        if (!smtpCommand($fp, 'EHLO ' . $ehloHost, '250')) {
            fclose($fp);
            return false;
        }
    }

    if (!smtpCommand($fp, 'AUTH LOGIN', '334')
        || !smtpCommand($fp, base64_encode($user), '334')
        || !smtpCommand($fp, base64_encode($pass), '235')
        || !smtpCommand($fp, 'MAIL FROM:<' . $user . '>', '250')
        || !smtpCommand($fp, 'RCPT TO:<' . $to . '>', '250')
        || !smtpCommand($fp, 'DATA', '354')
    ) {
        fclose($fp);
        return false;
    }

    fwrite($fp, $payload . "\r\n.\r\n");
    $dataOk = str_starts_with(smtpRead($fp), '250');
    smtpCommand($fp, 'QUIT', '221');
    fclose($fp);

    return $dataOk;
}

function sendSmtpEmail(string $to, string $subject, string $body, ?string $html = null): bool
{
    $host = trim(getSetting('smtp_host', 'smtp.gmail.com')) ?: 'smtp.gmail.com';
    $configuredPort = (int) getSetting('smtp_port', '587');
    if ($configuredPort <= 0) {
        $configuredPort = 587;
    }
    $user = trim(getSetting('smtp_user', getSetting('notification_email', '')));
    $pass = (string) getSetting('smtp_pass', '');
    if ($user === '' || $pass === '') {
        return false;
    }

    $fromName = getSetting('site_name', 'ALCROS') . ' - ' . getSetting('office_name', 'Local Civil Registrar Office');
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    [$headers, $mimeBody] = buildEmailMime($fromName, $user, $body, $html);
    $payload = $headers
        . 'To: <' . $to . ">\r\n"
        . 'Subject: ' . $encodedSubject . "\r\n\r\n"
        . str_replace("\n", "\r\n", $mimeBody) . "\r\n";
    $payload = preg_replace('/^\./m', '..', $payload);

    $ports = array_values(array_unique([$configuredPort, 465, 587]));
    foreach ($ports as $port) {
        if (sendSmtpEmailAttempt($to, $subject, $payload, $host, (int) $port, $user, $pass)) {
            return true;
        }
    }

    return false;
}

function isEmailConfigured(): bool
{
    $user = trim(getSetting('smtp_user', getSetting('notification_email', '')));
    $pass = (string) getSetting('smtp_pass', '');

    return $user !== '' && $pass !== '';
}

function citizenEmailFailureReason(): string
{
    if (!isEmailConfigured()) {
        return 'Gmail SMTP is not configured. Set Gmail address and App Password in Settings → Configuration (Operations, Queue & Email).';
    }

    return 'Email delivery failed. Check Gmail SMTP credentials and App Password.';
}

function sendCitizenEmail(string $to, string $subject, string $body, ?string $html = null): bool
{
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    if (sendSmtpEmail($to, $subject, $body, $html)) {
        return true;
    }

    if (!isEmailConfigured()) {
        return false;
    }

    $from    = getSetting('smtp_user', getSetting('notification_email', getSetting('office_email', 'aloran@gov.ph')));
    $office  = getSetting('office_name', 'Local Civil Registrar Office');
    [$headers, $mimeBody] = buildEmailMime('ALCROS - ' . $office, $from, $body, $html);
    return @mail($to, $subject, str_replace("\n", "\r\n", $mimeBody), $headers);
}

function notifyRequestSubmitted(array $data): bool
{
    if (empty($data['notify_email']) || empty($data['email'])) {
        return false;
    }

    $details = [
        'Document'       => (string) ($data['document_label'] ?? ''),
        'Current status' => 'Pending review',
    ];
    if (!empty($data['appointment_date']) && !empty($data['appointment_time'])) {
        $details['Preferred visit'] = formatAppointmentEmailDisplay(
            $data['appointment_date'],
            $data['appointment_time']
        );
    }

    if (!function_exists('appendDocumentRequestRelationshipToCitizenMail')) {
        require_once __DIR__ . '/document_request_relationship_requirements.php';
    }

    $mail = citizenMailWithCertificateFees([
        'heading'      => 'Request received',
        'name'         => citizenNotifyPersonName($data),
        'intro'        => 'Thank you for submitting your document request through ALCROS.',
        'code_label'   => 'Tracking code',
        'code'         => $data['tracking_code'],
        'details'      => $details,
        'note'         => "We will email this Gmail address when staff verifies your request, when the status changes, and at 5 hours, 3 hours, and 1 hour before your preferred visit.\n\nKeep this code safe - you will need it to check your status.",
        'button_label' => 'Track your request',
        'button_url'   => trackRequestUrl($data['tracking_code']),
        'accent'       => '#2563eb',
    ]);
    $mail = appendDocumentRequestRelationshipToCitizenMail($mail, $data);

    return sendCitizenNotice(
        $data['email'],
        'ALCROS - Request received (' . $data['tracking_code'] . ')',
        $mail,
        'request_submitted'
    );
}

function syncDocumentRequestAppointment(PDO $pdo, int $requestId, string $requestStatus, ?string $rejectionReason = null): void
{
    ensureCitizenNotifyColumns($pdo);
    ensureSoftDeleteColumns($pdo);
    ensureAppointmentUpdatedColumn($pdo);
    ensureRejectionReasonColumns($pdo);
    $status = normalizeRequestStatus($requestStatus);

    $stmt = $pdo->prepare(
        'SELECT tracking_code, first_name, middle_name, last_name, email, phone, notify_email, notify_sms,
                document_type, appointment_date, appointment_time, id_front_path, id_back_path
         FROM document_requests WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->execute([$requestId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return;
    }

    $trackingCode = (string) $row['tracking_code'];
    $apptStmt = $pdo->prepare(
        'SELECT id, status FROM appointments
         WHERE tracking_code = ? AND deleted_at IS NULL
         ORDER BY updated_at DESC, id DESC
         LIMIT 1'
    );
    $apptStmt->execute([$trackingCode]);
    $existing = $apptStmt->fetch(PDO::FETCH_ASSOC);

    if ($status === 'verified' || $status === 'ready') {
        $apptDate = $row['appointment_date'] ?? null;
        $apptTime = $row['appointment_time'] ?? null;
        if (!$apptDate || !$apptTime) {
            return;
        }

        $normalizedTime = normalizeAppointmentTime($apptTime);
        $serviceType = documentTypeLabel($row['document_type']);

        $existingId = $existing ? (int) ($existing['id'] ?? 0) : null;
        ensureVisitSlotAvailableForWrite(
            $pdo,
            (string) $apptDate,
            $normalizedTime,
            $trackingCode,
            $existingId ?: null,
            true,
            'certificate'
        );

        if ($existing) {
            $pdo->prepare(
                "UPDATE appointments
                 SET status = 'confirmed', appointment_date = ?, appointment_time = ?, service_type = ?,
                     notify_email = ?, notify_sms = ?, updated_at = NOW()
                 WHERE id = ?"
            )->execute([
                $apptDate,
                $normalizedTime,
                $serviceType,
                (int) ($row['notify_email'] ?? 0),
                (int) ($row['notify_sms'] ?? 0),
                $existing['id'],
            ]);

            return;
        }

        $apptCode = generateAppointmentCode();
        $pdo->prepare(
            'INSERT INTO appointments
             (appointment_code, first_name, middle_name, last_name, email, phone, notify_email, notify_sms,
              service_type, appointment_date, appointment_time, status, source, tracking_code,
              id_front_path, id_back_path)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $apptCode,
            $row['first_name'],
            $row['middle_name'] ?? null,
            $row['last_name'],
            $row['email'],
            $row['phone'],
            (int) ($row['notify_email'] ?? 0),
            (int) ($row['notify_sms'] ?? 0),
            $serviceType,
            $apptDate,
            $normalizedTime,
            'confirmed',
            'document_request',
            $trackingCode,
            $row['id_front_path'] ?? null,
            $row['id_back_path'] ?? null,
        ]);

        return;
    }

    if (!$existing) {
        return;
    }

    $apptStatus = match ($status) {
        'rejected'  => 'cancelled',
        'completed' => 'completed',
        default     => null,
    };
    if ($apptStatus !== null && $existing['status'] !== $apptStatus) {
        if ($apptStatus === 'cancelled') {
            $reason = normalizeStaffRejectionReason($rejectionReason);
            $pdo->prepare(
                'UPDATE appointments SET status = ?, rejection_reason = ?, updated_at = NOW() WHERE id = ?'
            )->execute([$apptStatus, $reason, $existing['id']]);
        } else {
            $pdo->prepare('UPDATE appointments SET status = ?, updated_at = NOW() WHERE id = ?')
                ->execute([$apptStatus, $existing['id']]);
        }
    }
}

function syncAppointmentToDocumentRequest(PDO $pdo, int $appointmentId, string $appointmentStatus): void
{
    ensureSoftDeleteColumns($pdo);
    ensureRejectionReasonColumns($pdo);

    $stmt = $pdo->prepare(
        'SELECT tracking_code, rejection_reason FROM appointments WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->execute([$appointmentId]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$appointment) {
        return;
    }

    $trackingCode = trim((string) ($appointment['tracking_code'] ?? ''));
    if ($trackingCode === '') {
        return;
    }

    $reqStmt = $pdo->prepare(
        'SELECT id, status FROM document_requests WHERE tracking_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $reqStmt->execute([$trackingCode]);
    $request = $reqStmt->fetch(PDO::FETCH_ASSOC);
    if (!$request) {
        return;
    }

    $requestId = (int) $request['id'];
    $currentStatus = normalizeRequestStatus((string) $request['status']);

    $targetAction = match ($appointmentStatus) {
        'completed' => 'completed',
        'cancelled' => 'rejected',
        default     => null,
    };
    if ($targetAction === null) {
        return;
    }

    if ($targetAction === 'completed' && $currentStatus !== 'ready') {
        return;
    }

    if ($targetAction === 'rejected' && !in_array($currentStatus, ['pending', 'ready'], true)) {
        return;
    }

    $reason = $appointmentStatus === 'cancelled'
        ? normalizeStaffRejectionReason($appointment['rejection_reason'] ?? null)
        : null;
    updateDocumentRequestStatus($pdo, $requestId, $targetAction, true, $reason);
}

function staffCitizenNotifyWarningsReset(): void
{
    $GLOBALS['alcros_staff_citizen_notify_warnings'] = [];
}

/** @return list<string> */
function staffCitizenNotifyWarnings(): array
{
    $list = $GLOBALS['alcros_staff_citizen_notify_warnings'] ?? [];

    return is_array($list) ? $list : [];
}

function staffCitizenNotifyWarningAdd(string $line): void
{
    $line = trim($line);
    if ($line === '') {
        return;
    }
    if (!isset($GLOBALS['alcros_staff_citizen_notify_warnings']) || !is_array($GLOBALS['alcros_staff_citizen_notify_warnings'])) {
        $GLOBALS['alcros_staff_citizen_notify_warnings'] = [];
    }
    $GLOBALS['alcros_staff_citizen_notify_warnings'][] = $line;
}

function staffCitizenNotifyAppendToStaffMessage(string $baseMessage): string
{
    $warnings = staffCitizenNotifyWarnings();
    if ($warnings === []) {
        return $baseMessage;
    }

    return trim($baseMessage) . "\n\n" . implode("\n", $warnings);
}

function staffCitizenNotifyFlashType(bool $actionSucceeded): string
{
    if (!$actionSucceeded) {
        return 'error';
    }

    return staffCitizenNotifyWarnings() !== [] ? 'warning' : 'success';
}

/** @param array{attempted: bool, sent: bool} $result */
function staffCitizenNotifyRecordEmailAttempt(array $result): void
{
    if (empty($result['attempted']) || !empty($result['sent'])) {
        return;
    }
    staffCitizenNotifyWarningAdd('Email was not sent. ' . citizenEmailFailureReason());
}

/** @param array{attempted: bool, sent: bool} $result */
function staffCitizenNotifyRecordSmsAttempt(array $result): void
{
    if (empty($result['attempted']) || !empty($result['sent'])) {
        return;
    }
    require_once __DIR__ . '/sms.php';
    $err = smsLastDeliveryError();
    staffCitizenNotifyWarningAdd(
        'SMS was not sent.' . ($err !== null ? ' ' . $err : ' Check Settings → SMS (IPROG).')
    );
}

/** @return array{attempted: bool, sent: bool} */
function citizenEmailNotifySkipped(): array
{
    return ['attempted' => false, 'sent' => false];
}

/** @return array{attempted: bool, sent: bool} */
function citizenEmailNotifyResult(bool $sent): array
{
    return ['attempted' => true, 'sent' => $sent];
}

function updateDocumentRequestStatus(
    PDO $pdo,
    int $id,
    string $status,
    bool $skipNotifications = false,
    ?string $rejectionReason = null
): bool {
    if ($id <= 0) {
        return false;
    }

    ensureSoftDeleteColumns($pdo);
    ensureRejectionReasonColumns($pdo);

    $oldStmt = $pdo->prepare('SELECT status, tracking_code FROM document_requests WHERE id = ? AND deleted_at IS NULL LIMIT 1');
    $oldStmt->execute([$id]);
    $row = $oldStmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return false;
    }

    $rawOldStatus = (string) $row['status'];
    $oldStatus = normalizeRequestStatus($rawOldStatus);
    $staffAction = $status;

    if (!isAllowedRequestStatusTransition($oldStatus, $staffAction)) {
        return false;
    }

    $saveStatus = match ($staffAction) {
        'verified' => 'ready',
        default    => $staffAction,
    };

    if ($oldStatus === $saveStatus) {
        return true;
    }

    $slotLockHeld = false;
    $dayLockHeld = false;
    $slotLockDate = null;
    $slotLockTime = null;
    if ($staffAction === 'verified') {
        $visitStmt = $pdo->prepare(
            'SELECT tracking_code, appointment_date, appointment_time
             FROM document_requests WHERE id = ? AND deleted_at IS NULL LIMIT 1'
        );
        $visitStmt->execute([$id]);
        $visitRow = $visitStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $slotLockDate = (string) ($visitRow['appointment_date'] ?? '');
        $slotLockTime = (string) ($visitRow['appointment_time'] ?? '');
        $trackingCode = trim((string) ($visitRow['tracking_code'] ?? ''));
        if ($slotLockDate !== '' && $slotLockTime !== '') {
            if (!acquireAppointmentDayLock($pdo, $slotLockDate, 10, 'certificate')) {
                return false;
            }
            $dayLockHeld = true;
            if (!acquireAppointmentSlotLock($pdo, $slotLockDate, $slotLockTime, 10, 'certificate')) {
                releaseAppointmentDayLock($pdo, $slotLockDate, 'certificate');

                return false;
            }
            $slotLockHeld = true;
            $linked = $trackingCode !== '' ? fetchLatestLinkedAppointmentForRequest($pdo, $trackingCode) : null;
            $linkedId = $linked ? (int) ($linked['id'] ?? 0) : null;
            try {
                ensureVisitSlotAvailableForWrite(
                    $pdo,
                    $slotLockDate,
                    $slotLockTime,
                    $trackingCode,
                    $linkedId ?: null,
                    false,
                    'certificate'
                );
            } catch (RuntimeException $e) {
                releaseAppointmentSlotLock($pdo, $slotLockDate, $slotLockTime, 'certificate');
                releaseAppointmentDayLock($pdo, $slotLockDate, 'certificate');

                return false;
            }
        }
    }

    $savedRejectionReason = null;
    if ($staffAction === 'rejected') {
        $savedRejectionReason = normalizeStaffRejectionReason($rejectionReason);
        if ($savedRejectionReason === null) {
            if ($slotLockHeld && $slotLockDate !== null && $slotLockTime !== null) {
                releaseAppointmentSlotLock($pdo, $slotLockDate, $slotLockTime, 'certificate');
            }
            if ($dayLockHeld && $slotLockDate !== null) {
                releaseAppointmentDayLock($pdo, $slotLockDate, 'certificate');
            }

            return false;
        }
    }

    try {
        $pdo->beginTransaction();

        if ($staffAction === 'rejected') {
            $stmt = $pdo->prepare(
                'UPDATE document_requests SET status = ?, rejection_reason = ?, updated_at = NOW() WHERE id = ? AND status = ?'
            );
            $stmt->execute([$saveStatus, $savedRejectionReason, $id, $rawOldStatus]);
        } else {
            $stmt = $pdo->prepare('UPDATE document_requests SET status = ?, updated_at = NOW() WHERE id = ? AND status = ?');
            $stmt->execute([$saveStatus, $id, $rawOldStatus]);
        }
        if ($stmt->rowCount() === 0) {
            $pdo->rollBack();

            return false;
        }

        if ($staffAction === 'verified') {
            syncDocumentRequestAppointment($pdo, $id, 'verified');
        } else {
            syncDocumentRequestAppointment(
                $pdo,
                $id,
                $saveStatus,
                $staffAction === 'rejected' ? $savedRejectionReason : null
            );
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        return false;
    } finally {
        if ($slotLockHeld && $slotLockDate !== null && $slotLockTime !== null) {
            releaseAppointmentSlotLock($pdo, $slotLockDate, $slotLockTime, 'certificate');
        }
        if ($dayLockHeld && $slotLockDate !== null) {
            releaseAppointmentDayLock($pdo, $slotLockDate, 'certificate');
        }
    }

    if (!$skipNotifications) {
        staffCitizenNotifyWarningsReset();
        try {
            $emailResult = notifyRequestStatusChange($pdo, $id, $saveStatus, $staffAction, $savedRejectionReason);
            staffCitizenNotifyRecordEmailAttempt($emailResult);
        } catch (Throwable $e) {
            // Status is already saved; email failure should not block staff.
        }

        try {
            require_once __DIR__ . '/sms.php';
            $smsResult = notifyRequestStatusSms($pdo, $id, $saveStatus, $staffAction, $savedRejectionReason);
            staffCitizenNotifyRecordSmsAttempt($smsResult);
        } catch (Throwable $e) {
            // Status is already saved; SMS failure should not block staff.
        }
    }

    $actor = function_exists('staffId') ? staffId() : 'system';
    logRequestStatusChange($pdo, $id, (string) $row['tracking_code'], $oldStatus, $saveStatus, $actor);
    $logLabel = requestStatusLabel($saveStatus);
    if ($staffAction === 'verified') {
        $logLabel = 'Ready for Pickup';
    }
    logActivity($actor, 'Request Updated', 'Changed ' . $row['tracking_code'] . ' to ' . $logLabel);

    return true;
}

function updateAppointmentStatus(
    PDO $pdo,
    int $id,
    string $status,
    ?string $rejectionReason = null,
    bool $allowLateScheduledNoShow = false
): bool {
    if ($id <= 0) {
        return false;
    }

    ensureSoftDeleteColumns($pdo);
    ensureAppointmentUpdatedColumn($pdo);
    ensureRejectionReasonColumns($pdo);

    $oldStmt = $pdo->prepare(
        'SELECT status, appointment_code, appointment_date, appointment_time
         FROM appointments WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $oldStmt->execute([$id]);
    $row = $oldStmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return false;
    }

    $oldStatus = (string) $row['status'];
    if (!isAllowedAppointmentStatusTransition($oldStatus, $status)) {
        $lateScheduledNoShow = $allowLateScheduledNoShow
            && $status === 'no_show'
            && $oldStatus === 'scheduled'
            && visitLateQualifiesForNoShow($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
        if (!$lateScheduledNoShow) {
            return false;
        }
    }

    if ($oldStatus === $status) {
        return true;
    }

    $savedRejectionReason = null;
    if ($status === 'cancelled') {
        $savedRejectionReason = normalizeStaffRejectionReason($rejectionReason);
        if ($savedRejectionReason === null) {
            return false;
        }
    }

    $syncsLinkedRequest = in_array($status, ['cancelled', 'completed'], true);

    try {
        $pdo->beginTransaction();

        if ($status === 'cancelled') {
            $stmt = $pdo->prepare(
                'UPDATE appointments SET status = ?, rejection_reason = ?, updated_at = NOW() WHERE id = ? AND status = ?'
            );
            $stmt->execute([$status, $savedRejectionReason, $id, $oldStatus]);
        } else {
            $stmt = $pdo->prepare('UPDATE appointments SET status = ?, updated_at = NOW() WHERE id = ? AND status = ?');
            $stmt->execute([$status, $id, $oldStatus]);
        }
        if ($stmt->rowCount() === 0) {
            $pdo->rollBack();

            return false;
        }

        if ($syncsLinkedRequest) {
            syncAppointmentToDocumentRequest($pdo, $id, $status);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        return false;
    }

    staffCitizenNotifyWarningsReset();
    try {
        $emailResult = notifyAppointmentStatusChange($pdo, $id, $status, $savedRejectionReason);
        staffCitizenNotifyRecordEmailAttempt($emailResult);
    } catch (Throwable $e) {
        // Status is already saved; email failure should not block staff.
    }

    try {
        require_once __DIR__ . '/sms.php';
        $smsResult = notifyAppointmentStatusSms($pdo, $id, $status);
        staffCitizenNotifyRecordSmsAttempt($smsResult);
    } catch (Throwable $e) {
        // Status is already saved; SMS failure should not block staff.
    }

    $actor = function_exists('staffId') ? staffId() : 'system';
    logActivity($actor, 'Appointment Updated', 'Changed ' . $row['appointment_code'] . ' to ' . appointmentStatusLabel($status));

    return true;
}

/** @return array{attempted: bool, sent: bool} */
function notifyRequestStatusChange(
    PDO $pdo,
    int $requestId,
    string $newStatus,
    ?string $staffAction = null,
    ?string $rejectionReason = null
): array {
    ensureCitizenNotifyColumns($pdo);
    ensureRejectionReasonColumns($pdo);
    $stmt = $pdo->prepare(
        'SELECT tracking_code, first_name, middle_name, last_name,
                requester_first_name, requester_middle_name, requester_last_name,
                requester_relationship, email, document_type, status, appointment_date, appointment_time, notify_email, rejection_reason
         FROM document_requests WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$requestId]);
    $row = $stmt->fetch();
    if (!citizenWantsEmailNotify($row)) {
        return citizenEmailNotifySkipped();
    }

    $status = $staffAction === 'verified' ? 'verified' : normalizeRequestStatus($newStatus);
    $appointment = fetchDocumentRequestAppointment($pdo, (string) $row['tracking_code']);
    $visitSchedule = formatAppointmentEmailDisplay(
        $appointment['appointment_date'] ?? $row['appointment_date'] ?? null,
        $appointment['appointment_time'] ?? $row['appointment_time'] ?? null
    );

    $intro = match ($status) {
        'verified'  => 'Your request has been verified, your pickup visit is confirmed, and your document is ready for pickup.',
        'ready'     => 'Good news - your document is ready for pickup and your visit remains confirmed.',
        'completed' => 'Your request has been completed.',
        'rejected'  => 'There is an update on your document request.',
        default     => 'There is an update on your document request.',
    };
    $subject = match ($status) {
        'verified', 'ready' => 'ALCROS - Ready for pickup (' . $row['tracking_code'] . ')',
        default             => 'ALCROS - Request update (' . $row['tracking_code'] . ')',
    };
    $accent = match ($status) {
        'verified', 'ready' => '#16a34a',
        'completed'         => '#475569',
        'rejected'          => '#dc2626',
        default             => '#2563eb',
    };
    $heading = match ($status) {
        'verified'  => 'Confirmed · Ready for pickup',
        'ready'     => 'Ready for pickup',
        'completed' => 'Request completed',
        'rejected'  => 'Request update',
        default     => 'Request update',
    };

    $effectiveReason = normalizeStaffRejectionReason($rejectionReason ?? ($row['rejection_reason'] ?? null));

    $details = [
        'Document'   => documentTypeLabel($row['document_type']),
        'New status' => publicRequestStatusLabel($newStatus),
    ];
    if ($status === 'verified' || $status === 'ready') {
        $details['Visit status'] = 'Confirmed';
        if ($visitSchedule !== '-') {
            $details['Scheduled visit'] = $visitSchedule;
        }
    }
    if ($status === 'rejected' && $effectiveReason !== null) {
        $details['Reason'] = $effectiveReason;
    }

    if (!function_exists('appendDocumentRequestRelationshipToCitizenMail')) {
        require_once __DIR__ . '/document_request_relationship_requirements.php';
    }

    $mail = citizenMailWithCertificateFees([
        'heading'      => $heading,
        'name'         => citizenNotifyPersonName($row),
        'intro'        => $intro,
        'code_label'   => 'Tracking code',
        'code'         => $row['tracking_code'],
        'details'      => $details,
        'note'         => publicRequestStatusMessage($newStatus, $appointment, true, $effectiveReason),
        'button_label' => 'View full details',
        'button_url'   => trackRequestUrl($row['tracking_code']),
        'accent'       => $accent,
    ]);
    $mail = appendDocumentRequestRelationshipToCitizenMail($mail, $row);

    $sent = sendCitizenNotice($row['email'], $subject, $mail, 'request_' . $status);

    return citizenEmailNotifyResult($sent);
}

function notifyAppointmentBooked(array $data): bool
{
    if (empty($data['notify_email']) || empty($data['email'])) {
        return false;
    }

    require_once __DIR__ . '/appointment_notice_requirements.php';

    $serviceType = (string) ($data['service_type'] ?? $data['service_label'] ?? '');
    $row = [
        'service_type'   => $serviceType,
        'source'         => (string) ($data['source'] ?? 'standalone'),
        'tracking_code'  => (string) ($data['tracking_code'] ?? ''),
    ];

    $mail = [
        'heading'      => 'Appointment booked',
        'name'         => personNameFromRow($data),
        'intro'        => 'Your appointment was booked successfully.',
        'code_label'   => 'Appointment code',
        'code'         => $data['appointment_code'],
        'details'      => [
            'Service'  => appointmentServiceLabel($serviceType),
            'Schedule' => formatAppointmentEmailDisplay($data['appointment_date'] ?? null, $data['appointment_time'] ?? null),
            'Status'   => 'Awaiting confirmation',
        ],
        'note'         => isStandaloneSpecialServiceAppointmentRow($row)
            ? 'Your preferred date and time are saved. Staff must still confirm your visit. Prepare the documents listed below before you come. We will email you when the status changes and at 5 hours, 3 hours, and 1 hour before a confirmed appointment.'
            : 'Your preferred date and time are saved, but staff must still confirm your visit. We will email this Gmail address when the status changes and at 5 hours, 3 hours, and 1 hour before a confirmed appointment.',
        'button_label' => 'Track appointment',
        'button_url'   => trackRequestUrl($data['appointment_code']),
        'accent'       => '#2563eb',
    ];
    $mail = appendSpecialServiceRequirementsToCitizenMail($mail, $row);

    return sendCitizenNotice(
        $data['email'],
        'ALCROS - Appointment booked (' . $data['appointment_code'] . ')',
        $mail,
        'appointment_booked'
    );
}

/** @return array{attempted: bool, sent: bool} */
function notifyAppointmentStatusChange(PDO $pdo, int $appointmentId, string $newStatus, ?string $rejectionReason = null): array
{
    ensureCitizenNotifyColumns($pdo);
    ensureRejectionReasonColumns($pdo);
    $stmt = $pdo->prepare(
        'SELECT appointment_code, first_name, middle_name, last_name, email, service_type, appointment_date, appointment_time,
                notify_email, source, tracking_code, rejection_reason
         FROM appointments WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$appointmentId]);
    $row = $stmt->fetch();
    if (!citizenWantsEmailNotify($row)) {
        return citizenEmailNotifySkipped();
    }

    require_once __DIR__ . '/appointment_notice_requirements.php';

    $accent = match ($newStatus) {
        'completed' => '#16a34a',
        'cancelled', 'no_show' => '#dc2626',
        'confirmed' => '#2563eb',
        default => '#2563eb',
    };

    $effectiveReason = normalizeStaffRejectionReason($rejectionReason ?? ($row['rejection_reason'] ?? null));

    $details = [
        'Service'    => appointmentServiceLabel((string) $row['service_type']),
        'Schedule'   => formatAppointmentEmailDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null),
        'New status' => appointmentStatusLabel($newStatus),
    ];
    if ($newStatus === 'cancelled' && $effectiveReason !== null) {
        $details['Reason'] = $effectiveReason;
    }

    $mail = [
        'heading'      => 'Appointment update',
        'name'         => personNameFromRow($row),
        'intro'        => 'There is an update on your appointment.',
        'code_label'   => 'Appointment code',
        'code'         => $row['appointment_code'],
        'details'      => $details,
        'note'         => appointmentStatusMessage($newStatus, $effectiveReason),
        'button_label' => 'View full details',
        'button_url'   => trackRequestUrl($row['appointment_code']),
        'accent'       => $accent,
    ];
    if ($newStatus === 'confirmed') {
        if (isStandaloneSpecialServiceAppointmentRow($row)) {
            $mail['note'] = 'Your appointment has been confirmed by our office. Please arrive on time and prepare the documents listed below.';
        }
        $mail = appendSpecialServiceRequirementsToCitizenMail($mail, $row);
    }

    $sent = sendCitizenNotice(
        $row['email'],
        'ALCROS - Appointment update (' . $row['appointment_code'] . ')',
        $mail,
        'appointment_' . $newStatus
    );

    return citizenEmailNotifyResult($sent);
}

function reminderLeadTimes(): array
{
    return [5, 3, 1];
}

/** Document request statuses that may receive pre-visit email/SMS reminders. */
function visitReminderDocumentRequestStatuses(): array
{
    return ['verified', 'ready'];
}

/** Appointment statuses that may receive pre-visit email/SMS reminders. */
function visitReminderAppointmentStatuses(): array
{
    return ['confirmed'];
}

function visitReminderStatusInSql(string $column, array $statuses): string
{
    $quoted = array_map(
        static fn (string $status): string => "'" . str_replace("'", "''", $status) . "'",
        $statuses
    );

    return $column . ' IN (' . implode(', ', $quoted) . ')';
}

function documentRequestEligibleForVisitReminder(?array $row): bool
{
    if ($row === null || $row === []) {
        return false;
    }

    $status = function_exists('normalizeRequestStatus')
        ? normalizeRequestStatus((string) ($row['status'] ?? ''))
        : (string) ($row['status'] ?? '');

    return in_array($status, visitReminderDocumentRequestStatuses(), true);
}

function appointmentEligibleForVisitReminder(?array $row): bool
{
    if ($row === null || $row === []) {
        return false;
    }

    return in_array((string) ($row['status'] ?? ''), visitReminderAppointmentStatuses(), true);
}

function reminderSentColumn(int $hours): string
{
    return match ($hours) {
        5 => 'reminder_5h_sent_at',
        3 => 'reminder_3h_sent_at',
        1 => 'reminder_1h_sent_at',
        default => throw new InvalidArgumentException('Unsupported reminder lead time.'),
    };
}

function reminderHoursLabel(int $hours): string
{
    return $hours === 1 ? '1 hour' : $hours . ' hours';
}

function ensureReminderLeadColumns(PDO $pdo, string $table): void
{
    if (!in_array($table, ['document_requests', 'appointments'], true)) {
        return;
    }

    foreach (reminderLeadTimes() as $hours) {
        $column = reminderSentColumn($hours);
        try {
            $pdo->query("SELECT `$column` FROM `$table` LIMIT 1");
        } catch (Throwable $e) {
            try {
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` TIMESTAMP NULL DEFAULT NULL AFTER reminder_sent_at");
            } catch (Throwable $ignored) {
            }
        }
    }

    try {
        $pdo->exec(
            "UPDATE `$table`
             SET reminder_5h_sent_at = reminder_sent_at
             WHERE reminder_sent_at IS NOT NULL
               AND reminder_5h_sent_at IS NULL"
        );
    } catch (Throwable $ignored) {
    }
}

function notifyAppointmentReminder(array $row, int $hoursBefore): bool
{
    if (!citizenWantsEmailNotify($row)) {
        return false;
    }

    require_once __DIR__ . '/appointment_notice_requirements.php';

    $hoursLabel = reminderHoursLabel($hoursBefore);

    $mail = [
        'heading'            => 'Appointment reminder',
        'name'               => personNameFromRow($row),
        'intro'              => 'This is a reminder that your appointment is in about ' . $hoursLabel . '.',
        'code_label'   => 'Appointment code',
        'code'         => $row['appointment_code'],
        'details'      => [
            'Service'  => appointmentServiceLabel((string) ($row['service_type'] ?? '')),
            'Schedule' => formatAppointmentEmailDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null),
        ],
        'note'         => isStandaloneSpecialServiceAppointmentRow($row)
            ? 'Please arrive on time and prepare the documents listed below.'
            : 'Please arrive on time and bring a valid ID.',
        'button_label' => 'View appointment',
        'button_url'   => trackRequestUrl((string) $row['appointment_code']),
        'accent'       => '#d97706',
    ];
    $mail = appendSpecialServiceRequirementsToCitizenMail($mail, $row);

    return sendCitizenNotice(
        (string) $row['email'],
        'ALCROS - Appointment in ' . $hoursLabel . ' (' . $row['appointment_code'] . ')',
        $mail,
        'appointment_reminder_' . $hoursBefore . 'h'
    );
}

function notifyRequestVisitReminder(array $row, int $hoursBefore): bool
{
    if (!citizenWantsEmailNotify($row)) {
        return false;
    }

    $hoursLabel = reminderHoursLabel($hoursBefore);

    if (!function_exists('appendDocumentRequestRelationshipToCitizenMail')) {
        require_once __DIR__ . '/document_request_relationship_requirements.php';
    }

    $mail = citizenMailWithCertificateFees([
        'heading'            => 'Visit reminder',
        'name'               => citizenNotifyPersonName($row),
        'intro'              => 'This is a reminder that your preferred visit for document pickup is in about ' . $hoursLabel . '.',
        'code_label'   => 'Tracking code',
        'code'         => $row['tracking_code'],
        'details'      => [
            'Document'        => documentTypeLabel((string) ($row['document_type'] ?? '')),
            'Current status'  => requestStatusLabel((string) ($row['status'] ?? 'pending')),
            'Preferred visit' => formatAppointmentEmailDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null),
        ],
        'note'         => 'Please arrive on time and bring your tracking code and a valid ID.',
        'button_label' => 'Track your request',
        'button_url'   => trackRequestUrl((string) $row['tracking_code']),
        'accent'       => '#d97706',
    ]);
    $mail = appendDocumentRequestRelationshipToCitizenMail($mail, $row);

    return sendCitizenNotice(
        (string) $row['email'],
        'ALCROS - Visit in ' . $hoursLabel . ' (' . $row['tracking_code'] . ')',
        $mail,
        'appointment_reminder_' . $hoursBefore . 'h'
    );
}

function appointmentMinutesUntil(?string $date, ?string $time): ?int
{
    if (!$date || !$time) {
        return null;
    }

    $ts = strtotime($date . ' ' . $time);
    if ($ts === false) {
        return null;
    }

    return (int) floor(($ts - time()) / 60);
}

function visitSoonWindowMinutes(): int
{
    return 60;
}

function formatVisitSoonLabel(int $minutesUntil): string
{
    if ($minutesUntil < 1) {
        return 'very soon';
    }
    if ($minutesUntil === 1) {
        return '1 minute';
    }
    if ($minutesUntil < 60) {
        return $minutesUntil . ' minutes';
    }

    return '1 hour';
}

function visitIsWithinSoonWindow(?string $date, ?string $time, ?int $withinMinutes = null): bool
{
    $withinMinutes = $withinMinutes ?? visitSoonWindowMinutes();
    $minutesUntil = appointmentMinutesUntil($date, $time);

    return $minutesUntil !== null && $minutesUntil > 0 && $minutesUntil <= $withinMinutes;
}

/** Minutes after scheduled visit time before staff may mark no-show from the manage list. */
function visitNoShowGraceMinutes(): int
{
    return 20;
}

/** Minutes past the scheduled visit, or null if there is no visit or it is not past yet. */
function visitMinutesLate(?string $date, ?string $time): ?int
{
    if (!$date || !$time) {
        return null;
    }

    $minutesUntil = appointmentMinutesUntil($date, $time);
    if ($minutesUntil === null || $minutesUntil >= 0) {
        return null;
    }

    return $minutesUntil * -1;
}

function visitLateQualifiesForNoShow(?string $date, ?string $time): bool
{
    $late = visitMinutesLate($date, $time);

    return $late !== null && $late >= visitNoShowGraceMinutes();
}

function fetchLatestLinkedAppointmentForRequest(PDO $pdo, string $trackingCode): ?array
{
    ensureSoftDeleteColumns($pdo);
    $trackingCode = trim($trackingCode);
    if ($trackingCode === '') {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT id, status, appointment_date, appointment_time, appointment_code
         FROM appointments
         WHERE tracking_code = ? AND deleted_at IS NULL
         ORDER BY updated_at DESC, id DESC
         LIMIT 1'
    );
    $stmt->execute([$trackingCode]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

function documentRequestVisitMarkedNoShow(PDO $pdo, array $row): bool
{
    $trackingCode = trim((string) ($row['tracking_code'] ?? ''));
    if ($trackingCode === '') {
        return false;
    }

    $appointment = fetchLatestLinkedAppointmentForRequest($pdo, $trackingCode);

    return $appointment !== null && (string) ($appointment['status'] ?? '') === 'no_show';
}

function documentRequestCanMarkVisitNoShow(PDO $pdo, array $row): bool
{
    if (!empty($row['deleted_at'])) {
        return false;
    }

    $status = normalizeRequestStatus((string) ($row['status'] ?? ''));
    if ($status !== 'ready') {
        return false;
    }

    if (documentRequestVisitMarkedNoShow($pdo, $row)) {
        return false;
    }

    return visitLateQualifiesForNoShow($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
}

function appointmentVisitMarkedNoShow(array $row): bool
{
    return (string) ($row['status'] ?? '') === 'no_show';
}

function appointmentCanMarkVisitNoShow(array $row): bool
{
    if (!empty($row['deleted_at'])) {
        return false;
    }

    $status = (string) ($row['status'] ?? '');
    if ($status !== 'confirmed') {
        return false;
    }

    return visitLateQualifiesForNoShow($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
}

function insertDocumentRequestNoShowAppointment(PDO $pdo, array $requestRow): ?int
{
    ensureCitizenNotifyColumns($pdo);
    ensureSoftDeleteColumns($pdo);

    $apptDate = $requestRow['appointment_date'] ?? null;
    $apptTime = $requestRow['appointment_time'] ?? null;
    if (!$apptDate || !$apptTime) {
        return null;
    }

    $normalizedTime = normalizeAppointmentTime((string) $apptTime);
    if ($normalizedTime === '') {
        return null;
    }

    $trackingCode = (string) ($requestRow['tracking_code'] ?? '');
    $serviceType = documentTypeLabel((string) ($requestRow['document_type'] ?? ''));
    $apptCode = generateAppointmentCode();

    $pdo->prepare(
        'INSERT INTO appointments
         (appointment_code, first_name, middle_name, last_name, email, phone, notify_email, notify_sms,
          service_type, appointment_date, appointment_time, status, source, tracking_code,
          id_front_path, id_back_path)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $apptCode,
        $requestRow['first_name'],
        $requestRow['middle_name'] ?? null,
        $requestRow['last_name'],
        $requestRow['email'],
        $requestRow['phone'],
        (int) ($requestRow['notify_email'] ?? 0),
        (int) ($requestRow['notify_sms'] ?? 0),
        $serviceType,
        $apptDate,
        $normalizedTime,
        'no_show',
        'document_request',
        $trackingCode,
        $requestRow['id_front_path'] ?? null,
        $requestRow['id_back_path'] ?? null,
    ]);

    return (int) $pdo->lastInsertId();
}

function markAppointmentVisitNoShow(PDO $pdo, int $appointmentId): bool
{
    ensureSoftDeleteColumns($pdo);

    $stmt = $pdo->prepare(
        'SELECT id, status, appointment_date, appointment_time
         FROM appointments WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->execute([$appointmentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return false;
    }

    if (appointmentVisitMarkedNoShow($row)) {
        return true;
    }

    if (!appointmentCanMarkVisitNoShow($row)) {
        return false;
    }

    $allowLateScheduled = (string) ($row['status'] ?? '') === 'scheduled';

    return updateAppointmentStatus($pdo, $appointmentId, 'no_show', null, $allowLateScheduled);
}

function markDocumentRequestVisitNoShow(PDO $pdo, int $requestId): bool
{
    $row = fetchDocumentRequestById($pdo, $requestId);
    if (!$row) {
        return false;
    }

    if (documentRequestVisitMarkedNoShow($pdo, $row)) {
        return true;
    }

    if (!documentRequestCanMarkVisitNoShow($pdo, $row)) {
        return false;
    }

    $trackingCode = trim((string) ($row['tracking_code'] ?? ''));
    $appointment = $trackingCode !== '' ? fetchLatestLinkedAppointmentForRequest($pdo, $trackingCode) : null;
    if ($appointment) {
        return markAppointmentVisitNoShow($pdo, (int) $appointment['id']);
    }

    $newId = insertDocumentRequestNoShowAppointment($pdo, $row);
    if ($newId === null || $newId <= 0) {
        return false;
    }

    staffCitizenNotifyWarningsReset();
    try {
        $emailResult = notifyAppointmentStatusChange($pdo, $newId, 'no_show');
        staffCitizenNotifyRecordEmailAttempt($emailResult);
    } catch (Throwable $e) {
        // Saved; notification failure should not block staff.
    }

    try {
        require_once __DIR__ . '/sms.php';
        $smsResult = notifyAppointmentStatusSms($pdo, $newId, 'no_show');
        staffCitizenNotifyRecordSmsAttempt($smsResult);
    } catch (Throwable $e) {
        // Saved; notification failure should not block staff.
    }

    $actor = function_exists('staffId') ? staffId() : 'system';
    logActivity($actor, 'Appointment Updated', 'Marked visit no-show for request ' . $row['tracking_code']);

    return true;
}

/**
 * @param array<string, string> $redirectHidden
 */
function renderManageVisitLateNoShowCell(
    PDO $pdo,
    array $row,
    string $entity,
    string $formAction,
    array $redirectHidden
): string {
    $date = $row['appointment_date'] ?? null;
    $time = $row['appointment_time'] ?? null;
    $minutesLate = visitMinutesLate(is_string($date) ? $date : null, is_string($time) ? $time : null);

    if ($entity === 'request') {
        $isNoShow = documentRequestVisitMarkedNoShow($pdo, $row);
        $canMark = documentRequestCanMarkVisitNoShow($pdo, $row);
        $idField = 'request_id';
        $entityId = (int) ($row['id'] ?? 0);
    } else {
        $isNoShow = appointmentVisitMarkedNoShow($row);
        $canMark = appointmentCanMarkVisitNoShow($row);
        $idField = 'appointment_id';
        $entityId = (int) ($row['id'] ?? 0);
    }

    $html = '<div class="manage-visit-late-cell" onclick="event.stopPropagation()">';

    if ($isNoShow) {
        $html .= '<span class="manage-visit-late manage-visit-late--noshow">No-show</span>';
    } elseif ($minutesLate !== null) {
        $html .= '<span class="manage-visit-late">' . (int) $minutesLate . ' min late</span>';
    } else {
        $html .= '<span class="manage-visit-late manage-visit-late--muted">-</span>';
    }

    if ($canMark && $entityId > 0) {
        $html .= '<form method="POST" action="' . htmlspecialchars($formAction) . '" class="manage-visit-noshow-form">';
        $html .= authFormField();
        foreach ($redirectHidden as $name => $value) {
            $html .= '<input type="hidden" name="' . htmlspecialchars((string) $name) . '" value="' . htmlspecialchars((string) $value) . '">';
        }
        $html .= '<input type="hidden" name="' . htmlspecialchars($idField) . '" value="' . $entityId . '">';
        $html .= '<input type="hidden" name="mark_visit_no_show" value="1">';
        $html .= '<button type="submit" class="manage-row-action manage-row-action--labeled manage-row-action--noshow" ';
        $html .= 'title="Mark no-show" aria-label="Mark no-show" ';
        $html .= 'data-bulk-confirm="Mark this visit as a no-show? The citizen may be notified." data-loading-text="Saving…">';
        $html .= '<span class="manage-row-action__label">NO-SHOW</span></button></form>';
    }

    $html .= '</div>';

    return $html;
}

function reportDocumentRequestNoShowLabel(array $row): string
{
    return (string) ($row['visit_appointment_status'] ?? '') === 'no_show' ? 'Yes' : 'No';
}

function reportAppointmentNoShowLabel(array $row): string
{
    return ((string) ($row['status'] ?? '')) === 'no_show' ? 'Yes' : 'No';
}

function markAllVisitEmailRemindersSent(PDO $pdo, string $table, int $id): void
{
    if (!in_array($table, ['document_requests', 'appointments'], true)) {
        return;
    }

    foreach (reminderLeadTimes() as $hours) {
        $column = reminderSentColumn($hours);
        $pdo->prepare(
            "UPDATE `$table` SET `$column` = COALESCE(`$column`, NOW()) WHERE id = ?"
        )->execute([$id]);
    }
}

function notifyRequestVisitSoon(array $row): bool
{
    if (!citizenWantsEmailNotify($row)) {
        return false;
    }

    $minutesUntil = appointmentMinutesUntil($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
    if ($minutesUntil === null || $minutesUntil <= 0 || $minutesUntil > visitSoonWindowMinutes()) {
        return false;
    }

    $soonLabel = formatVisitSoonLabel($minutesUntil);

    if (!function_exists('appendDocumentRequestRelationshipToCitizenMail')) {
        require_once __DIR__ . '/document_request_relationship_requirements.php';
    }

    $mail = citizenMailWithCertificateFees([
        'heading'      => 'Your visit is coming up soon',
        'name'         => citizenNotifyPersonName($row),
        'intro'        => 'Your preferred LCRO visit is in about ' . $soonLabel . '. Please head to the office if you are not already on your way.',
        'code_label'   => 'Tracking code',
        'code'         => $row['tracking_code'],
        'details'      => [
            'Document'        => documentTypeLabel((string) ($row['document_type'] ?? '')),
            'Current status'  => requestStatusLabel((string) ($row['status'] ?? 'pending')),
            'Preferred visit' => formatAppointmentEmailDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null),
        ],
        'note'         => 'Bring your tracking code and a valid ID. Staff may still need a short time to review your request when you arrive.',
        'button_label' => 'Track your request',
        'button_url'   => trackRequestUrl((string) $row['tracking_code']),
        'accent'       => '#d97706',
    ]);
    $mail = appendDocumentRequestRelationshipToCitizenMail($mail, $row);

    return sendCitizenNotice(
        (string) $row['email'],
        'ALCROS - Visit today in ' . $soonLabel . ' (' . $row['tracking_code'] . ')',
        $mail,
        'visit_soon'
    );
}

function notifyAppointmentVisitSoon(array $row): bool
{
    if (!citizenWantsEmailNotify($row)) {
        return false;
    }

    $minutesUntil = appointmentMinutesUntil($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
    if ($minutesUntil === null || $minutesUntil <= 0 || $minutesUntil > visitSoonWindowMinutes()) {
        return false;
    }

    $soonLabel = formatVisitSoonLabel($minutesUntil);

    require_once __DIR__ . '/appointment_notice_requirements.php';

    $mail = [
        'heading'      => 'Your appointment is coming up soon',
        'name'         => personNameFromRow($row),
        'intro'        => 'Your LCRO appointment is in about ' . $soonLabel . '. Please head to the office if you are not already on your way.',
        'code_label'   => 'Appointment code',
        'code'         => $row['appointment_code'],
        'details'      => [
            'Service'  => appointmentServiceLabel((string) ($row['service_type'] ?? '')),
            'Schedule' => formatAppointmentEmailDisplay($row['appointment_date'] ?? null, $row['appointment_time'] ?? null),
            'Status'   => appointmentStatusLabel((string) ($row['status'] ?? 'scheduled')),
        ],
        'note'         => isStandaloneSpecialServiceAppointmentRow($row)
            ? 'Please arrive on time and prepare the documents listed below.'
            : 'Please arrive on time and bring a valid ID.',
        'button_label' => 'View appointment',
        'button_url'   => trackRequestUrl((string) $row['appointment_code']),
        'accent'       => '#d97706',
    ];
    $mail = appendSpecialServiceRequirementsToCitizenMail($mail, $row);

    return sendCitizenNotice(
        (string) $row['email'],
        'ALCROS - Appointment today in ' . $soonLabel . ' (' . $row['appointment_code'] . ')',
        $mail,
        'visit_soon'
    );
}

function maybeSendVisitSoonEmail(PDO $pdo, string $table, int $id): bool
{
    ensureCitizenNotifyColumns($pdo);

    if ($table === 'document_requests') {
        $stmt = $pdo->prepare(
            'SELECT id, tracking_code, first_name, middle_name, last_name,
                    requester_first_name, requester_middle_name, requester_last_name,
                    requester_relationship, email, phone, document_type, status,
                    appointment_date, appointment_time, notify_email, notify_sms, reminder_1h_sent_at
             FROM document_requests WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row || !documentRequestEligibleForVisitReminder($row)) {
            return false;
        }
        if (!visitIsWithinSoonWindow($row['appointment_date'] ?? null, $row['appointment_time'] ?? null)) {
            return false;
        }
        if (!empty($row['reminder_1h_sent_at'])) {
            return false;
        }
        $emailSent = notifyRequestVisitSoon($row);
        require_once __DIR__ . '/sms.php';
        $smsSent = notifyRequestVisitSoonSms($row);
        if (!$emailSent && !$smsSent) {
            return false;
        }
        markAllVisitEmailRemindersSent($pdo, 'document_requests', $id);
        return true;
    }

    if ($table === 'appointments') {
        $stmt = $pdo->prepare(
            'SELECT id, appointment_code, first_name, middle_name, last_name, email, phone, service_type, status,
                    appointment_date, appointment_time, notify_email, notify_sms, source, tracking_code, reminder_1h_sent_at
             FROM appointments WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row || !appointmentEligibleForVisitReminder($row)) {
            return false;
        }
        if (!visitIsWithinSoonWindow($row['appointment_date'] ?? null, $row['appointment_time'] ?? null)) {
            return false;
        }
        if (!empty($row['reminder_1h_sent_at'])) {
            return false;
        }
        $emailSent = notifyAppointmentVisitSoon($row);
        require_once __DIR__ . '/sms.php';
        $smsSent = notifyAppointmentVisitSoonSms($row);
        if (!$emailSent && !$smsSent) {
            return false;
        }
        markAllVisitEmailRemindersSent($pdo, 'appointments', $id);
        return true;
    }

    return false;
}

function nextDueReminderLeadTime(int $minutesUntil): ?int
{
    if ($minutesUntil <= 0) {
        return null;
    }
    if ($minutesUntil <= 60) {
        return 1;
    }
    if ($minutesUntil <= 180) {
        return 3;
    }
    if ($minutesUntil <= 300) {
        return 5;
    }

    return null;
}

function markEarlierRemindersSkipped(PDO $pdo, string $table, int $id, int $sentHours): void
{
    if (!in_array($table, ['document_requests', 'appointments'], true)) {
        return;
    }

    foreach (reminderLeadTimes() as $hours) {
        if ($hours <= $sentHours) {
            continue;
        }
        $column = reminderSentColumn($hours);
        $stmt = $pdo->prepare(
            "UPDATE `$table` SET `$column` = COALESCE(`$column`, NOW()) WHERE id = ? AND `$column` IS NULL"
        );
        $stmt->execute([$id]);
    }
}

function sendDueEmailReminderRow(PDO $pdo, array $row, string $table, callable $notifyFn): bool
{
    $minutesUntil = appointmentMinutesUntil($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
    if ($minutesUntil === null) {
        return false;
    }

    $leadTime = nextDueReminderLeadTime($minutesUntil);
    if ($leadTime === null) {
        return false;
    }

    $column = reminderSentColumn($leadTime);
    if (!empty($row[$column])) {
        return false;
    }

    $claim = $pdo->prepare("UPDATE `$table` SET `$column` = NOW() WHERE id = ? AND `$column` IS NULL");
    $undo = $pdo->prepare("UPDATE `$table` SET `$column` = NULL WHERE id = ?");
    $claim->execute([(int) $row['id']]);
    if ($claim->rowCount() === 0) {
        return false;
    }

    if ($notifyFn($row, $leadTime)) {
        markEarlierRemindersSkipped($pdo, $table, (int) $row['id'], $leadTime);
        return true;
    }

    $undo->execute([(int) $row['id']]);
    return false;
}

function sendDueDocumentRequestEmailReminders(PDO $pdo): int
{
    $requestStatusSql = visitReminderStatusInSql('status', visitReminderDocumentRequestStatuses());
    $stmt = $pdo->query(
        "SELECT id, tracking_code, first_name, middle_name, last_name,
                requester_first_name, requester_middle_name, requester_last_name,
                requester_relationship, email, document_type, status,
                appointment_date, appointment_time, notify_email,
                reminder_5h_sent_at, reminder_3h_sent_at, reminder_1h_sent_at
         FROM document_requests
         WHERE notify_email = 1
           AND email IS NOT NULL AND email != ''
           AND {$requestStatusSql}
           AND appointment_date IS NOT NULL
           AND appointment_time IS NOT NULL
           AND TIMESTAMP(appointment_date, appointment_time) > NOW()
           AND TIMESTAMP(appointment_date, appointment_time) <= DATE_ADD(NOW(), INTERVAL 5 HOUR)
           AND (reminder_5h_sent_at IS NULL OR reminder_3h_sent_at IS NULL OR reminder_1h_sent_at IS NULL)"
    );
    $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    $sent = 0;

    foreach ($rows as $row) {
        $minutesUntil = appointmentMinutesUntil($row['appointment_date'] ?? null, $row['appointment_time'] ?? null);
        $leadTime = $minutesUntil === null ? null : nextDueReminderLeadTime($minutesUntil);
        if ($leadTime === null) {
            continue;
        }

        $column = reminderSentColumn($leadTime);
        if (sendDueEmailReminderRow($pdo, $row, 'document_requests', 'notifyRequestVisitReminder')) {
            $sent++;
            $pdo->prepare(
                "UPDATE appointments SET `$column` = NOW()
                 WHERE email = ? AND appointment_date = ? AND appointment_time = ? AND `$column` IS NULL"
            )->execute([$row['email'], $row['appointment_date'], $row['appointment_time']]);
        }
    }

    return $sent;
}

function sendDueStandaloneAppointmentEmailReminders(PDO $pdo): int
{
    $apptStatusSql = visitReminderStatusInSql('a.status', visitReminderAppointmentStatuses());
    $stmt = $pdo->query(
        "SELECT id, appointment_code, first_name, middle_name, last_name, email, service_type,
                appointment_date, appointment_time, notify_email, source, tracking_code,
                reminder_5h_sent_at, reminder_3h_sent_at, reminder_1h_sent_at
         FROM appointments a
         WHERE notify_email = 1
           AND " . appointmentStandaloneSql('a') . "
           AND email IS NOT NULL AND email != ''
           AND {$apptStatusSql}
           AND TIMESTAMP(appointment_date, appointment_time) > NOW()
           AND TIMESTAMP(appointment_date, appointment_time) <= DATE_ADD(NOW(), INTERVAL 5 HOUR)
           AND (reminder_5h_sent_at IS NULL OR reminder_3h_sent_at IS NULL OR reminder_1h_sent_at IS NULL)"
    );
    $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    $sent = 0;

    foreach ($rows as $row) {
        if (sendDueEmailReminderRow($pdo, $row, 'appointments', 'notifyAppointmentReminder')) {
            $sent++;
        }
    }

    return $sent;
}

function sendDueAppointmentReminders(PDO $pdo): int
{
    ensureCitizenNotifyColumns($pdo);

    $lockDir = __DIR__ . '/../storage';
    if (!is_dir($lockDir)) {
        @mkdir($lockDir, 0755, true);
    }
    $lockFile = $lockDir . '/appointment_reminders.lock';
    $lock = @fopen($lockFile, 'c');
    if (!$lock) {
        error_log('ALCROS appointment reminders: could not open lock file.');
        return 0;
    }

    if (!flock($lock, LOCK_EX | LOCK_NB)) {
        fclose($lock);
        return 0;
    }

    $sent = 0;
    $failed = false;
    try {
        $sent += sendDueDocumentRequestEmailReminders($pdo);
        $sent += sendDueStandaloneAppointmentEmailReminders($pdo);
        require_once __DIR__ . '/sms.php';
        $sent += sendDueSmsVisitReminders($pdo);
        require_once __DIR__ . '/appointment_follow_up.php';
        $sent += sendDueFollowUpReminders($pdo);
    } catch (Throwable $e) {
        $failed = true;
        error_log('ALCROS appointment reminders failed: ' . $e->getMessage());
        if (function_exists('recordReminderSchedulerFailure')) {
            recordReminderSchedulerFailure($pdo, $e->getMessage());
        }
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
        @unlink($lockFile);
    }

    if (!$failed && function_exists('recordReminderSchedulerSuccess')) {
        recordReminderSchedulerSuccess($pdo);
    }

    return $sent;
}

/**
 * Why reminder cron may report sent=0 (no citizen PII).
 *
 * @return array<string, mixed>
 */
function alcrosAppointmentReminderDiagnostics(PDO $pdo): array
{
    ensureCitizenNotifyColumns($pdo);

    $mysqlNow = (string) ($pdo->query('SELECT NOW()')->fetchColumn() ?: '');
    $visitFutureSql = 'appointment_date IS NOT NULL AND appointment_time IS NOT NULL AND TIMESTAMP(appointment_date, appointment_time) > NOW()';
    $visitIn5hSql = $visitFutureSql . ' AND TIMESTAMP(appointment_date, appointment_time) <= DATE_ADD(NOW(), INTERVAL 5 HOUR)';
    $visitIn1hSql = $visitFutureSql . ' AND TIMESTAMP(appointment_date, appointment_time) <= DATE_ADD(NOW(), INTERVAL 1 HOUR)';
    $emailPendingSql = '(reminder_5h_sent_at IS NULL OR reminder_3h_sent_at IS NULL OR reminder_1h_sent_at IS NULL)';

    $count = static function (PDO $pdo, string $sql): int {
        $value = $pdo->query($sql)->fetchColumn();

        return (int) $value;
    };

    $docStatuses = visitReminderStatusInSql('status', visitReminderDocumentRequestStatuses());
    $apptStatuses = visitReminderStatusInSql('a.status', visitReminderAppointmentStatuses());
    $standalone = appointmentStandaloneSql('a');

    if (!function_exists('alcrosFollowUpReminderDiagnostics')) {
        require_once __DIR__ . '/appointment_follow_up.php';
    }
    $followUpDiagnostics = alcrosFollowUpReminderDiagnostics($pdo);

    $reminderStorageDir = __DIR__ . '/../storage';
    $reminderLockFile = $reminderStorageDir . '/appointment_reminders.lock';

    return [
        'office_timezone' => function_exists('alcrosOfficeTimezone') ? alcrosOfficeTimezone() : date_default_timezone_get(),
        'php_now'         => date('c'),
        'mysql_now'       => $mysqlNow,
        'scheduler_storage' => [
            'storage_dir_exists'  => is_dir($reminderStorageDir),
            'storage_dir_writable' => is_dir($reminderStorageDir) && is_writable($reminderStorageDir),
            'lock_can_open'       => @fopen($reminderLockFile, 'c') !== false,
        ],
        'document_requests' => [
            'future_visits'              => $count($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$docStatuses} AND {$visitFutureSql}"),
            'in_email_window_5h'         => $count($pdo, "SELECT COUNT(*) FROM document_requests WHERE {$docStatuses} AND {$visitIn5hSql}"),
            'eligible_email_reminders'   => $count($pdo, "SELECT COUNT(*) FROM document_requests WHERE notify_email = 1 AND email IS NOT NULL AND email != '' AND {$docStatuses} AND {$visitIn5hSql} AND {$emailPendingSql}"),
            'in_window_but_notify_off'   => $count($pdo, "SELECT COUNT(*) FROM document_requests WHERE (notify_email = 0 OR email IS NULL OR email = '') AND {$docStatuses} AND {$visitIn5hSql}"),
            'in_1h_sms_window'           => $count($pdo, "SELECT COUNT(*) FROM document_requests WHERE notify_sms = 1 AND phone IS NOT NULL AND phone != '' AND {$docStatuses} AND {$visitIn1hSql} AND sms_reminder_1h_sent_at IS NULL"),
        ],
        'standalone_appointments' => [
            'future_visits'              => $count($pdo, "SELECT COUNT(*) FROM appointments a WHERE {$standalone} AND {$apptStatuses} AND {$visitFutureSql}"),
            'in_email_window_5h'         => $count($pdo, "SELECT COUNT(*) FROM appointments a WHERE {$standalone} AND {$apptStatuses} AND {$visitIn5hSql}"),
            'eligible_email_reminders'   => $count($pdo, "SELECT COUNT(*) FROM appointments a WHERE notify_email = 1 AND email IS NOT NULL AND email != '' AND {$standalone} AND {$apptStatuses} AND {$visitIn5hSql} AND {$emailPendingSql}"),
            'in_window_but_notify_off'   => $count($pdo, "SELECT COUNT(*) FROM appointments a WHERE (notify_email = 0 OR email IS NULL OR email = '') AND {$standalone} AND {$apptStatuses} AND {$visitIn5hSql}"),
            'eligible_sms_1h_confirmed' => $count($pdo, "SELECT COUNT(*) FROM appointments a WHERE notify_sms = 1 AND phone IS NOT NULL AND phone != '' AND {$standalone} AND {$apptStatuses} AND {$visitIn1hSql} AND a.sms_reminder_1h_sent_at IS NULL"),
        ],
        'follow_up_reminders' => $followUpDiagnostics,
        'hints' => [
            'Email reminders run only for visits in the next 5 hours with notify_email = 1 (citizen must opt in on the notification preferences modal).',
            'Visit reminders run only after staff accept a request (verified/ready) or confirm an appointment (confirmed).',
            'SMS reminders run only about 1 hour before; standalone appointments must be status confirmed.',
            'Follow-up reminders send email/SMS the day before the follow-up date and again on the follow-up date (from 8:00 AM local).',
            'sent=0 with ok=true means the cron ran but no eligible citizen matched this run (or SMTP/SMS send failed after match).',
        ],
    ];
}

function runReminderSchedulerIfDue(?PDO $pdo = null, int $intervalSeconds = 300): int
{
    $pdo = $pdo ?? getDB();
    $tickFile = __DIR__ . '/../storage/last_reminder_tick.txt';
    $tickDir = dirname($tickFile);
    if (!is_dir($tickDir)) {
        @mkdir($tickDir, 0755, true);
    }

    $now = time();
    $intervalSeconds = max(60, $intervalSeconds);
    $last = is_file($tickFile) ? (int) trim((string) file_get_contents($tickFile)) : 0;
    if ($last > 0 && ($now - $last) < $intervalSeconds) {
        return 0;
    }

    @file_put_contents($tickFile, (string) $now, LOCK_EX);

    return sendDueAppointmentReminders($pdo);
}

function formatAppointmentDisplay(?string $date, ?string $time): string
{
    if (!$date) {
        return '';
    }
    $out = formatDateEmailDisplay($date);
    if ($time) {
        $ts = strtotime(trim($time));
        $out .= $ts ? ' · ' . date('g:i A', $ts) : '';
    }

    return $out;
}

/**
 * Stack date over time in manage-request / appointment tables so columns do not overlap.
 */
function manageTableDateTimeHtml(?string $dateOrDatetime, ?string $time = null, string $empty = '-'): string
{
    $dateOrDatetime = $dateOrDatetime !== null ? trim($dateOrDatetime) : '';
    $time = $time !== null ? trim($time) : '';

    if ($dateOrDatetime === '' && $time === '') {
        return '<span class="manage-datetime"><span class="manage-datetime__date">' . htmlspecialchars($empty) . '</span></span>';
    }

    $dateLabel = '';
    $timeLabel = '';

    if ($time !== '') {
        $dateLabel = $dateOrDatetime !== '' ? formatDateEmailDisplay($dateOrDatetime) : '';
        $ts = strtotime($time);
        $timeLabel = $ts ? date('g:i A', $ts) : '';
    } else {
        $ts = strtotime($dateOrDatetime);
        if ($ts) {
            $dateLabel = date('M j, Y', $ts);
            if (preg_match('/\d{1,2}:\d{2}/', $dateOrDatetime)) {
                $timeLabel = date('g:i A', $ts);
            }
        } else {
            $dateLabel = $dateOrDatetime;
        }
    }

    $html = '<span class="manage-datetime">';
    $html .= '<span class="manage-datetime__date">' . htmlspecialchars($dateLabel !== '' ? $dateLabel : $empty) . '</span>';
    if ($timeLabel !== '') {
        $html .= '<span class="manage-datetime__time">' . htmlspecialchars($timeLabel) . '</span>';
    }
    $html .= '</span>';

    return $html;
}

function isMaintenanceMode(): bool
{
    return getSetting('maintenance_mode', '0') === '1';
}

function arePublicRequestsAllowed(): bool
{
    return getSetting('allow_public_requests', '1') === '1';
}

function countOperationalPrintJobs(PDO $pdo, string $documentKind): int
{
    if (!in_array($documentKind, ['certification', 'certificate'], true)) {
        return 0;
    }

    try {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
             FROM print_jobs pj
             INNER JOIN print_templates pt ON pt.id = pj.template_id
             WHERE pt.document_kind = ?'
        );
        $stmt->execute([$documentKind]);

        return (int) $stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function deleteOperationalPrintJobs(PDO $pdo, string $documentKind): int
{
    if (!in_array($documentKind, ['certification', 'certificate'], true)) {
        return 0;
    }

    $stmt = $pdo->prepare(
        'DELETE pj FROM print_jobs pj
         INNER JOIN print_templates pt ON pt.id = pj.template_id
         WHERE pt.document_kind = ?'
    );
    $stmt->execute([$documentKind]);

    return $stmt->rowCount();
}

function getSystemStats(PDO $pdo): array
{
    $tables = [
        'document_requests' => 'Requests',
        'appointments'      => 'Appointments',
        'civil_records'     => 'Civil Records',
        'queue_tickets'     => 'Queue Tickets',
        'staff'             => 'Staff Accounts',
        'activity_logs'     => 'Activity Logs',
    ];
    $stats = [];
    foreach ($tables as $table => $label) {
        try {
            $stats[$table] = [
                'label' => $label,
                'count' => (int) $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn(),
            ];
        } catch (PDOException $e) {
            $stats[$table] = ['label' => $label, 'count' => 0];
        }
    }

    $stats['certification_prints'] = [
        'label' => 'Certification prints',
        'count' => countOperationalPrintJobs($pdo, 'certification'),
    ];
    $stats['certificate_prints'] = [
        'label' => 'Certificate prints',
        'count' => countOperationalPrintJobs($pdo, 'certificate'),
    ];

    return $stats;
}

function clearOperationalData(PDO $pdo, array $types, string $staffId): array
{
    $allowed = [
        'appointments',
        'document_requests',
        'civil_records',
        'queue_tickets',
        'certification_prints',
        'certificate_prints',
    ];
    $types = array_values(array_unique(array_intersect($allowed, $types)));
    if ($types === []) {
        throw new InvalidArgumentException('Select at least one data type to clear.');
    }

    $clearAllQueue = in_array('queue_tickets', $types, true);
    $clearCivilRecords = in_array('civil_records', $types, true);

    if ($clearAllQueue) {
        require_once __DIR__ . '/queue_announcements.php';
        ensureQueueAnnouncementTable($pdo);
    }
    if ($clearCivilRecords) {
        require_once __DIR__ . '/record_locks.php';
        ensureCivilRecordEditLocksTable($pdo);
    }

    $results = [
        'appointments'          => 0,
        'document_requests'     => 0,
        'civil_records'         => 0,
        'queue_tickets'         => 0,
        'queue_announcements'   => 0,
        'certification_prints'  => 0,
        'certificate_prints'    => 0,
    ];

    $pdo->beginTransaction();
    try {
        if (in_array('document_requests', $types, true)) {
            $rows = $pdo->query('SELECT id_front_path, id_back_path FROM document_requests')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                deleteIdUploadFiles($row['id_front_path'] ?? null, $row['id_back_path'] ?? null);
            }

            $results['document_requests'] = (int) $pdo->exec('DELETE FROM document_requests');
            if (!$clearAllQueue) {
                $results['queue_tickets'] += (int) $pdo->exec("DELETE FROM queue_tickets WHERE purpose = 'document_claim'");
            }
        }

        if (in_array('appointments', $types, true)) {
            $rows = $pdo->query('SELECT id_front_path, id_back_path FROM appointments')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                deleteIdUploadFiles($row['id_front_path'] ?? null, $row['id_back_path'] ?? null);
            }

            $results['appointments'] = (int) $pdo->exec('DELETE FROM appointments');
            if (!$clearAllQueue) {
                $results['queue_tickets'] += (int) $pdo->exec("DELETE FROM queue_tickets WHERE purpose = 'appointment'");
            }

            $lockFile = __DIR__ . '/../storage/appointment_reminders.lock';
            if (is_file($lockFile)) {
                @unlink($lockFile);
            }
        }

        if (in_array('civil_records', $types, true)) {
            if (!in_array('document_requests', $types, true)) {
                $pdo->exec('UPDATE document_requests SET civil_record_id = NULL WHERE civil_record_id IS NOT NULL');
            }

            require_once __DIR__ . '/staff_resource_locks.php';
            ensureStaffResourceLocksTable($pdo);
            $pdo->prepare('DELETE FROM staff_resource_locks WHERE resource_type = ?')
                ->execute([STAFF_LOCK_TYPE_CIVIL_RECORD]);
            $results['civil_records'] = (int) $pdo->exec('DELETE FROM civil_records');
        }

        if ($clearAllQueue) {
            $results['queue_tickets'] = (int) $pdo->exec('DELETE FROM queue_tickets');
            $results['queue_announcements'] = (int) $pdo->exec('DELETE FROM queue_announcements');
        }

        if (in_array('certification_prints', $types, true)) {
            $results['certification_prints'] = deleteOperationalPrintJobs($pdo, 'certification');
        }

        if (in_array('certificate_prints', $types, true)) {
            $results['certificate_prints'] = deleteOperationalPrintJobs($pdo, 'certificate');
        }

        if ($pdo->inTransaction()) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    $clearedLabels = [];
    if (in_array('document_requests', $types, true)) {
        $clearedLabels[] = 'request documents';
    }
    if (in_array('appointments', $types, true)) {
        $clearedLabels[] = 'appointments';
    }
    if (in_array('civil_records', $types, true)) {
        $clearedLabels[] = 'civil records';
    }
    if ($clearAllQueue) {
        $clearedLabels[] = 'queue tickets';
    }
    if (in_array('certification_prints', $types, true)) {
        $clearedLabels[] = 'certification print logs';
    }
    if (in_array('certificate_prints', $types, true)) {
        $clearedLabels[] = 'certificate print logs';
    }

    $detailParts = [];
    if ($results['document_requests'] > 0) {
        $detailParts[] = $results['document_requests'] . ' request(s)';
    }
    if ($results['appointments'] > 0) {
        $detailParts[] = $results['appointments'] . ' appointment(s)';
    }
    if ($results['civil_records'] > 0) {
        $detailParts[] = $results['civil_records'] . ' civil record(s)';
    }
    if ($results['queue_tickets'] > 0) {
        $detailParts[] = $results['queue_tickets'] . ' queue ticket(s)';
    }
    if ($results['queue_announcements'] > 0) {
        $detailParts[] = $results['queue_announcements'] . ' queue announcement(s)';
    }
    if ($results['certification_prints'] > 0) {
        $detailParts[] = $results['certification_prints'] . ' certification print log(s)';
    }
    if ($results['certificate_prints'] > 0) {
        $detailParts[] = $results['certificate_prints'] . ' certificate print log(s)';
    }

    $summary = implode(', ', $clearedLabels);
    $counts = $detailParts !== [] ? implode(', ', $detailParts) : 'no matching rows';
    logActivity($staffId, 'Operational Data Cleared', "Cleared $summary ($counts).");

    return $results;
}

function resolveReportDateRange(string $range, ?string $from = null, ?string $to = null): array
{
    $today = date('Y-m-d');

    if ($range === 'week') {
        return [date('Y-m-d', strtotime('-6 days')), $today];
    }

    if ($range === 'month') {
        return [date('Y-m-01'), $today];
    }

    if ($range === 'custom' && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $from) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $to)) {
        if ($from > $to) {
            return [$to, $from];
        }

        return [$from, $to];
    }

    return [$today, $today];
}

function reportRangeLabel(string $range, string $from, string $to): string
{
    if ($from === $to) {
        return formatDateEmailDisplay($from);
    }

    return formatDateEmailDisplay($from) . ' – ' . formatDateEmailDisplay($to);
}

function civilRecordRegisteredDateExpr(string $recordsAlias = 'cr'): string
{
    return 'COALESCE(brd.registration_date, drd.registration_date, '
        . $recordsAlias . '.event_date, DATE(' . $recordsAlias . '.created_at))';
}

function resolveReportYear(?string $yearInput = null): int
{
    $year = (int) ($yearInput ?? date('Y'));
    $current = (int) date('Y');

    if ($year < 2000 || $year > $current + 1) {
        return $current;
    }

    return $year;
}

/** Calendar years offered on Reports → Civil Records (earliest registration through current year). */
function reportCivilRecordsYearOptions(PDO $pdo): array
{
    $current = (int) date('Y');
    $minYear = $current;

    try {
        $dateExpr = civilRecordRegisteredDateExpr('cr');
        $stmt = $pdo->query(
            "SELECT MIN(YEAR($dateExpr)) AS min_year
             FROM civil_records cr
             LEFT JOIN birth_record_details brd ON brd.civil_record_id = cr.id
             LEFT JOIN death_record_details drd ON drd.civil_record_id = cr.id
             WHERE cr.deleted_at IS NULL"
        );
        $row = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
        if ($row && $row['min_year'] !== null && $row['min_year'] !== '') {
            $minYear = max(2000, (int) $row['min_year']);
        } else {
            $minYear = max(2000, $current - 9);
        }
    } catch (Throwable $e) {
        $minYear = max(2000, $current - 9);
    }

    if ($minYear > $current) {
        $minYear = $current;
    }

    $years = [];
    for ($y = $current; $y >= $minYear; $y--) {
        $years[] = $y;
    }

    return $years !== [] ? $years : [$current];
}

function buildCivilRecordsYearReport(PDO $pdo, int $year): array
{
    $dateExpr = civilRecordRegisteredDateExpr();
    $yearTotals = ['birth' => 0, 'death' => 0, 'marriage' => 0, 'total' => 0];

    $priorYear = $year - 1;
    $priorTotals = ['birth' => 0, 'death' => 0, 'marriage' => 0, 'total' => 0];
    if ($priorYear >= 2000) {
        $priorStmt = $pdo->prepare(
            "SELECT cr.record_type, COUNT(*) AS cnt
             FROM civil_records cr
             LEFT JOIN birth_record_details brd ON brd.civil_record_id = cr.id
             LEFT JOIN death_record_details drd ON drd.civil_record_id = cr.id
             WHERE cr.deleted_at IS NULL AND YEAR($dateExpr) = ?
             GROUP BY cr.record_type"
        );
        $priorStmt->execute([$priorYear]);
        foreach ($priorStmt->fetchAll() as $row) {
            $type = (string) $row['record_type'];
            if (!in_array($type, ['birth', 'death', 'marriage'], true)) {
                continue;
            }
            $cnt = (int) $row['cnt'];
            $priorTotals[$type] = $cnt;
            $priorTotals['total'] += $cnt;
        }
    }

    $monthStmt = $pdo->prepare(
        "SELECT MONTH($dateExpr) AS month_num, cr.record_type, COUNT(*) AS cnt
         FROM civil_records cr
         LEFT JOIN birth_record_details brd ON brd.civil_record_id = cr.id
         LEFT JOIN death_record_details drd ON drd.civil_record_id = cr.id
         WHERE cr.deleted_at IS NULL AND YEAR($dateExpr) = ?
         GROUP BY month_num, cr.record_type
         ORDER BY month_num, cr.record_type"
    );
    $monthStmt->execute([$year]);
    $months = [];
    for ($m = 1; $m <= 12; $m++) {
        $months[$m] = [
            'label' => date('F', mktime(0, 0, 0, $m, 1, $year)),
            'birth' => 0,
            'death' => 0,
            'marriage' => 0,
            'total' => 0,
        ];
    }
    foreach ($monthStmt->fetchAll() as $row) {
        $m = (int) $row['month_num'];
        $type = (string) $row['record_type'];
        if ($m < 1 || $m > 12 || !in_array($type, ['birth', 'death', 'marriage'], true)) {
            continue;
        }
        $cnt = (int) $row['cnt'];
        $months[$m][$type] = $cnt;
        $months[$m]['total'] += $cnt;
        $yearTotals[$type] += $cnt;
        $yearTotals['total'] += $cnt;
    }

    $peakMonth = null;
    $peakTotal = -1;
    foreach ($months as $monthRow) {
        if ((int) $monthRow['total'] > $peakTotal) {
            $peakTotal = (int) $monthRow['total'];
            $peakMonth = $monthRow;
        }
    }
    if ($peakMonth !== null && $peakTotal <= 0) {
        $peakMonth = null;
    }

    $yoy = static function (int $current, int $previous): ?array {
        if ($previous === 0) {
            return $current > 0 ? ['pct' => 100, 'up' => true, 'label' => 'new'] : null;
        }
        $pct = (int) round((($current - $previous) / $previous) * 100);

        return ['pct' => abs($pct), 'up' => $pct >= 0, 'label' => ($pct >= 0 ? '+' : '−') . abs($pct) . '%'];
    };

    $yearYoY = $yoy((int) $yearTotals['total'], (int) $priorTotals['total']);
    $typeYoY = [];
    foreach (['birth', 'death', 'marriage'] as $typeKey) {
        $typeYoY[$typeKey] = $yoy((int) $yearTotals[$typeKey], (int) $priorTotals[$typeKey]);
    }

    $report = [
        'year' => $year,
        'prior_year' => $priorYear,
        'generated_at' => date('Y-m-d H:i:s'),
        'office_name' => getSetting('office_name', 'Local Civil Registrar Office'),
        'site_name' => getSetting('site_name', 'ALCROS'),
        'year_totals' => $yearTotals,
        'prior_year_totals' => $priorTotals,
        'year_yoy' => $yearYoY,
        'type_yoy' => $typeYoY,
        'peak_month' => $peakMonth,
        'months' => $months,
        'record_types' => ['birth', 'death', 'marriage'],
    ];
    $report['chart_payload'] = buildCivilRecordsReportChartPayload($report);

    return $report;
}

/** @param array<string, mixed> $recordsReport */
function buildCivilRecordsReportChartPayload(array $recordsReport): array
{
    $totals = $recordsReport['year_totals'] ?? ['birth' => 0, 'death' => 0, 'marriage' => 0, 'total' => 0];
    $months = $recordsReport['months'] ?? [];

    $monthLabels = [];
    $monthBirth = [];
    $monthDeath = [];
    $monthMarriage = [];
    $monthTotals = [];
    for ($m = 1; $m <= 12; $m++) {
        $ts = mktime(0, 0, 0, $m, 1, (int) ($recordsReport['year'] ?? date('Y')));
        $monthLabels[] = date('M', $ts);
        $monthBirth[] = (int) ($months[$m]['birth'] ?? 0);
        $monthDeath[] = (int) ($months[$m]['death'] ?? 0);
        $monthMarriage[] = (int) ($months[$m]['marriage'] ?? 0);
        $monthTotals[] = (int) ($months[$m]['total'] ?? 0);
    }

    return [
        'hasData' => (int) ($totals['total'] ?? 0) > 0,
        'types' => [
            'labels' => ['Birth', 'Death', 'Marriage'],
            'counts' => [
                (int) ($totals['birth'] ?? 0),
                (int) ($totals['death'] ?? 0),
                (int) ($totals['marriage'] ?? 0),
            ],
            'colors' => ['#2563eb', '#64748b', '#ec4899'],
        ],
        'monthly' => [
            'labels'   => $monthLabels,
            'birth'    => $monthBirth,
            'death'    => $monthDeath,
            'marriage' => $monthMarriage,
            'totals'   => $monthTotals,
        ],
    ];
}

function printJobDocumentKindLabel(string $kind): string
{
    return match ($kind) {
        'certification' => 'Certification',
        'certificate' => 'Certificate',
        default => ucfirst($kind),
    };
}

/** @param array<string, mixed> $row */
function printJobSourceSummary(array $row): string
{
    $tracking = trim((string) ($row['tracking_code'] ?? ''));
    if ($tracking !== '') {
        return 'Request ' . $tracking;
    }

    $registry = trim((string) ($row['registry_number'] ?? ''));
    if ($registry === '') {
        $registry = trim((string) ($row['record_registry'] ?? ''));
    }
    if ($registry !== '') {
        return 'Record ' . $registry;
    }

    if (!empty($row['civil_record_id'])) {
        return 'Record #' . (int) $row['civil_record_id'];
    }

    if (!empty($row['request_id'])) {
        return 'Request #' . (int) $row['request_id'];
    }

    return '-';
}

/**
 * Completed production print jobs for operational reports.
 *
 * @return array{
 *     available: bool,
 *     jobs: list<array<string, mixed>>,
 *     by_document_kind: array{certification: int, certificate: int},
 *     by_certificate_type: array{birth: int, death: int, marriage: int}
 * }
 */
function fetchOperationalPrintReportData(PDO $pdo, string $from, string $to): array
{
    $empty = [
        'available' => false,
        'jobs' => [],
        'by_document_kind' => ['certification' => 0, 'certificate' => 0],
        'by_certificate_type' => ['birth' => 0, 'death' => 0, 'marriage' => 0],
    ];

    try {
        $pdo->query('SELECT id FROM print_jobs LIMIT 1');
        $pdo->query('SELECT document_kind FROM print_templates LIMIT 1');
    } catch (Throwable $e) {
        return $empty;
    }

    $baseWhere = "pj.print_mode = 'production'
        AND pj.status = 'completed'
        AND DATE(pj.printed_at) BETWEEN ? AND ?";

    $kindStmt = $pdo->prepare(
        "SELECT pt.document_kind, COUNT(*) AS cnt
         FROM print_jobs pj
         INNER JOIN print_templates pt ON pt.id = pj.template_id
         WHERE {$baseWhere}
         GROUP BY pt.document_kind"
    );
    $kindStmt->execute([$from, $to]);
    $byKind = ['certification' => 0, 'certificate' => 0];
    foreach ($kindStmt->fetchAll(PDO::FETCH_ASSOC) as $kindRow) {
        $key = (string) ($kindRow['document_kind'] ?? '');
        if (isset($byKind[$key])) {
            $byKind[$key] = (int) ($kindRow['cnt'] ?? 0);
        }
    }

    $typeStmt = $pdo->prepare(
        "SELECT pj.certificate_type, COUNT(*) AS cnt
         FROM print_jobs pj
         INNER JOIN print_templates pt ON pt.id = pj.template_id
         WHERE {$baseWhere}
         GROUP BY pj.certificate_type"
    );
    $typeStmt->execute([$from, $to]);
    $byType = ['birth' => 0, 'death' => 0, 'marriage' => 0];
    foreach ($typeStmt->fetchAll(PDO::FETCH_ASSOC) as $typeRow) {
        $key = (string) ($typeRow['certificate_type'] ?? '');
        if (isset($byType[$key])) {
            $byType[$key] = (int) ($typeRow['cnt'] ?? 0);
        }
    }

    $listStmt = $pdo->prepare(
        "SELECT pj.id, pj.printed_at, pj.certificate_type, pj.page_side, pj.copies, pj.printed_by,
                pt.document_kind, pj.request_id, pj.civil_record_id, pj.registry_number,
                dr.tracking_code, cr.registry_number AS record_registry
         FROM print_jobs pj
         INNER JOIN print_templates pt ON pt.id = pj.template_id
         LEFT JOIN document_requests dr ON dr.id = pj.request_id
         LEFT JOIN civil_records cr ON cr.id = pj.civil_record_id
         WHERE {$baseWhere}
         ORDER BY pj.printed_at DESC"
    );
    $listStmt->execute([$from, $to]);

    return [
        'available' => true,
        'jobs' => $listStmt->fetchAll(PDO::FETCH_ASSOC),
        'by_document_kind' => $byKind,
        'by_certificate_type' => $byType,
    ];
}

function buildOperationalReport(PDO $pdo, string $from, string $to): array
{
    $summaryStmt = $pdo->prepare(
        "SELECT
            SUM(CASE WHEN DATE(submitted_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) AS requests_submitted,
            SUM(CASE WHEN status = 'completed' AND DATE(updated_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) AS requests_completed
         FROM document_requests"
    );
    $summaryStmt->execute([$from, $to, $from, $to]);
    $requestSummary = $summaryStmt->fetch() ?: [];

    $apptSummaryStmt = $pdo->prepare(
        "SELECT
            SUM(CASE WHEN appointment_date BETWEEN ? AND ? THEN 1 ELSE 0 END) AS appointments_scheduled,
            SUM(CASE WHEN status = 'completed' AND appointment_date BETWEEN ? AND ? THEN 1 ELSE 0 END) AS appointments_completed
         FROM appointments"
    );
    $apptSummaryStmt->execute([$from, $to, $from, $to]);
    $apptSummary = $apptSummaryStmt->fetch() ?: [];

    $queueSummaryStmt = $pdo->prepare(
        "SELECT
            SUM(CASE WHEN status = 'completed' AND DATE(created_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) AS queue_served,
            SUM(CASE WHEN status = 'waiting' AND DATE(created_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) AS queue_waiting,
            SUM(CASE WHEN status = 'skipped' AND DATE(created_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) AS queue_skipped
         FROM queue_tickets"
    );
    $queueSummaryStmt->execute([$from, $to, $from, $to, $from, $to]);
    $queueSummary = $queueSummaryStmt->fetch() ?: [];

    $statusRows = $pdo->prepare(
        "SELECT status, COUNT(*) AS cnt FROM document_requests
         WHERE DATE(submitted_at) BETWEEN ? AND ?
         GROUP BY status ORDER BY cnt DESC"
    );
    $statusRows->execute([$from, $to]);
    $requestsByStatus = [];
    foreach ($statusRows->fetchAll() as $row) {
        $requestsByStatus[$row['status']] = (int) $row['cnt'];
    }

    $typeRows = $pdo->prepare(
        "SELECT document_type, COUNT(*) AS cnt FROM document_requests
         WHERE DATE(submitted_at) BETWEEN ? AND ?
         GROUP BY document_type ORDER BY cnt DESC"
    );
    $typeRows->execute([$from, $to]);
    $requestsByType = [];
    foreach ($typeRows->fetchAll() as $row) {
        $requestsByType[$row['document_type']] = (int) $row['cnt'];
    }

    $requestList = $pdo->prepare(
        "SELECT dr.tracking_code, dr.first_name, dr.middle_name, dr.last_name, dr.document_type, dr.status,
                dr.submitted_at, dr.updated_at, dr.appointment_date, dr.appointment_time,
                (
                    SELECT a.status FROM appointments a
                    WHERE a.tracking_code = dr.tracking_code AND a.deleted_at IS NULL
                    ORDER BY a.updated_at DESC, a.id DESC
                    LIMIT 1
                ) AS visit_appointment_status
         FROM document_requests dr
         WHERE DATE(dr.submitted_at) BETWEEN ? AND ?
         ORDER BY dr.submitted_at DESC"
    );
    $requestList->execute([$from, $to]);

    $apptStatusRows = $pdo->prepare(
        "SELECT status, COUNT(*) AS cnt FROM appointments
         WHERE appointment_date BETWEEN ? AND ?
         GROUP BY status ORDER BY cnt DESC"
    );
    $apptStatusRows->execute([$from, $to]);
    $appointmentsByStatus = [];
    foreach ($apptStatusRows->fetchAll() as $row) {
        $appointmentsByStatus[$row['status']] = (int) $row['cnt'];
    }

    $appointmentList = $pdo->prepare(
        "SELECT appointment_code, first_name, middle_name, last_name, service_type, appointment_date, appointment_time, status, source, created_at
         FROM appointments
         WHERE appointment_date BETWEEN ? AND ?
         ORDER BY appointment_date ASC, appointment_time ASC"
    );
    $appointmentList->execute([$from, $to]);

    $queuePurposeRows = $pdo->prepare(
        "SELECT purpose, COUNT(*) AS cnt FROM queue_tickets
         WHERE DATE(created_at) BETWEEN ? AND ?
         GROUP BY purpose ORDER BY cnt DESC"
    );
    $queuePurposeRows->execute([$from, $to]);
    $queueByPurpose = [];
    foreach ($queuePurposeRows->fetchAll() as $row) {
        $queueByPurpose[$row['purpose']] = (int) $row['cnt'];
    }

    ensureQueueTicketTimingColumns($pdo);

    $queueList = $pdo->prepare(
        "SELECT ticket_number, purpose, status, first_name, middle_name, last_name, reference_code, window_number,
                created_at, called_at, first_called_at
         FROM queue_tickets
         WHERE DATE(created_at) BETWEEN ? AND ?
         ORDER BY created_at DESC"
    );
    $queueList->execute([$from, $to]);
    $queueTickets = enrichQueueTicketsWithWaitMetrics($queueList->fetchAll());
    $queueWaitSummary = buildQueueWaitSummary($queueTickets);
    $printReport = fetchOperationalPrintReportData($pdo, $from, $to);

    return [
        'from' => $from,
        'to' => $to,
        'generated_at' => date('Y-m-d H:i:s'),
        'office_name' => getSetting('office_name', 'Local Civil Registrar Office'),
        'site_name' => getSetting('site_name', 'ALCROS'),
        'summary' => [
            'requests_submitted'   => (int) ($requestSummary['requests_submitted'] ?? 0),
            'requests_completed'   => (int) ($requestSummary['requests_completed'] ?? 0),
            'appointments_scheduled' => (int) ($apptSummary['appointments_scheduled'] ?? 0),
            'appointments_completed' => (int) ($apptSummary['appointments_completed'] ?? 0),
            'queue_served'         => (int) ($queueSummary['queue_served'] ?? 0),
            'queue_waiting'        => (int) ($queueSummary['queue_waiting'] ?? 0),
            'queue_skipped'        => (int) ($queueSummary['queue_skipped'] ?? 0),
            'pending_requests'     => (int) $pdo->query('SELECT COUNT(*) FROM document_requests WHERE ' . documentRequestActiveSql() . " AND status = 'pending'")->fetchColumn(),
            'ready_for_pickup'     => (int) $pdo->query('SELECT COUNT(*) FROM document_requests WHERE ' . documentRequestActiveSql() . " AND status = 'ready'")->fetchColumn(),
            'total_records'        => (int) $pdo->query('SELECT COUNT(*) FROM civil_records WHERE deleted_at IS NULL')->fetchColumn(),
            'certifications_printed' => (int) ($printReport['by_document_kind']['certification'] ?? 0),
            'certificates_printed'   => (int) ($printReport['by_document_kind']['certificate'] ?? 0),
        ],
        'print_jobs' => $printReport['jobs'],
        'prints_by_document_kind' => $printReport['by_document_kind'],
        'prints_by_certificate_type' => $printReport['by_certificate_type'],
        'prints_available' => $printReport['available'],
        'requests_by_status' => $requestsByStatus,
        'requests_by_type' => $requestsByType,
        'requests' => $requestList->fetchAll(),
        'appointments_by_status' => $appointmentsByStatus,
        'appointments' => $appointmentList->fetchAll(),
        'queue_by_purpose' => $queueByPurpose,
        'queue_tickets' => $queueTickets,
        'queue_wait_summary' => $queueWaitSummary,
    ];
}

function formatReportDateTime(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return 'Not recorded';
    }

    $ts = strtotime($value);

    return $ts ? date('F j, Y g:i A', $ts) : $value;
}

/** @return list<string> */
function reportExportSectionKeys(): array
{
    return ['overview', 'requests', 'appointments', 'queue', 'prints', 'records'];
}

/** @return list<string> */
function parseReportExportSections(?string $raw): array
{
    $valid = reportExportSectionKeys();
    $sections = [];

    foreach (explode(',', (string) $raw) as $part) {
        $part = trim($part);
        if (in_array($part, $valid, true)) {
            $sections[] = $part;
        }
    }

    return array_values(array_unique($sections));
}

function reportExportRecordsType(?string $raw): string
{
    $type = strtolower(trim((string) $raw));

    return in_array($type, ['all', 'birth', 'death', 'marriage'], true) ? $type : 'all';
}

/** @param list<string> $sections */
function reportOperationalExcelFilename(array $sections, string $recordsType, int $reportYear): string
{
    require_once __DIR__ . '/excel_export.php';

    $slug = [
        'overview'     => 'overview',
        'requests'     => 'document_requests',
        'appointments' => 'appointments',
        'queue'        => 'queue',
        'prints'       => 'print_jobs',
        'records'      => 'civil_records',
    ];

    $sections = array_values(array_unique($sections));
    sort($sections);

    $sectionParts = [];
    foreach ($sections as $key) {
        $sectionParts[] = $slug[$key] ?? $key;
    }

    if (count($sections) === 1) {
        $only = $sections[0];
        if ($only === 'records') {
            return alcrosExcelDownloadFilename(
                'report_civil_records',
                (string) $reportYear,
                $recordsType !== 'all' ? $recordsType : 'all_types'
            );
        }

        return alcrosExcelDownloadFilename('report_' . ($slug[$only] ?? $only));
    }

    $segments = ['report_operational', implode('-', $sectionParts)];
    if (in_array('records', $sections, true)) {
        $segments[] = (string) $reportYear;
        if ($recordsType !== 'all') {
            $segments[] = $recordsType;
        }
    }

    return alcrosExcelDownloadFilename(...$segments);
}

function reportCivilRecordsExcelUrl(
    string $recordsType,
    int $year,
    string $range = 'today',
    string $fromDate = '',
    string $toDate = ''
): string {
    $params = [
        'action'       => 'export',
        'sections'     => 'records',
        'records_type' => reportExportRecordsType($recordsType),
        'year'         => max(2000, $year),
    ];

    if ($range !== 'today') {
        $params['range'] = $range;
    }
    if ($range === 'custom') {
        $params['from'] = $fromDate;
        $params['to'] = $toDate;
    }

    return buildAuthUrl('report.php', $params);
}

function reportRecordsExportFromClause(): string
{
    return 'civil_records cr'
        . ' LEFT JOIN birth_record_details brd ON brd.civil_record_id = cr.id'
        . ' LEFT JOIN death_record_details drd ON drd.civil_record_id = cr.id';
}

/** @return array{0: string, 1: list<mixed>} */
function reportRecordsExportWhere(int $year, string $type): array
{
    $dateExpr = civilRecordRegisteredDateExpr('cr');
    $where = "cr.deleted_at IS NULL AND YEAR($dateExpr) = ?";
    $params = [$year];

    if ($type !== 'all') {
        $where .= ' AND cr.record_type = ?';
        $params[] = $type;
    }

    return [$where, $params];
}

/** @return list<array<string, mixed>> */
function reportExportRecordsFetchChunk(PDO $pdo, string $where, array $params, int $afterId, int $limit): array
{
    $from = reportRecordsExportFromClause();
    $sql = "SELECT cr.* FROM $from WHERE $where AND cr.id > ?"
        . ' ORDER BY cr.id ASC LIMIT ' . max(1, $limit);
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge($params, [$afterId]));

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** @return list<string|null> */
function reportCivilRecordExportRowValues(array $row, string $type): array
{
    require_once __DIR__ . '/printing.php';

    $values = printBuildFieldValues($row, $type, ['keep_empty' => true]);

    return array_map(
        static function (string $column) use ($values) {
            $value = $values[$column] ?? null;
            if ($value === null || trim((string) $value) === '') {
                return null;
            }

            return (string) $value;
        },
        civilRecordCsvColumns($type)
    );
}

require_once __DIR__ . '/system_errors.php';
