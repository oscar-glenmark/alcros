<?php
/**
 * ALCROS security helpers - headers, CSRF, rate limits, session hardening.
 */

function securityStoragePath(string $file): string
{
    $dir = __DIR__ . '/../storage';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    return $dir . '/' . $file;
}

function authSecretKey(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }

    $path = securityStoragePath('auth_secret.txt');
    if (is_readable($path)) {
        $secret = trim((string) file_get_contents($path));
        if ($secret !== '') {
            return $secret;
        }
    }

    $secret = bin2hex(random_bytes(32));
    file_put_contents($path, $secret, LOCK_EX);

    return $secret;
}

function cronSecretKey(): string
{
    $path = securityStoragePath('cron_secret.txt');
    if (is_readable($path)) {
        $stored = trim((string) file_get_contents($path));
        if ($stored !== '') {
            return $stored;
        }
    }

    $secret = bin2hex(random_bytes(24));
    file_put_contents($path, $secret, LOCK_EX);

    return $secret;
}

function bootstrapSecurity(): void
{
    static $booted = false;
    if ($booted) {
        return;
    }
    $booted = true;

    sendSecurityHeaders();

    if (defined('ALCROS_PUBLIC_READ_API') && ALCROS_PUBLIC_READ_API) {
        return;
    }

    if (session_status() === PHP_SESSION_NONE) {
        if (!function_exists('alcrosRequestIsHttps')) {
            require_once __DIR__ . '/hosting.php';
        }
        $secure = alcrosRequestIsHttps();

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    ensureCsrfToken();
}

function sendSecurityHeaders(): void
{
    static $sent = false;
    if ($sent || headers_sent()) {
        return;
    }
    $sent = true;

    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header(
        'Content-Security-Policy: default-src \'self\'; '
        . 'script-src \'self\' \'unsafe-inline\'; '
        . 'style-src \'self\' \'unsafe-inline\'; '
        . 'font-src \'self\' data:; '
        . 'img-src \'self\' data: https:; '
        . 'connect-src \'self\'; '
        . 'frame-ancestors \'self\'; '
        . 'base-uri \'self\'; '
        . 'form-action \'self\''
    );

    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function ensureCsrfToken(): void
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function csrfToken(): string
{
    ensureCsrfToken();

    return (string) $_SESSION['csrf_token'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') . '">';
}

function validateCsrf(?string $token): bool
{
    ensureCsrfToken();
    if (!is_string($token) || $token === '') {
        return false;
    }

    return hash_equals((string) $_SESSION['csrf_token'], $token);
}

function iniParseSize(string $value): int
{
    $value = trim($value);
    if ($value === '') {
        return 0;
    }

    $unit = strtolower(substr($value, -1));
    $num = (float) $value;

    return (int) match ($unit) {
        'g' => $num * 1024 * 1024 * 1024,
        'm' => $num * 1024 * 1024,
        'k' => $num * 1024,
        default => $num,
    };
}

/** POST body exceeded post_max_size - PHP empties $_POST so CSRF appears to fail. */
function requestBodyExceededPostLimit(): bool
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return false;
    }

    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length <= 0) {
        return false;
    }

    $limit = iniParseSize((string) ini_get('post_max_size'));

    return $limit > 0 && $length > $limit;
}

function postLimitExceededMessage(): string
{
    $max = ini_get('post_max_size') ?: 'unknown';

    return 'Request is too large (max ' . $max . '). Use a smaller CSV or file, or increase post_max_size and upload_max_filesize in PHP.';
}

function isJsonApiRequest(): bool
{
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_FILENAME'] ?? ''));
    if (str_contains($script, '/api/')) {
        return true;
    }

    $accept = (string) ($_SERVER['HTTP_ACCEPT'] ?? '');
    if (str_contains($accept, 'application/json')) {
        return true;
    }

    return strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
}

/**
 * Send a response status.
 *
 * Apache replaces status codes it does not know (such as 419) with 500 unless
 * the status line carries an explicit reason phrase, which would hide session
 * expiry from the front-end handlers that check for it.
 */
function sendHttpStatus(int $status): void
{
    $reasons = [
        419 => 'Authentication Timeout',
    ];

    if (isset($reasons[$status])) {
        $protocol = (string) ($_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.1');
        header($protocol . ' ' . $status . ' ' . $reasons[$status], true, $status);

        return;
    }

    http_response_code($status);
}

function jsonClientError(int $status, string $code, string $message): never
{
    sendHttpStatus($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo json_encode([
        'ok'      => false,
        'code'    => $code,
        'error'   => $message,
        'message' => $message,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function requireCsrf(): void
{
    if (requestBodyExceededPostLimit()) {
        if (isJsonApiRequest()) {
            jsonClientError(413, 'payload_too_large', postLimitExceededMessage());
        }
        http_response_code(413);
        exit(postLimitExceededMessage());
    }

    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!validateCsrf(is_string($token) ? $token : '')) {
        if (isJsonApiRequest()) {
            jsonClientError(419, 'csrf_expired', 'Invalid or expired security token. Please refresh the page and try again.');
        }
        sendHttpStatus(419);
        exit('Invalid or expired security token. Please refresh the page and try again.');
    }
}

function requireStaffPostCsrf(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return;
    }

    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($script === 'login.php') {
        return;
    }

    requireCsrf();
}

function publicCsrfField(): string
{
    return csrfField();
}

function requirePublicPostCsrf(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return;
    }
    requireCsrf();
}

function rateLimitKey(string $action, ?string $suffix = null): string
{
    $ip = clientIpAddress();
    $part = preg_replace('/[^a-z0-9_-]+/i', '_', $action) ?: 'action';
    $extra = $suffix !== null ? '_' . preg_replace('/[^a-z0-9_-]+/i', '_', $suffix) : '';

    return $part . '_' . md5($ip . $extra);
}

function alcrosValidateIpAddress(string $ip): ?string
{
    $ip = trim($ip);
    if ($ip === '') {
        return null;
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return null;
    }

    if (function_exists('inet_pton') && function_exists('inet_ntop')) {
        $packed = @inet_pton($ip);
        if ($packed !== false) {
            $normalized = inet_ntop($packed);

            return $normalized !== false ? $normalized : $ip;
        }
    }

    return $ip;
}

function alcrosFirstValidIpFromForwardedHeader(string $header): ?string
{
    foreach (explode(',', $header) as $part) {
        $candidate = trim($part);
        if ($candidate === '') {
            continue;
        }

        if (preg_match('/^\[(.+)\](?::\d+)?$/', $candidate, $matches)) {
            $candidate = $matches[1];
        } elseif (preg_match('/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/', $candidate, $matches)) {
            $candidate = $matches[1];
        }

        $validated = alcrosValidateIpAddress($candidate);
        if ($validated !== null) {
            return $validated;
        }
    }

    return null;
}

function clientIpAddress(): string
{
    if (!function_exists('alcrosTrustProxyClientIp')) {
        require_once __DIR__ . '/hosting.php';
    }

    if (alcrosTrustProxyClientIp()) {
        $trustedHeaders = [
            (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''),
            (string) ($_SERVER['HTTP_X_REAL_IP'] ?? ''),
        ];

        foreach ($trustedHeaders as $headerValue) {
            $headerValue = trim($headerValue);
            if ($headerValue === '') {
                continue;
            }

            $validated = alcrosValidateIpAddress($headerValue);
            if ($validated !== null) {
                return $validated;
            }
        }

        $forwarded = trim((string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''));
        if ($forwarded !== '') {
            $fromChain = alcrosFirstValidIpFromForwardedHeader($forwarded);
            if ($fromChain !== null) {
                return $fromChain;
            }
        }
    }

    $remote = alcrosValidateIpAddress((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

    return $remote ?? '0.0.0.0';
}

/** Human-readable IP for emails and activity logs (canonical form when possible). */
function formatClientIpAddress(?string $ip = null): string
{
    $ip = trim($ip ?? clientIpAddress());
    if ($ip === '' || $ip === '0.0.0.0') {
        return 'Unavailable';
    }

    $validated = alcrosValidateIpAddress($ip);
    if ($validated === null) {
        return $ip;
    }

    if ($validated === '::1') {
        return '127.0.0.1 (local)';
    }

    return $validated;
}

function rateLimitStorageFile(string $key): string
{
    $dir = securityStoragePath('rate_limits');
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    return $dir . '/' . hash('sha256', $key) . '.json';
}

/** @return array{count: int, reset: int, lockout_alert_sent: int, lockout_admin_inbox_sent: int, last_ip: string} */
function rateLimitReadState(string $key, int $windowSeconds): array
{
    $now = time();
    $defaults = [
        'count'                     => 0,
        'reset'                     => $now + $windowSeconds,
        'lockout_alert_sent'        => 0,
        'lockout_admin_inbox_sent'  => 0,
        'last_ip'                   => '',
    ];

    $file = rateLimitStorageFile($key);
    if (!is_readable($file)) {
        return $defaults;
    }

    $decoded = json_decode((string) file_get_contents($file), true);
    if (!is_array($decoded)) {
        return $defaults;
    }

    if ((int) ($decoded['reset'] ?? 0) <= $now) {
        return $defaults;
    }

    $lastIp = trim((string) ($decoded['last_ip'] ?? ''));
    if ($lastIp !== '') {
        $lastIp = formatClientIpAddress($lastIp);
        if ($lastIp === 'Unavailable') {
            $lastIp = '';
        }
    }

    return [
        'count'                    => (int) ($decoded['count'] ?? 0),
        'reset'                    => (int) ($decoded['reset'] ?? ($now + $windowSeconds)),
        'lockout_alert_sent'       => !empty($decoded['lockout_alert_sent']) ? 1 : 0,
        'lockout_admin_inbox_sent' => !empty($decoded['lockout_admin_inbox_sent']) ? 1 : 0,
        'last_ip'                  => $lastIp,
    ];
}

/** @param array{count?: int, reset?: int, lockout_alert_sent?: int, lockout_admin_inbox_sent?: int, last_ip?: string} $data */
function rateLimitWriteState(string $key, array $data): void
{
    $payload = [
        'count'                    => (int) ($data['count'] ?? 0),
        'reset'                    => (int) ($data['reset'] ?? (time() + 900)),
        'lockout_alert_sent'       => !empty($data['lockout_alert_sent']) ? 1 : 0,
        'lockout_admin_inbox_sent' => !empty($data['lockout_admin_inbox_sent']) ? 1 : 0,
    ];

    $lastIp = trim((string) ($data['last_ip'] ?? ''));
    if ($lastIp !== '') {
        $validatedLastIp = alcrosValidateIpAddress($lastIp);
        if ($validatedLastIp !== null) {
            $payload['last_ip'] = $validatedLastIp;
        }
    }

    file_put_contents(
        rateLimitStorageFile($key),
        json_encode($payload),
        LOCK_EX
    );
}

function rateLimitIsBlocked(string $key, int $maxAttempts, int $windowSeconds): bool
{
    $data = rateLimitReadState($key, $windowSeconds);

    return $data['count'] >= $maxAttempts;
}

/**
 * Record a failed staff portal sign-in (wrong password or unrecognized Staff ID).
 *
 * @return array{allowed: bool, count: int, limit_reached: bool}
 */
function rateLimitRecordFailedAttempt(string $key, int $maxAttempts, int $windowSeconds): array
{
    $data = rateLimitReadState($key, $windowSeconds);
    $count = $data['count'];

    if ($count >= $maxAttempts) {
        return [
            'allowed'       => false,
            'count'         => $count,
            'limit_reached' => true,
        ];
    }

    $data['count'] = $count + 1;
    $data['last_ip'] = clientIpAddress();
    rateLimitWriteState($key, $data);
    $newCount = (int) $data['count'];

    return [
        'allowed'       => true,
        'count'         => $newCount,
        'limit_reached' => $newCount >= $maxAttempts,
    ];
}

function rateLimitLockoutAlertAlreadySent(string $key, int $windowSeconds): bool
{
    $data = rateLimitReadState($key, $windowSeconds);

    return $data['lockout_alert_sent'] === 1;
}

function rateLimitMarkLockoutAlertSent(string $key, int $windowSeconds): void
{
    $data = rateLimitReadState($key, $windowSeconds);
    $data['lockout_alert_sent'] = 1;
    rateLimitWriteState($key, $data);
}

function rateLimitAdminInboxLockoutAlreadySent(string $key, int $windowSeconds): bool
{
    $data = rateLimitReadState($key, $windowSeconds);

    return $data['lockout_admin_inbox_sent'] === 1;
}

function rateLimitMarkAdminInboxLockoutSent(string $key, int $windowSeconds): void
{
    $data = rateLimitReadState($key, $windowSeconds);
    $data['lockout_admin_inbox_sent'] = 1;
    rateLimitWriteState($key, $data);
}

function rateLimitCheck(string $key, int $maxAttempts, int $windowSeconds): bool
{
    $dir = securityStoragePath('rate_limits');
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $file = $dir . '/' . hash('sha256', $key) . '.json';
    $now = time();
    $data = ['count' => 0, 'reset' => $now + $windowSeconds];

    if (is_readable($file)) {
        $decoded = json_decode((string) file_get_contents($file), true);
        if (is_array($decoded)) {
            $data = $decoded;
        }
    }

    if (($data['reset'] ?? 0) <= $now) {
        $data = ['count' => 0, 'reset' => $now + $windowSeconds];
    }

    if (($data['count'] ?? 0) >= $maxAttempts) {
        return false;
    }

    $data['count'] = (int) ($data['count'] ?? 0) + 1;
    file_put_contents($file, json_encode($data), LOCK_EX);

    return true;
}

/** Seconds until the rate-limit window resets, or null if not currently blocked. */
function rateLimitRetryAfterSeconds(string $key, int $maxAttempts, int $windowSeconds): ?int
{
    $dir = securityStoragePath('rate_limits');
    $file = $dir . '/' . hash('sha256', $key) . '.json';
    $now = time();

    if (!is_readable($file)) {
        return null;
    }

    $decoded = json_decode((string) file_get_contents($file), true);
    if (!is_array($decoded)) {
        return null;
    }

    $reset = (int) ($decoded['reset'] ?? 0);
    $count = (int) ($decoded['count'] ?? 0);

    if ($reset <= $now || $count < $maxAttempts) {
        return null;
    }

    return max(1, $reset - $now);
}

function rateLimitOrAbort(string $key, int $maxAttempts, int $windowSeconds, string $message): void
{
    if (rateLimitCheck($key, $maxAttempts, $windowSeconds)) {
        return;
    }

    http_response_code(429);
    if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')
        || str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => $message]);
        exit;
    }

    exit($message);
}

function passwordMinLength(): int
{
    return 8;
}

function validatePasswordStrength(string $password): ?string
{
    $min = passwordMinLength();
    if (strlen($password) < $min) {
        return 'Password must be at least ' . $min . ' characters.';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        return 'Password must include at least one uppercase letter.';
    }
    if (!preg_match('/[a-z]/', $password)) {
        return 'Password must include at least one lowercase letter.';
    }
    if (!preg_match('/[0-9]/', $password)) {
        return 'Password must include at least one number.';
    }

    return null;
}

function sanitizeOverviewHtml(string $html): string
{
    return strip_tags($html, '<strong><em><br><p><ul><ol><li>');
}

function sanitizeExternalUrl(string $url, string $fallback = 'privacy.php'): string
{
    $url = trim($url);
    if ($url === '') {
        return $fallback;
    }

    if (str_starts_with($url, '/') && !str_starts_with($url, '//')) {
        return $url;
    }

    if (preg_match('#^https?://#i', $url)) {
        $host = parse_url($url, PHP_URL_HOST);
        $siteHost = $_SERVER['HTTP_HOST'] ?? '';
        if ($host && $siteHost && strcasecmp($host, $siteHost) === 0) {
            return $url;
        }
    }

    return $fallback;
}

function requireCronSecret(): void
{
    $expected = cronSecretKey();
    $provided = (string) ($_GET['cron_secret'] ?? $_POST['cron_secret'] ?? $_SERVER['HTTP_X_CRON_SECRET'] ?? '');
    if ($provided === '' || !hash_equals($expected, $provided)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Forbidden']);
        exit;
    }
}

function queueDisplayTokenKey(): string
{
    $path = securityStoragePath('queue_display_token.txt');
    if (is_readable($path)) {
        $stored = trim((string) file_get_contents($path));
        if ($stored !== '') {
            return $stored;
        }
    }

    $secret = bin2hex(random_bytes(24));
    file_put_contents($path, $secret, LOCK_EX);

    return $secret;
}

function requireQueueAnnouncementAccess(): void
{
    $expected = queueDisplayTokenKey();
    $provided = (string) ($_POST['display_token'] ?? $_GET['display_token'] ?? '');
    if ($provided !== '' && hash_equals($expected, $provided)) {
        return;
    }

    if (function_exists('getAuthenticatedStaff') && getAuthenticatedStaff()) {
        if (function_exists('isAdmin') && isAdmin()) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Forbidden']);
            exit;
        }

        return;
    }

    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Forbidden']);
    exit;
}

function isSensitiveUploadPath(string $path): bool
{
    $path = str_replace('\\', '/', $path);
    $path = ltrim($path, '/');

    return str_starts_with($path, 'uploads/ids/')
        || str_starts_with($path, 'uploads/staff/');
}

function uploadPathIsUnderRoot(string $resolvedPath, string $uploadsRoot): bool
{
    $resolvedPath = str_replace('\\', '/', $resolvedPath);
    $uploadsRoot = str_replace('\\', '/', $uploadsRoot);
    if (PHP_OS_FAMILY === 'Windows') {
        $resolvedPath = strtolower($resolvedPath);
        $uploadsRoot = strtolower($uploadsRoot);
    }

    return $resolvedPath === $uploadsRoot || str_starts_with($resolvedPath, $uploadsRoot . '/');
}

function normalizeUploadRelativePath(string $path): ?string
{
    $path = str_replace('\\', '/', trim($path));
    $path = ltrim($path, '/');
    if ($path === '' || str_contains($path, '..') || !isSensitiveUploadPath($path)) {
        return null;
    }

    $root = realpath(__DIR__ . '/../uploads');
    if ($root === false) {
        return null;
    }

    $fullPath = __DIR__ . '/../' . str_replace('/', DIRECTORY_SEPARATOR, $path);
    $resolved = realpath($fullPath);
    if ($resolved !== false && uploadPathIsUnderRoot($resolved, $root)) {
        return $path;
    }

    if (is_file($fullPath)) {
        $parent = realpath(dirname($fullPath));
        if ($parent !== false && uploadPathIsUnderRoot($parent, $root)) {
            return $path;
        }
    }

    $parent = realpath(dirname($fullPath));
    if ($parent === false || !uploadPathIsUnderRoot($parent, $root)) {
        return null;
    }

    $basename = basename($path);
    if ($basename === '' || $basename === '.' || $basename === '..') {
        return null;
    }

    return $path;
}

function publicTrackingRequest(array $row): array
{
    return [
        'tracking_code'    => $row['tracking_code'] ?? '',
        'citizen_name'     => documentRequestNameOnRecord($row),
        'requester_name'   => personRequesterNameFromRow($row),
        'document_type'    => $row['document_type'] ?? '',
        'status'           => $row['status'] ?? '',
        'submitted_at'     => $row['submitted_at'] ?? '',
        'updated_at'       => $row['updated_at'] ?? '',
        'appointment_date' => $row['appointment_date'] ?? null,
        'appointment_time' => $row['appointment_time'] ?? null,
    ];
}

function publicTrackingAppointment(array $row): array
{
    return [
        'appointment_code' => $row['appointment_code'] ?? '',
        'citizen_name'     => personNameFromRow($row),
        'service_type'     => $row['service_type'] ?? '',
        'status'           => $row['status'] ?? '',
        'appointment_date' => $row['appointment_date'] ?? '',
        'appointment_time' => $row['appointment_time'] ?? '',
        'created_at'       => $row['created_at'] ?? '',
        'updated_at'       => $row['updated_at'] ?? ($row['created_at'] ?? ''),
    ];
}

function protectedUploadUrl(?string $path): ?string
{
    if ($path === null || trim($path) === '') {
        return null;
    }

    $normalized = normalizeUploadRelativePath($path);
    if ($normalized === null) {
        return null;
    }

    if (!function_exists('buildAuthUrl')) {
        require_once __DIR__ . '/auth.php';
    }

    $query = [
        'f'   => $normalized,
        'raw' => '1',
    ];
    $full = __DIR__ . '/../' . str_replace('/', DIRECTORY_SEPARATOR, $normalized);
    if (is_file($full)) {
        $query['v'] = (string) (filemtime($full) ?: time());
    }

    return buildAuthUrl('file.php', $query);
}
