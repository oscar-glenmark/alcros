<?php

/**
 * Dependency-free XLSX writer.
 *
 * Builds Office Open XML workbooks without a third-party spreadsheet library.
 * Uses ZipArchive when available; otherwise packs the archive in pure PHP.
 * Only the features ALCROS import templates need are implemented: text and
 * number cells, fonts, solid fills, thin borders, alignment, column widths,
 * row heights, merged ranges, and one frozen pane plus one autofilter per sheet.
 *
 * Style arrays accept: bold, italic, size, color, fill, wrap, halign, valign,
 * border, format ('general' | 'text' | 'number' | 'date' | 'datetime').
 */

final class AlcrosXlsxSheet
{
    private string $name = 'Sheet1';

    /** @var array<int, array<int, array{v: mixed, numeric: bool}>> row => col => cell */
    private array $cells = [];

    /** @var array<int, array<int, array<string, mixed>>> row => col => style */
    private array $cellStyles = [];

    /** @var list<string> */
    private array $merges = [];

    /** @var array<int, float> */
    private array $rowHeights = [];

    /** @var array<int, float> */
    private array $colWidths = [];

    private ?int $freezeRow = null;
    private ?string $autoFilter = null;
    private int $maxRow = 0;
    private int $maxCol = 0;

    /** @var list<array{path: string, col: int, row: int, width_px: int, height_px: int}> */
    private array $images = [];

    public function __construct(string $name)
    {
        $this->setTitle($name);
    }

    public function setTitle(string $name): self
    {
        $name = str_replace(['\\', '/', '?', '*', '[', ']', ':'], ' ', trim($name));
        $name = trim(preg_replace('/\s+/u', ' ', $name) ?? $name);
        if ($name === '') {
            $name = 'Sheet';
        }
        // Excel rejects sheet names longer than 31 characters.
        $this->name = mb_substr($name, 0, 31, 'UTF-8');

        return $this;
    }

    public function getTitle(): string
    {
        return $this->name;
    }

    public function setCell(int $col, int $row, mixed $value): void
    {
        $col = max(1, $col);
        $row = max(1, $row);

        if (is_bool($value)) {
            $value = $value ? 'Yes' : 'No';
        } elseif ($value === null) {
            $value = '';
        }

        $numeric = is_int($value) || is_float($value);
        if (!$numeric && !is_string($value)) {
            $value = (string) $value;
        }

        $this->cells[$row][$col] = ['v' => $value, 'numeric' => $numeric];
        $this->maxRow = max($this->maxRow, $row);
        $this->maxCol = max($this->maxCol, $col);
    }

    public function getCellValue(int $col, int $row): mixed
    {
        return $this->cells[$row][$col]['v'] ?? null;
    }

    /** Turn numeric-looking text into real numbers so Excel can total them. */
    public function coerceNumeric(int $col, int $firstRow, int $lastRow): void
    {
        for ($row = $firstRow; $row <= $lastRow; $row++) {
            if (!isset($this->cells[$row][$col])) {
                continue;
            }
            $cell = $this->cells[$row][$col];
            if ($cell['numeric'] || !is_string($cell['v'])) {
                continue;
            }
            $text = trim($cell['v']);
            if ($text === '' || !is_numeric($text)) {
                continue;
            }
            $this->cells[$row][$col] = [
                'v' => $text + 0,
                'numeric' => true,
            ];
        }
    }

    public function mergeCells(int $firstCol, int $firstRow, int $lastCol, int $lastRow): void
    {
        if ($lastCol <= $firstCol && $lastRow <= $firstRow) {
            return;
        }

        $this->merges[] = AlcrosXlsxWorkbook::columnLetter($firstCol) . $firstRow
            . ':' . AlcrosXlsxWorkbook::columnLetter($lastCol) . $lastRow;
        $this->maxRow = max($this->maxRow, $lastRow);
        $this->maxCol = max($this->maxCol, $lastCol);
    }

    public function setRowHeight(int $row, float $height): void
    {
        $this->rowHeights[$row] = $height;
    }

    public function setColumnWidth(int $col, float $width): void
    {
        $this->colWidths[$col] = $width;
    }

    public function getColumnWidth(int $col): ?float
    {
        return $this->colWidths[$col] ?? null;
    }

    /** Merge style properties onto every cell in the range. */
    public function applyStyle(int $firstCol, int $firstRow, int $lastCol, int $lastRow, array $props): void
    {
        for ($row = $firstRow; $row <= $lastRow; $row++) {
            for ($col = $firstCol; $col <= $lastCol; $col++) {
                $current = $this->cellStyles[$row][$col] ?? [];
                $this->cellStyles[$row][$col] = array_merge($current, $props);
                $this->maxRow = max($this->maxRow, $row);
                $this->maxCol = max($this->maxCol, $col);
            }
        }
    }

    /** Freeze every row above $row. */
    public function freezeAbove(int $row): void
    {
        $this->freezeRow = max(1, $row);
    }

    public function setAutoFilter(int $firstCol, int $firstRow, int $lastCol, int $lastRow): void
    {
        $this->autoFilter = AlcrosXlsxWorkbook::columnLetter($firstCol) . $firstRow
            . ':' . AlcrosXlsxWorkbook::columnLetter($lastCol) . $lastRow;
    }

    /**
     * Embed a PNG image anchored at the top-left of a cell (1-based col/row).
     *
     * @return bool False when the file is missing or not a readable PNG.
     */
    public function addImageFromFile(int $col, int $row, string $absolutePath, int $widthPx, int $heightPx): bool
    {
        $col = max(1, $col);
        $row = max(1, $row);
        $widthPx = max(1, $widthPx);
        $heightPx = max(1, $heightPx);

        if (!is_readable($absolutePath)) {
            return false;
        }

        $info = @getimagesize($absolutePath);
        if ($info === false || ($info[2] ?? 0) !== IMAGETYPE_PNG) {
            return false;
        }

        $this->images[] = [
            'path'      => $absolutePath,
            'col'       => $col,
            'row'       => $row,
            'width_px'  => $widthPx,
            'height_px' => $heightPx,
        ];
        $this->maxCol = max($this->maxCol, $col);
        $this->maxRow = max($this->maxRow, $row);

        return true;
    }

    /** @return list<array{path: string, col: int, row: int, width_px: int, height_px: int}> */
    public function getImages(): array
    {
        return $this->images;
    }

    public function hasImages(): bool
    {
        return $this->images !== [];
    }

    public function buildXml(AlcrosXlsxStyleTable $styles): string
    {
        $path = tempnam(sys_get_temp_dir(), 'alcros_xlsx_sheet_');
        if ($path === false) {
            throw new RuntimeException('Could not create a temporary worksheet file.');
        }

        try {
            $this->buildXmlToFile($path, $styles);
            $xml = file_get_contents($path);

            return $xml === false ? '' : $xml;
        } finally {
            if (is_file($path)) {
                @unlink($path);
            }
        }
    }

    public function buildXmlToFile(string $path, AlcrosXlsxStyleTable $styles): void
    {
        $handle = fopen($path, 'wb');
        if ($handle === false) {
            throw new RuntimeException('Could not write the worksheet file.');
        }

        $lastRef = AlcrosXlsxWorkbook::columnLetter(max(1, $this->maxCol)) . max(1, $this->maxRow);

        $worksheetNs = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
        $relNs = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
        $worksheetOpen = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="' . $worksheetNs . '" xmlns:r="' . $relNs . '">';

        fwrite(
            $handle,
            $worksheetOpen
            . '<dimension ref="A1:' . $lastRef . '"/>'
            . $this->buildSheetViewsXml()
            . '<sheetFormatPr defaultRowHeight="15"/>'
            . $this->buildColsXml()
            . '<sheetData>'
        );

        $rowNumbers = array_unique(array_merge(
            array_keys($this->cells),
            array_keys($this->cellStyles),
            array_keys($this->rowHeights)
        ));
        sort($rowNumbers);

        foreach ($rowNumbers as $row) {
            fwrite($handle, $this->buildRowXml((int) $row, $styles));
        }

        fwrite($handle, '</sheetData>');

        if ($this->autoFilter !== null) {
            fwrite($handle, '<autoFilter ref="' . $this->autoFilter . '"/>');
        }

        if ($this->merges !== []) {
            $merges = array_values(array_unique($this->merges));
            fwrite($handle, '<mergeCells count="' . count($merges) . '">');
            foreach ($merges as $ref) {
                fwrite($handle, '<mergeCell ref="' . $ref . '"/>');
            }
            fwrite($handle, '</mergeCells>');
        }

        if ($this->images !== []) {
            fwrite($handle, '<drawing r:id="rId1"/>');
        }

        fwrite($handle, '</worksheet>');
        fclose($handle);
    }

    private function buildSheetViewsXml(): string
    {
        $xml = '<sheetViews><sheetView workbookViewId="0">';
        if ($this->freezeRow !== null && $this->freezeRow > 1) {
            $split = $this->freezeRow - 1;
            $xml .= '<pane ySplit="' . $split . '" topLeftCell="A' . $this->freezeRow . '"'
                . ' activePane="bottomLeft" state="frozen"/>'
                . '<selection pane="bottomLeft" activeCell="A' . $this->freezeRow . '"'
                . ' sqref="A' . $this->freezeRow . '"/>';
        }

        return $xml . '</sheetView></sheetViews>';
    }

    private function buildColsXml(): string
    {
        if ($this->colWidths === []) {
            return '';
        }

        ksort($this->colWidths);
        $xml = '<cols>';
        foreach ($this->colWidths as $col => $width) {
            $xml .= '<col min="' . $col . '" max="' . $col . '"'
                . ' width="' . round($width, 2) . '" customWidth="1"/>';
        }

        return $xml . '</cols>';
    }

    private function buildRowXml(int $row, AlcrosXlsxStyleTable $styles): string
    {
        $attrs = ' r="' . $row . '"';
        if (isset($this->rowHeights[$row])) {
            $attrs .= ' ht="' . round($this->rowHeights[$row], 2) . '" customHeight="1"';
        }

        $columns = array_unique(array_merge(
            array_keys($this->cells[$row] ?? []),
            array_keys($this->cellStyles[$row] ?? [])
        ));
        sort($columns);

        if ($columns === []) {
            return '<row' . $attrs . '/>';
        }

        $xml = '<row' . $attrs . '>';
        foreach ($columns as $col) {
            $xml .= $this->buildCellXml((int) $col, $row, $styles);
        }

        return $xml . '</row>';
    }

    private function buildCellXml(int $col, int $row, AlcrosXlsxStyleTable $styles): string
    {
        $ref = AlcrosXlsxWorkbook::columnLetter($col) . $row;
        $styleId = $styles->idFor($this->cellStyles[$row][$col] ?? []);
        $attrs = ' r="' . $ref . '"';
        if ($styleId > 0) {
            $attrs .= ' s="' . $styleId . '"';
        }

        $cell = $this->cells[$row][$col] ?? null;
        if ($cell === null) {
            return '<c' . $attrs . '/>';
        }

        if ($cell['numeric']) {
            $number = is_float($cell['v']) && !is_finite($cell['v']) ? 0 : $cell['v'];

            return '<c' . $attrs . '><v>' . AlcrosXlsxWorkbook::numberText($number) . '</v></c>';
        }

        $text = (string) $cell['v'];
        if ($text === '') {
            return '<c' . $attrs . '/>';
        }

        return '<c' . $attrs . ' t="inlineStr"><is><t xml:space="preserve">'
            . AlcrosXlsxWorkbook::xmlText($text) . '</t></is></c>';
    }
}

/** Collects unique cell formats and renders them as styles.xml. */
final class AlcrosXlsxStyleTable
{
    /** @var array<string, int> */
    private array $lookup = [];

    /** @var list<array<string, mixed>> */
    private array $styles = [];

    /** @var list<string> */
    private array $fonts = [];

    /** @var list<string> */
    private array $fills = [];

    /** @var list<string> */
    private array $borders = [];

    /** @var array<string, int> */
    private array $numberFormats = [];

    public function idFor(array $props): int
    {
        $props = $this->normalize($props);
        if ($props === []) {
            return 0;
        }

        $key = md5(serialize($props));
        if (!isset($this->lookup[$key])) {
            $this->styles[] = $props;
            $this->lookup[$key] = count($this->styles); // index 0 is the default format
        }

        return $this->lookup[$key];
    }

    public function buildXml(): string
    {
        // Excel requires fill 0 = none and fill 1 = gray125 before any custom fill.
        $this->fonts = [$this->fontXml([])];
        $this->fills = [
            '<fill><patternFill patternType="none"/></fill>',
            '<fill><patternFill patternType="gray125"/></fill>',
        ];
        $this->borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'];
        $this->numberFormats = [];

        $cellXfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
        foreach ($this->styles as $props) {
            $cellXfs[] = $this->cellXfXml($props);
        }

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';

        if ($this->numberFormats !== []) {
            $xml .= '<numFmts count="' . count($this->numberFormats) . '">';
            foreach ($this->numberFormats as $code => $id) {
                $xml .= '<numFmt numFmtId="' . $id . '" formatCode="'
                    . AlcrosXlsxWorkbook::xmlText((string) $code) . '"/>';
            }
            $xml .= '</numFmts>';
        }

        $xml .= '<fonts count="' . count($this->fonts) . '">' . implode('', $this->fonts) . '</fonts>'
            . '<fills count="' . count($this->fills) . '">' . implode('', $this->fills) . '</fills>'
            . '<borders count="' . count($this->borders) . '">' . implode('', $this->borders) . '</borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="' . count($cellXfs) . '">' . implode('', $cellXfs) . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';

        return $xml;
    }

    private function normalize(array $props): array
    {
        $clean = [];

        foreach (['bold', 'italic', 'wrap'] as $flag) {
            if (!empty($props[$flag])) {
                $clean[$flag] = true;
            }
        }

        if (isset($props['size']) && (float) $props['size'] > 0) {
            $clean['size'] = (float) $props['size'];
        }

        foreach (['color', 'fill', 'border'] as $colorKey) {
            $rgb = strtoupper(trim((string) ($props[$colorKey] ?? '')));
            if (preg_match('/^[0-9A-F]{6}$/', $rgb) === 1) {
                $clean[$colorKey] = $rgb;
            }
        }

        $halign = (string) ($props['halign'] ?? '');
        if (in_array($halign, ['left', 'center', 'right'], true)) {
            $clean['halign'] = $halign;
        }

        $valign = (string) ($props['valign'] ?? '');
        if (in_array($valign, ['top', 'center', 'bottom'], true)) {
            $clean['valign'] = $valign;
        }

        $format = (string) ($props['format'] ?? '');
        if ($format !== '' && $format !== 'general') {
            $clean['format'] = $format;
        }

        ksort($clean);

        return $clean;
    }

    private function cellXfXml(array $props): string
    {
        $fontId = $this->registerFont($props);
        $fillId = $this->registerFill($props);
        $borderId = $this->registerBorder($props);
        $numFmtId = $this->registerNumberFormat($props);

        $xf = '<xf numFmtId="' . $numFmtId . '" fontId="' . $fontId . '"'
            . ' fillId="' . $fillId . '" borderId="' . $borderId . '" xfId="0"';

        if ($fontId > 0) {
            $xf .= ' applyFont="1"';
        }
        if ($fillId > 1) {
            $xf .= ' applyFill="1"';
        }
        if ($borderId > 0) {
            $xf .= ' applyBorder="1"';
        }
        if ($numFmtId > 0) {
            $xf .= ' applyNumberFormat="1"';
        }

        $alignment = '';
        if (isset($props['halign'])) {
            $alignment .= ' horizontal="' . $props['halign'] . '"';
        }
        if (isset($props['valign'])) {
            $alignment .= ' vertical="' . $props['valign'] . '"';
        }
        if (!empty($props['wrap'])) {
            $alignment .= ' wrapText="1"';
        }

        if ($alignment === '') {
            return $xf . '/>';
        }

        return $xf . ' applyAlignment="1"><alignment' . $alignment . '/></xf>';
    }

    private function registerFont(array $props): int
    {
        $xml = $this->fontXml($props);
        $existing = array_search($xml, $this->fonts, true);
        if ($existing !== false) {
            return (int) $existing;
        }

        $this->fonts[] = $xml;

        return count($this->fonts) - 1;
    }

    private function fontXml(array $props): string
    {
        $xml = '<font>';
        if (!empty($props['bold'])) {
            $xml .= '<b/>';
        }
        if (!empty($props['italic'])) {
            $xml .= '<i/>';
        }
        $xml .= '<sz val="' . ($props['size'] ?? 11) . '"/>'
            . '<color rgb="FF' . ($props['color'] ?? '000000') . '"/>'
            . '<name val="Calibri"/><family val="2"/>';

        return $xml . '</font>';
    }

    private function registerFill(array $props): int
    {
        if (!isset($props['fill'])) {
            return 0;
        }

        $xml = '<fill><patternFill patternType="solid">'
            . '<fgColor rgb="FF' . $props['fill'] . '"/><bgColor indexed="64"/>'
            . '</patternFill></fill>';

        $existing = array_search($xml, $this->fills, true);
        if ($existing !== false) {
            return (int) $existing;
        }

        $this->fills[] = $xml;

        return count($this->fills) - 1;
    }

    private function registerBorder(array $props): int
    {
        if (!isset($props['border'])) {
            return 0;
        }

        $side = '<%s style="thin"><color rgb="FF' . $props['border'] . '"/></%s>';
        $xml = '<border>'
            . sprintf($side, 'left', 'left')
            . sprintf($side, 'right', 'right')
            . sprintf($side, 'top', 'top')
            . sprintf($side, 'bottom', 'bottom')
            . '<diagonal/></border>';

        $existing = array_search($xml, $this->borders, true);
        if ($existing !== false) {
            return (int) $existing;
        }

        $this->borders[] = $xml;

        return count($this->borders) - 1;
    }

    private function registerNumberFormat(array $props): int
    {
        $code = match ($props['format'] ?? 'general') {
            'text'     => '@',
            'number'   => '0',
            'date'     => 'yyyy-mm-dd',
            'datetime' => 'yyyy-mm-dd hh:mm',
            default    => '',
        };

        if ($code === '') {
            return 0;
        }

        if (!isset($this->numberFormats[$code])) {
            // Custom number format ids must start at 164.
            $this->numberFormats[$code] = 164 + count($this->numberFormats);
        }

        return $this->numberFormats[$code];
    }
}

final class AlcrosXlsxWorkbook
{
    /** @var list<AlcrosXlsxSheet> */
    private array $sheets = [];

    private int $activeSheet = 0;
    private string $title = 'ALCROS Export';
    private string $creator = 'ALCROS';

    public function __construct(string $title = 'ALCROS Export')
    {
        $this->title = $title;
        $this->sheets[] = new AlcrosXlsxSheet('Sheet1');
    }

    public function setProperties(string $title, string $creator = 'ALCROS'): self
    {
        $this->title = $title;
        $this->creator = $creator;

        return $this;
    }

    public function getActiveSheet(): AlcrosXlsxSheet
    {
        return $this->sheets[$this->activeSheet] ?? $this->sheets[0];
    }

    public static function columnLetter(int $index): string
    {
        $index = max(1, $index);
        $letters = '';
        while ($index > 0) {
            $remainder = ($index - 1) % 26;
            $letters = chr(65 + $remainder) . $letters;
            $index = intdiv($index - 1, 26);
        }

        return $letters;
    }

    public static function xmlText(string $value): string
    {
        if (!mb_check_encoding($value, 'UTF-8')) {
            $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }
        // Strip control characters that are illegal in XML 1.0.
        $value = preg_replace('/[\x{0}-\x{8}\x{B}\x{C}\x{E}-\x{1F}]/u', '', $value) ?? $value;

        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    public static function numberText(int|float $value): string
    {
        if (is_int($value)) {
            return (string) $value;
        }

        return rtrim(rtrim(sprintf('%.10F', $value), '0'), '.') ?: '0';
    }

    public function writeToFile(string $path): void
    {
        $this->ensureUniqueSheetNames();

        if (!class_exists('ZipArchive')) {
            $this->writeToFileWithPacker($path);

            return;
        }

        $styles = new AlcrosXlsxStyleTable();
        $sheetPaths = [];
        $tempFiles = [];
        $drawingBundle = $this->buildDrawingBundle();

        try {
            foreach ($this->sheets as $index => $sheet) {
                $sheetPath = tempnam(sys_get_temp_dir(), 'alcros_xlsx_sheet_');
                if ($sheetPath === false) {
                    throw new RuntimeException('Could not create a temporary worksheet file.');
                }
                $tempFiles[] = $sheetPath;
                $sheet->buildXmlToFile($sheetPath, $styles);
                $sheetPaths[$index] = $sheetPath;
            }

            $stylesPath = tempnam(sys_get_temp_dir(), 'alcros_xlsx_styles_');
            if ($stylesPath === false) {
                throw new RuntimeException('Could not create a temporary styles file.');
            }
            $tempFiles[] = $stylesPath;
            file_put_contents($stylesPath, $styles->buildXml());

            $zip = new ZipArchive();
            if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                throw new RuntimeException('Could not create the Excel archive.');
            }

            $zip->addFromString('[Content_Types].xml', $this->contentTypesXml($drawingBundle));
            $zip->addFromString('_rels/.rels', $this->rootRelsXml());
            $zip->addFromString('docProps/core.xml', $this->corePropsXml());
            $zip->addFromString('docProps/app.xml', $this->appPropsXml());
            $zip->addFromString('xl/workbook.xml', $this->workbookXml());
            $zip->addFromString('xl/_rels/workbook.xml.rels', $this->workbookRelsXml());
            $zip->addFile($stylesPath, 'xl/styles.xml');

            foreach ($sheetPaths as $index => $sheetPath) {
                $zip->addFile($sheetPath, 'xl/worksheets/sheet' . ($index + 1) . '.xml');
                if (isset($drawingBundle['sheet_rels'][$index])) {
                    $zip->addFromString(
                        'xl/worksheets/_rels/sheet' . ($index + 1) . '.xml.rels',
                        $drawingBundle['sheet_rels'][$index]
                    );
                }
            }

            foreach ($drawingBundle['drawings'] as $drawingPath => $drawingXml) {
                $zip->addFromString($drawingPath, $drawingXml);
            }
            foreach ($drawingBundle['drawing_rels'] as $drawingRelPath => $drawingRelXml) {
                $zip->addFromString($drawingRelPath, $drawingRelXml);
            }
            foreach ($drawingBundle['media'] as $mediaPath => $mediaBinary) {
                $zip->addFromString($mediaPath, $mediaBinary);
            }

            $zip->close();
        } finally {
            foreach ($tempFiles as $tempFile) {
                if (is_file($tempFile)) {
                    @unlink($tempFile);
                }
            }
        }
    }

    /** @param array<string, string> $parts */
    private function writeToFileWithPacker(string $path): void
    {
        $styles = new AlcrosXlsxStyleTable();
        $drawingBundle = $this->buildDrawingBundle();
        $parts = [
            '[Content_Types].xml'        => $this->contentTypesXml($drawingBundle),
            '_rels/.rels'                => $this->rootRelsXml(),
            'docProps/core.xml'          => $this->corePropsXml(),
            'docProps/app.xml'           => $this->appPropsXml(),
            'xl/workbook.xml'            => $this->workbookXml(),
            'xl/_rels/workbook.xml.rels' => $this->workbookRelsXml(),
            'xl/styles.xml'              => $styles->buildXml(),
        ];

        foreach ($this->sheets as $index => $sheet) {
            $parts['xl/worksheets/sheet' . ($index + 1) . '.xml'] = $sheet->buildXml($styles);
            if (isset($drawingBundle['sheet_rels'][$index])) {
                $parts['xl/worksheets/_rels/sheet' . ($index + 1) . '.xml.rels']
                    = $drawingBundle['sheet_rels'][$index];
            }
        }

        foreach ($drawingBundle['drawings'] as $drawingPath => $drawingXml) {
            $parts[$drawingPath] = $drawingXml;
        }
        foreach ($drawingBundle['drawing_rels'] as $drawingRelPath => $drawingRelXml) {
            $parts[$drawingRelPath] = $drawingRelXml;
        }
        foreach ($drawingBundle['media'] as $mediaPath => $mediaBinary) {
            $parts[$mediaPath] = $mediaBinary;
        }

        file_put_contents($path, $this->zipParts($parts));
    }

    private function ensureUniqueSheetNames(): void
    {
        $seen = [];
        foreach ($this->sheets as $sheet) {
            $name = $sheet->getTitle();
            $key = mb_strtolower($name, 'UTF-8');
            if (!isset($seen[$key])) {
                $seen[$key] = 1;
                continue;
            }

            $seen[$key]++;
            $suffix = ' (' . $seen[$key] . ')';
            $sheet->setTitle(mb_substr($name, 0, 31 - mb_strlen($suffix, 'UTF-8'), 'UTF-8') . $suffix);
        }
    }

    /** @param array<string, string> $parts */
    private function zipParts(array $parts): string
    {
        if (class_exists('ZipArchive')) {
            return self::zipPartsWithZipArchive($parts);
        }

        return AlcrosZipPacker::pack($parts);
    }

    /** @param array<string, string> $parts */
    private static function zipPartsWithZipArchive(array $parts): string
    {
        $tempFile = tempnam(sys_get_temp_dir(), 'alcros_xlsx_');
        if ($tempFile === false) {
            throw new RuntimeException('Could not create a temporary file for the Excel export.');
        }

        try {
            $zip = new ZipArchive();
            if ($zip->open($tempFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                throw new RuntimeException('Could not create the Excel archive.');
            }

            foreach ($parts as $name => $contents) {
                $zip->addFromString($name, $contents);
            }
            $zip->close();

            $binary = file_get_contents($tempFile);
            if ($binary === false) {
                throw new RuntimeException('Could not read the generated Excel file.');
            }

            return $binary;
        } finally {
            if (is_file($tempFile)) {
                @unlink($tempFile);
            }
        }
    }

    /**
     * @param array{drawings: array<string, string>, drawing_rels: array<string, string>, media: array<string, string>, sheet_rels: array<int, string>} $drawingBundle
     */
    private function contentTypesXml(array $drawingBundle): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>';

        if ($drawingBundle['media'] !== []) {
            $xml .= '<Default Extension="png" ContentType="image/png"/>';
        }

        $xml .= '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';

        foreach (array_keys($this->sheets) as $index) {
            $xml .= '<Override PartName="/xl/worksheets/sheet' . ($index + 1) . '.xml"'
                . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }

        foreach (array_keys($drawingBundle['drawings']) as $drawingPath) {
            $xml .= '<Override PartName="/' . $drawingPath . '"'
                . ' ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>';
        }

        return $xml
            . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            . '</Types>';
    }

    /**
     * @return array{
     *   drawings: array<string, string>,
     *   drawing_rels: array<string, string>,
     *   media: array<string, string>,
     *   sheet_rels: array<int, string>
     * }
     */
    private function buildDrawingBundle(): array
    {
        $bundle = [
            'drawings'     => [],
            'drawing_rels' => [],
            'media'        => [],
            'sheet_rels'   => [],
        ];

        $mediaPathBySource = [];
        $mediaCounter = 0;

        foreach ($this->sheets as $sheetIndex => $sheet) {
            if (!$sheet->hasImages()) {
                continue;
            }

            $drawingNumber = $sheetIndex + 1;
            $drawingPart = 'xl/drawings/drawing' . $drawingNumber . '.xml';
            $drawingRelPart = 'xl/drawings/_rels/drawing' . $drawingNumber . '.xml.rels';

            $imageRels = [];
            $anchorsXml = '';
            $picId = 1;

            foreach ($sheet->getImages() as $image) {
                $source = $image['path'];
                if (!isset($mediaPathBySource[$source])) {
                    $binary = file_get_contents($source);
                    if ($binary === false) {
                        continue;
                    }
                    $mediaCounter++;
                    $mediaPart = 'xl/media/image' . $mediaCounter . '.png';
                    $mediaPathBySource[$source] = $mediaPart;
                    $bundle['media'][$mediaPart] = $binary;
                }

                $mediaPart = $mediaPathBySource[$source] ?? null;
                if ($mediaPart === null) {
                    continue;
                }

                $relId = 'rId' . count($imageRels) + 1;
                $imageRels[] = [
                    'id'     => $relId,
                    'target' => '../media/' . basename($mediaPart),
                ];

                $anchorsXml .= $this->buildOneCellAnchorXml(
                    $image['col'],
                    $image['row'],
                    $image['width_px'],
                    $image['height_px'],
                    $relId,
                    $picId
                );
                $picId++;
            }

            if ($anchorsXml === '') {
                continue;
            }

            $bundle['drawings'][$drawingPart] = $this->buildDrawingXml($anchorsXml);
            $bundle['drawing_rels'][$drawingRelPart] = $this->buildDrawingRelsXml($imageRels);
            $bundle['sheet_rels'][$sheetIndex] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                . '<Relationship Id="rId1"'
                . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"'
                . ' Target="../drawings/drawing' . $drawingNumber . '.xml"/>'
                . '</Relationships>';
        }

        return $bundle;
    }

    private function buildDrawingXml(string $anchorsXml): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"'
            . ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
            . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . $anchorsXml
            . '</xdr:wsDr>';
    }

    /** @param list<array{id: string, target: string}> $rels */
    private function buildDrawingRelsXml(array $rels): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';

        foreach ($rels as $rel) {
            $xml .= '<Relationship Id="' . self::xmlText($rel['id']) . '"'
                . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"'
                . ' Target="' . self::xmlText($rel['target']) . '"/>';
        }

        return $xml . '</Relationships>';
    }

    private function buildOneCellAnchorXml(
        int $col,
        int $row,
        int $widthPx,
        int $heightPx,
        string $embedRelId,
        int $picId
    ): string {
        $colIndex = max(0, $col - 1);
        $rowIndex = max(0, $row - 1);
        $cx = $widthPx * 9525;
        $cy = $heightPx * 9525;
        $name = 'ALCROS Logo ' . $picId;

        return '<xdr:oneCellAnchor>'
            . '<xdr:from>'
            . '<xdr:col>' . $colIndex . '</xdr:col><xdr:colOff>0</xdr:colOff>'
            . '<xdr:row>' . $rowIndex . '</xdr:row><xdr:rowOff>0</xdr:rowOff>'
            . '</xdr:from>'
            . '<xdr:ext cx="' . $cx . '" cy="' . $cy . '"/>'
            . '<xdr:pic>'
            . '<xdr:nvPicPr>'
            . '<xdr:cNvPr id="' . $picId . '" name="' . self::xmlText($name) . '"/>'
            . '<xdr:cNvPicPr/>'
            . '</xdr:nvPicPr>'
            . '<xdr:blipFill>'
            . '<a:blip r:embed="' . self::xmlText($embedRelId) . '"/>'
            . '<a:stretch><a:fillRect/></a:stretch>'
            . '</xdr:blipFill>'
            . '<xdr:spPr>'
            . '<a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm>'
            . '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
            . '</xdr:spPr>'
            . '</xdr:pic>'
            . '<xdr:clientData/>'
            . '</xdr:oneCellAnchor>';
    }

    private function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            . '</Relationships>';
    }

    private function corePropsXml(): string
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $title = self::xmlText($this->title);
        $creator = self::xmlText($this->creator);

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<cp:coreProperties'
            . ' xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
            . ' xmlns:dc="http://purl.org/dc/elements/1.1/"'
            . ' xmlns:dcterms="http://purl.org/dc/terms/"'
            . ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:title>' . $title . '</dc:title>'
            . '<dc:subject>' . $title . '</dc:subject>'
            . '<dc:creator>' . $creator . '</dc:creator>'
            . '<cp:lastModifiedBy>' . $creator . '</cp:lastModifiedBy>'
            . '<dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created>'
            . '<dcterms:modified xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:modified>'
            . '</cp:coreProperties>';
    }

    private function appPropsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"'
            . ' xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
            . '<Application>ALCROS</Application>'
            . '</Properties>';
    }

    private function workbookXml(): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
            . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<bookViews><workbookView activeTab="' . $this->activeSheet . '"/></bookViews>'
            . '<sheets>';

        foreach ($this->sheets as $index => $sheet) {
            $xml .= '<sheet name="' . self::xmlText($sheet->getTitle()) . '"'
                . ' sheetId="' . ($index + 1) . '" r:id="rId' . ($index + 1) . '"/>';
        }

        return $xml . '</sheets></workbook>';
    }

    private function workbookRelsXml(): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';

        foreach (array_keys($this->sheets) as $index) {
            $xml .= '<Relationship Id="rId' . ($index + 1) . '"'
                . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"'
                . ' Target="worksheets/sheet' . ($index + 1) . '.xml"/>';
        }

        return $xml . '<Relationship Id="rId' . (count($this->sheets) + 1) . '"'
            . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"'
            . ' Target="styles.xml"/>'
            . '</Relationships>';
    }
}

/**
 * Minimal ZIP writer for in-memory XLSX parts (no ZipArchive required).
 *
 * @internal
 */
final class AlcrosZipPacker
{
    /** @param array<string, string> $parts path => raw file contents */
    public static function pack(array $parts): string
    {
        if ($parts === []) {
            throw new RuntimeException('Cannot create an empty Excel archive.');
        }

        $local = '';
        $central = '';
        $offset = 0;
        $count = 0;
        [$dosTime, $dosDate] = self::dosDateTime();

        foreach ($parts as $name => $contents) {
            if (!is_string($name) || $name === '' || str_contains($name, '\\')) {
                throw new RuntimeException('Invalid archive entry name.');
            }
            if (!is_string($contents)) {
                throw new RuntimeException('Invalid archive entry contents.');
            }

            $nameBytes = $name;
            $flags = 0x0800; // UTF-8 file names
            $crc = crc32($contents) & 0xFFFFFFFF;
            $size = strlen($contents);

            $compressed = gzdeflate($contents, 6);
            if ($compressed === false || strlen($compressed) >= $size) {
                $method = 0;
                $payload = $contents;
            } else {
                $method = 8;
                $payload = $compressed;
            }

            $payloadSize = strlen($payload);

            $localHeader = pack(
                'VvvvvvVVVvv',
                0x04034b50,
                20,
                $flags,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $payloadSize,
                $size,
                strlen($nameBytes),
                0
            ) . $nameBytes;

            $local .= $localHeader . $payload;

            $central .= pack(
                'VvvvvvvVVVvvvvvVV',
                0x02014b50,
                20,
                20,
                $flags,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $payloadSize,
                $size,
                strlen($nameBytes),
                0,
                0,
                0,
                0,
                0,
                $offset
            ) . $nameBytes;

            $offset += strlen($localHeader) + $payloadSize;
            $count++;
        }

        $centralSize = strlen($central);

        return $local . $central . pack(
            'VvvvvVVv',
            0x06054b50,
            0,
            0,
            $count,
            $count,
            $centralSize,
            $offset,
            0
        );
    }

    /** @return array{0: int, 1: int} DOS time and date for the current moment. */
    private static function dosDateTime(): array
    {
        $parts = getdate();
        $time = (($parts['hours'] & 0x1F) << 11)
            | (($parts['minutes'] & 0x3F) << 5)
            | ((intdiv($parts['seconds'], 2)) & 0x1F);
        $year = max(1980, min(2107, $parts['year']));
        $date = ((($year - 1980) & 0x7F) << 9)
            | (($parts['mon'] & 0x0F) << 5)
            | ($parts['mday'] & 0x1F);

        return [$time, $date];
    }
}
