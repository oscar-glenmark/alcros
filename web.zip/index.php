<?php
/**
 * ALCROS - Local Civil Registry of Aloran
 * Landing page (index.php)
 */
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';

$site = getSiteSettings();
$homeAnnouncement = getHomeLatestAnnouncement();
try {
    runReminderSchedulerIfDue(getDB());
} catch (Throwable $e) {
    // Non-fatal when MySQL is unavailable.
}
$maintenanceMode = isMaintenanceMode();
$publicRequestsAllowed = arePublicRequestsAllowed();

// Staff login in header on desktop; mobile uses More menu / footer - never auto-route to the staff dashboard.
$staffPortalUrl   = 'login.php';
$staffPortalLabel = 'Staff Login';
$currentPage = basename($_SERVER['PHP_SELF']);
$documentTypes = getDocumentTypes();
$year = date('Y');

$serviceCards = [
    ['slug' => 'birth', 'label' => 'Birth Certificate', 'desc' => 'Request an official copy of a birth certificate.', 'icon' => 'users', 'color' => 'bg-blue-600', 'link' => 'request.php?type=birth'],
    ['slug' => 'death', 'label' => 'Death Certificate', 'desc' => 'Request an official copy of a death certificate.', 'icon' => 'activity', 'color' => 'bg-emerald-600', 'link' => 'request.php?type=death'],
    ['slug' => 'marriage', 'label' => 'Marriage Certificate', 'desc' => 'Request an official copy of a marriage certificate.', 'icon' => 'heart', 'color' => 'bg-amber-500', 'link' => 'request.php?type=marriage'],
    ['slug' => 'other', 'label' => 'Other Services', 'desc' => 'CENOMAR, corrections, appointments, and more.', 'icon' => 'file-text', 'color' => 'bg-orange-600', 'link' => 'services.php'],
];

$howSteps = [
    ['num' => '01', 'icon' => 'clipboard-list', 'title' => 'Request Online', 'desc' => 'Choose the certificate type and fill out the online request form.'],
    ['num' => '02', 'icon' => 'upload', 'title' => 'Submit Details', 'desc' => 'Provide your information and upload the required supporting documents.'],
    ['num' => '03', 'icon' => 'shield-check', 'title' => 'Office Processing', 'desc' => 'Our staff verifies your request and prepares your certificate.'],
    ['num' => '04', 'icon' => 'package', 'title' => 'Track & Claim', 'desc' => 'Monitor your request status online and claim once ready.'],
];

$whyItems = [
    ['icon' => 'shield-check', 'title' => 'Secure & Reliable', 'desc' => 'Official LCRO records handled with care and compliance.'],
    ['icon' => 'smartphone', 'title' => 'Accessible', 'desc' => 'Use ALCROS from any device with an internet connection.'],
    ['icon' => 'search', 'title' => 'Easy to Track', 'desc' => 'Check your request status anytime with your tracking code.'],
];

$faqs = [
    ['q' => 'How do I request a certificate?', 'a' => 'Click Request a Certificate, choose your document type, complete the online form, and upload the required documents. You will receive a tracking code by email.'],
    ['q' => 'How long does processing take?', 'a' => 'Processing time varies by document type and completeness of requirements. Track your request online for real-time status updates from our office.'],
    ['q' => 'Where do I claim my certificate?', 'a' => 'Once your request status shows Ready, visit the Local Civil Registrar Office at the Municipal Hall during office hours with a valid ID.'],
    ['q' => 'What documents do I need?', 'a' => 'Requirements depend on the certificate type. The request form will guide you on valid IDs and supporting documents to upload.'],
    ['q' => 'Can I track my request online?', 'a' => 'Yes. Use the Track My Request section with your reference number (e.g. ALR-XXXXXXXX) to view current status.'],
    ['q' => 'Is my personal information secure?', 'a' => 'ALCROS follows the Data Privacy Act (RA 10173). Your information is used only for civil registry services and is not shared without authorization.'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>
    <?= alcrosCitizenHeadMeta() ?>
    <title>ALCROS -Aloran Local Civil Registry Online System</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= vendorScriptTag('lucide.min.js') ?>
    <?= publicStylesheet('landing') ?>
</head>
<body class="bg-white citizen-portal">

    <!-- HEADER -->
    <header class="site-header sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between gap-4 py-3">
                <a href="index.php" class="flex items-center gap-3 min-w-0">
                    <?= alcrosFaviconImg(48, 'brand-logo shrink-0') ?>
                    <div class="site-brand-text">
                        <div class="site-brand-title">ALCROSsssssss</div>
                        <div class="site-brand-subtitle">Aloran Local Civil Registry Online System</div>
                    </div>
                </a>

                <nav class="hidden lg:flex items-center gap-1 xl:gap-2">
                    <a href="index.php" class="nav-link" data-nav-section="home">Home</a>
                    <a href="#services" class="nav-link" data-nav-section="services">Services</a>
                    <button type="button" data-open-track class="nav-link cursor-pointer bg-transparent border-0 border-b-2 border-transparent">Track Request</button>
                    <a href="#about" class="nav-link" data-nav-section="about">About</a>
                    <a href="#faqs" class="nav-link" data-nav-section="faqs">FAQs </a>
                    <a href="#contact" class="nav-link" data-nav-section="contact">Contact Us</a>
                </nav>

                <div class="flex items-center gap-2 shrink-0">
                    <a href="<?= htmlspecialchars($staffPortalUrl) ?>" class="btn-login hidden lg:inline-block shrink-0">
                        <?= htmlspecialchars($staffPortalLabel) ?>
                    </a>
                    <button type="button" id="mobileNavToggle" class="lg:hidden p-2 text-white" aria-label="Open menu">
                        <i data-lucide="menu" class="w-6 h-6"></i>
                    </button>
                </div>
            </div>

            <div id="mobileNav" class="hidden lg:hidden pb-4 border-t border-white/10 pt-3">
                <div class="flex flex-col gap-1">
                    <a href="index.php" class="nav-link" data-nav-section="home">Home</a>
                    <a href="#services" class="nav-link" data-nav-section="services">Services</a>
                    <button type="button" data-open-track class="nav-link text-left cursor-pointer bg-transparent border-0">Track Request</button>
                    <a href="#about" class="nav-link" data-nav-section="about">About</a>
                    <a href="#faqs" class="nav-link" data-nav-section="faqs">FAQs</a>
                    <a href="#contact" class="nav-link" data-nav-section="contact">Contact Us</a>
                </div>
            </div>
        </div>
    </header>

    <!-- HERO -->
    <section id="home" class="hero-section flex items-center scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16 lg:py-20">
            <div class="grid lg:grid-cols-2 gap-10 items-center">
                <div class="relative z-10 max-w-xl">
                    <h1 class="text-white text-2xl sm:text-3xl md:text-4xl lg:text-[2.65rem] font-black leading-tight tracking-tight uppercase mb-2">Aloran Local Civil Registry</h1>
                    <p class="text-gold text-4xl md:text-5xl lg:text-6xl font-black tracking-tight mb-4">ALCROS</p>
                    <p class="text-white text-lg md:text-xl font-semibold mb-3">Access Civil Registry Services Easily and Securely Online</p>
                    <p class="text-white/75 text-sm md:text-base leading-relaxed mb-8 max-w-lg">
                    <div class="flex flex-col sm:flex-row gap-3">
                        <?php if ($publicRequestsAllowed && !$maintenanceMode): ?>
                        <a href="request.php?entry=hero" class="btn-gold inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-sm">
                            Request a Certificate
                        </a>
                        <?php else: ?>
                        <span class="inline-flex items-center justify-center px-6 py-3.5 rounded-sm bg-slate-600 text-white/80 text-sm font-bold uppercase cursor-not-allowed">Requests Unavailable</span>
                        <?php endif; ?>
                        <button type="button" data-open-track class="btn-outline-light inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-sm">
                            <i data-lucide="search" class="w-4 h-4"></i> Track My Request
                        </button>
                    </div>
                </div>
                <div class="hidden lg:flex justify-end items-center relative">
                    <?= alcrosFaviconImg(320, 'hero-seal rounded-full') ?>
                </div>
            </div>
        </div>
    </section>

    <!-- OUR SERVICES -->
    <section id="services" class="py-16 md:py-20 bg-slate-50 scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-2xl md:text-3xl font-black text-slate-900 uppercase tracking-wide">Our Services</h2>
                <p class="text-slate-500 text-sm mt-2 max-w-xl mx-auto">Select a service below to start your online request.</p>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php foreach ($serviceCards as $card):
                    $isOtherServices = ($card['slug'] ?? '') === 'other';
                ?>
                <a href="<?= htmlspecialchars($card['link']) ?>" class="service-card bg-white rounded-lg p-6 flex flex-col text-center<?= $isOtherServices ? ' service-card--highlight' : '' ?>">
                    <?php if ($isOtherServices): ?>
                    <span class="service-card__badge">CENOMAR · Appointments · More</span>
                    <?php endif; ?>
                    <div class="w-16 h-16 rounded-full <?= htmlspecialchars($card['color']) ?> text-white flex items-center justify-center mx-auto mb-5 shadow-md<?= $isOtherServices ? ' service-card__icon--highlight' : '' ?>">
                        <i data-lucide="<?= htmlspecialchars($card['icon']) ?>" class="w-7 h-7"></i>
                    </div>
                    <h3 class="font-bold text-slate-900 text-sm uppercase tracking-wide mb-2"><?= htmlspecialchars($card['label']) ?></h3>
                    <p class="text-slate-500 text-xs leading-relaxed mb-5 flex-1"><?= htmlspecialchars($card['desc']) ?></p>
                    <span class="text-[11px] font-bold uppercase tracking-wide inline-flex items-center justify-center gap-1<?= $isOtherServices ? ' service-card__cta service-card__cta--highlight' : ' text-slate-800' ?>">
                        <?= $isOtherServices ? 'View All Services' : 'Request Now' ?> <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                    </span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- HOW IT WORKSssss -->
    <section id="how-it-works" class="py-16 md:py-20 bg-white scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-14">
                <h2 class="text-2xl md:text-3xl font-black text-slate-900 uppercase tracking-wide">How It Works</h2>
            </div>
            <div class="relative">
                <div class="steps-line absolute hidden md:block"></div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 relative">
                    <?php foreach ($howSteps as $step): ?>
                    <div class="text-center">
                        <div class="relative inline-flex flex-col items-center">
                            <div class="w-16 h-16 rounded-full bg-[#071428] text-white flex items-center justify-center mb-4 shadow-lg relative z-10">
                                <i data-lucide="<?= htmlspecialchars($step['icon']) ?>" class="w-7 h-7"></i>
                            </div>
                            <span class="text-[10px] font-black text-slate-400 tracking-widest mb-1"><?= htmlspecialchars($step['num']) ?></span>
                        </div>
                        <h3 class="font-bold text-slate-900 text-sm mb-2"><?= htmlspecialchars($step['title']) ?></h3>
                        <p class="text-slate-500 text-xs leading-relaxed max-w-[220px] mx-auto"><?= htmlspecialchars($step['desc']) ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- TRACK BANNER -->
    <section class="track-banner-section px-4 sm:px-6 lg:px-8">
        <div class="track-banner py-6 md:py-7 max-w-4xl mx-auto">
            <div class="track-banner-inner px-4 sm:px-5">
                <div class="flex items-center gap-2 sm:gap-2.5 shrink-0">
                    <div class="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white/10 flex items-center justify-center text-gold">
                        <i data-lucide="search" class="w-5 h-5 sm:w-6 sm:h-6"></i>
                    </div>
                    <h2 class="text-white font-black text-sm sm:text-base md:text-lg uppercase tracking-wider whitespace-nowrap">Track Your Request</h2>
                </div>
                <form id="home-track-form" class="flex flex-col sm:flex-row gap-2 flex-1 min-w-0">
                    <input type="text" id="home-track-input" placeholder="Enter tracking code (e.g. ALR-ABC12345)"
                        class="flex-1 min-w-0 rounded-sm border-0 px-3 py-2.5 sm:py-3 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 uppercase">
                    <button type="submit" class="btn-gold px-6 sm:px-7 py-2.5 sm:py-3 rounded-sm shrink-0">Track</button>
                </form>
            </div>
        </div>
    </section>

    <!-- WHY CHOOSE -->
    <section class="py-16 md:py-20 bg-slate-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-2xl md:text-3xl font-black text-slate-900 uppercase tracking-wide">Why Choose ALCROS?</h2>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
                <?php foreach ($whyItems as $item): ?>
                <div class="text-center">
                    <div class="w-14 h-14 rounded-full bg-[#071428] text-gold flex items-center justify-center mx-auto mb-4">
                        <i data-lucide="<?= htmlspecialchars($item['icon']) ?>" class="w-6 h-6"></i>
                    </div>
                    <h3 class="font-bold text-slate-900 text-sm mb-2"><?= htmlspecialchars($item['title']) ?></h3>
                    <p class="text-slate-500 text-xs leading-relaxed"><?= htmlspecialchars($item['desc']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ANNOUNCEMENTS + ABOUT -->
    <section id="about" class="py-16 md:py-20 bg-white scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-2 gap-8">
                <div class="border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                    <div class="bg-[#071428] text-white px-5 py-3 font-bold text-sm uppercase tracking-wider">Latest Announcements</div>
                    <div class="p-5">
                        <article class="border-l-4 border-amber-400 pl-4">
                            <time class="text-[11px] font-bold text-slate-400 uppercase"><?= htmlspecialchars($homeAnnouncement['date']) ?></time>
                            <h3 class="font-bold text-slate-900 text-sm mt-1 mb-2"><?= htmlspecialchars($homeAnnouncement['title']) ?></h3>
                            <p class="text-slate-600 text-xs leading-relaxed"><?= htmlspecialchars($homeAnnouncement['body']) ?></p>
                        </article>
                    </div>
                </div>
                <div class="border border-slate-200 rounded-lg overflow-hidden shadow-sm flex flex-col">
                    <div class="bg-[#071428] text-white px-5 py-3 font-bold text-sm uppercase tracking-wider">About ALCROSsss</div>
                    <div class="p-5 flex flex-col sm:flex-row gap-5 flex-1">
                        <img src="images/municipal-hall.jpg" alt="Aloran Municipal Hall" class="w-full sm:w-36 h-28 object-cover rounded-md shrink-0">
                        <div>
                            <p class="text-slate-600 text-xs leading-relaxed mb-3">
                                <strong class="text-slate-900">ALCROS</strong> (Aloran Local Civil Registry Online System) is the official digital portal of the <?= htmlspecialchars($site['office']) ?>.
                                It allows citizens to request civil registry documents and track applications online.
                            </p>
                            <p class="text-slate-500 text-xs leading-relaxed">
                                <?= htmlspecialchars($site['address']) ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section id="faqs" class="py-16 md:py-20 bg-slate-50 scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-2xl md:text-3xl font-black text-slate-900 uppercase tracking-wide">Frequently Asked Questions</h2>
            </div>
            <div class="grid md:grid-cols-2 gap-4 max-w-5xl mx-auto">
                <?php foreach ($faqs as $faq): ?>
                <details class="faq-item bg-white border border-slate-200 rounded-lg px-4 py-3 group">
                    <summary class="flex items-center justify-between gap-3 cursor-pointer py-2 font-semibold text-sm text-slate-800">
                        <span><?= htmlspecialchars($faq['q']) ?></span>
                        <i data-lucide="chevron-down" class="faq-chevron w-4 h-4 text-slate-400 shrink-0 transition-transform"></i>
                    </summary>
                    <p class="text-slate-500 text-xs leading-relaxed pb-3 pr-6"><?= htmlspecialchars($faq['a']) ?></p>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer id="contact" class="footer-dark scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
                <div>
                    <div class="flex items-center gap-3 mb-4">
                        <?= alcrosFaviconImg(44, 'brand-logo shrink-0') ?>
                        <div>
                            <div class="text-white font-extrabold text-base">ALCROS</div>
                            <div class="text-white/60 text-[10px] italic">Aloran Local Civil Registry Online System</div>
                        </div>
                    </div>
                    <p class="text-xs leading-relaxed text-white/60">Municipality of Aloran, Misamis Occidental, Philippines</p>
                </div>
                <div>
                    <h4 class="text-white font-bold text-xs uppercase tracking-wider mb-4">Quick Links</h4>
                    <ul class="space-y-2 text-xs">
                        <li><a href="index.php" class="hover:text-gold transition">Home</a></li>
                        <li><a href="#services" class="hover:text-gold transition">Services</a></li>
                        <li><button type="button" data-open-track class="hover:text-gold transition bg-transparent border-0 p-0 cursor-pointer text-left text-white/75">Track Request</button></li>
                        <li><a href="services.php" class="hover:text-gold transition">All Services</a></li>
                        <li><a href="<?= htmlspecialchars($staffPortalUrl) ?>" class="hover:text-gold transition"><?= htmlspecialchars($staffPortalLabel) ?></a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-bold text-xs uppercase tracking-wider mb-4">Contact Us Now</h4>
                    <ul class="space-y-3 text-xs">
                        <li class="flex items-start gap-2">
                            <i data-lucide="map-pin" class="w-4 h-4 text-gold shrink-0 mt-0.5"></i>
                            <span><?= htmlspecialchars($site['address']) ?></span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i data-lucide="phone" class="w-4 h-4 text-gold shrink-0"></i>
                            <a href="tel:<?= htmlspecialchars($site['phone']) ?>" class="hover:text-gold transition"><?= htmlspecialchars($site['phone']) ?></a>
                        </li>
                        <li class="flex items-center gap-2">
                            <i data-lucide="mail" class="w-4 h-4 text-gold shrink-0"></i>
                            <a href="mailto:<?= htmlspecialchars($site['email']) ?>" class="hover:text-gold transition break-all"><?= htmlspecialchars($site['email']) ?></a>
                        </li>
                        <?php if (trim((string) ($site['head'] ?? '')) !== ''): ?>
                        <li class="flex items-start gap-2 pt-1">
                            <i data-lucide="user-check" class="w-4 h-4 text-gold shrink-0 mt-0.5"></i>
                            <span>
                                <span class="block text-[10px] font-bold uppercase tracking-wide text-white/40 mb-0.5">Office Head / Signatory</span>
                                <?= htmlspecialchars($site['head']) ?>
                            </span>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-bold text-xs uppercase tracking-wider mb-4">Follow Us</h4>
                    <div class="flex gap-3 items-center">
                        <?php
                        $facebookUrl = trim((string) ($site['facebook_url'] ?? ''));
                        $instagramUrl = trim((string) ($site['instagram_url'] ?? ''));
                        ?>
                        <?php if ($facebookUrl !== ''): ?>
                        <a href="<?= htmlspecialchars($facebookUrl) ?>" target="_blank" rel="noopener noreferrer" class="footer-social-link footer-facebook-link" aria-label="Facebook">
                            <svg class="footer-social-link__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <circle class="footer-facebook-link__bg" cx="12" cy="12" r="12"/>
                                <path class="footer-facebook-link__f" d="M13.397 20.997v-8.196h2.765l.411-3.209h-3.176V7.548c0-.926.258-1.56 1.587-1.56h1.684V3.127A22.336 22.336 0 0 0 14.201 3c-2.444 0-4.122 1.492-4.122 4.203v2.343H7.62v3.209h2.459v8.197h3.318z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($instagramUrl !== ''): ?>
                        <a href="<?= htmlspecialchars($instagramUrl) ?>" target="_blank" rel="noopener noreferrer" class="footer-social-link footer-instagram-link" aria-label="Instagram">
                            <svg class="footer-social-link__icon footer-instagram-link__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <defs>
                                    <linearGradient id="footerInstagramGradient" gradientUnits="userSpaceOnUse" x1="0" y1="24" x2="24" y2="0">
                                        <stop offset="0%" stop-color="#feda75"/>
                                        <stop offset="15%" stop-color="#fa7e1e"/>
                                        <stop offset="40%" stop-color="#d62976"/>
                                        <stop offset="70%" stop-color="#962fbf"/>
                                        <stop offset="100%" stop-color="#4f5bd5"/>
                                    </linearGradient>
                                </defs>
                                <rect class="footer-instagram-link__bg" width="24" height="24" rx="6.5"/>
                                <rect class="footer-instagram-link__frame" x="5.25" y="5.25" width="13.5" height="13.5" rx="4"/>
                                <circle class="footer-instagram-link__lens" cx="12" cy="12" r="3.2"/>
                                <circle class="footer-instagram-link__flash" cx="16.85" cy="7.15" r="1"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                    </div>
                    <p class="text-[11px] text-white/50 mt-4"><?= htmlspecialchars($site['hours']) ?></p>
                </div>  
            </div>
        </div>
        <div class="border-t border-white/10">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-2 text-[11px] text-white/50">
                <span>&copy; <?= htmlspecialchars($year) ?> ALCROS. All Rights Reserved.</span>
                <div class="flex gap-4">
                    <button type="button" data-open-privacy class="hover:text-white transition bg-transparent border-0 p-0 cursor-pointer">Privacy Policy Notice</button>
                </div>
            </div>
        </div>
    </footer>

    <?php
    $citizenMobileTab = 'home';
    require __DIR__ . '/includes/citizen_mobile_tabbar.php';
    ?>
    <?php require __DIR__ . '/includes/track_floating.php'; ?>
    <?= scriptTag('public/track-floating.js') ?>
    <?php require __DIR__ . '/includes/maintenance_announcement.php'; ?>
    <?php require __DIR__ . '/includes/privacy_agreement.php'; ?>
    <?php require __DIR__ . '/includes/notification_consent.php'; ?>
    <?= scriptTag('public/landing.js') ?>
    <?= lucideInitScript() ?>
</body>
</html>
