<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/api_helpers.php';
requireStaffLogin();
requirePageAccess('live-queue.php');
releaseSessionLock();

$activePage = 'live-queue.php';
$alcrosAdminRealtime = true;
$pdo = getDB();
$tables = queuePurposeConfig();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = (string) ($_POST['action'] ?? '');
    $purpose = (string) ($_POST['purpose'] ?? '');

    try {
        if ($action === 'next' && isset($tables[$purpose])) {
            $tableNum = queueTableForPurpose($purpose);
            $result = queueAdvanceNext($pdo, $purpose, $tableNum, staffId());
            if ($result['called_ticket']) {
                queueFlashSet('success', 'Now calling ' . $result['called_ticket'] . " at Table $tableNum.");
            } else {
                queueFlashSet('success', $result['had_serving']
                    ? 'Current ticket finished. No one else is waiting in this line.'
                    : 'No one is waiting in this line.');
            }
        } elseif ($action === 'call_again' && isset($tables[$purpose])) {
            $tableNum = queueTableForPurpose($purpose);
            $ticket = queueCallAgain($pdo, $purpose, $tableNum, staffId());
            if ($ticket) {
                queueFlashSet('success', "Calling $ticket again at Table $tableNum.");
            } else {
                queueFlashSet('error', 'No ticket is currently being served at this table.');
            }
        } elseif ($action === 'skip' && isset($tables[$purpose])) {
            $ticket = queueSkipServing($pdo, $purpose, staffId());
            if ($ticket) {
                queueFlashSet('success', "Skipped $ticket. Tap Call next for the next citizen.");
            } else {
                queueFlashSet('error', 'No ticket is currently being served at this table.');
            }
        } elseif ($action === 'no_show' && isset($tables[$purpose])) {
            $tableNum = queueTableForPurpose($purpose);
            $result = queueNoShowAndAdvance($pdo, $purpose, $tableNum, staffId());
            if ($result['no_show_ticket'] === null) {
                queueFlashSet('error', 'No ticket is currently being served at this table.');
            } elseif ($result['called_ticket'] !== null) {
                queueFlashSet(
                    'success',
                    'No-show: ' . $result['no_show_ticket'] . '. Now calling ' . $result['called_ticket'] . " at Table $tableNum."
                );
            } else {
                queueFlashSet(
                    'success',
                    'No-show: ' . $result['no_show_ticket'] . '. No one else is waiting in this line.'
                );
            }
        } else {
            queueFlashSet('error', 'Could not update the queue. Please try again.');
        }
    } catch (Throwable $e) {
        queueFlashSet('error', 'Could not update the queue. Please try again.');
    }

    redirectWithAuth('live-queue.php');
}

$flash = queueFlashGet();
$grouped = fetchQueueTicketsGrouped($pdo);
$totalWaiting = array_sum(array_map(fn ($g) => count($g['waiting']), $grouped));

$pageTitle = 'Live Queue';
$pageSubtitle = 'One button per table - tap when you are ready for the next citizen.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title>Live Queue - ALCROS</title>
    <?= alcrosUiHead() ?>
    <?= adminLayoutHeadStyles() ?>
</head>
<body class="flex min-h-screen" data-realtime="queue">
    <?php require __DIR__ . '/includes/admin_sidebar.php'; ?>
    <main class="admin-main flex flex-col">
        <?php require __DIR__ . '/includes/admin_header.php'; ?>
        <div class="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full admin-page-wrap">
            <div class="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-100 bg-blue-50/60 px-4 py-3">
                <div class="min-w-0">
                    <p class="text-xs font-bold text-slate-800">Public display &amp; voice</p>
                    <p class="text-[11px] text-slate-600">Keep queue display open in another tab (can stay in the background). Enable voice there once - calls announce even while you work here.</p>
                </div>
                <a href="queue_display.php" target="_blank" rel="noopener noreferrer" class="shrink-0 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-bold">
                    <i data-lucide="monitor" class="w-4 h-4"></i> Open queue display
                </a>
            </div>

            <p class="mb-6 text-sm font-semibold text-slate-600">
                <span id="stat-queue-waiting"><?= $totalWaiting ?></span> citizen<?= $totalWaiting === 1 ? '' : 's' ?> waiting total
            </p>

            <div id="queue-tables" class="grid grid-cols-1 md:grid-cols-3 gap-5">
                <?php foreach ($tables as $purpose => $cfg):
                    $serving   = $grouped[$purpose]['serving'];
                    $waiting   = $grouped[$purpose]['waiting'];
                    $waitCount = count($waiting);
                    $hasServing = (bool) $serving;
                    $canNext   = $hasServing || $waitCount > 0;

                    if ($hasServing && $waitCount > 0) {
                        $btnLabel = 'Finish & call next';
                    } elseif ($hasServing) {
                        $btnLabel = 'Finish (no one waiting)';
                    } elseif ($waitCount > 0) {
                        $btnLabel = 'Call next';
                    } else {
                        $btnLabel = 'No one waiting';
                    }
                ?>
                <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden" data-purpose="<?= htmlspecialchars($purpose) ?>">
                    <div class="px-5 py-3 <?= $cfg['bg'] ?> border-b border-slate-100">
                        <p class="text-[10px] font-black uppercase tracking-wider text-slate-500">Table <?= (int) $cfg['table'] ?></p>
                        <h2 class="text-lg font-black text-slate-900"><?= htmlspecialchars($cfg['label']) ?></h2>
                    </div>

                    <div class="p-5 text-center">
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Now serving</p>
                        <div class="queue-serving-slot min-h-[72px] flex flex-col items-center justify-center mb-4" data-purpose="<?= htmlspecialchars($purpose) ?>">
                            <?php if ($serving): ?>
                            <p class="queue-serving-number text-5xl font-black text-slate-900 leading-none"><?= htmlspecialchars($serving['ticket_number']) ?></p>
                            <?php $servingName = personNameFromRow($serving); if ($servingName !== ''): ?>
                            <p class="text-sm text-slate-500 mt-2"><?= htmlspecialchars($servingName) ?></p>
                            <?php endif; ?>
                            <?php else: ?>
                            <p class="queue-serving-number text-4xl font-black text-slate-200">-</p>
                            <?php endif; ?>
                        </div>

                        <form method="POST" class="mb-3 queue-next-form" data-no-confirm>
                            <?= authFormField() ?>
                            <input type="hidden" name="purpose" value="<?= htmlspecialchars($purpose) ?>">
                            <input type="hidden" name="action" value="next">
                            <button type="submit"
                                class="queue-next-btn w-full py-4 rounded-xl text-white font-black text-sm uppercase tracking-wide <?= $cfg['btn'] ?> disabled:opacity-40 disabled:cursor-not-allowed"
                                data-loading-text="Updating queue…"
                                <?= $canNext ? '' : 'disabled' ?>>
                                <?= htmlspecialchars($btnLabel) ?>
                            </button>
                        </form>

                        <?php if ($hasServing): ?>
                        <form method="POST" class="mb-4 queue-no-show-form" data-no-confirm>
                            <?= authFormField() ?>
                            <input type="hidden" name="purpose" value="<?= htmlspecialchars($purpose) ?>">
                            <input type="hidden" name="action" value="no_show">
                            <button type="submit"
                                class="queue-no-show-btn w-full py-2.5 rounded-xl border-2 border-rose-200 bg-rose-50 text-rose-700 font-bold text-xs uppercase tracking-wide hover:bg-rose-100 hover:border-rose-300 flex items-center justify-center gap-2"
                                data-loading-text="Marking no-show…">
                                <i data-lucide="user-x" class="w-4 h-4"></i> No show
                            </button>
                        </form>
                        <?php else: ?>
                        <div class="queue-no-show-slot hidden mb-4"></div>
                        <?php endif; ?>

                        <?php if ($hasServing): ?>
                        <form method="POST" class="mb-4" data-no-confirm>
                            <?= authFormField() ?>
                            <input type="hidden" name="purpose" value="<?= htmlspecialchars($purpose) ?>">
                            <input type="hidden" name="action" value="call_again">
                            <button type="submit"
                                class="queue-call-again-btn w-full py-2.5 rounded-xl border-2 border-slate-200 text-slate-600 font-bold text-xs uppercase tracking-wide hover:bg-slate-50 flex items-center justify-center gap-2"
                                data-loading-text="Calling again…">
                                <i data-lucide="volume-2" class="w-4 h-4"></i> Call again
                            </button>
                        </form>
                        <?php else: ?>
                        <div class="queue-call-again-slot hidden mb-4"></div>
                        <?php endif; ?>

                        <div class="text-left">
                            <p class="queue-wait-badge text-sm text-slate-600 mb-2" data-purpose="<?= htmlspecialchars($purpose) ?>">
                                <?php if ($waitCount === 0): ?>
                                No one in line
                                <?php else: ?>
                                <span class="font-bold text-slate-800"><?= $waitCount ?></span> waiting -
                                next: <span class="queue-next-preview font-mono font-bold text-base text-slate-900"><?= htmlspecialchars($waiting[0]['ticket_number']) ?></span>
                                <?php endif; ?>
                            </p>
                            <?php if ($waitCount > 1): ?>
                            <p class="queue-waiting-list text-[11px] text-slate-400 font-mono leading-relaxed" data-purpose="<?= htmlspecialchars($purpose) ?>">
                                Then: <?= htmlspecialchars(implode(', ', array_column(array_slice($waiting, 1), 'ticket_number'))) ?>
                            </p>
                            <?php else: ?>
                            <p class="queue-waiting-list text-[11px] text-slate-400 hidden" data-purpose="<?= htmlspecialchars($purpose) ?>"></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
                <?php endforeach; ?>
            </div>

            <div class="mt-8 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-100 bg-blue-50/60 px-4 py-3">
                <div class="min-w-0">
                    <p class="text-xs font-bold text-slate-800">Citizen kiosk</p>
                    <p class="text-[11px] text-slate-600">Citizens get queue tickets at the kiosk. Numbers starting with W, A, or C go to Tables 1, 2, and 3.</p>
                </div>
                <a href="kiosk.php" target="_blank" rel="noopener noreferrer" class="shrink-0 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-bold">
                    <i data-lucide="ticket" class="w-4 h-4"></i> Open kiosk
                </a>
            </div>
        </div>
    </main>
    <?= actionResultScript($flash) ?>
    <?= lucideInitScript() ?>
</body>
</html>
