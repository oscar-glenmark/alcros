<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';

$staff = getAuthenticatedStaff();
if ($staff) {
    try {
        logActivity($staff['staff_id'], 'Staff Logout', 'Logged out of staff portal');
    } catch (Throwable $e) {
        // ignore
    }
}
try {
    staffRememberMeRevokeCurrent(getDB());
} catch (Throwable $e) {
    staffRememberMeClearCookie();
}
staffSessionLogout();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>
    <title>Logging out...</title>
</head>
<body>
<?= scriptTag('core/logout.js') ?>
</body>
</html>
