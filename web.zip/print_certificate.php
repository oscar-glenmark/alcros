<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/printing.php';
require_once __DIR__ . '/includes/print_fill_controls.php';
require_once __DIR__ . '/includes/certification_print.php';
requireStaffLogin();
requirePageAccess('print_certificate.php');

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$activePage = 'print_certificate.php';
$pdo = getDB();
@set_time_limit(120);
try {
    ensurePrintTables($pdo);
} catch (Throwable $e) {
    // Continue if tables already exist.
}

$requestId = (int) ($_GET['request_id'] ?? 0);
$recordId = (int) ($_GET['record_id'] ?? 0);
$documentKind = normalizePrintDocumentKind($_GET['kind'] ?? 'certificate');
$isCertification = $documentKind === 'certification';

if ($isCertification) {
    $context = printCertificationContext($pdo, $recordId, $requestId);
} else {
    $context = printRequestContext($pdo, $requestId ?: null, $recordId ?: null);
}

if (!$context['ok']) {
    $pageTitle = $isCertification ? 'Print Certification' : 'Print Certificate';
    $pageSubtitle = 'Unable to prepare print preview.';
    $printError = $context['error'];
} else {
    $request = $context['request'];
    $record = $context['record'];
    $certificateType = $context['certificate_type'];
    $recordSource = $context['record_source'] ?? 'civil_record';
    $printError = null;

    if ($isCertification && $recordSource !== 'civil_record') {
        $printError = 'Certification requires an existing civil registry record. It does not create a new registration entry.';
    } else {
        $pageTitle = $isCertification ? 'Print Certification' : 'Print Certificate';
        $pageSubtitle = $isCertification
            ? certificationTitle($certificateType) . ' · Existing LCRO Record'
            : printCertificateTitle($certificateType) . ' · Municipal Form No. ' . printCertificateFormNumber($certificateType);
        $certFillOverrides = $isCertification
            ? certificationIssuedToOverridesForPrint($request, $record)
            : [];
        $fillEditorFields = $isCertification
            ? printCertificationFillEditorFields($certificateType, $record, $certFillOverrides, $pdo)
            : printFillEditorFields($certificateType, $record, [], $pdo);
        $frontTemplate = getPrintTemplate($pdo, $certificateType, 'front', $documentKind);
        if ($isCertification) {
            $certPaper = certificationPaperSize($certificateType);
            $paperW = (float) $certPaper['paper_width_mm'];
            $paperH = (float) $certPaper['paper_height_mm'];
        } else {
            $paperW = printOfficialPaperWidthMm();
            $paperH = printOfficialPaperHeightMm();
        }
    }
}

$globalCalibration = printGlobalCalibration();
$printModeSetting = printMode();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>
    <title><?= htmlspecialchars($pageTitle) ?> · ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= adminLayoutHeadStyles('print-certificate') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
</head>
<body class="flex min-h-screen print-page--<?= htmlspecialchars($certificateType ?? 'birth') ?><?= !empty($isCertification) ? ' print-page--certification' : '' ?>">
<?php require __DIR__ . '/includes/admin_sidebar.php'; ?>
<main class="admin-main">
    <?php require __DIR__ . '/includes/admin_header.php'; ?>

    <div class="admin-content print-certificate-page">
        <?php if ($printError): ?>
            <div class="print-cert-alert print-cert-alert--error">
                <i data-lucide="alert-circle"></i>
                <div>
                    <strong>Cannot open print preview</strong>
                    <p><?= htmlspecialchars($printError) ?></p>
                    <a href="<?= htmlspecialchars(!empty($isCertification) ? buildAuthUrl('records.php') : buildStaffOperationalUrl('manage_request.php')) ?>" class="print-cert-link">Back</a>
                </div>
            </div>
        <?php else: ?>
            <?php if (!$isCertification && ($recordSource ?? '') === 'request'): ?>
            <div class="print-cert-alert print-cert-alert--warn no-print">
                <i data-lucide="info"></i>
                <div>
                    <strong>Using request data</strong>
                    <p>No matching civil record was found in the registry. Fields are pre-filled from the document request - review and edit the fill-in data below before printing.</p>
                </div>
            </div>
            <?php endif; ?>
            <section class="print-cert-summary">
                <div class="print-cert-summary__grid">
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label"><?= $isCertification ? 'Document' : 'Certificate' ?></span>
                        <strong><?= htmlspecialchars($isCertification ? certificationTitle($certificateType) : printCertificateTitle($certificateType)) ?></strong>
                    </div>
                    <?php if ($request): ?>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Request</span>
                        <strong><?= htmlspecialchars($request['tracking_code']) ?></strong>
                    </div>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Requester</span>
                        <strong><?= htmlspecialchars(personRequesterNameFromRow($request) ?: personNameFromRow($request)) ?></strong>
                    </div>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Name on certificate</span>
                        <strong><?= htmlspecialchars(personNameFromRow($request)) ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Registry No.</span>
                        <strong><?= htmlspecialchars($record['registry_number'] ?: '-') ?></strong>
                    </div>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Book / Page</span>
                        <strong><?= htmlspecialchars(certificationBookPageReference($record) ?: '-') ?></strong>
                    </div>
                    <div class="print-cert-summary__item">
                        <span class="print-cert-label">Print Mode</span>
                        <strong><?= $printModeSetting === 'digital' ? 'Digital Form' : 'Pre-printed Overlay' ?></strong>
                    </div>
                    <div class="print-cert-summary__item print-cert-summary__item--copies">
                        <label class="print-cert-label" for="printCopies">Copies</label>
                        <input type="number"
                               id="printCopies"
                               class="print-cert-copies-input"
                               name="print_copies"
                               min="1"
                               max="99"
                               step="1"
                               value="1"
                               inputmode="numeric">
                    </div>
                </div>
            </section>

            <?php if (!$isCertification): ?>
            <section class="print-cert-options no-print" id="backPageOptions" hidden>
                <div class="print-cert-options__inner">
                    <h2 class="print-cert-section-title">Back Page Options</h2>
                    <div class="print-cert-checks">
                        <?php if ($certificateType === 'birth'): ?>
                            <label><input type="checkbox" id="optPaternity" checked> Paternity affidavit</label>
                            <label><input type="checkbox" id="optDelayedBirth"> Delayed birth affidavit</label>
                        <?php elseif ($certificateType === 'marriage'): ?>
                            <label><input type="checkbox" id="optDelayedMarriage" checked> Delayed marriage affidavit</label>
                        <?php elseif ($certificateType === 'death'): ?>
                            <label><input type="checkbox" id="optInfantSection" checked> Infant 0–7 days</label>
                            <label><input type="checkbox" id="optPostmortem"> Postmortem (autopsy)</label>
                            <label><input type="checkbox" id="optDelayedDeath"> Delayed death affidavit</label>
                        <?php endif; ?>
                    </div>
                </div>
                <p class="print-cert-hint print-cert-hint--compact">Affidavit sections fill only when checked. Signatures are never auto-generated.</p>
            </section>
            <?php else: ?>
            <section class="print-cert-options no-print">
                <div class="print-cert-options__inner">
                    <h2 class="print-cert-section-title">Print Options</h2>
                    <div class="print-cert-checks">
                        <label><input type="checkbox" id="optShowBackground" checked> Show background</label>
                    </div>
                </div>
                <p class="print-cert-hint print-cert-hint--compact">When checked, the form background is included in the preview and print. When unchecked, only the filled-in data is printed - load blank A4 certification paper.</p>
            </section>
            <?php endif; ?>
            <div class="print-cert-workspace">
            <section class="print-cert-fill no-print">
                <div class="print-cert-fill-chrome">
                    <div class="print-cert-fill-chrome__top">
                        <h2 class="print-cert-fill-chrome__title">Edit Fill-in Data</h2>
                        <div class="print-cert-fill-chrome__actions">
                            <a href="<?= htmlspecialchars($request ? buildStaffOperationalUrl('manage_request.php') : buildAuthUrl('records.php')) ?>" class="print-cert-btn print-cert-btn--primary print-cert-fill-chrome__btn">Cancel</a>
                            <button type="button" class="print-cert-btn print-cert-btn--ghost print-cert-fill-chrome__btn" id="resetFillData">Reset to record data</button>
                        </div>
                    </div>
                    <div class="print-cert-fill-chrome__body">
                        <p class="print-cert-hint print-cert-fill-chrome__hint">Change values before printing. Use <strong>Back page</strong> for affidavit sections. Back Page Options checkboxes control print output only.</p>
                    </div>
                    <?php if (!$isCertification): ?>
                    <div class="print-cert-fill-chrome__footer">
                        <div class="print-cert-fill-tabs print-cert-fill-tabs--page" role="tablist" aria-label="Fill-in page">
                            <button type="button" class="print-cert-fill-tab is-active" data-fill-tab="front" role="tab" aria-selected="true">Front page</button>
                            <button type="button" class="print-cert-fill-tab" data-fill-tab="back" role="tab" aria-selected="false">Back page</button>
                        </div>
                        <button type="button" class="print-cert-fill-tab print-cert-fill-tab--both print-cert-fill-chrome__both" id="previewViewBoth" data-preview-view="both">Both pages</button>
                    </div>
                    <?php endif; ?>
                </div>
                <?php $printFillGrouped = groupPrintFillFieldsForEntryForm($certificateType, $fillEditorFields); ?>
                <?php foreach ($isCertification ? ['front'] : ['front', 'back'] as $fillSide): ?>
                <div class="print-cert-fill-grid<?= $isCertification ? '' : ' print-cert-fill-grid--sectioned' ?>" id="fillFields<?= ucfirst($fillSide) ?>" data-fill-panel="<?= $fillSide ?>" role="tabpanel"<?= $fillSide === 'back' ? ' hidden' : '' ?>>
                    <?php if ($isCertification): ?>
                        <?php renderPrintFillWorkspaceClassicList($fillEditorFields, $fillSide); ?>
                    <?php else: ?>
                        <?php renderPrintFillGroupedSectionPanels($certificateType, $printFillGrouped, $fillSide, 'workspace'); ?>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </section>

            <section class="print-cert-previews print-cert-previews--local"
                     data-preview-view="front"
                     data-paper-w="<?= htmlspecialchars((string) $paperW) ?>"
                     data-paper-h="<?= htmlspecialchars((string) $paperH) ?>">
                <div class="print-cert-preview-block" data-preview-side="front">
                    <div class="print-cert-preview-head">
                        <h2>Front Preview</h2>
                        <div class="print-cert-preview-actions no-print">
                            <button type="button" class="print-cert-btn print-cert-btn--ghost" data-print-side="front" data-test="1">Test Print Front</button>
                            <button type="button" class="print-cert-btn print-cert-btn--primary" data-print-side="front">Print Front</button>
                        </div>
                    </div>
                    <div class="print-cert-preview-viewport" data-preview-viewport="front">
                        <div class="print-cert-preview-scaler" data-preview-scaler="front">
                            <iframe id="previewFront" class="print-cert-frame print-cert-frame--local" title="Front preview" scrolling="no"></iframe>
                        </div>
                    </div>
                </div>
                <?php if (!$isCertification): ?>
                <div class="print-cert-preview-block" data-preview-side="back">
                    <div class="print-cert-preview-head">
                        <h2>Back Preview</h2>
                        <div class="print-cert-preview-actions no-print">
                            <button type="button" class="print-cert-btn print-cert-btn--ghost" data-print-side="back" data-test="1">Test Print Back</button>
                            <button type="button" class="print-cert-btn print-cert-btn--primary" data-print-side="back">Print Back</button>
                        </div>
                    </div>
                    <div class="print-cert-preview-viewport" data-preview-viewport="back">
                        <div class="print-cert-preview-scaler" data-preview-scaler="back">
                            <iframe id="previewBack" class="print-cert-frame print-cert-frame--local" title="Back preview" scrolling="no"></iframe>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </section>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php if (!$printError): ?>
<?= csrfField() ?>
<?= pageConfigJson([
    'requestId' => (int) ($request['id'] ?? $requestId),
    'recordId' => (int) (($record['id'] ?? 0) ?: $recordId),
    'documentKind' => $documentKind,
    'locationsApiUrl' => buildAuthUrl('api/locations.php'),
    'printAuthUrl' => buildAuthUrl('print_render.php'),
    'apiPrintUrl' => buildAuthUrl('api/print.php'),
    'paperWidthMm' => $paperW,
    'paperHeightMm' => $paperH,
    'calibrationRev' => printCalibrationRevision(),
    'initialFillValues' => array_column($fillEditorFields, 'value', 'field_name'),
]) ?>
<?= scriptTag('admin/print-fit-text.js') ?>
<?= scriptTag('core/page-config.js') ?>
<?= scriptTag('core/cascading-location.js') ?>
<?= scriptTag('admin/print-certificate.js') ?>
<?php endif; ?>
<?= lucideInitScript() ?>
</body>
</html>
