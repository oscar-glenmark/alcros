<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/scripts.php';
require_once __DIR__ . '/includes/lucide_icons.php';
require_once __DIR__ . '/includes/printing.php';
require_once __DIR__ . '/includes/record_locks.php';
require_once __DIR__ . '/includes/cascading_location.php';
require_once __DIR__ . '/includes/print_fill_controls.php';
require_once __DIR__ . '/includes/records_list.php';
require_once __DIR__ . '/includes/records_form.php';
require_once __DIR__ . '/includes/records_csv_import.php';
require_once __DIR__ . '/includes/civil_record_audit.php';
require_once __DIR__ . '/includes/civil_registry_numbering.php';
requireStaffLogin();
requirePageAccess('records.php');
releaseSessionLock();

$activePage = 'records.php';
$canManageCivilRecords = staffCanManageCivilRecords();
$pdo = getDB();
ensurePersonNamePartColumns($pdo);

try {
    $pdo->query('SELECT deleted_at FROM civil_records LIMIT 1');
} catch (PDOException $e) {
    $pdo->exec('ALTER TABLE civil_records ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL AFTER notes');
}

function ensureCivilRecordExtendedColumns(PDO $pdo): void
{
    ensureCivilRecordTypeTables($pdo);
}

ensureCivilRecordExtendedColumns($pdo);
ensureCivilRecordPrintSchema($pdo);
syncCivilRecordDerivedFields($pdo);
ensureCivilRegistryNumberingSchema($pdo);

$validTypes = ['birth', 'death', 'marriage'];

function buildRecordsUrl(array $overrides = []): string
{
    return buildRecordsUrlFromFilters(currentRecordsFilters(), $overrides);
}

function currentRecordsFilters(): array
{
    return recordsListNormalizeFilters([
        'type' => $_GET['type'] ?? 'all',
        'q'    => $_GET['q'] ?? '',
        'sort' => $_GET['sort'] ?? 'name',
        'dir'  => $_GET['dir'] ?? 'asc',
        'page' => $_GET['page'] ?? 1,
    ]);
}

function recordsExportTypeFromRequest(): string
{
    global $validTypes;

    $exportType = (string) ($_GET['export_type'] ?? 'all');
    if (!in_array($exportType, ['all', ...$validTypes], true)) {
        return 'all';
    }

    return $exportType;
}

function recordsExportFilters(): array
{
    return [
        'type' => recordsExportTypeFromRequest(),
    ];
}

function recordsExportUrl(string $exportType): string
{
    global $validTypes;

    if (!in_array($exportType, ['all', ...$validTypes], true)) {
        $exportType = 'all';
    }

    return buildAuthUrl('records.php', [
        'action'      => 'export',
        'export_type' => $exportType,
    ]);
}

/** Export scope: all non-deleted records, optionally limited to one record type. Search is never applied. */
function buildRecordsExportWhere(string $exportType): array
{
    $where  = 'cr.deleted_at IS NULL';
    $params = [];

    if ($exportType !== 'all' && in_array($exportType, ['birth', 'death', 'marriage'], true)) {
        $where .= ' AND cr.record_type = ?';
        $params[] = $exportType;
    }

    return [$where, $params];
}

function recordsExportCsvChunkSize(): int
{
    return 2500;
}

/** @return array<string, int> */
function exportCivilRecordsTypeCounts(PDO $pdo, string $where, array $params, array $types): array
{
    $counts = array_fill_keys($types, 0);
    if ($types === []) {
        return $counts;
    }

    if (preg_match('/\bcr\.record_type\s*=\s*\?/', $where) === 1) {
        $type = $types[0];
        $counts[$type] = exportCivilRecordsTypeCount($pdo, $where, $params, $type);

        return $counts;
    }

    $stmt = $pdo->prepare("SELECT cr.record_type, COUNT(*) AS cnt FROM civil_records cr WHERE $where GROUP BY cr.record_type");
    $stmt->execute($params);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $type = (string) ($row['record_type'] ?? '');
        if (isset($counts[$type])) {
            $counts[$type] = (int) ($row['cnt'] ?? 0);
        }
    }

    return $counts;
}

function civilRecordSearchBlob(array $r): string
{
    $parts = [
        civilRecordDisplayName($r),
        $r['first_name'] ?? '',
        $r['middle_name'] ?? '',
        $r['last_name'] ?? '',
        civilRecordRegistryNumber($r) ?? '',
        $r['book_number'] ?? '',
        $r['page_number'] ?? '',
        $r['code_number'] ?? '',
        $r['father_name'] ?? '',
        $r['mother_name'] ?? '',
        $r['husband_name'] ?? '',
        $r['wife_name'] ?? '',
        $r['husband_father_name'] ?? '',
        $r['husband_mother_maiden_name'] ?? '',
        $r['wife_father_name'] ?? '',
        $r['wife_mother_maiden_name'] ?? '',
        $r['place'] ?? '',
        $r['marriage_place'] ?? '',
        $r['notes'] ?? '',
        (string) ($r['id'] ?? ''),
    ];

    foreach ([
        'birth_date', 'event_date', 'registration_date', 'parents_marriage_date',
        'death_date', 'marriage_date', 'husband_birth_date', 'wife_birth_date',
    ] as $dateCol) {
        if (!empty($r[$dateCol])) {
            $parts = array_merge($parts, adminSearchDateBlobVariants((string) $r[$dateCol]));
        }
    }

    return implode(' ', array_filter(array_map(static fn ($v) => trim((string) $v), $parts), static fn ($v) => $v !== ''));
}

function civilRecordExportRowValues(array $row, string $type): array
{
    $values = printBuildFieldValues($row, $type, ['keep_empty' => true]);

    return array_map(
        static function (string $column) use ($values) {
            $value = $values[$column] ?? null;
            if ($value === null || trim((string) $value) === '') {
                return null;
            }

            return (string) $value;
        },
        civilRecordCsvColumns($type)
    );
}

function exportCivilRecordsTypeWhere(string $where, array $params, string $type): array
{
    if (preg_match('/\bcr\.record_type\s*=\s*\?/', $where) !== 1) {
        $where .= ' AND cr.record_type = ?';
        $params[] = $type;
    }

    return [$where, $params];
}

function exportCivilRecordsTypeCount(PDO $pdo, string $where, array $params, string $type): int
{
    [$typeWhere, $typeParams] = exportCivilRecordsTypeWhere($where, $params, $type);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM civil_records cr WHERE $typeWhere");
    $stmt->execute($typeParams);

    return (int) $stmt->fetchColumn();
}

/** @return list<array<string, mixed>> */
function exportCivilRecordsFetchChunk(PDO $pdo, string $where, array $params, int $afterId, int $limit): array
{
    $sql = "SELECT cr.* FROM civil_records cr WHERE $where AND cr.id > ?"
        . ' ORDER BY cr.id ASC LIMIT ' . max(1, $limit);
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge($params, [$afterId]));

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function exportCivilRecordTemplateXlsx(PDO $pdo, string $type): void
{
    global $validTypes;

    if (!in_array($type, $validTypes, true)) {
        $type = 'birth';
    }

    require_once __DIR__ . '/includes/excel_export.php';

    $spreadsheet = alcrosExcelNewSpreadsheet('ALCROS ' . ucfirst($type) . ' Import Template');
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Import data');

    $headers = printFillCsvTemplateHeadersForType($pdo, $type);
    $sample = civilRecordCsvSampleRowFromPrintFields($type, $pdo);

    $row = 1;
    alcrosExcelWriteMetaBlock($sheet, [
        'ALCROS bulk import template - ' . civilRecordTypeLabel($type),
        ['Instructions', 'Enter one record per row using the column headers below. The sample row is skipped on import.'],
        ['Dates', 'Use YYYY-MM-DD or MM/DD/YYYY, or separate day / month / year columns where provided.'],
        ['Required', $type === 'marriage'
            ? 'Husband and wife name columns (see template headers).'
            : ($type === 'death'
                ? 'Deceased first and last name, date of death (death_date), and registry_number. Other certificate fields are optional on import.'
                : 'child_first_name and child_last_name')],
    ], $row);

    alcrosExcelWriteTable($sheet, $headers, [$sample], $row);

    alcrosExcelSendDownload(
        $spreadsheet,
        alcrosExcelDownloadFilename($type . '_records_import_template')
    );
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== realpath(__FILE__)) {
    return;
}

// JSON - recent update history (view modal info button)
if (isset($_GET['action']) && $_GET['action'] === 'record_update_history') {
    header('Content-Type: application/json; charset=UTF-8');
    $recordId = (int) ($_GET['id'] ?? 0);
    if ($recordId <= 0 || !fetchFullCivilRecord($pdo, $recordId)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Record not found.'], JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    $updateHistory = fetchCivilRecordUpdateHistory($pdo, $recordId, 15);
    echo json_encode([
        'ok'           => true,
        'record_id'    => $recordId,
        'history_html' => renderCivilRecordUpdateHistoryMarkup($updateHistory),
    ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
    exit;
}

// JSON list fragment for live search / filters (no full page reload)
if (isset($_GET['action']) && $_GET['action'] === 'list_fragment') {
    header('Content-Type: application/json; charset=UTF-8');
    try {
        $payload = recordsListAjaxPayload($pdo, $_GET);
        echo json_encode(['ok' => true] + $payload, JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Could not load records.'], JSON_INVALID_UTF8_SUBSTITUTE);
    }
    exit;
}

// JSON record details for view modal
if (isset($_GET['action']) && $_GET['action'] === 'view_record') {
    header('Content-Type: application/json; charset=UTF-8');
    $recordId = (int) ($_GET['id'] ?? 0);
    $record = fetchFullCivilRecord($pdo, $recordId);
    if (!$record) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Record not found.'], JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    $record = civilRecordExpandForView($record);
    $lock = fetchCivilRecordEditLock($pdo, $recordId);
    echo json_encode([
        'ok'        => true,
        'record'    => $record,
        'edit_lock' => $lock ? formatCivilRecordEditLock($lock, staffId()) : null,
    ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
    exit;
}

// Import template download
if (isset($_GET['action']) && $_GET['action'] === 'template') {
    if (!$canManageCivilRecords) {
        assertStaffCanManageCivilRecords();
    }
    $tplType = $_GET['type'] ?? 'birth';
    if (!in_array($tplType, $validTypes, true)) {
        $tplType = 'birth';
    }
    exportCivilRecordTemplateXlsx($pdo, $tplType);
}

if (isset($_GET['action']) && $_GET['action'] === 'export') {
    @ini_set('memory_limit', '1024M');
    @set_time_limit(0);
    ignore_user_abort(true);

    $filters = recordsExportFilters();
    logActivity(staffId(), 'Excel Export', 'Exported civil records (' . ($filters['type'] ?? 'all') . ')');
    require_once __DIR__ . '/includes/spreadsheet_exports.php';
    exportCivilRecordsXlsx($pdo, $filters);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string) ($_POST['action'] ?? ''));

    if ($action !== '') {
    if (!$canManageCivilRecords) {
        assertStaffCanManageCivilRecords();
    }
    try {
        if ($action === 'create') {
            $data = normalizeRecordInput(prepareCivilRecordFormInput($_POST));
            $newRecordId = saveCivilRecord($pdo, $data, null);
            recordCivilRecordAudit($pdo, $newRecordId, 'created', [], $data);
            logActivity(staffId(), 'Record Created', 'New ' . $data['record_type'] . ' record: ' . civilRecordDisplayName($data));
            recordsFlashSet('success', 'Record saved successfully.');
        } elseif ($action === 'update' && !empty($_POST['record_id'])) {
            $id = (int) $_POST['record_id'];
            $editReason = parseCivilRecordEditReasonFromPost($_POST);
            if ($editReason === null) {
                throw new InvalidArgumentException(
                    'Please select a reason for this update before saving (e.g. typographical error, incorrect date, or encoding mistake).'
                );
            }
            assertCivilRecordEditableByStaff($pdo, $id, staffId());
            $recordBefore = fetchFullCivilRecord($pdo, $id);
            $data = normalizeRecordInput(prepareCivilRecordFormInput($_POST), false, $recordBefore);
            saveCivilRecord($pdo, $data, $id);
            $auditLogged = false;
            if ($recordBefore) {
                $recordAfter = fetchFullCivilRecord($pdo, $id) ?? $recordBefore;
                $auditLogged = recordCivilRecordAudit($pdo, $id, 'updated', $recordBefore, $recordAfter, $editReason);
            }
            releaseCivilRecordEditLock($pdo, $id, staffId());
            if ($auditLogged) {
                logActivity(staffId(), 'Record Updated', "Updated record #$id: " . civilRecordDisplayName($data));
                recordsFlashSet('success', 'Record updated successfully.');
            } else {
                recordsFlashSet('success', 'No field changes were detected - nothing was logged.');
            }
        } elseif ($action === 'import_csv') {
            @set_time_limit(600);
            if (empty($_FILES['csv_file']['tmp_name']) || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
                throw new InvalidArgumentException('Please choose a CSV file to import.');
            }
            if (($_FILES['csv_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                throw new InvalidArgumentException(csvUploadErrorMessage((int) ($_FILES['csv_file']['error'] ?? UPLOAD_ERR_NO_FILE)));
            }
            $importType = $_POST['import_type'] ?? '';
            if (!in_array($importType, $validTypes, true)) {
                throw new InvalidArgumentException('Please choose Birth, Death, or Marriage before importing.');
            }
            $result = importCsvRecords($pdo, $_FILES['csv_file']['tmp_name'], $importType);
            $imported = $result['imported'];
            $skipped = $result['skipped'];
            $errors = $result['errors'];
            $sampleSkipped = $result['sample_skipped'] ?? 0;

            if ($imported > 0) {
                logActivity(staffId(), 'CSV Import', "Imported $imported $importType records");
            }

            if ($imported === 0) {
                $msg = 'No records were imported.';
                if ($sampleSkipped > 0) {
                    $msg .= " $sampleSkipped template sample row(s) skipped - add your own data rows below the header.";
                }
                if ($skipped > 0) {
                    $msg .= " $skipped row(s) skipped.";
                }
                if (!empty($errors)) {
                    $msg .= ' ' . implode(' ', array_slice($errors, 0, 3));
                }
                recordsFlashSet('error', $msg);
            } else {
                $msg = "Successfully imported $imported " . ucfirst($importType) . ' record(s).';
                if ($sampleSkipped > 0) {
                    $msg .= " Skipped $sampleSkipped template sample row(s).";
                }
                if ($skipped > 0) {
                    $msg .= " Skipped $skipped invalid row(s).";
                    if (!empty($errors)) {
                        $msg .= ' ' . implode(' ', array_slice($errors, 0, 2));
                    }
                }
                recordsFlashSet('success', $msg);
            }
        }
    } catch (InvalidArgumentException $e) {
        recordsFlashSet('error', $e->getMessage());
    } catch (PDOException $e) {
        recordsFlashSet('error', 'Could not complete the action. Please try again.');
    } catch (Throwable $e) {
        error_log('ALCROS CSV import failed: ' . $e->getMessage());
        recordsFlashSet('error', 'Import failed: ' . $e->getMessage());
    }

    redirectWithAuth('records.php', currentRecordsFilters());
    }
}

$filters = currentRecordsFilters();
$type   = $filters['type'];
$search = $filters['q'];

$typeCounts = $pdo->query(
    "SELECT record_type, COUNT(*) AS cnt
     FROM civil_records
     WHERE deleted_at IS NULL AND record_type IN ('birth', 'death', 'marriage')
     GROUP BY record_type"
)->fetchAll(PDO::FETCH_KEY_PAIR);
$birthCount    = (int) ($typeCounts['birth'] ?? 0);
$deathCount    = (int) ($typeCounts['death'] ?? 0);
$marriageCount = (int) ($typeCounts['marriage'] ?? 0);

$recordsListHtml = renderRecordsListPanel($pdo, $filters);

$editRecord = null;
$editLockBlocked = null;
$editLockHeld = false;
if ((isset($_GET['edit']) || isset($_GET['new'])) && !$canManageCivilRecords) {
    redirectWithAuth('records.php', currentRecordsFilters());
}
if (isset($_GET['edit'])) {
    $editId = (int) $_GET['edit'];
    $editRecord = fetchFullCivilRecord($pdo, $editId);
    if ($editRecord) {
        $lockResult = acquireCivilRecordEditLock($pdo, $editId, staffId(), staffName());
        if ($lockResult['ok']) {
            $editLockHeld = true;
        } else {
            $editLockBlocked = $lockResult;
        }
    }
}

$showModal = isset($_GET['new']);
$recordUpdateHistory = [];
$flash = recordsFlashGet();

$pageTitle = 'Civil Records';
$pageSubtitle = 'Manage birth, death, and marriage registry entries with search, export, and import.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title>Civil Records - ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= adminLayoutHeadStyles('records') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
</head>
<body class="flex min-h-screen<?= $editRecord ? ' records-entry-modal-open' : '' ?>">

    <?php require __DIR__ . '/includes/admin_sidebar.php'; ?>
    <?php if (isset($_GET['edit'])): ?>
    <script>
    (function () {
        if (window.AlcrosLoading && typeof window.AlcrosLoading.page === 'function') {
            window.AlcrosLoading.page(true, 'Opening editor…');
        }
    })();
    </script>
    <?php endif; ?>

    <main class="admin-main flex flex-col bg-[#fdfdfd]">
        <?php require __DIR__ . '/includes/admin_header.php'; ?>

        <div class="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full admin-page-wrap space-y-6">
            <div class="flex flex-wrap gap-2 sm:gap-3 items-center justify-end">
                    <div class="relative" id="recordsExportMenu">
                        <button type="button" id="recordsExportBtn"
                                class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-[11px] font-bold uppercase flex items-center shadow-sm">
                            <i data-lucide="upload" class="w-4 h-4 mr-2"></i> Export
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5 ml-1.5 opacity-80"></i>
                        </button>
                        <div id="recordsExportPanel" class="hidden absolute right-0 mt-2 w-64 bg-white border border-gray-100 rounded-xl shadow-lg z-50 py-1 text-xs">
                            <?php
                            $exportOptions = [
                                'all'      => 'All records',
                                'birth'    => 'Birth records',
                                'death'    => 'Death records',
                                'marriage' => 'Marriage records',
                            ];
                            ?>
                            <?php foreach ($exportOptions as $exportKey => $exportLabel): ?>
                            <a href="<?= htmlspecialchars(recordsExportUrl($exportKey)) ?>"
                               class="block px-3 py-2.5 font-semibold text-slate-700 hover:bg-gray-50">
                                <?= htmlspecialchars($exportLabel) ?>
                            </a>
                            <?php endforeach; ?>
                            <p class="px-3 py-2 border-t border-gray-100 text-[10px] text-gray-400 leading-snug">Exports every record for the option you choose. Search does not affect downloads.</p>
                        </div>
                    </div>
                    <?php if ($canManageCivilRecords): ?>
                    <div class="relative" id="recordsImportMenu">
                        <button type="button" id="recordsImportBtn"
                                class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg text-[11px] font-bold uppercase flex items-center shadow-sm">
                            <i data-lucide="download" class="w-4 h-4 mr-2"></i> Import
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5 ml-1.5 opacity-80"></i>
                        </button>
                        <div id="recordsImportPanel" class="hidden absolute right-0 mt-2 w-64 bg-white border border-gray-100 rounded-xl shadow-lg z-50 py-1 text-xs">
                            <p class="px-4 py-2 text-[9px] font-bold text-gray-400 uppercase tracking-widest">Bulk import (CSV)</p>
                            <?php foreach ($validTypes as $t): ?>
                            <button type="button" data-import-type="<?= htmlspecialchars($t) ?>" class="w-full px-3 py-2.5 text-left font-semibold text-slate-700 hover:bg-gray-50 flex items-center gap-2">
                                <?= lucideSvg('file-text', 'w-4 h-4 text-gray-400 shrink-0') ?>
                                Import <?= htmlspecialchars(civilRecordTypeLabel($t)) ?> Records
                            </button>
                            <?php endforeach; ?>
                            <p class="px-3 py-2 border-t border-gray-100 text-[10px] text-gray-400 leading-snug">Download a template from the import dialog. Upload one CSV at a time.</p>
                        </div>
                    </div>
                    <div class="relative" id="newEntryWrapper">
                        <button type="button" id="newEntryBtn"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-[11px] font-bold uppercase flex items-center shadow-md transition">
                            <span class="mr-2 text-lg leading-none">+</span> New Entry
                        </button>
                        <div id="newEntryMenu" class="hidden absolute right-0 top-full mt-2 w-64 bg-white rounded-xl border border-gray-100 entry-dropdown z-50 py-2">
                            <p class="px-4 py-2 text-[9px] font-bold text-gray-400 uppercase tracking-widest">Manual Entry</p>
                            <?php foreach (['birth' => ['label' => 'Birth', 'icon' => 'baby'], 'death' => ['label' => 'Death', 'icon' => 'activity'], 'marriage' => ['label' => 'Marriage', 'icon' => 'heart']] as $entryType => $entryMeta): ?>
                            <button type="button" data-single-entry-type="<?= $entryType ?>" class="entry-menu-item w-full px-4 py-2.5 text-left text-sm font-bold text-slate-800 flex items-center gap-3">
                                <span class="text-blue-600 text-base leading-none">+</span>
                                <i data-lucide="<?= $entryMeta['icon'] ?>" class="w-4 h-4 text-gray-400"></i>
                                Add <?= $entryMeta['label'] ?> Record
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                <?php foreach (['birth' => ['count' => $birthCount, 'icon' => 'users', 'bg' => 'bg-blue-50 text-blue-600'], 'death' => ['count' => $deathCount, 'icon' => 'activity', 'bg' => 'bg-gray-50 text-gray-400'], 'marriage' => ['count' => $marriageCount, 'icon' => 'heart', 'bg' => 'bg-pink-50 text-pink-500']] as $key => $meta): ?>
                <a href="<?= buildRecordsUrl(['type' => $key, 'page' => 1]) ?>" class="stat-card bg-white p-4 rounded-lg border border-gray-100 shadow-sm block <?= $type === $key ? 'ring-2 ring-blue-500' : '' ?>">
                    <div class="<?= $meta['bg'] ?> p-1.5 rounded-md w-fit mb-2"><?= lucideSvg($meta['icon'], 'w-4 h-4') ?></div>
                    <p class="text-[9px] font-bold text-gray-400 uppercase tracking-widest"><?= civilRecordTypeLabel($key) ?></p>
                    <p class="text-2xl font-black text-slate-900 leading-tight mt-0.5"><?= $meta['count'] ?></p>
                </a>
                <?php endforeach; ?>
            </div>

            <form method="GET" action="<?= htmlspecialchars(buildAuthUrl('records.php')) ?>" class="admin-toolbar" id="recordsToolbarForm" data-records-ajax-search="1">
                <?= authFormField() ?>
                <div id="recordsToolbarHiddenFields">
                    <?php if ($type !== 'all'): ?><input type="hidden" name="type" value="<?= htmlspecialchars($type) ?>"><?php endif; ?>
                    <?php if ($filters['sort'] !== 'name'): ?><input type="hidden" name="sort" value="<?= htmlspecialchars($filters['sort']) ?>"><?php endif; ?>
                    <?php if ($filters['dir'] !== 'asc'): ?><input type="hidden" name="dir" value="<?= htmlspecialchars($filters['dir']) ?>"><?php endif; ?>
                </div>
                <div class="records-toolbar-search-row">
                    <div class="relative flex-1 min-w-0 records-toolbar-search">
                        <span class="absolute left-3 top-2.5 pointer-events-none text-gray-400"><?= lucideSvg('search', 'w-4 h-4') ?></span>
                        <input type="text" name="q" id="recordsSearchInput" value="<?= htmlspecialchars($search) ?>" placeholder="First, middle, last, full name, DOB, DOM, registry…"
                            class="records-search-input w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border-none rounded-lg focus:ring-0 text-slate-600 placeholder-gray-400" autocomplete="off"
                            aria-controls="recordsListPanel" aria-describedby="recordsSearchStatus">
                    </div>
                    <button type="submit" class="records-toolbar-search-btn bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold shrink-0" data-loading-text="Searching…">Search</button>
                </div>
                <p id="recordsSearchStatus" class="sr-only" aria-live="polite"></p>
                <div class="admin-toolbar-filters" id="recordsTypeFilters">
                    <?php
                    $filterTabs = [
                        'all'      => ['label' => 'All', 'icon' => 'layers'],
                        'birth'    => ['label' => 'Birth', 'icon' => 'users'],
                        'death'    => ['label' => 'Death', 'icon' => 'activity'],
                        'marriage' => ['label' => 'Marriage', 'icon' => 'heart'],
                    ];
                    foreach ($filterTabs as $key => $filterMeta):
                    ?>
                    <a href="<?= htmlspecialchars(buildRecordsUrl(['type' => $key, 'page' => 1, 'q' => $search !== '' ? $search : null])) ?>"
                       data-records-type="<?= htmlspecialchars($key) ?>"
                       class="filter-chip filter-chip--with-icon whitespace-nowrap shrink-0 records-list-nav <?= $type === $key ? 'bg-white shadow-sm text-blue-600' : 'text-gray-400 hover:text-gray-600' ?>">
                        <?= lucideSvg($filterMeta['icon'], 'records-filter-icon shrink-0') ?>
                        <span><?= htmlspecialchars($filterMeta['label']) ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </form>

            <?= $recordsListHtml ?>
        </div>
    </main>

    <?php if ($canManageCivilRecords):
    $modalRecord = $editRecord ?: [];
    $modalMode = $editRecord ? 'edit' : 'create';
    $entryFormReadOnly = $editRecord && $editLockBlocked;
    $modalTitle = $editRecord
        ? 'Edit Civil Record'
        : 'Add ' . civilRecordTypeLabel($modalRecord['record_type'] ?? ($type !== 'all' ? $type : 'birth')) . ' Record';
    $submitAction = $editRecord ? 'update' : 'create';
    $defaultRecordType = $modalRecord['record_type'] ?? ($type !== 'all' ? $type : 'birth');
    $entryFormEditMode = (bool) $editRecord;
    $recordUpdateHistory = $editRecord
        ? fetchCivilRecordUpdateHistory($pdo, (int) $editRecord['id'], 15)
        : [];
    ?>
    <div class="records-entry-modal<?= $editRecord ? ' is-open' : ' hidden' ?>" id="entryModal">
        <div class="records-entry-dialog">
            <div class="records-entry-header">
                <h2 class="text-lg font-black text-slate-900 min-w-0 flex-1" id="entryModalTitle"><?= htmlspecialchars($modalTitle) ?></h2>
                <div class="records-entry-header__actions shrink-0">
                    <?php if ($entryFormEditMode): ?>
                    <button type="button"
                            id="recordUpdatesInfoBtn"
                            class="records-updates-info-btn"
                            aria-label="Information - edit policy and recent updates"
                            title="Information - edit policy and recent updates">
                        <?= lucideSvg('info', 'w-4 h-4') ?>
                    </button>
                    <?php endif; ?>
                    <button type="button" class="records-entry-header__close close-modal" aria-label="Close">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>
            <form method="POST" class="records-entry-form" id="entryForm" novalidate>
                <?= authFormField() ?>
                <input type="hidden" name="action" id="entryAction" value="<?= $submitAction ?>">
                <?php if ($editRecord): ?><input type="hidden" name="record_id" value="<?= (int) $editRecord['id'] ?>"><?php endif; ?>
                <input type="hidden" name="record_type" id="recordTypeInput" value="<?= htmlspecialchars($defaultRecordType) ?>">

                <?php if ($entryFormReadOnly): ?>
                <div class="records-edit-lock-banner" role="alert">
                    <strong>Record locked.</strong>
                    <?= htmlspecialchars($editLockBlocked['locked_by'] ?? 'Another staff member') ?> is editing this record right now. Close this form and try again in a few minutes.
                </div>
                <?php endif; ?>

                <div class="records-entry-scroll space-y-5">
                <fieldset class="records-entry-fieldset" <?= $entryFormReadOnly ? 'disabled' : '' ?>>
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Record Type</label>
                        <?php if ($entryFormEditMode): ?>
                        <p class="text-[11px] text-slate-500 mb-2">This is a <strong><?= htmlspecialchars(civilRecordTypeLabel($defaultRecordType)) ?></strong> record. Type cannot be changed while editing.</p>
                        <?php endif; ?>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 <?= $entryFormEditMode ? 'record-type-tabs--locked' : '' ?>" id="recordTypeTabs" <?= $entryFormEditMode ? 'data-record-type-locked="1"' : '' ?>>
                            <?php foreach (['birth' => ['label' => 'Birth', 'icon' => 'baby', 'active' => 'border-blue-500 bg-blue-50 text-blue-700'], 'death' => ['label' => 'Death', 'icon' => 'activity', 'active' => 'border-slate-400 bg-slate-50 text-slate-700'], 'marriage' => ['label' => 'Marriage', 'icon' => 'heart', 'active' => 'border-pink-400 bg-pink-50 text-pink-700']] as $t => $meta): ?>
                            <button type="button" data-record-type="<?= $t ?>"
                                class="record-type-tab rounded-xl border-2 px-3 py-3 text-center transition <?= $defaultRecordType === $t ? $meta['active'] : 'border-gray-200 text-gray-500 hover:border-gray-300' ?>"
                                <?= $entryFormEditMode ? 'disabled aria-disabled="true"' : '' ?>>
                                <?= lucideSvg($meta['icon'], 'records-type-tab-icon mx-auto mb-1') ?>
                                <span class="text-xs font-bold"><?= $meta['label'] ?></span>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>


                    <div class="records-entry-print-fill-bottom">
                        <?php renderRecordsEntryPrintFillSection($pdo, 'birth', $modalRecord, $defaultRecordType === 'birth', $entryFormEditMode); ?>
                        <?php renderRecordsEntryPrintFillSection($pdo, 'death', $modalRecord, $defaultRecordType === 'death', $entryFormEditMode); ?>
                        <?php renderRecordsEntryPrintFillSection($pdo, 'marriage', $modalRecord, $defaultRecordType === 'marriage', $entryFormEditMode); ?>
                    </div>
                </fieldset>

                <?php if ($entryFormEditMode && !$entryFormReadOnly): ?>
                <input type="hidden" name="edit_reason_category" id="editReasonCategory" value="">
                <input type="hidden" name="edit_reason_detail" id="editReasonDetail" value="">
                <?php endif; ?>
                </div>

                <div class="records-entry-footer">
                    <button type="button" class="border border-gray-200 rounded-xl py-3 px-4 text-sm font-bold text-gray-600 hover:bg-gray-50 close-modal sm:flex-1"><?= $entryFormReadOnly ? 'Close' : 'Cancel' ?></button>
                    <?php if (!$entryFormReadOnly): ?>
                    <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-3 text-sm font-bold inline-flex items-center justify-center gap-2">
                        <i data-lucide="save" class="w-4 h-4"></i> <?= $editRecord ? 'Update Record' : 'Add Record' ?>
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <?= renderCivilRecordEditReasonModalMarkup() ?>
    <?php endif; ?>

    <div id="recordUpdatesModal" class="records-updates-modal hidden" aria-hidden="true">
        <div class="records-updates-modal__backdrop" data-record-updates-close tabindex="-1" aria-hidden="true"></div>
        <div class="records-updates-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="recordUpdatesModalTitle">
            <div class="records-updates-modal__header">
                <div>
                    <h2 id="recordUpdatesModalTitle" class="records-updates-modal__title">Recent updates</h2>
                    <p class="records-updates-modal__subtitle">Edit policy and audit history for this registry entry</p>
                </div>
                <button type="button" class="records-updates-modal__close" data-record-updates-close aria-label="Close recent updates">
                    <?= lucideSvg('x', 'w-5 h-5') ?>
                </button>
            </div>
            <div id="recordUpdatesModalBody" class="records-updates-modal__body">
                <div id="recordUpdatesEditNotice" class="hidden" hidden>
                    <?= renderCivilRecordEditReasonNoticeMarkup() ?>
                </div>
                <div id="recordUpdatesHistoryPanel">
                    <?= renderCivilRecordUpdateHistoryMarkup($recordUpdateHistory) ?>
                </div>
            </div>
        </div>
    </div>

    <div id="viewModal" class="records-view-modal hidden" aria-hidden="true">
        <div class="records-view-modal__backdrop close-modal" aria-hidden="true"></div>
        <div class="records-view-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="viewModalTitle">
            <div class="records-view-modal__header">
                <div class="records-view-modal__heading">
                    <div class="records-view-modal__title-row">
                        <h2 id="viewModalTitle" class="records-detail-title">Record Details</h2>
                        <span id="viewModalBadge" class="records-type-badge"></span>
                    </div>
                    <p id="viewModalSubtitle" class="records-detail-meta"></p>
                </div>
                <div class="records-view-modal__header-actions">
                    <button type="button"
                            id="viewRecordUpdatesInfoBtn"
                            class="records-updates-info-btn records-view-modal__info-btn"
                            aria-label="Information - recent updates to this record"
                            title="Information - recent updates">
                        <?= lucideSvg('info', 'w-4 h-4') ?>
                    </button>
                    <button type="button" class="records-view-modal__close close-modal" aria-label="Close record details">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>
            <div id="viewContent" class="records-view-modal__body"></div>
            <?php if ($canManageCivilRecords): ?>
            <div class="records-view-modal__actions">
                <div class="records-view-print-group">
                    <a href="#" id="viewPrintCertificateLink" class="records-view-action records-view-action--print">
                        <?= lucideSvg('printer', 'w-4 h-4 shrink-0') ?>
                        Print Certificate
                    </a>
                    <a href="#" id="viewPrintCertificationLink" class="records-view-action records-view-action--print-secondary">
                        <?= lucideSvg('printer', 'w-4 h-4 shrink-0') ?>
                        Print Certification
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($canManageCivilRecords): ?>
    <div class="fixed inset-0 bg-black/40 z-50 hidden items-center justify-center p-4" id="importModal">
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-lg font-black text-slate-900" id="importModalTitle">Import Records</h2>
                <button type="button" class="text-gray-400 hover:text-gray-600 close-modal"><i data-lucide="x" class="w-5 h-5"></i></button>
            </div>
            <form method="POST" enctype="multipart/form-data" class="space-y-4" id="importForm" data-no-confirm data-no-loading action="<?= htmlspecialchars(buildAuthUrl('records.php')) ?>">
                <?= authFormField() ?>
                <input type="hidden" name="action" value="import_csv">
                <input type="hidden" name="import_type" id="importType" value="">
                <p class="text-xs text-gray-500" id="importColumnsHelp">Download the Excel template below, enter one record per row, then upload the CSV file. Large files (100k+ rows) are imported in batches in your browser so server upload limits do not apply. The sample row is skipped automatically.</p>
                <div>
                    <label class="block text-[11px] font-bold text-gray-700 mb-1">CSV File *</label>
                    <input type="file" name="csv_file" accept=".csv,text/csv,text/plain" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-blue-50 file:text-blue-600 file:font-bold file:text-xs">
                </div>
                <a href="#" id="importTemplateLink" download class="text-blue-600 text-[10px] font-bold flex items-center hover:underline">
                    <i data-lucide="download" class="w-3.5 h-3.5 mr-2"></i> Download Excel Template
                </a>
                <div id="importProgressWrap" class="hidden space-y-2 pt-1" aria-live="polite">
                    <p id="importProgressText" class="text-xs font-semibold text-slate-600">Preparing import…</p>
                    <div class="h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div id="importProgressBar" class="h-full bg-blue-600 transition-all duration-200" style="width:0%"></div>
                    </div>
                </div>
                <div class="flex gap-3 pt-2" id="importFormActions">
                    <button type="submit" id="importSubmitBtn" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-3 text-sm font-bold">Import Records</button>
                    <button type="button" class="flex-1 border border-gray-200 rounded-xl py-3 text-sm font-bold text-gray-600 hover:bg-gray-50 close-modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <?= actionResultScript($flash) ?>
    <?= pageConfigJson([
        'recordsAuthUrl' => buildAuthUrl('records.php'),
        'canManageCivilRecords' => $canManageCivilRecords,
        'printCertificateUrl' => buildAuthUrl('print_certificate.php'),
        'printCertificationUrl' => buildAuthUrl('print_certificate.php', ['kind' => 'certification']),
        'recordViewSections' => [
            'birth' => civilRecordViewSections('birth', $pdo),
            'death' => civilRecordViewSections('death', $pdo),
            'marriage' => civilRecordViewSections('marriage', $pdo),
        ],
        'openEntryModal' => $canManageCivilRecords && (bool) ($showModal || $editRecord),
        'defaultEntryType' => $editRecord['record_type'] ?? ($type !== 'all' ? $type : 'birth'),
        'editRecordId' => ($canManageCivilRecords && $editRecord) ? (int) $editRecord['id'] : null,
        'lockRecordType' => $canManageCivilRecords && (bool) $editRecord,
        'editLockHeld' => $canManageCivilRecords && $editLockHeld,
        'editLockBlocked' => $canManageCivilRecords ? $editLockBlocked : null,
        'recordsLockApiUrl' => buildAuthUrl('api/records.php'),
        'recordsImportApiUrl' => buildAuthUrl('api/records_import.php'),
        'locationsApiUrl' => buildAuthUrl('api/locations.php'),
        'manualEntryRequiredFields' => civilRecordManualEntryRequiredFieldsForJs(),
    ], 'records-config') ?>
    <?= scriptTag('core/page-config.js') ?>
    <?= scriptTag('core/admin-search.js') ?>
    <?= scriptTag('core/cascading-location.js') ?>
    <?= scriptTag('admin/civil-record-entry-validation.js') ?>
    <?= scriptTag('core/confirm.js') ?>
    <?= scriptTag('admin/records.js') ?>
    <?= lucideInitScript() ?>
</body>
</html>
