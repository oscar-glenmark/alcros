<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/system_errors.php';
require_once __DIR__ . '/includes/duplicati_backup.php';
require_once __DIR__ . '/includes/registry_backup.php';
require_once __DIR__ . '/includes/hosting.php';
require_once __DIR__ . '/includes/office_fees.php';
require_once __DIR__ . '/includes/document_request_relationship_requirements.php';
require_once __DIR__ . '/includes/scripts.php';
requireStaffLogin();
requirePageAccess('system_settings.php');

$activePage = 'system_settings.php';
$pdo = getDB();
ensureStaffProfileColumns($pdo);
$isAdmin = isAdmin();
$currentStaffId = staffId();

$adminSettingKeys = [
    'site_name', 'office_name', 'office_address', 'office_phone', 'office_email',
    'office_hours', 'office_head', 'social_facebook_url', 'social_instagram_url',
    'home_announcement_date', 'home_announcement_title', 'home_announcement_note',
    'maintenance_mode', 'allow_public_requests', 'notification_email',
    'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass',
    'sms_enabled', 'iprog_api_token', 'iprog_sender_name',
];

$defaults = [
    'site_name'               => 'ALCROS',
    'office_name'             => 'Local Civil Registrar Office (LCRO) of Aloran',
    'office_address'          => 'Municipal Hall, Aloran, Misamis Occidental, Philippines',
    'office_phone'            => '+639473212350',
    'office_email'            => 'aloran@gov.ph',
    'office_hours'            => '8:00 AM - 5:00 PM (Monday to Friday)',
    'office_head'             => 'ATTY. LOCAL CIVIL REGISTRAR',
    'home_announcement_date'  => '',
    'home_announcement_title' => 'Office Schedule',
    'home_announcement_note'  => 'Walk-in clients and online request claimants are served during these hours.',
    'social_facebook_url'     => 'https://www.facebook.com/aloranmisamis.occidental.9',
    'social_instagram_url'    => '',
    'maintenance_mode'        => '0',
    'allow_public_requests'   => '1',
    'notification_email'      => 'aloran@gov.ph',
    'smtp_host'               => 'smtp.gmail.com',
    'smtp_port'               => '587',
    'smtp_user'               => '',
    'smtp_pass'               => '',
    'sms_enabled'             => '0',
    'iprog_api_token'         => '',
    'iprog_sender_name'       => '',
];

function currentStaffRow(PDO $pdo, string $staffId): ?array
{
    $stmt = $pdo->prepare('SELECT staff_id, first_name, middle_name, last_name, email, recovery_gmail_2sv_confirmed, role, created_at, profile_photo_path FROM staff WHERE staff_id = ? LIMIT 1');
    $stmt->execute([$staffId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function adminCount(PDO $pdo): int
{
    return (int) $pdo->query("SELECT COUNT(*) FROM staff WHERE role = 'Administrator'")->fetchColumn();
}

if ($isAdmin && isset($_GET['action']) && $_GET['action'] === 'download_registry_backup') {
    $file = basename((string) ($_GET['file'] ?? ''));
    if ($file === '' || !preg_match('/^alcros-registry-\d{4}-\d{2}-\d{2}-\d{6}\.zip$/', $file)) {
        http_response_code(400);
        exit('Invalid backup file.');
    }
    $path = alcrosRegistryBackupArchiveDir() . DIRECTORY_SEPARATOR . $file;
    if (!is_file($path)) {
        http_response_code(404);
        exit('Backup file not found.');
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Content-Length: ' . (string) filesize($path));
    readfile($path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['settings_action'] ?? '';
    $handled = false;

    try {
        if ($action === 'update_profile') {
            $nameParts = normalizeCitizenNameParts(personNamePartsFromInput($_POST, 'profile_'));
            $email = normalizeStaffEmail(trim($_POST['profile_email'] ?? ''));
            if (($nameError = validatePersonNameParts($nameParts)) !== null) {
                throw new InvalidArgumentException($nameError);
            }
            if ($emailError = validateStaffEmail($email)) {
                throw new InvalidArgumentException($emailError);
            }
            if (staffEmailInUse($pdo, $email, $currentStaffId)) {
                throw new InvalidArgumentException('That Gmail address is already used by another staff account.');
            }
            $existing = currentStaffRow($pdo, $currentStaffId);
            $needs2sv = staffRecoveryGmailNeeds2svConfirmation($existing, $email);
            $confirmedCheckbox = !empty($_POST['recovery_gmail_2sv_confirmed']);
            if ($needs2sv && ($error2sv = validateStaffRecoveryGmail2sv($confirmedCheckbox))) {
                throw new InvalidArgumentException($error2sv);
            }
            $confirmedValue = staffRecoveryGmail2svConfirmedValue($existing, $email, $confirmedCheckbox);
            $profileChangedLabels = staffProfileChangedFieldLabels($existing, $nameParts, $email, $confirmedValue);
            $pdo->prepare('UPDATE staff SET first_name = ?, middle_name = ?, last_name = ?, email = ?, recovery_gmail_2sv_confirmed = ? WHERE staff_id = ?')
                ->execute([$nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name'], $email, $confirmedValue, $currentStaffId]);
            $_SESSION['staff_name'] = formatPersonName($nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name']);
            if ($profileChangedLabels !== []) {
                logActivity($currentStaffId, 'Profile Updated', staffProfileChangeActivityDetails($profileChangedLabels));
            }
            settingsFlashSet('success', $profileChangedLabels !== [] ? 'Your profile has been updated.' : 'No profile changes were detected.');
            $handled = true;
        } elseif ($action === 'change_password') {
            $current = $_POST['current_password'] ?? '';
            $newPass = $_POST['new_password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';
            $stmt = $pdo->prepare('SELECT password_hash FROM staff WHERE staff_id = ?');
            $stmt->execute([$currentStaffId]);
            $hash = $stmt->fetchColumn();
            if (!$hash || !password_verify($current, $hash)) {
                throw new InvalidArgumentException('Current password is incorrect.');
            }
            if ($passwordError = validatePasswordStrength($newPass)) {
                throw new InvalidArgumentException($passwordError);
            }
            if ($newPass !== $confirm) {
                throw new InvalidArgumentException('New passwords do not match.');
            }
            $pdo->prepare('UPDATE staff SET password_hash = ? WHERE staff_id = ?')->execute([password_hash($newPass, PASSWORD_DEFAULT), $currentStaffId]);
            staffRememberMeRevokeAllForStaff($pdo, $currentStaffId);
            logActivity($currentStaffId, 'Password Changed', 'Updated account password');
            settingsFlashSet('success', 'Password changed successfully.');
            $handled = true;
        } elseif ($action === 'save_settings' && $isAdmin) {
            $smtpPassMask = '••••••••••••••••';
            $settingsChanged = false;
            $feesBefore = getSetting(officeFeesSettingKey(), '');
            $requirementsBefore = getSetting(officeRequirementsSettingKey(), '');
            $docRelReqBefore = getSetting(documentRequestRelationshipSettingKey(), '');

            foreach ($adminSettingKeys as $key) {
                $default = $defaults[$key] ?? '';
                if (in_array($key, ['maintenance_mode', 'allow_public_requests', 'sms_enabled'], true)) {
                    $newValue = isset($_POST[$key]) ? '1' : '0';
                    if (setSettingIfChanged($key, $newValue, $default)) {
                        $settingsChanged = true;
                    }
                } elseif ($key === 'smtp_pass') {
                    $smtpPass = (string) ($_POST['smtp_pass'] ?? '');
                    if ($smtpPass !== '' && $smtpPass !== $smtpPassMask) {
                        if (setSettingIfChanged($key, $smtpPass, $default)) {
                            $settingsChanged = true;
                        }
                    }
                } elseif ($key === 'iprog_api_token') {
                    $apiKey = (string) ($_POST['iprog_api_token'] ?? '');
                    if ($apiKey !== '' && $apiKey !== $smtpPassMask) {
                        if (setSettingIfChanged($key, $apiKey, $default)) {
                            $settingsChanged = true;
                        }
                    }
                } elseif ($key === 'iprog_sender_name') {
                    $newValue = trim((string) ($_POST[$key] ?? ''));
                    if (setSettingIfChanged($key, $newValue, $default)) {
                        $settingsChanged = true;
                    }
                } elseif (isset($_POST[$key])) {
                    $newValue = trim((string) $_POST[$key]);
                    if (setSettingIfChanged($key, $newValue, $default)) {
                        $settingsChanged = true;
                    }
                }
            }
            if (getSetting('maintenance_mode', '0') === '1') {
                if (setSettingIfChanged('allow_public_requests', '0', $defaults['allow_public_requests'] ?? '1')) {
                    $settingsChanged = true;
                }
            } elseif (getSetting('allow_public_requests', '0') === '1') {
                if (setSettingIfChanged('maintenance_mode', '0', $defaults['maintenance_mode'] ?? '0')) {
                    $settingsChanged = true;
                }
            }
            if (isset($_POST['office_fees']) && is_array($_POST['office_fees'])) {
                saveOfficeFeesFromPost($_POST['office_fees']);
                if (getSetting(officeFeesSettingKey(), '') !== $feesBefore) {
                    $settingsChanged = true;
                }
            }
            if (isset($_POST['office_requirements']) && is_array($_POST['office_requirements'])) {
                saveOfficeRequirementsFromPost($_POST['office_requirements']);
                if (getSetting(officeRequirementsSettingKey(), '') !== $requirementsBefore) {
                    $settingsChanged = true;
                }
            }
            if (isset($_POST['document_request_relationship_req']) && is_array($_POST['document_request_relationship_req'])) {
                saveDocumentRequestRelationshipRequirementsFromPost($_POST['document_request_relationship_req']);
                if (getSetting(documentRequestRelationshipSettingKey(), '') !== $docRelReqBefore) {
                    $settingsChanged = true;
                }
            }
            if ($settingsChanged) {
                logActivity($currentStaffId, 'Settings Updated', 'System configuration saved');
            }
            require_once __DIR__ . '/includes/sms.php';
            purgeObsoleteSemaphoreSettings();
            require_once __DIR__ . '/includes/system_errors.php';
            clearStaleEmailConfigFailureAlert($pdo);
            clearStaleEmailDeliveryFailureAlert($pdo);
            syncSystemErrors($pdo);
            settingsFlashSet(
                'success',
                $settingsChanged
                    ? 'System settings saved successfully.'
                    : 'No setting changes were detected - activity log was not updated.'
            );
            $handled = true;
        } elseif ($action === 'add_staff' && $isAdmin) {
            $nameParts = normalizeCitizenNameParts(personNamePartsFromInput($_POST, 'staff_'));
            $newStaffId = strtoupper(trim($_POST['staff_id_new'] ?? ''));
            $email = normalizeStaffEmail(trim($_POST['staff_email'] ?? ''));
            $password = $_POST['staff_password'] ?? '';
            $role = $_POST['staff_role'] ?? 'Staff';
            $validRoles = ['Staff', 'Administrator'];
            if (!in_array($role, $validRoles, true)) {
                $role = 'Staff';
            }
            if (($nameError = validatePersonNameParts($nameParts)) !== null || $newStaffId === '' || $password === '') {
                throw new InvalidArgumentException($nameError ?? 'Please fill in name, staff ID, and password.');
            }
            if ($emailError = validateStaffEmail($email)) {
                throw new InvalidArgumentException($emailError);
            }
            if (staffEmailInUse($pdo, $email)) {
                throw new InvalidArgumentException('That Gmail address is already used by another staff account.');
            }
            if ($error2sv = validateStaffRecoveryGmail2sv(!empty($_POST['recovery_gmail_2sv_confirmed']))) {
                throw new InvalidArgumentException($error2sv);
            }
            if ($passwordError = validatePasswordStrength($password)) {
                throw new InvalidArgumentException($passwordError);
            }
            if (!preg_match('/^[A-Z0-9\-]+$/', $newStaffId)) {
                throw new InvalidArgumentException('Staff ID may only contain letters, numbers, and hyphens.');
            }
            $exists = $pdo->prepare('SELECT COUNT(*) FROM staff WHERE staff_id = ?');
            $exists->execute([$newStaffId]);
            if ((int) $exists->fetchColumn() > 0) {
                throw new InvalidArgumentException('That Staff ID is already in use.');
            }
            $pdo->prepare('INSERT INTO staff (staff_id, first_name, middle_name, last_name, email, recovery_gmail_2sv_confirmed, password_hash, role) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
                ->execute([$newStaffId, $nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name'], $email, password_hash($password, PASSWORD_DEFAULT), $role]);
            $displayName = formatPersonName($nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name']);
            logActivity($currentStaffId, 'Staff Added', "Created staff account $newStaffId ($displayName)");
            settingsFlashSet('success', "Staff member $displayName ($newStaffId) added successfully.");
            $handled = true;
        } elseif ($action === 'update_staff' && $isAdmin) {
            $targetId = strtoupper(trim($_POST['target_staff_id'] ?? ''));
            $nameParts = normalizeCitizenNameParts(personNamePartsFromInput($_POST, 'edit_staff_'));
            $email = normalizeStaffEmail(trim($_POST['edit_staff_email'] ?? ''));
            $role = $_POST['edit_staff_role'] ?? 'Staff';
            $validRoles = ['Staff', 'Administrator'];
            if (!in_array($role, $validRoles, true)) {
                $role = 'Staff';
            }
            if ($targetId === '' || ($nameError = validatePersonNameParts($nameParts)) !== null) {
                throw new InvalidArgumentException($nameError ?? 'Staff ID and name are required.');
            }
            if ($emailError = validateStaffEmail($email)) {
                throw new InvalidArgumentException($emailError);
            }
            if (staffEmailInUse($pdo, $email, $targetId)) {
                throw new InvalidArgumentException('That Gmail address is already used by another staff account.');
            }
            $existing = currentStaffRow($pdo, $targetId);
            $needs2sv = staffRecoveryGmailNeeds2svConfirmation($existing, $email);
            $confirmedCheckbox = !empty($_POST['recovery_gmail_2sv_confirmed']);
            if ($needs2sv && ($error2sv = validateStaffRecoveryGmail2sv($confirmedCheckbox))) {
                throw new InvalidArgumentException($error2sv);
            }
            $confirmedValue = staffRecoveryGmail2svConfirmedValue($existing, $email, $confirmedCheckbox);
            if ($targetId === $currentStaffId && $role !== 'Administrator' && adminCount($pdo) <= 1) {
                throw new InvalidArgumentException('Cannot demote the last administrator account.');
            }
            $staffChangedLabels = staffProfileChangedFieldLabels($existing, $nameParts, $email, $confirmedValue, $role);
            $pdo->prepare('UPDATE staff SET first_name = ?, middle_name = ?, last_name = ?, email = ?, recovery_gmail_2sv_confirmed = ?, role = ? WHERE staff_id = ?')
                ->execute([$nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name'], $email, $confirmedValue, $role, $targetId]);
            if ($targetId === $currentStaffId) {
                $_SESSION['staff_name'] = formatPersonName($nameParts['first_name'], $nameParts['middle_name'], $nameParts['last_name']);
            }
            if ($staffChangedLabels !== []) {
                logActivity(
                    $currentStaffId,
                    'Staff Updated',
                    'Updated account ' . $targetId . ' (' . implode(', ', $staffChangedLabels) . ')'
                );
            }
            settingsFlashSet(
                'success',
                $staffChangedLabels !== []
                    ? "Staff account $targetId updated."
                    : "No changes were detected for $targetId."
            );
            $handled = true;
        } elseif ($action === 'reset_staff_password' && $isAdmin) {
            $targetId = strtoupper(trim($_POST['target_staff_id'] ?? ''));
            $newPass = $_POST['reset_password'] ?? '';
            if ($targetId === '' || strlen($newPass) < passwordMinLength()) {
                throw new InvalidArgumentException('Staff ID and a password of at least ' . passwordMinLength() . ' characters are required.');
            }
            if ($passwordError = validatePasswordStrength($newPass)) {
                throw new InvalidArgumentException($passwordError);
            }
            $pdo->prepare('UPDATE staff SET password_hash = ? WHERE staff_id = ?')->execute([password_hash($newPass, PASSWORD_DEFAULT), $targetId]);
            staffRememberMeRevokeAllForStaff($pdo, $targetId);
            logActivity($currentStaffId, 'Password Reset', "Reset password for $targetId");
            settingsFlashSet('success', "Password reset for $targetId.");
            $handled = true;
        } elseif ($action === 'upload_staff_photo' && $isAdmin) {
            $targetId = strtoupper(trim($_POST['target_staff_id'] ?? ''));
            if ($targetId === '') {
                throw new InvalidArgumentException('Staff ID is required.');
            }
            $exists = $pdo->prepare('SELECT profile_photo_path FROM staff WHERE staff_id = ?');
            $exists->execute([$targetId]);
            $existing = $exists->fetch();
            if (!$existing) {
                throw new InvalidArgumentException('Staff account not found.');
            }
            $newPath = saveStaffPhotoUpload($_FILES['staff_photo'] ?? [], $targetId);
            if (!$newPath) {
                throw new InvalidArgumentException('Invalid photo. Use JPG, PNG, or WEBP (max upload size allowed by server).');
            }
            deleteStaffPhotoFile($existing['profile_photo_path'] ?? null);
            $pdo->prepare('UPDATE staff SET profile_photo_path = ? WHERE staff_id = ?')->execute([$newPath, $targetId]);
            logActivity($currentStaffId, 'Staff Photo Updated', "Updated profile photo for $targetId");
            settingsFlashSet('success', "Profile photo updated for $targetId.");
            $handled = true;
        } elseif ($action === 'remove_staff_photo' && $isAdmin) {
            $targetId = strtoupper(trim($_POST['target_staff_id'] ?? ''));
            if ($targetId === '') {
                throw new InvalidArgumentException('Staff ID is required.');
            }
            $photoStmt = $pdo->prepare('SELECT profile_photo_path FROM staff WHERE staff_id = ?');
            $photoStmt->execute([$targetId]);
            $photo = $photoStmt->fetchColumn();
            if (!$photo) {
                throw new InvalidArgumentException('Staff account not found.');
            }
            deleteStaffPhotoFile($photo ?: null);
            $pdo->prepare('UPDATE staff SET profile_photo_path = NULL WHERE staff_id = ?')->execute([$targetId]);
            logActivity($currentStaffId, 'Staff Photo Removed', "Removed profile photo for $targetId");
            settingsFlashSet('success', "Profile photo removed for $targetId.");
            $handled = true;
        } elseif ($action === 'remove_staff' && $isAdmin) {
            $targetId = strtoupper(trim($_POST['target_staff_id'] ?? ''));
            if ($targetId === '') {
                throw new InvalidArgumentException('Staff ID is required.');
            }
            if ($targetId === $currentStaffId) {
                throw new InvalidArgumentException('You cannot remove your own account.');
            }
            $targetStmt = $pdo->prepare('SELECT role FROM staff WHERE staff_id = ?');
            $targetStmt->execute([$targetId]);
            $targetRole = $targetStmt->fetchColumn();
            if (!$targetRole) {
                throw new InvalidArgumentException('Staff account not found.');
            }
            if ($targetRole === 'Administrator' && adminCount($pdo) <= 1) {
                throw new InvalidArgumentException('Cannot remove the last administrator account.');
            }
            $photoStmt = $pdo->prepare('SELECT profile_photo_path FROM staff WHERE staff_id = ?');
            $photoStmt->execute([$targetId]);
            deleteStaffPhotoFile($photoStmt->fetchColumn() ?: null);
            $pdo->prepare('DELETE FROM staff WHERE staff_id = ?')->execute([$targetId]);
            logActivity($currentStaffId, 'Staff Removed', "Removed staff account $targetId");
            settingsFlashSet('success', "Staff account $targetId removed.");
            $handled = true;
        } elseif ($action === 'clear_old_logs' && $isAdmin) {
            $days = max(7, (int) ($_POST['log_retention_days'] ?? 30));
            $stmt = $pdo->prepare('DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)');
            $stmt->execute([$days]);
            $deleted = $stmt->rowCount();
            logActivity($currentStaffId, 'Logs Cleared', "Removed $deleted activity log entries older than $days days");
            settingsFlashSet('success', "Cleared $deleted old activity log entries.");
            $handled = true;
        } elseif ($action === 'fix_system_error' && $isAdmin) {
            $errorKey = trim((string) ($_POST['error_key'] ?? ''));
            if ($errorKey === '' || !preg_match('/^[a-z0-9\-]+$/', $errorKey)) {
                throw new InvalidArgumentException('Invalid system error.');
            }
            $result = runSystemErrorFix($pdo, $errorKey, $currentStaffId);
            if (empty($result['already_resolved'])) {
                settingsFlashSet($result['ok'] ? 'success' : 'error', $result['message']);
            }
            $handled = true;
        } elseif ($action === 'clear_data' && $isAdmin) {
            $types = is_array($_POST['clear_data_types'] ?? null) ? $_POST['clear_data_types'] : [];
            $clearAllQueue = in_array('queue_tickets', $types, true);
            $results = clearOperationalData($pdo, $types, $currentStaffId);

            $parts = [];
            if ($results['document_requests'] > 0) {
                $parts[] = $results['document_requests'] . ' request(s)';
            }
            if ($results['appointments'] > 0) {
                $parts[] = $results['appointments'] . ' appointment(s)';
            }
            if ($results['civil_records'] > 0) {
                $parts[] = $results['civil_records'] . ' civil record(s)';
            }
            if ($results['queue_tickets'] > 0) {
                $parts[] = $results['queue_tickets'] . ($clearAllQueue ? ' queue ticket(s)' : ' related queue ticket(s)');
            }
            if ($results['queue_announcements'] > 0) {
                $parts[] = $results['queue_announcements'] . ' queue announcement(s)';
            }
            if ($results['certification_prints'] > 0) {
                $parts[] = $results['certification_prints'] . ' certification print log(s)';
            }
            if ($results['certificate_prints'] > 0) {
                $parts[] = $results['certificate_prints'] . ' certificate print log(s)';
            }

            settingsFlashSet(
                'success',
                $parts !== []
                    ? 'Cleared ' . implode(', ', $parts) . '.'
                    : 'No records found for the selected data types.'
            );
            $handled = true;
        } elseif ($action === 'save_registry_backup_settings' && $isAdmin) {
            $enabled = isset($_POST['registry_backup_enabled']) ? '1' : '0';
            $retention = max(3, min(90, (int) ($_POST['registry_backup_retention_count'] ?? 14)));
            $publicUrl = rtrim(trim((string) ($_POST['registry_backup_public_url'] ?? '')), '/');
            if ($publicUrl !== '' && !preg_match('#^https?://#i', $publicUrl)) {
                throw new InvalidArgumentException('Public site URL must start with http:// or https://');
            }
            setSetting('registry_backup_enabled', $enabled);
            setSetting('registry_backup_retention_count', (string) $retention);
            setSetting('registry_backup_public_url', $publicUrl);

            $gdriveEnabled = isset($_POST['registry_backup_gdrive_enabled']) ? '1' : '0';
            $gdriveFolder = alcrosGoogleDriveNormalizeFolderId(
                trim((string) ($_POST['registry_backup_gdrive_folder_id'] ?? ''))
            );
            $gdriveRetention = max(0, min(90, (int) ($_POST['registry_backup_gdrive_retention_count'] ?? 0)));
            setSetting('registry_backup_gdrive_enabled', $gdriveEnabled);
            setSetting('registry_backup_gdrive_folder_id', $gdriveFolder);
            setSetting('registry_backup_gdrive_retention_count', (string) $gdriveRetention);
            setSetting('registry_backup_gdrive_auth_mode', 'oauth');
            $oauthClientId = trim((string) ($_POST['registry_backup_gdrive_oauth_client_id'] ?? ''));
            if ($oauthClientId !== '') {
                setSetting('registry_backup_gdrive_oauth_client_id', $oauthClientId);
            }
            $oauthSecret = (string) ($_POST['registry_backup_gdrive_oauth_client_secret'] ?? '');
            $oauthSecretMask = '••••••••••••••••';
            if ($oauthSecret !== '' && $oauthSecret !== $oauthSecretMask) {
                setSetting('registry_backup_gdrive_oauth_client_secret', trim($oauthSecret));
            }
            setSetting('registry_backup_gdrive_token', '');
            setSetting('registry_backup_gdrive_token_exp', '0');

            if ($enabled === '1' && trim(getSetting('registry_backup_cron_token', '')) === '') {
                alcrosRegistryBackupRegenerateCronToken();
            }
            settingsFlashSet('success', 'Registry backup settings saved.');
            $handled = true;
        } elseif ($action === 'test_registry_gdrive' && $isAdmin) {
            $test = alcrosGoogleDriveTestConnection();
            settingsFlashSet($test['ok'] ? 'success' : 'error', $test['message']);
            $handled = true;
        } elseif ($action === 'disconnect_registry_gdrive_oauth' && $isAdmin) {
            alcrosGoogleDriveDisconnectOAuth();
            settingsFlashSet('success', 'Google Drive sign-in removed from this server.');
            $handled = true;
        } elseif ($action === 'regenerate_registry_backup_token' && $isAdmin) {
            alcrosRegistryBackupRegenerateCronToken();
            settingsFlashSet('success', 'Registry backup URL token regenerated. Update your SmarterASP Schedule Task URL.');
            $handled = true;
        } elseif ($action === 'run_registry_backup' && $isAdmin) {
            $result = runAlcrosRegistryHostedBackup($pdo, false);
            if (!$result['ok']) {
                throw new InvalidArgumentException($result['message']);
            }
            logActivity(
                $currentStaffId,
                'Backup Created',
                'Registry backup zip ' . ($result['filename'] ?? '') . ' (' . alcrosFormatBytes((int) ($result['bytes'] ?? 0)) . ')'
            );
            $flashMsg = (string) ($result['message'] ?? ('Registry backup created: ' . (string) ($result['filename'] ?? '')));
            $gdriveResult = $result['gdrive'] ?? null;
            $flashType = 'success';
            if (is_array($gdriveResult) && ($gdriveResult['ok'] ?? false) !== true) {
                $flashType = 'warning';
            } elseif (is_array($gdriveResult) && trim((string) ($gdriveResult['prune_warning'] ?? '')) !== '') {
                $flashType = 'warning';
            }
            settingsFlashSet($flashType, $flashMsg);
            $handled = true;
        }
    } catch (InvalidArgumentException $e) {
        settingsFlashSet('error', $e->getMessage());
        $handled = true;
    } catch (PDOException $e) {
        settingsFlashSet('error', 'Could not complete the action. Please try again.');
        $handled = true;
    }

    if ($handled) {
        $tab = $_POST['active_tab'] ?? 'my-account';
        $redirectParams = array_filter(['tab' => $tab !== 'my-account' ? $tab : null]);
        if ($tab === 'admin-tools' && !empty($_POST['admin_sub'])) {
            $redirectParams['admin_sub'] = $_POST['admin_sub'];
        }
        redirectWithAuth('system_settings.php', $redirectParams);
    }
}

$settings = [];
foreach ($adminSettingKeys as $key) {
    $settings[$key] = getSetting($key, $defaults[$key] ?? '');
}
$smtpPassMask = '••••••••••••••••';
$smtpPassSaved = trim($settings['smtp_pass']) !== '';
$iprogTokenSaved = trim($settings['iprog_api_token']) !== '';
$officeFeesForm = $isAdmin ? officeFeesFormValues() : [];
$officeRequirementsForm = $isAdmin ? officeRequirementsFormValues() : [];
$documentRequestRelationshipForm = $isAdmin ? documentRequestRelationshipRequirementsFormValues() : [];
$documentRequestRelationshipCatalog = documentRequestRelationshipCatalog();

$currentStaff = currentStaffRow($pdo, $currentStaffId);
$profileNeeds2svConfirmation = staffRecoveryGmailNeeds2svConfirmation($currentStaff, (string) ($currentStaff['email'] ?? ''));
$staffMembers = $pdo->query('SELECT staff_id, first_name, middle_name, last_name, email, recovery_gmail_2sv_confirmed, role, created_at, profile_photo_path FROM staff ORDER BY created_at ASC')->fetchAll();
$systemStats = $isAdmin ? getSystemStats($pdo) : [];
$recentLogs = [];
if ($isAdmin) {
    $recentLogsRaw = $pdo->query(
        'SELECT staff_id, action, details, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 8'
    )->fetchAll();
    $recentLogs = enrichActivityLogsForDisplay($pdo, $recentLogsRaw, 'w-8 h-8 text-[10px]');
}

$lastLoginStmt = $pdo->prepare(
    "SELECT created_at FROM activity_logs WHERE staff_id = ? AND action = 'Staff Login' ORDER BY created_at DESC LIMIT 1 OFFSET 1"
);
$lastLoginStmt->execute([$currentStaffId]);
$lastLogin = $lastLoginStmt->fetchColumn();

$activeTab = $_GET['tab'] ?? 'my-account';
$validTabs = $isAdmin
    ? ['my-account', 'security', 'account-management', 'system-configuration', 'admin-tools']
    : ['my-account', 'security', 'notifications'];
if (!in_array($activeTab, $validTabs, true)) {
    $activeTab = 'my-account';
}

$adminToolsSection = 'overview';
if ($isAdmin && $activeTab === 'admin-tools') {
    $adminToolsSection = $_GET['admin_sub'] ?? 'overview';
    if (!in_array($adminToolsSection, ['overview', 'activity', 'backup', 'maintenance'], true)) {
        $adminToolsSection = 'overview';
    }
}

$backupManifest = $isAdmin ? alcrosDuplicatiReadManifest() : null;
$backupDir = $isAdmin ? alcrosDuplicatiBackupDir() : '';
$backupDirSize = ($isAdmin && is_dir($backupDir)) ? alcrosDuplicatiBackupDirSize($backupDir) : 0;
$backupLastRun = $isAdmin ? getSetting('backup_last_run_at', '') : '';
$backupLastStatus = $isAdmin ? getSetting('backup_last_status', '') : '';
$backupLastMessage = $isAdmin ? getSetting('backup_last_message', '') : '';
$backupRecordCount = $isAdmin
    ? (int) ($backupManifest['counts']['civil_records'] ?? ($systemStats['civil_records']['count'] ?? 0))
    : 0;
$backupStaffCount = $isAdmin
    ? (int) ($backupManifest['counts']['staff'] ?? count($staffMembers))
    : 0;
$appointmentRemindersCronUrl = $isAdmin ? alcrosAppointmentRemindersCronUrl() : '';
$registryBackupCronUrl = $isAdmin ? alcrosRegistryBackupCronUrl() : '';
$registryBackupEnabled = $isAdmin && alcrosRegistryBackupEnabled();
$registryBackupRetention = $isAdmin ? alcrosRegistryBackupRetentionCount() : 14;
$registryBackupPublicUrl = $isAdmin ? trim(getSetting('registry_backup_public_url', '')) : '';
$registryBackupLastRun = $isAdmin ? getSetting('registry_backup_last_run_at', '') : '';
$registryBackupLastStatus = $isAdmin ? getSetting('registry_backup_last_status', '') : '';
$registryBackupLastMessage = $isAdmin ? getSetting('registry_backup_last_message', '') : '';
$registryBackupLastFilename = $isAdmin ? getSetting('registry_backup_last_filename', '') : '';
$registryBackupArchives = $isAdmin ? alcrosRegistryBackupListArchives() : [];
$registryBackupGdriveEnabled = $isAdmin && alcrosGoogleDriveBackupEnabled();
$registryBackupGdriveFolderId = $isAdmin ? alcrosGoogleDriveFolderId() : '';
$registryBackupGdriveRetention = $isAdmin ? (int) getSetting('registry_backup_gdrive_retention_count', '0') : 0;
$registryBackupGdriveLastRun = $isAdmin ? getSetting('registry_backup_gdrive_last_run_at', '') : '';
$registryBackupGdriveLastStatus = $isAdmin ? getSetting('registry_backup_gdrive_last_status', '') : '';
$registryBackupGdriveLastMessage = $isAdmin ? getSetting('registry_backup_gdrive_last_message', '') : '';
$registryBackupGdriveOAuthClientId = $isAdmin ? alcrosGoogleDriveOAuthClientId() : '';
$registryBackupGdriveOAuthSecretSaved = $isAdmin && trim(getSetting('registry_backup_gdrive_oauth_client_secret', '')) !== '';
$registryBackupGdriveOAuthSecret = $isAdmin ? getSetting('registry_backup_gdrive_oauth_client_secret', '') : '';
$registryBackupGdriveOAuthConnected = $isAdmin && alcrosGoogleDriveOAuthConnected();
$registryBackupGdriveOAuthEmail = $isAdmin ? alcrosGoogleDriveOAuthConnectedEmail() : '';
$registryBackupGdriveConnectUrl = $isAdmin ? buildAuthUrl('api/gdrive_oauth.php', ['action' => 'start']) : '';
$showHostedScheduleTasks = $isAdmin;

function settingsPageUrl(string $tab, ?string $adminSub = null): string
{
    return buildAuthUrl('system_settings.php', array_filter([
        'tab' => $tab !== 'my-account' ? $tab : null,
        'admin_sub' => ($tab === 'admin-tools' && $adminSub && $adminSub !== 'overview') ? $adminSub : null,
    ]));
}

if ($isAdmin) {
    alcrosGoogleDriveOAuthConsumePendingFlash();
}
$flash = settingsFlashGet();
$activeSystemErrors = [];
if ($isAdmin) {
    syncSystemErrors($pdo);
    $activeSystemErrors = fetchActiveSystemErrors($pdo);
}
$currentStaffPhoto = $currentStaff['profile_photo_path'] ?? null;

$pageTitle = $isAdmin ? 'System Settings' : 'My Settings';
$pageSubtitle = 'Manage your account, security' . ($isAdmin ? ', staff accounts, and system-wide configurations' : ', and credentials') . '.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?= faviconLinkTag() ?>    <title><?= $isAdmin ? 'System Settings' : 'My Settings' ?> - ALCROS</title>
    <?= vendorScriptTag('tailwindcss.js') ?>
    <?= interFontTags() ?>
    <?= publicStylesheet('password-toggle') ?>
    <?= adminLayoutHeadStyles('settings') ?>
    <?= vendorScriptTag('lucide.min.js') ?>
</head>
<body class="flex min-h-screen">
    <?php require __DIR__ . '/includes/admin_sidebar.php'; ?>

    <main class="admin-main flex-1 flex flex-col bg-[#f8fafc]">
        <?php require __DIR__ . '/includes/admin_header.php'; ?>

        <div class="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto admin-page-wrap">
            <div class="settings-layout grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start min-w-0">
                <aside class="settings-tab-nav lg:col-span-3 bg-white border border-slate-100 rounded-2xl p-3 shadow-sm space-y-1 min-w-0">
                    <?php
                    $tabs = [
                        'my-account' => ['label' => 'My Account', 'icon' => 'user', 'desc' => ''],
                        'security'   => ['label' => 'Security', 'icon' => 'shield', 'desc' => ''],
                    ];
                    if (!$isAdmin) {
                        $tabs['notifications'] = ['label' => 'Notifications', 'icon' => 'bell-ring', 'desc' => 'Desktop pop-up alerts'];
                    }
                    if ($isAdmin) {
                        $tabs['account-management']   = ['label' => 'Staff Accounts', 'icon' => 'users', 'desc' => 'Portal users & roles'];
                        $tabs['system-configuration'] = ['label' => 'Configuration', 'icon' => 'settings', 'desc' => 'Office, fees & requirements'];
                        $tabs['admin-tools']          = ['label' => 'Admin Tools', 'icon' => 'wrench', 'desc' => 'Stats, logs & upkeep'];
                    }
                    foreach ($tabs as $id => $tab):
                    ?>
                    <button type="button" data-tab="<?= htmlspecialchars($id) ?>" id="btn-<?= $id ?>"
                        class="tab-btn w-full flex items-start gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-600 text-left <?= $activeTab === $id ? 'active' : '' ?>">
                        <i data-lucide="<?= $tab['icon'] ?>" class="w-4 h-4 text-slate-500 shrink-0 mt-0.5"></i>
                        <span class="min-w-0">
                            <span class="tab-label block"><?= htmlspecialchars($tab['label']) ?></span>
                            <?php if (!empty($tab['desc'])): ?>
                            <span class="tab-desc"><?= htmlspecialchars($tab['desc']) ?></span>
                            <?php endif; ?>
                        </span>
                    </button>
                    <?php endforeach; ?>
                    <div class="settings-tab-nav-footer pt-2 mt-2 border-t border-slate-100">
                        <button type="button" data-logout-trigger
                            class="settings-tab-logout w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-left text-red-600 hover:bg-red-50 transition-colors">
                            <i data-lucide="log-out" class="w-4 h-4 shrink-0"></i>
                            <span>Logout</span>
                        </button>
                    </div>
                </aside>

                <section class="settings-tab-panel lg:col-span-9 space-y-6 min-w-0">
                    <!-- MY ACCOUNT -->
                    <div id="tab-my-account" class="tab-content bg-white border border-slate-100 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm <?= $activeTab !== 'my-account' ? 'hidden' : '' ?>">
                        <div class="flex items-center gap-5 mb-8">
                            <?= renderStaffAvatar($currentStaffPhoto, personNameFromRow($currentStaff ?? []), 'w-20 h-20 text-3xl', 'rounded-2xl') ?>
                            <div>
                                <h2 class="text-2xl font-bold text-slate-900"><?= htmlspecialchars(personNameFromRow($currentStaff ?? [])) ?></h2>
                                <p class="text-sm text-slate-400 font-mono"><?= htmlspecialchars($currentStaffId) ?></p>
                                <span class="inline-block mt-2 text-[10px] font-bold uppercase px-2 py-0.5 rounded <?= staffRole() === 'Staff' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>"><?= htmlspecialchars(staffRole()) ?></span>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                            <div class="bg-slate-50 rounded-xl p-4 border border-slate-100">
                                <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Member Since</p>
                                <p class="text-sm font-semibold text-slate-800"><?= formatRecordDate(substr($currentStaff['created_at'] ?? '', 0, 10)) ?></p>
                            </div>
                            <div class="bg-slate-50 rounded-xl p-4 border border-slate-100">
                                <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Last Login</p>
                                <p class="text-sm font-semibold text-slate-800"><?= $lastLogin ? formatRecordDate(substr($lastLogin, 0, 10)) : 'First session' ?></p>
                            </div>
                            <div class="bg-slate-50 rounded-xl p-4 border border-slate-100">
                                <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Recovery Gmail</p>
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($currentStaff['email'] ?? 'Not set') ?></p>
                                <?php if (!empty($currentStaff['email'])): ?>
                                <p class="text-[10px] mt-1 <?= !empty($currentStaff['recovery_gmail_2sv_confirmed']) ? 'text-emerald-600' : 'text-amber-600' ?> font-semibold">
                                    <?= !empty($currentStaff['recovery_gmail_2sv_confirmed']) ? '2-Step Verification confirmed' : '2-Step Verification not confirmed - password reset disabled' ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="bg-slate-50 rounded-xl p-4 border border-slate-100">
                                <p class="text-[10px] font-bold text-slate-400 uppercase mb-1">Office Email</p>
                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($settings['office_email']) ?></p>
                            </div>
                        </div>

                        <form method="POST" class="space-y-4 border-t border-slate-100 pt-6" id="profileForm">
                            <?= authFormField() ?>
                            <input type="hidden" name="settings_action" value="update_profile">
                            <input type="hidden" name="active_tab" value="my-account">
                            <h3 class="text-sm font-bold text-slate-900">Update Name</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:col-span-2">
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">First Name</label>
                                    <input type="text" name="profile_first_name" required value="<?= htmlspecialchars($currentStaff['first_name'] ?? '') ?>"
                                        class="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Middle Name</label>
                                    <input type="text" name="profile_middle_name" value="<?= htmlspecialchars($currentStaff['middle_name'] ?? '') ?>"
                                        placeholder="Leave blank if none"
                                        autocomplete="additional-name"
                                        class="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Last Name</label>
                                    <input type="text" name="profile_last_name" required value="<?= htmlspecialchars($currentStaff['last_name'] ?? '') ?>"
                                        class="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-[min(100%,11rem)_minmax(0,1fr)] gap-4">
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Staff ID</label>
                                    <input type="text" readonly value="<?= htmlspecialchars($currentStaffId) ?>"
                                        class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-500 font-mono">
                                </div>
                                <div class="min-w-0">
                                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Recovery Gmail *</label>
                                    <input type="email" name="profile_email" id="profileEmail" required value="<?= htmlspecialchars($currentStaff['email'] ?? '') ?>" placeholder="you@gmail.com"
                                        data-original-email="<?= htmlspecialchars($currentStaff['email'] ?? '') ?>"
                                        data-2sv-confirmed="<?= !empty($currentStaff['recovery_gmail_2sv_confirmed']) ? '1' : '0' ?>"
                                        class="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
                                    <p class="text-[10px] text-slate-400 mt-1">Must be a Gmail account with <strong>Google 2-Step Verification</strong> already enabled. Used for password reset codes.</p>
                                </div>
                                <div class="sm:col-span-2 col-span-full recovery-2sv-field <?= $profileNeeds2svConfirmation ? '' : 'hidden' ?>" id="profile2svField">
                                    <label class="flex items-start gap-3 cursor-pointer">
                                        <input type="checkbox" name="recovery_gmail_2sv_confirmed" value="1" class="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 recovery-2sv-checkbox" <?= $profileNeeds2svConfirmation ? 'required' : '' ?>>
                                        <span class="text-xs text-slate-600 leading-relaxed">I confirm this Gmail account already has Google 2-Step Verification turned on. <a href="https://myaccount.google.com/signinoptions/two-step-verification" target="_blank" rel="noopener noreferrer" class="text-blue-600 font-semibold hover:underline">Enable 2-Step Verification</a></span>
                                    </label>
                                </div>
                            </div>
                            <div class="flex justify-end">
                                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl text-sm font-semibold inline-flex items-center gap-2">
                                    <i data-lucide="save" class="w-4 h-4"></i> Save Profile
                                </button>
                            </div>
                        </form>
                    </div>

                    <?php if (!$isAdmin): ?>
                    <!-- NOTIFICATIONS (Staff only) -->
                    <div id="tab-notifications" class="tab-content bg-white border border-slate-100 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm <?= $activeTab !== 'notifications' ? 'hidden' : '' ?>">
                        <?php require __DIR__ . '/includes/settings_desktop_notifications.php'; ?>
                    </div>
                    <?php endif; ?>

                    <!-- SECURITY -->
                    <div id="tab-security" class="tab-content bg-white border border-slate-100 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm <?= $activeTab !== 'security' ? 'hidden' : '' ?>">
                        <h2 class="text-lg font-bold text-slate-900 mb-1">Security & Credentials</h2>
                        <p class="text-xs text-slate-500 mb-6">Change your password and review account security policies.</p>

                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm text-slate-600 mb-8 space-y-1">
                            <p><strong>Password policy:</strong> Minimum <?= passwordMinLength() ?> characters with uppercase, lowercase, and a number.</p>
                            <p><strong>Forgot password:</strong> Use the link on the login page. A 6-digit code is sent to your registered Gmail with 2-Step Verification confirmed.</p>
                            <p><strong>Recovery Gmail:</strong> Must be @gmail.com with Google 2-Step Verification already enabled before password reset works.</p>
                            <p><strong>Staff IDs:</strong> Alphanumeric characters and hyphens only (e.g. ALORAN-001).</p>
                            <p><strong>Session:</strong> Login tokens expire after 7 days of inactivity.</p>
                        </div>

                        <form method="POST" class="space-y-4 max-w-lg">
                            <?= authFormField() ?>
                            <input type="hidden" name="settings_action" value="change_password">
                            <input type="hidden" name="active_tab" value="security">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Current Password</label>
                                <input type="password" name="current_password" required autocomplete="current-password"
                                    class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">New Password</label>
                                <input type="password" name="new_password" required minlength="<?= passwordMinLength() ?>" autocomplete="new-password"
                                    class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Confirm New Password</label>
                                <input type="password" name="confirm_password" required minlength="<?= passwordMinLength() ?>" autocomplete="new-password"
                                    class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                            </div>
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl text-sm font-semibold inline-flex items-center gap-2">
                                <i data-lucide="key" class="w-4 h-4"></i> Update Password
                            </button>
                        </form>
                    </div>

                    <?php if ($isAdmin): ?>
                    <!-- ACCOUNT MANAGEMENT -->
                    <div id="tab-account-management" class="tab-content bg-white border border-slate-100 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm <?= $activeTab !== 'account-management' ? 'hidden' : '' ?>">
                        <div class="flex justify-between items-start mb-6">
                            <div>
                                <h2 class="text-lg font-bold text-slate-900 mb-1">Staff Members</h2>
                                <p class="text-xs text-slate-500">Manage staff portal access and profile photos.</p>
                            </div>
                            <span class="text-[10px] font-bold uppercase bg-slate-100 text-slate-600 px-3 py-1 rounded-full"><?= count($staffMembers) ?> accounts</span>
                        </div>

                        <form method="POST" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 pb-8 border-b border-slate-100">
                            <?= authFormField() ?>
                            <input type="hidden" name="settings_action" value="add_staff">
                            <input type="hidden" name="active_tab" value="account-management">
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:col-span-2">
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">First Name</label>
                                    <input type="text" name="staff_first_name" required placeholder="Juan" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Middle Name</label>
                                    <input type="text" name="staff_middle_name" placeholder="Optional" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Last Name</label>
                                    <input type="text" name="staff_last_name" required placeholder="Cruz" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                                </div>
                            </div>
                            <div class="sm:col-span-2 grid grid-cols-1 sm:grid-cols-[min(100%,11rem)_minmax(0,1fr)] gap-4">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Staff ID</label>
                                <input type="text" name="staff_id_new" required placeholder="ALORAN-002" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm uppercase focus:outline-none focus:border-blue-500">
                            </div>
                                <div class="min-w-0">
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Recovery Gmail *</label>
                                <input type="email" name="staff_email" required placeholder="staff@gmail.com" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                                <p class="text-[10px] text-slate-400 mt-1">Gmail with Google 2-Step Verification required.</p>
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Role</label>
                                <select name="staff_role" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                                    <option value="Staff">Staff</option>
                                    <option value="Administrator">Administrator</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">Password</label>
                                <input type="password" name="staff_password" required minlength="<?= passwordMinLength() ?>" placeholder="Minimum <?= passwordMinLength() ?> characters" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500">
                            </div>
                            <div class="sm:col-span-2">
                                <label class="flex items-start gap-3 cursor-pointer">
                                    <input type="checkbox" name="recovery_gmail_2sv_confirmed" value="1" required class="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                                    <span class="text-xs text-slate-600 leading-relaxed">I confirm this Gmail account already has Google 2-Step Verification turned on. <a href="https://myaccount.google.com/signinoptions/two-step-verification" target="_blank" rel="noopener noreferrer" class="text-blue-600 font-semibold hover:underline">Enable 2-Step Verification</a></span>
                                </label>
                            </div>
                            <div class="sm:col-span-2">
                                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl text-sm font-semibold">Add Staff Member</button>
                            </div>
                        </form>

                        <div class="overflow-x-auto rounded-xl border border-slate-200">
                            <table class="w-full text-sm text-left">
                                <thead class="bg-slate-50 text-[10px] font-bold uppercase text-slate-400 border-b border-slate-200">
                                    <tr>
                                        <th class="px-4 py-3">Photo</th>
                                        <th class="px-4 py-3">Staff ID</th>
                                        <th class="px-4 py-3">Name</th>
                                        <th class="px-4 py-3">Gmail</th>
                                        <th class="px-4 py-3">2SV</th>
                                        <th class="px-4 py-3">Role</th>
                                        <th class="px-4 py-3">Added</th>
                                        <th class="px-4 py-3 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100">
                                    <?php foreach ($staffMembers as $member): ?>
                                    <tr class="hover:bg-slate-50/50">
                                        <td class="px-4 py-3 w-[5.5rem]">
                                            <div class="flex flex-col items-center gap-1">
                                                <?= renderStaffAvatar($member['profile_photo_path'] ?? null, personNameFromRow($member), 'w-10 h-10 text-sm') ?>
                                                <form method="POST" enctype="multipart/form-data" class="staff-photo-form">
                                                    <?= authFormField() ?>
                                                    <input type="hidden" name="settings_action" value="upload_staff_photo">
                                                    <input type="hidden" name="active_tab" value="account-management">
                                                    <input type="hidden" name="target_staff_id" value="<?= htmlspecialchars($member['staff_id']) ?>">
                                                    <input type="file" name="staff_photo" accept="image/jpeg,image/png,image/webp" class="hidden staff-photo-input">
                                                    <button type="button" class="staff-photo-trigger text-[10px] font-semibold text-blue-600 hover:underline">Change</button>
                                                </form>
                                                <?php if (!empty($member['profile_photo_path'])): ?>
                                                <form method="POST">
                                                    <?= authFormField() ?>
                                                    <input type="hidden" name="settings_action" value="remove_staff_photo">
                                                    <input type="hidden" name="active_tab" value="account-management">
                                                    <input type="hidden" name="target_staff_id" value="<?= htmlspecialchars($member['staff_id']) ?>">
                                                    <button type="submit" class="text-[10px] text-slate-400 hover:text-red-500">Remove</button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="px-4 py-3 font-mono text-xs font-bold text-blue-600 whitespace-nowrap"><?= htmlspecialchars($member['staff_id']) ?></td>
                                        <td class="px-4 py-3 font-semibold text-slate-800 whitespace-nowrap">
                                            <?= htmlspecialchars(personNameFromRow($member)) ?>
                                            <?php if ($member['staff_id'] === $currentStaffId): ?><span class="text-[9px] text-blue-500 font-normal"> (You)</span><?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-xs text-slate-600 whitespace-nowrap"><?= htmlspecialchars($member['email'] ?? '-') ?></td>
                                        <td class="px-4 py-3 whitespace-nowrap">
                                            <?php if (empty($member['email'])): ?>
                                            <span class="text-[10px] text-slate-400">-</span>
                                            <?php elseif (!empty($member['recovery_gmail_2sv_confirmed'])): ?>
                                            <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">Confirmed</span>
                                            <?php else: ?>
                                            <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-700">Required</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded whitespace-nowrap <?= $member['role'] === 'Staff' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>"><?= htmlspecialchars($member['role']) ?></span>
                                        </td>
                                        <td class="px-4 py-3 text-slate-400 text-xs whitespace-nowrap"><?= formatDateDisplay($member['created_at']) ?></td>
                                        <td class="px-4 py-3 text-right whitespace-nowrap">
                                            <button type="button" class="edit-staff-btn text-[10px] font-semibold text-blue-600 hover:underline"
                                                data-staff-id="<?= htmlspecialchars($member['staff_id']) ?>"
                                                data-staff-first-name="<?= htmlspecialchars($member['first_name'] ?? '') ?>"
                                                data-staff-middle-name="<?= htmlspecialchars($member['middle_name'] ?? '') ?>"
                                                data-staff-last-name="<?= htmlspecialchars($member['last_name'] ?? '') ?>"
                                                data-staff-email="<?= htmlspecialchars($member['email'] ?? '') ?>"
                                                data-staff-role="<?= htmlspecialchars($member['role']) ?>"
                                                data-staff-2sv-confirmed="<?= !empty($member['recovery_gmail_2sv_confirmed']) ? '1' : '0' ?>">Edit</button>
                                            <span class="text-slate-200 mx-1">·</span>
                                            <button type="button" class="reset-staff-btn text-[10px] font-semibold text-amber-600 hover:underline"
                                                data-staff-id="<?= htmlspecialchars($member['staff_id']) ?>">Reset</button>
                                            <?php if ($member['staff_id'] !== $currentStaffId): ?>
                                            <span class="text-slate-200 mx-1">·</span>
                                            <form method="POST" class="inline">
                                                <?= authFormField() ?>
                                                <input type="hidden" name="settings_action" value="remove_staff">
                                                <input type="hidden" name="active_tab" value="account-management">
                                                <input type="hidden" name="target_staff_id" value="<?= htmlspecialchars($member['staff_id']) ?>">
                                                <button type="submit" class="text-[10px] font-semibold text-red-500 hover:underline">Delete</button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- SYSTEM CONFIGURATION -->
                    <div id="tab-system-configuration" class="tab-content bg-white border border-slate-100 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm <?= $activeTab !== 'system-configuration' ? 'hidden' : '' ?>">
                        <div class="mb-6">
                            <h2 class="text-lg font-bold text-slate-900">System Configuration</h2>
                            <p class="text-xs text-slate-500 mt-1">Expand each section to edit. Save once at the bottom - all changes apply together.</p>
                        </div>
                        <form method="POST" class="space-y-4">
                            <?= authFormField() ?>
                            <input type="hidden" name="settings_action" value="save_settings">
                            <input type="hidden" name="active_tab" value="system-configuration">

                            <details class="config-section group rounded-xl border border-slate-200 overflow-hidden" open>
                                <summary class="flex items-center justify-between gap-3 px-4 py-3.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-sm text-slate-800">
                                    <span class="flex items-center gap-2"><i data-lucide="building-2" class="w-4 h-4 text-slate-500"></i> Office Information</span>
                                    <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 config-chevron"></i>
                                </summary>
                                <div class="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100">
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Site Name</label><input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Office Name</label><input type="text" name="office_name" value="<?= htmlspecialchars($settings['office_name']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div class="sm:col-span-2"><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Address</label><input type="text" name="office_address" value="<?= htmlspecialchars($settings['office_address']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Phone</label><input type="text" name="office_phone" value="<?= htmlspecialchars($settings['office_phone']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Email</label><input type="email" name="office_email" value="<?= htmlspecialchars($settings['office_email']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Office Hours</label><input type="text" name="office_hours" value="<?= htmlspecialchars($settings['office_hours']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Office Head / Signatory</label><input type="text" name="office_head" value="<?= htmlspecialchars($settings['office_head']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div class="sm:col-span-2 pt-3 mt-1 border-t border-slate-100 space-y-4">
                                        <div>
                                            <p class="text-xs font-bold text-slate-800">Home page — Latest Announcements</p>
                                            <p class="text-[10px] text-slate-500 mt-0.5">The schedule line uses <strong>Office Hours</strong> above and is not edited here.</p>
                                        </div>
                                        <div class="rounded-xl border border-slate-200 bg-slate-50/80 px-4 py-3 text-xs text-slate-600 leading-relaxed">
                                            <span class="font-semibold text-slate-800"><?= htmlspecialchars($settings['office_hours'] !== '' ? $settings['office_hours'] : ($defaults['office_hours'] ?? '')) ?>.</span>
                                            <span class="text-slate-400"> (from Office Hours)</span>
                                        </div>
                                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            <div>
                                                <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1" for="homeAnnouncementDate">Announcement date</label>
                                                <input type="date" id="homeAnnouncementDate" name="home_announcement_date" value="<?= htmlspecialchars($settings['home_announcement_date']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                                                <p class="text-[10px] text-slate-400 mt-1">Leave blank to show today&rsquo;s date.</p>
                                            </div>
                                            <div>
                                                <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1" for="homeAnnouncementTitle">Announcement title</label>
                                                <input type="text" id="homeAnnouncementTitle" name="home_announcement_title" value="<?= htmlspecialchars($settings['home_announcement_title']) ?>" placeholder="Office Schedule" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                                            </div>
                                            <div class="sm:col-span-2">
                                                <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1" for="homeAnnouncementNote">Announcement note</label>
                                                <textarea id="homeAnnouncementNote" name="home_announcement_note" rows="2" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm leading-relaxed" placeholder="Walk-in clients and online request claimants are served during these hours."><?= htmlspecialchars($settings['home_announcement_note']) ?></textarea>
                                                <p class="text-[10px] text-slate-400 mt-1">Shown after the office hours line on the home page.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="sm:col-span-2"><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Facebook Page URL</label><input type="url" name="social_facebook_url" value="<?= htmlspecialchars($settings['social_facebook_url']) ?>" placeholder="https://www.facebook.com/..." class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div class="sm:col-span-2"><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Instagram Profile URL</label><input type="url" name="social_instagram_url" value="<?= htmlspecialchars($settings['social_instagram_url']) ?>" placeholder="https://www.instagram.com/..." class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                </div>
                            </details>

                            <details class="config-section group rounded-xl border border-slate-200 overflow-hidden">
                                <summary class="flex items-center justify-between gap-3 px-4 py-3.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-sm text-slate-800">
                                    <span class="flex items-center gap-2"><i data-lucide="clipboard-list" class="w-4 h-4 text-slate-500"></i> Office Fees &amp; Requirements</span>
                                    <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 config-chevron"></i>
                                </summary>
                                <div class="p-4 space-y-4 border-t border-slate-100">
                                    <p class="text-xs text-slate-600 leading-relaxed">
                                        <strong>Fees:</strong> one line per row - shown on All Services, requirement modals, and citizen emails. Leave blank to hide fees for that service.<br>
                                        <strong>Requirements:</strong> special-service appointments (per service below). Fast-track certificates include <strong>requester relationship</strong> checklists (birth, death, marriage). One line per item; sub-items use two spaces and a dash (<code class="bg-slate-100 px-1 rounded text-[10px]">  - </code>). Notes are for legal or other non-fee text (fees are edited above).
                                    </p>
                                    <div class="space-y-4">
                                        <?php foreach (officeFeesCatalog() as $feeKey => $feeMeta):
                                            $reqForm = $officeRequirementsForm[$feeKey] ?? null;
                                            $hasRequirements = officeRequirementsEditable($feeKey);
                                        ?>
                                        <div class="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-4">
                                            <h3 class="text-sm font-bold text-slate-800"><?= htmlspecialchars($feeMeta['label']) ?></h3>
                                            <?php if (!empty($feeMeta['hint'])): ?>
                                            <p class="text-[10px] text-slate-500 -mt-2"><?= htmlspecialchars($feeMeta['hint']) ?></p>
                                            <?php endif; ?>

                                    <div>
                                                <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="office-fee-<?= htmlspecialchars($feeKey) ?>">Office fees</label>
                                                <textarea
                                                    id="office-fee-<?= htmlspecialchars($feeKey) ?>"
                                                    name="office_fees[<?= htmlspecialchars($feeKey) ?>]"
                                                    rows="<?= max(2, min(4, count($feeMeta['defaults'] ?? []))) ?>"
                                                    class="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-mono leading-relaxed bg-white"
                                                    placeholder="Example:&#10;Processing fee: PHP 100.00"><?= htmlspecialchars($officeFeesForm[$feeKey] ?? '') ?></textarea>
                                    </div>

                                            <?php if ($feeKey === 'document_certificate'): ?>
                                            <div class="pt-3 border-t border-slate-200/80 space-y-4">
                                                <p class="text-[10px] text-slate-500 leading-relaxed">Required documents by requester relationship - shown on the certificate request wizard and in request emails.</p>
                                                <?php
                                                $docTypeLabels = [
                                                    'birth'    => 'Birth Certificate',
                                                    'death'    => 'Death Certificate',
                                                    'marriage' => 'Marriage Certificate',
                                                ];
                                                foreach ($documentRequestRelationshipCatalog as $docType => $relationships):
                                                ?>
                                                <div class="rounded-lg border border-slate-200/80 bg-white p-3 space-y-3">
                                                    <h4 class="text-xs font-bold text-slate-800"><?= htmlspecialchars($docTypeLabels[$docType] ?? ucfirst($docType)) ?></h4>
                                                    <?php foreach ($relationships as $relSlug => $relLabel):
                                                        $relForm = $documentRequestRelationshipForm[$docType][$relSlug] ?? ['items' => '', 'notes' => ''];
                                                    ?>
                                                    <div class="rounded-lg border border-slate-100 bg-slate-50/80 p-3 space-y-2">
                                                        <p class="text-xs font-bold text-slate-700"><?= htmlspecialchars($relLabel) ?></p>
                                                        <div>
                                                            <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="doc-rel-items-<?= htmlspecialchars($docType) ?>-<?= htmlspecialchars($relSlug) ?>">Required documents</label>
                                                            <textarea
                                                                id="doc-rel-items-<?= htmlspecialchars($docType) ?>-<?= htmlspecialchars($relSlug) ?>"
                                                                name="document_request_relationship_req[<?= htmlspecialchars($docType) ?>][<?= htmlspecialchars($relSlug) ?>][items]"
                                                                rows="3"
                                                                class="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-mono leading-relaxed bg-white"
                                                                placeholder="One requirement per line"><?= htmlspecialchars($relForm['items'] ?? '') ?></textarea>
                                                        </div>
                                                        <div>
                                                            <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="doc-rel-notes-<?= htmlspecialchars($docType) ?>-<?= htmlspecialchars($relSlug) ?>">Other notes (optional)</label>
                                                            <textarea
                                                                id="doc-rel-notes-<?= htmlspecialchars($docType) ?>-<?= htmlspecialchars($relSlug) ?>"
                                                                name="document_request_relationship_req[<?= htmlspecialchars($docType) ?>][<?= htmlspecialchars($relSlug) ?>][notes]"
                                                                rows="2"
                                                                class="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm leading-relaxed bg-white"><?= htmlspecialchars($relForm['notes'] ?? '') ?></textarea>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; ?>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                            <?php endif; ?>

                                            <?php if ($hasRequirements && is_array($reqForm)): ?>
                                            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-2 border-t border-slate-200/80">
                                                <div class="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                                    <div>
                                                        <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="office-req-subtitle-<?= htmlspecialchars($feeKey) ?>">Requirements subtitle</label>
                                                        <input type="text" id="office-req-subtitle-<?= htmlspecialchars($feeKey) ?>" name="office_requirements[<?= htmlspecialchars($feeKey) ?>][subtitle]" value="<?= htmlspecialchars($reqForm['subtitle'] ?? '') ?>" class="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white" placeholder="e.g. R.A. 9048">
                                    </div>
                                                    <div class="sm:col-span-1">
                                                        <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="office-req-lead-<?= htmlspecialchars($feeKey) ?>">Intro / lead</label>
                                                        <textarea id="office-req-lead-<?= htmlspecialchars($feeKey) ?>" name="office_requirements[<?= htmlspecialchars($feeKey) ?>][lead]" rows="2" class="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white"><?= htmlspecialchars($reqForm['lead'] ?? '') ?></textarea>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="office-req-items-<?= htmlspecialchars($feeKey) ?>">Checklist items</label>
                                                    <textarea id="office-req-items-<?= htmlspecialchars($feeKey) ?>" name="office_requirements[<?= htmlspecialchars($feeKey) ?>][items]" rows="8" class="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-mono leading-relaxed bg-white" placeholder="One item per line&#10;  - Sub-item"><?= htmlspecialchars($reqForm['items'] ?? '') ?></textarea>
                                                </div>
                                                <div>
                                                    <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1" for="office-req-notes-<?= htmlspecialchars($feeKey) ?>">Other notes (non-fee)</label>
                                                    <textarea id="office-req-notes-<?= htmlspecialchars($feeKey) ?>" name="office_requirements[<?= htmlspecialchars($feeKey) ?>][notes]" rows="8" class="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm leading-relaxed bg-white" placeholder="Legal basis, reminders…"><?= htmlspecialchars($reqForm['notes'] ?? '') ?></textarea>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </details>

                            <details class="config-section group rounded-xl border border-slate-200 overflow-hidden">
                                <summary class="flex items-center justify-between gap-3 px-4 py-3.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-sm text-slate-800">
                                    <span class="flex items-center gap-2"><i data-lucide="mail" class="w-4 h-4 text-slate-500"></i> Operations & Email</span>
                                    <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 config-chevron"></i>
                                </summary>
                                <div class="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100">
                                    <?php $gmailSmtpReady = isEmailConfigured(); ?>
                                    <div class="sm:col-span-2 rounded-lg px-3 py-2.5 text-[11px] font-semibold leading-relaxed <?= $gmailSmtpReady ? 'bg-emerald-50 text-emerald-900 border border-emerald-100' : 'bg-amber-50 text-amber-950 border border-amber-100' ?>">
                                        <?php if ($gmailSmtpReady): ?>
                                        Gmail SMTP is configured. Citizen and reminder emails use the Gmail address and App Password below.
                                        <?php else: ?>
                                        Gmail SMTP is not complete yet. Fill in <strong>Gmail Address (SMTP user)</strong> and <strong>Gmail App Password</strong> below, then Save. Notification Email alone does not enable sending.
                                        <?php endif; ?>
                                    </div>
                                    <div class="sm:col-span-2"><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Notification Email</label><input type="email" name="notification_email" value="<?= htmlspecialchars($settings['notification_email']) ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"><p class="text-[10px] text-slate-400 mt-1">Fallback From address if Gmail SMTP is not used.</p></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Gmail SMTP Host</label><input type="text" name="smtp_host" value="<?= htmlspecialchars($settings['smtp_host'] ?: 'smtp.gmail.com') ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Gmail SMTP Port</label><input type="number" name="smtp_port" value="<?= htmlspecialchars($settings['smtp_port'] ?: '587') ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"><p class="text-[10px] text-slate-400 mt-1">587 for STARTTLS, or 465 for SSL.</p></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Gmail Address (SMTP user)</label><input type="email" name="smtp_user" value="<?= htmlspecialchars($settings['smtp_user']) ?>" placeholder="youroffice@gmail.com" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"></div>
                                    <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Gmail App Password</label><input type="password" name="smtp_pass" id="smtpPassInput" value="<?= $smtpPassSaved ? htmlspecialchars($smtpPassMask) : '' ?>" autocomplete="new-password" data-saved-mask="<?= $smtpPassSaved ? htmlspecialchars($smtpPassMask) : '' ?>" data-saved-value="<?= $smtpPassSaved ? htmlspecialchars($settings['smtp_pass']) : '' ?>" placeholder="<?= $smtpPassSaved ? '' : 'App password from Google Account' ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"><p class="text-[10px] text-slate-400 mt-1">Create an App Password in Google Account → Security.<?= $smtpPassSaved ? ' Click the field, then the eye icon, to view the saved password.' : '' ?></p></div>
                                </div>
                            </details>

                            <details class="config-section group rounded-xl border border-slate-200 overflow-hidden">
                                <summary class="flex items-center justify-between gap-3 px-4 py-3.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-sm text-slate-800">
                                    <span class="flex items-center gap-2"><i data-lucide="message-square" class="w-4 h-4 text-slate-500"></i> SMS (IPROG)</span>
                                    <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 config-chevron"></i>
                                </summary>
                                <div class="p-4 space-y-4 border-t border-slate-100">
                                    <?php
                                    require_once __DIR__ . '/includes/sms.php';
                                    ensureExtendedSchema($pdo);
                                    $smsSummary = smsConfigurationSummary();
                                    $smsRecentLogs = $pdo->query(
                                        'SELECT sent_at, success, delivery_type AS sms_type, error_message, recipient
                                         FROM delivery_logs WHERE channel = \'sms\' ORDER BY sent_at DESC LIMIT 5'
                                    )->fetchAll(PDO::FETCH_ASSOC) ?: [];
                                    ?>
                                    <div class="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-xs text-slate-600">
                                        <?php if ($smsSummary['configured'] && empty($smsSummary['sender_hint'])): ?>
                                        <p class="font-semibold text-green-700">IPROG is configured and ready to send SMS.</p>
                                        <?php elseif ($smsSummary['configured'] && !empty($smsSummary['sender_hint'])): ?>
                                        <p class="font-semibold text-amber-700"><?= htmlspecialchars($smsSummary['sender_hint']) ?></p>
                                        <?php elseif ($smsSummary['has_api_key'] && !$smsSummary['enabled']): ?>
                                        <p class="font-semibold text-amber-700">API token is saved but <strong>Enable SMS notifications</strong> is off - no texts will be sent until you check that box and save.</p>
                                        <?php elseif ($smsSummary['enabled'] && !$smsSummary['has_api_key']): ?>
                                        <p class="font-semibold text-amber-700">SMS is enabled but no API token is saved yet.</p>
                                        <?php elseif (!$smsSummary['has_api_key']): ?>
                                        <p class="font-semibold text-slate-700">SMS is off until you subscribe at <a href="https://www.iprogsms.com" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">iprogsms.com</a> and enter your API token below.</p>
                                        <?php else: ?>
                                        <p class="font-semibold text-green-700">API token saved. Turn on SMS below and save.</p>
                                        <?php endif; ?>
                                        <p class="mt-1.5">Citizens must opt in at booking/request (<strong>09XXXXXXXXX</strong> only). Open <strong>Recent</strong> <i data-lucide="history" class="inline w-3 h-3 align-text-bottom text-slate-500"></i> to see when IPROG accepted or rejected messages.</p>
                                    </div>
                                    <?php if ($smsRecentLogs !== []):
                                        $smsRecentCount = count($smsRecentLogs);
                                        $smsRecentLatestFailed = empty($smsRecentLogs[0]['success']);
                                    ?>
                                    <details class="sms-recent-details rounded-xl border border-slate-200 bg-white overflow-hidden">
                                        <summary class="sms-recent-details__trigger flex items-center justify-between gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50/80">
                                            <span class="flex items-center gap-2.5 min-w-0">
                                                <span class="sms-recent-details__icon-wrap relative flex shrink-0 items-center justify-center w-9 h-9 rounded-lg bg-slate-100 text-slate-600">
                                                    <i data-lucide="history" class="w-4.5 h-4.5 w-[1.125rem] h-[1.125rem]" aria-hidden="true"></i>
                                                    <?php if ($smsRecentLatestFailed): ?>
                                                    <span class="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-red-500 ring-2 ring-white" title="Latest attempt failed"></span>
                                                    <?php endif; ?>
                                                </span>
                                                <span class="min-w-0">
                                                    <span class="block text-sm font-semibold text-slate-800">Recent SMS attempts</span>
                                                    <span class="block text-[11px] text-slate-500 truncate">Last <?= (int) $smsRecentCount ?> · tap to expand</span>
                                                </span>
                                            </span>
                                            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 shrink-0 sms-recent-details__chevron" aria-hidden="true"></i>
                                        </summary>
                                        <ul class="divide-y divide-slate-100 border-t border-slate-100 text-[11px]">
                                            <?php foreach ($smsRecentLogs as $logRow): ?>
                                            <li class="px-4 py-2.5 <?= !empty($logRow['success']) ? 'text-emerald-800 bg-emerald-50/40' : 'text-red-800 bg-red-50/40' ?>">
                                                <span class="font-semibold"><?= !empty($logRow['success']) ? 'Sent' : 'Failed' ?></span>
                                                · <?= htmlspecialchars((string) ($logRow['sms_type'] ?? '')) ?>
                                                · <?= htmlspecialchars((string) ($logRow['sent_at'] ?? '')) ?>
                                                <?php if (empty($logRow['success']) && !empty($logRow['error_message'])): ?>
                                                <br><span class="text-red-700/90"><?= htmlspecialchars((string) $logRow['error_message']) ?></span>
                                                <?php endif; ?>
                                            </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </details>
                                    <?php endif; ?>
                                    <label class="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-100 cursor-pointer">
                                        <div>
                                            <p class="text-sm font-semibold text-slate-800">Enable SMS notifications</p>
                                            <p class="text-xs text-slate-500">Turn on after your IPROG account is active and funded.</p>
                                        </div>
                                        <input type="checkbox" name="sms_enabled" value="1" <?= $settings['sms_enabled'] === '1' ? 'checked' : '' ?> class="rounded text-blue-600 w-5 h-5">
                                    </label>
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">IPROG API Token</label><input type="password" name="iprog_api_token" id="iprogApiTokenInput" value="<?= $iprogTokenSaved ? htmlspecialchars($smtpPassMask) : '' ?>" autocomplete="new-password" data-saved-mask="<?= $iprogTokenSaved ? htmlspecialchars($smtpPassMask) : '' ?>" data-saved-value="<?= $iprogTokenSaved ? htmlspecialchars($settings['iprog_api_token']) : '' ?>" placeholder="<?= $iprogTokenSaved ? '' : 'API token from IPROG dashboard' ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"><p class="text-[10px] text-slate-400 mt-1">Found in your IPROG SMS dashboard.<?= $iprogTokenSaved ? ' Click the field, then the eye icon, to view the saved token.' : '' ?></p></div>
                                        <div><label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Sender Name (optional)</label><input type="text" name="iprog_sender_name" value="<?= htmlspecialchars($settings['iprog_sender_name']) ?>" maxlength="11" placeholder="AlCROS" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm"><p class="text-[10px] text-slate-400 mt-1">Required for many <strong>Smart/TNT</strong> numbers - register at <a href="https://www.iprogsms.com/sender-names/new" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">IPROG sender names</a>.</p></div>
                                    </div>
                                </div>
                            </details>

                            <details class="config-section group rounded-xl border border-slate-200 overflow-hidden">
                                <summary class="flex items-center justify-between gap-3 px-4 py-3.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-sm text-slate-800">
                                    <span class="flex items-center gap-2"><i data-lucide="shield-check" class="w-4 h-4 text-slate-500"></i> Portal Access Controls</span>
                                    <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 config-chevron"></i>
                                </summary>
                                <div class="p-4 space-y-3 border-t border-slate-100">
                                    <label class="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 cursor-pointer">
                                        <div>
                                            <p class="text-sm font-semibold text-slate-800">Maintenance Mode</p>
                                            <p class="text-xs text-slate-500">Show the maintenance announcement and temporarily block new online transactions.</p>
                                        </div>
                                        <input type="checkbox" name="maintenance_mode" id="maintenanceModeToggle" value="1" <?= $settings['maintenance_mode'] === '1' ? 'checked' : '' ?> class="rounded text-blue-600 w-5 h-5">
                                    </label>
                                    <label class="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 cursor-pointer">
                                        <div>
                                            <p class="text-sm font-semibold text-slate-800">Allow Public Requests</p>
                                            <p class="text-xs text-slate-500">Citizens can submit new online transactions.</p>
                                        </div>
                                        <input type="checkbox" name="allow_public_requests" id="allowPublicRequestsToggle" value="1" <?= $settings['allow_public_requests'] === '1' ? 'checked' : '' ?> class="rounded text-blue-600 w-5 h-5">
                                    </label>
                                </div>
                            </details>

                            <div class="pt-2 flex justify-end sticky bottom-0 bg-white/95 backdrop-blur border-t border-slate-100 -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-4 mt-4">
                                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl text-sm font-semibold inline-flex items-center gap-2">
                                    <i data-lucide="save" class="w-4 h-4"></i> Save Settings
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- ADMIN TOOLS -->
                    <div id="tab-admin-tools" class="tab-content <?= $activeTab !== 'admin-tools' ? 'hidden' : '' ?>">
                        <div class="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden mb-5">
                            <div class="px-5 py-4 border-b border-slate-100">
                                <h2 class="text-base font-black text-slate-900">Admin Tools</h2>
                                <p class="text-xs text-slate-500 mt-0.5">System health, audit trail, and maintenance - one section at a time.</p>
                            </div>
                            <nav class="flex gap-1 p-2 overflow-x-auto bg-slate-50/80 border-b border-slate-100" aria-label="Admin tools sections">
                                <?php
                                $adminToolTabs = [
                                    'overview'    => ['label' => 'Overview', 'icon' => 'layout-dashboard'],
                                    'activity'    => ['label' => 'Activity', 'icon' => 'activity', 'count' => count($recentLogs)],
                                    'backup'      => ['label' => 'Backup', 'icon' => 'hard-drive'],
                                    'maintenance' => ['label' => 'Maintenance', 'icon' => 'wrench', 'count' => count($activeSystemErrors)],
                                ];
                                foreach ($adminToolTabs as $subKey => $subTab):
                                ?>
                                <a href="<?= htmlspecialchars(settingsPageUrl('admin-tools', $subKey)) ?>"
                                   class="admin-sub-tab flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold border border-transparent whitespace-nowrap text-slate-600 hover:bg-white <?= $adminToolsSection === $subKey ? 'is-active' : '' ?>">
                                    <i data-lucide="<?= $subTab['icon'] ?>" class="w-3.5 h-3.5"></i>
                                    <?= htmlspecialchars($subTab['label']) ?>
                                    <?php if (isset($subTab['count'])): ?>
                                    <span class="min-w-[1.1rem] h-5 px-1 rounded-full text-[10px] font-black flex items-center justify-center <?= $adminToolsSection === $subKey ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600' ?>"><?= (int) $subTab['count'] ?></span>
                                    <?php endif; ?>
                                </a>
                                <?php endforeach; ?>
                            </nav>

                            <!-- Overview -->
                            <div class="p-5 sm:p-6 <?= $adminToolsSection !== 'overview' ? 'hidden' : '' ?>">
                                <h3 class="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3">Database totals</h3>
                                <div class="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
                                    <?php foreach ($systemStats as $stat): ?>
                                    <div class="rounded-xl p-4 bg-slate-50 border border-slate-100">
                                        <p class="text-[10px] font-bold text-slate-400 uppercase"><?= htmlspecialchars($stat['label']) ?></p>
                                        <p class="text-xl font-black text-slate-900 mt-1"><?= number_format($stat['count']) ?></p>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <h3 class="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3">Quick links</h3>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <?php
                                    $adminQuickLinks = [
                                        ['url' => buildAuthUrl('analytics.php'), 'label' => 'Analytics', 'desc' => 'Charts, statistics & trends', 'icon' => 'trending-up'],
                                        ['url' => buildAuthUrl('activity-log.php'), 'label' => 'Full Activity Log', 'desc' => 'Search all staff actions', 'icon' => 'scroll-text'],
                                        ['url' => settingsPageUrl('system-configuration'), 'label' => 'Configuration', 'desc' => 'Office & portal settings', 'icon' => 'settings'],
                                    ];
                                    foreach ($adminQuickLinks as $link):
                                    ?>
                                    <a href="<?= htmlspecialchars($link['url']) ?>"
                                       class="flex items-start gap-3 p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/40 transition-colors">
                                        <div class="p-2 bg-white rounded-lg border border-slate-100 shrink-0">
                                            <i data-lucide="<?= $link['icon'] ?>" class="w-4 h-4 text-slate-600"></i>
                                        </div>
                                        <div class="min-w-0">
                                            <p class="text-sm font-bold text-slate-800"><?= htmlspecialchars($link['label']) ?></p>
                                            <p class="text-xs text-slate-500 mt-0.5"><?= htmlspecialchars($link['desc']) ?></p>
                                        </div>
                                        <i data-lucide="chevron-right" class="w-4 h-4 text-slate-300 shrink-0 mt-1"></i>
                                    </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Activity preview -->
                            <div class="p-5 sm:p-6 <?= $adminToolsSection !== 'activity' ? 'hidden' : '' ?>">
                                <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                                    <div>
                                        <h3 class="text-sm font-bold text-slate-900">Recent staff actions</h3>
                                        <p class="text-xs text-slate-500">Latest 8 entries - open the full log to search and filter.</p>
                                    </div>
                                    <a href="<?= htmlspecialchars(buildAuthUrl('activity-log.php')) ?>" class="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:underline">
                                        Open full log <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                                    </a>
                                </div>
                                <?php if (empty($recentLogs)): ?>
                                <p class="text-sm text-slate-400 py-8 text-center rounded-xl bg-slate-50 border border-slate-100">No activity logged yet.</p>
                                <?php else: ?>
                                <div class="divide-y divide-slate-100 rounded-xl border border-slate-100 overflow-hidden">
                                    <?php foreach ($recentLogs as $log): ?>
                                    <div class="px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 hover:bg-slate-50/60">
                                        <div class="flex items-center gap-3 min-w-0 flex-1">
                                            <span class="shrink-0" aria-hidden="true">
                                                <?= $log['staff_avatar_html'] ?? renderStaffAvatar(
                                                    null,
                                                    (string) ($log['staff_display_name'] ?? $log['staff_id'] ?? 'System'),
                                                    'w-8 h-8 text-[10px]'
                                                ) ?>
                                            </span>
                                            <div class="min-w-0">
                                                <p class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($log['action_display'] ?? activityLogDisplayAction((string) ($log['action'] ?? ''))) ?></p>
                                                <p class="text-xs text-slate-400 truncate"><?= htmlspecialchars($log['staff_id'] ?? 'System') ?> · <?= htmlspecialchars($log['details'] ?? '') ?></p>
                                            </div>
                                        </div>
                                        <span class="text-[11px] text-slate-400 shrink-0"><?= htmlspecialchars(formatDateDisplay($log['created_at'])) ?></span>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Registry backup -->
                            <div class="p-5 sm:p-6 <?= $adminToolsSection !== 'backup' ? 'hidden' : '' ?>">
                                <div class="backup-page">
                                    <div class="backup-page__head">
                                        <div class="min-w-0">
                                            <div class="backup-page__title-row">
                                                <h3 class="backup-page__title">Registry backup</h3>
                                                <details class="backup-scope-info">
                                                    <summary class="backup-scope-info__trigger" aria-label="What gets backed up">
                                                        <i data-lucide="info" class="backup-scope-info__icon" aria-hidden="true"></i>
                                                    </summary>
                                                    <div class="backup-scope-info__panel" role="note">
                                                        <p class="backup-scope-info__title">What gets backed up</p>
                                                        <ul class="backup-scope-info__list">
                                                            <li>Civil records (birth, death, marriage) and detail tables</li>
                                                            <li>Staff accounts (login IDs, roles, password hashes, emails)</li>
                                                            <li>Print templates, field positions, and calibrations</li>
                                                            <li>Print settings (global offsets, mode, province/city labels)</li>
                                                            <li>Staff profile photos and print form reference files</li>
                                                        </ul>
                                                        <p class="backup-scope-info__note">Requests, appointments, queue tickets, and activity logs are <strong>not</strong> included.</p>
                                                    </div>
                                                </details>
                                            </div>
                                            <p class="backup-page__subtitle">Zip on the server, optional Google Drive copy, scheduled via cron URL.</p>
                                        </div>
                                        <form method="POST" class="backup-toolbar">
                                            <?= authFormField() ?>
                                            <input type="hidden" name="settings_action" value="run_registry_backup">
                                            <input type="hidden" name="active_tab" value="admin-tools">
                                            <input type="hidden" name="admin_sub" value="backup">
                                            <button type="submit" class="backup-btn backup-btn--primary">
                                                <i data-lucide="play" class="w-4 h-4"></i> Run backup now
                                            </button>
                                        </form>
                                    </div>

                                    <div class="backup-glance">
                                        <div class="backup-glance__block">
                                            <p class="backup-glance__label">Dataset snapshot</p>
                                            <div class="backup-glance__metrics">
                                                <div><span class="text-slate-400">Records</span><strong><?= number_format($backupRecordCount) ?></strong></div>
                                                <div><span class="text-slate-400">Staff</span><strong><?= number_format($backupStaffCount) ?></strong></div>
                                                <div><span class="text-slate-400">Bundle</span><strong><?= htmlspecialchars(alcrosFormatBytes($backupDirSize)) ?></strong></div>
                                                <div><span class="text-slate-400">Last export</span><strong><?= $backupLastRun !== '' ? htmlspecialchars(formatReportDateTime($backupLastRun)) : '-' ?></strong></div>
                                            </div>
                                        </div>
                                        <div class="backup-glance__block">
                                            <p class="backup-glance__label">Latest zip archive</p>
                                            <div class="backup-glance__metrics">
                                                <div><span class="text-slate-400">Last run</span><strong><?= $registryBackupLastRun !== '' ? htmlspecialchars(formatReportDateTime($registryBackupLastRun)) : 'Not yet' ?></strong></div>
                                                <div><span class="text-slate-400">Status</span><strong><?= $registryBackupLastStatus !== '' ? htmlspecialchars(ucfirst($registryBackupLastStatus)) : '-' ?></strong></div>
                                                <div><span class="text-slate-400">Schedule</span><strong><span class="backup-badge <?= $registryBackupEnabled ? 'backup-badge--on' : 'backup-badge--off' ?>"><?= $registryBackupEnabled ? 'On' : 'Off' ?></span></strong></div>
                                                <div class="min-w-0 flex-1"><span class="text-slate-400">File</span><strong class="truncate"><?= $registryBackupLastFilename !== '' ? htmlspecialchars($registryBackupLastFilename) : '-' ?></strong></div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if ($backupLastMessage !== '' && $backupLastStatus === 'error'): ?>
                                    <div class="backup-alert backup-alert--error">Export error: <?= htmlspecialchars($backupLastMessage) ?></div>
                                    <?php endif; ?>
                                    <?php if ($registryBackupLastMessage !== '' && $registryBackupLastStatus === 'error'): ?>
                                    <div class="backup-alert backup-alert--error"><?= htmlspecialchars($registryBackupLastMessage) ?></div>
                                    <?php endif; ?>

                                    <form method="POST" enctype="multipart/form-data" id="registryBackupForm" class="flex flex-col gap-5">
                                        <?= authFormField() ?>
                                        <input type="hidden" name="settings_action" value="save_registry_backup_settings">
                                        <input type="hidden" name="active_tab" value="admin-tools">
                                        <input type="hidden" name="admin_sub" value="backup">

                                        <section class="backup-card">
                                            <div class="backup-card__head">
                                                <h4 class="backup-card__title"><i data-lucide="server" class="w-4 h-4 text-slate-500"></i> Server &amp; schedule</h4>
                                            </div>
                                            <div class="backup-card__body">
                                                <label class="backup-toggle">
                                                    <input type="checkbox" name="registry_backup_enabled" value="1" class="mt-0.5 rounded border-slate-300" <?= $registryBackupEnabled ? 'checked' : '' ?>>
                                                    <span><strong>Enable scheduled registry backup</strong><br>Turn this on before using the cron URL. Manual “Run backup now” works either way.</span>
                                                </label>
                                                <div class="backup-field-grid backup-field-grid--2">
                                                    <div class="backup-field">
                                                        <label for="registry_backup_retention_count">Keep zips on server</label>
                                                        <input type="number" id="registry_backup_retention_count" name="registry_backup_retention_count" min="3" max="90" value="<?= (int) $registryBackupRetention ?>">
                                                        <p class="backup-field__hint">Oldest files removed after this many runs (3–90).</p>
                                                    </div>
                                                    <div class="backup-field">
                                                        <label for="registry_backup_public_url">Public site URL</label>
                                                        <input type="url" id="registry_backup_public_url" name="registry_backup_public_url" value="<?= htmlspecialchars($registryBackupPublicUrl) ?>" placeholder="https://alcros.publicvm.com">
                                                        <p class="backup-field__hint">Optional - fixes cron/OAuth URLs if the host guess is wrong.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>

                                        <section class="backup-card">
                                            <div class="backup-card__head">
                                                <h4 class="backup-card__title"><i data-lucide="cloud" class="w-4 h-4 text-slate-500"></i> Google Drive</h4>
                                                <?php if ($registryBackupGdriveEnabled): ?>
                                                <span class="backup-badge backup-badge--on">Upload on</span>
                                                <?php else: ?>
                                                <span class="backup-badge backup-badge--off">Upload off</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="backup-card__body">
                                                <label class="backup-toggle">
                                                    <input type="checkbox" name="registry_backup_gdrive_enabled" value="1" class="mt-0.5 rounded border-slate-300" <?= $registryBackupGdriveEnabled ? 'checked' : '' ?>>
                                                    <span><strong>Upload each zip to Google Drive</strong><br>Sign in with your Gmail; zips go to a folder in your My Drive.</span>
                                                </label>

                                                <div class="backup-field-grid backup-field-grid--2">
                                                    <div class="backup-field">
                                                        <label for="registry_backup_gdrive_folder_id">Drive folder ID</label>
                                                        <input type="text" id="registry_backup_gdrive_folder_id" name="registry_backup_gdrive_folder_id" class="font-mono" value="<?= htmlspecialchars($registryBackupGdriveFolderId) ?>" placeholder="Folder ID or full Drive URL">
                                                        <p class="backup-field__hint">Folder in the connected Google account.</p>
                                                    </div>
                                                    <div class="backup-field">
                                                        <label for="registry_backup_gdrive_retention_count">Keep copies on Drive</label>
                                                        <input type="number" id="registry_backup_gdrive_retention_count" name="registry_backup_gdrive_retention_count" min="0" max="90" value="<?= (int) $registryBackupGdriveRetention ?>">
                                                        <p class="backup-field__hint">0 = match server retention (<?= (int) $registryBackupRetention ?>).</p>
                                                    </div>
                                                </div>

                                                <div class="backup-toolbar">
                                                    <?php if ($registryBackupGdriveOAuthConnected): ?>
                                                    <p class="backup-status-line backup-status-line--ok">Connected as <?= htmlspecialchars($registryBackupGdriveOAuthEmail !== '' ? $registryBackupGdriveOAuthEmail : 'Google account') ?></p>
                                                    <?php else: ?>
                                                    <p class="backup-status-line backup-status-line--bad">Not connected - save Client ID/Secret, then connect.</p>
                                                    <?php endif; ?>
                                                    <a href="<?= htmlspecialchars($registryBackupGdriveConnectUrl) ?>" class="backup-btn backup-btn--ghost">
                                                        <i data-lucide="log-in" class="w-4 h-4"></i> Connect
                                                    </a>
                                                    <?php if ($registryBackupGdriveOAuthConnected): ?>
                                                    <button type="submit" form="gdriveDisconnectForm" class="backup-btn backup-btn--ghost">Disconnect</button>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="backup-field-grid backup-field-grid--2">
                                                    <div class="backup-field">
                                                        <label for="registry_backup_gdrive_oauth_client_id">OAuth Client ID</label>
                                                        <input type="text" id="registry_backup_gdrive_oauth_client_id" name="registry_backup_gdrive_oauth_client_id" class="font-mono" value="<?= htmlspecialchars($registryBackupGdriveOAuthClientId) ?>" autocomplete="off">
                                                    </div>
                                                    <div class="backup-field">
                                                        <label for="gdriveOAuthClientSecretInput">OAuth Client secret</label>
                                                        <input type="password" name="registry_backup_gdrive_oauth_client_secret" id="gdriveOAuthClientSecretInput" class="font-mono w-full" value="<?= $registryBackupGdriveOAuthSecretSaved ? htmlspecialchars($smtpPassMask) : '' ?>" autocomplete="new-password" data-saved-mask="<?= $registryBackupGdriveOAuthSecretSaved ? htmlspecialchars($smtpPassMask) : '' ?>" data-saved-value="<?= $registryBackupGdriveOAuthSecretSaved ? htmlspecialchars($registryBackupGdriveOAuthSecret) : '' ?>" placeholder="<?= $registryBackupGdriveOAuthSecretSaved ? '' : 'From Google Cloud Console' ?>">
                                                        <p class="backup-field__hint"><?= $registryBackupGdriveOAuthSecretSaved ? 'Leave as dots to keep the saved secret. Click the field, then the eye icon, to view it.' : 'Paste the OAuth client secret from Google Cloud Console.' ?></p>
                                                    </div>
                                                </div>

                                                <?php if ($registryBackupGdriveLastMessage !== ''): ?>
                                                <p class="backup-status-line <?= $registryBackupGdriveLastStatus === 'success' ? 'backup-status-line--ok' : 'backup-status-line--bad' ?>">
                                                    Last Drive upload<?= $registryBackupGdriveLastRun !== '' ? ' · ' . htmlspecialchars(formatReportDateTime($registryBackupGdriveLastRun)) : '' ?>: <?= htmlspecialchars($registryBackupGdriveLastMessage) ?>
                                                </p>
                                                <?php endif; ?>
                                            </div>
                                        </section>

                                        <div class="backup-save-bar">
                                            <div class="backup-toolbar">
                                                <button type="submit" class="backup-btn backup-btn--save">
                                                    <i data-lucide="save" class="w-4 h-4"></i> Save settings
                                                </button>
                                                <button type="submit" form="registryGdriveTestForm" class="backup-btn backup-btn--accent">
                                                    <i data-lucide="plug" class="w-4 h-4"></i> Test Drive
                                                </button>
                                                <button type="submit" form="registryBackupTokenForm" class="backup-btn backup-btn--ghost">
                                                    <i data-lucide="key-round" class="w-4 h-4"></i> Regenerate cron token
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                    <form method="POST" id="gdriveDisconnectForm" class="hidden">
                                        <?= authFormField() ?>
                                        <input type="hidden" name="settings_action" value="disconnect_registry_gdrive_oauth">
                                        <input type="hidden" name="active_tab" value="admin-tools">
                                        <input type="hidden" name="admin_sub" value="backup">
                                    </form>
                                    <form method="POST" id="registryGdriveTestForm" class="hidden">
                                        <?= authFormField() ?>
                                        <input type="hidden" name="settings_action" value="test_registry_gdrive">
                                        <input type="hidden" name="active_tab" value="admin-tools">
                                        <input type="hidden" name="admin_sub" value="backup">
                                    </form>
                                    <form method="POST" id="registryBackupTokenForm" class="hidden" onsubmit="return confirm('Regenerate the backup URL token? Update your schedule task with the new URL.');">
                                        <?= authFormField() ?>
                                        <input type="hidden" name="settings_action" value="regenerate_registry_backup_token">
                                        <input type="hidden" name="active_tab" value="admin-tools">
                                        <input type="hidden" name="admin_sub" value="backup">
                                    </form>

                                    <details class="backup-details">
                                        <summary>Schedule task URLs (SmarterASP / cron) <i data-lucide="chevron-down" class="backup-details__chevron"></i></summary>
                                        <div class="backup-details__body space-y-3">
                                            <?php if ($showHostedScheduleTasks): ?>
                                            <p>Control Panel → <strong>Advance</strong> → <strong>Schedule Tasks</strong> → <strong>Call URL</strong>. See <code class="bg-slate-50 px-1 rounded">deploy/SMARTERASP.md</code>.</p>
                                            <?php endif; ?>
                                            <div class="backup-field">
                                                <label>Appointment reminders (every 15 min)</label>
                                                <div class="font-mono text-[11px] break-all bg-slate-50 border border-slate-200 rounded-md p-2"><?= htmlspecialchars($appointmentRemindersCronUrl) ?></div>
                                            </div>
                                            <div class="backup-field">
                                                <label>Registry backup (daily, e.g. 2:00 AM)</label>
                                                <div class="font-mono text-[11px] break-all bg-slate-50 border border-slate-200 rounded-md p-2"><?= htmlspecialchars($registryBackupCronUrl) ?></div>
                                                <p class="backup-field__hint">Enable scheduled backup above first. Test in browser - expect JSON <code>{"ok":true,...}</code>.</p>
                                            </div>
                                        </div>
                                    </details>

                                    <details class="backup-details">
                                        <summary>Stored backup zips on server (<?= count($registryBackupArchives) ?>) <i data-lucide="chevron-down" class="backup-details__chevron"></i></summary>
                                        <div class="backup-details__body">
                                            <p class="backup-field__hint m-0">Folder <code class="bg-slate-50 px-1 rounded text-[11px]">storage/backups/registry/</code> - download here or via FTP.</p>
                                            <?php if ($registryBackupArchives === []): ?>
                                            <p class="text-slate-500 mt-3 mb-0">No zip archives yet. Run a backup to create the first file.</p>
                                            <?php else: ?>
                                            <ul class="backup-archives-list">
                                                <?php foreach ($registryBackupArchives as $archive): ?>
                                                <li class="backup-archives-list__item">
                                                    <div class="backup-archives-list__meta">
                                                        <span class="backup-archives-list__name"><?= htmlspecialchars($archive['filename']) ?></span>
                                                        <span class="backup-archives-list__sub"><?= htmlspecialchars(alcrosFormatBytes($archive['size'])) ?> · <?= htmlspecialchars(formatReportDateTime(date('Y-m-d H:i:s', $archive['mtime']))) ?></span>
                                                    </div>
                                                    <a href="<?= htmlspecialchars(buildAuthUrl('system_settings.php', ['tab' => 'admin-tools', 'admin_sub' => 'backup', 'action' => 'download_registry_backup', 'file' => $archive['filename']])) ?>" class="backup-btn backup-btn--ghost shrink-0">
                                                        <i data-lucide="download" class="w-3.5 h-3.5"></i> Download
                                                    </a>
                                                </li>
                                                <?php endforeach; ?>
                                            </ul>
                                            <?php endif; ?>
                                        </div>
                                    </details>
                                </div>
                            </div>

                            <!-- Maintenance -->
                            <div class="p-5 sm:p-6 <?= $adminToolsSection !== 'maintenance' ? 'hidden' : '' ?>">
                                <div id="system-errors" class="rounded-xl border border-red-200 bg-red-50/60 p-5 mb-8">
                                    <div class="flex flex-wrap items-start justify-between gap-3 mb-4">
                                        <div>
                                            <h3 class="text-sm font-bold text-red-900 flex items-center gap-2">
                                                <i data-lucide="alert-triangle" class="w-4 h-4"></i> System errors
                                            </h3>
                                            <p class="text-xs text-red-800/80 mt-1">Includes Gmail delivery, SMS (IPROG), and reminder scheduler issues. Each item is fixed separately-Gmail errors need Gmail SMTP under Configuration, not SMS settings.</p>
                                        </div>
                                        <?php if (!empty($activeSystemErrors)): ?>
                                        <span class="inline-flex items-center min-w-[1.5rem] h-6 px-2 rounded-full bg-red-600 text-white text-[10px] font-black"><?= count($activeSystemErrors) ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <?php if (empty($activeSystemErrors)): ?>
                                    <div class="rounded-lg border border-emerald-200 bg-emerald-50/80 px-4 py-3 flex items-center gap-3">
                                        <i data-lucide="circle-check" class="w-5 h-5 text-emerald-600 shrink-0"></i>
                                        <p class="text-sm font-semibold text-emerald-900">No active system errors detected.</p>
                                    </div>
                                    <?php else: ?>
                                    <div class="space-y-3">
                                        <?php foreach ($activeSystemErrors as $sysError): ?>
                                        <div class="rounded-xl border border-red-100 bg-white/90 p-4 flex flex-col sm:flex-row sm:items-start gap-4">
                                            <div class="min-w-0 flex-1">
                                                <div class="flex flex-wrap items-center gap-2 mb-1">
                                                    <p class="text-sm font-bold text-red-950"><?= htmlspecialchars($sysError['title']) ?></p>
                                                    <span class="text-[10px] font-bold uppercase tracking-wide text-red-700/70 bg-red-100 px-2 py-0.5 rounded"><?= htmlspecialchars($sysError['category']) ?></span>
                                                </div>
                                                <p class="text-xs text-red-900/85 leading-relaxed"><?= htmlspecialchars($sysError['reason']) ?></p>
                                                <p class="text-[10px] text-red-800/60 mt-2">Detected <?= htmlspecialchars(formatDateDisplay($sysError['updated_at'] ?: $sysError['created_at'])) ?></p>
                                            </div>
                                            <form method="POST" class="shrink-0">
                                                <?= authFormField() ?>
                                                <input type="hidden" name="settings_action" value="fix_system_error">
                                                <input type="hidden" name="error_key" value="<?= htmlspecialchars($sysError['error_key']) ?>">
                                                <input type="hidden" name="active_tab" value="admin-tools">
                                                <input type="hidden" name="admin_sub" value="maintenance">
                                                <button type="submit" class="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap">
                                                    <i data-lucide="wrench" class="w-3.5 h-3.5"></i> Fix error
                                                </button>
                                            </form>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div class="rounded-xl border border-red-100 bg-red-50/50 p-5">
                                    <h4 class="text-sm font-bold text-red-900 flex items-center gap-2">
                                        <i data-lucide="alert-triangle" class="w-4 h-4"></i> Danger zone
                                    </h4>
                                    <p class="text-xs text-red-800/80 mt-1">Destructive maintenance actions. None of these can be undone.</p>

                                    <div class="mt-4 pt-4 border-t border-red-100">
                                        <p class="text-xs font-bold text-red-900 mb-1">Clear old activity logs</p>
                                        <p class="text-xs text-red-800/80 mb-3">Permanently removes old activity log rows only.</p>
                                        <form method="POST" class="flex flex-wrap items-end gap-3">
                                            <?= authFormField() ?>
                                            <input type="hidden" name="settings_action" value="clear_old_logs">
                                            <input type="hidden" name="active_tab" value="admin-tools">
                                            <input type="hidden" name="admin_sub" value="maintenance">
                                            <div>
                                                <label class="block text-[10px] font-bold text-red-900/70 uppercase mb-1">Remove logs older than</label>
                                                <select name="log_retention_days" class="border border-red-200 rounded-lg px-3 py-2 text-sm bg-white">
                                                    <option value="30">30 days</option>
                                                    <option value="60">60 days</option>
                                                    <option value="90">90 days</option>
                                                    <option value="180">180 days</option>
                                                </select>
                                            </div>
                                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-xs font-bold">Clear old logs</button>
                                        </form>
                                    </div>

                                    <div class="mt-4 pt-4 border-t border-red-100">
                                        <p class="text-xs font-bold text-red-900 mb-1">Clear operational data</p>
                                        <p class="text-xs text-red-800/80 mb-3">Permanently deletes selected live records. Staff accounts, office settings, and activity logs are kept.</p>
                                        <form method="POST" id="clearOperationalDataForm" class="space-y-4">
                                            <?= authFormField() ?>
                                            <input type="hidden" name="settings_action" value="clear_data">
                                            <input type="hidden" name="active_tab" value="admin-tools">
                                            <input type="hidden" name="admin_sub" value="maintenance">
                                            <fieldset class="space-y-2">
                                                <legend class="block text-[10px] font-bold text-red-900/70 uppercase mb-1">Data to clear</legend>
                                                <?php
                                                $clearDataOptions = [
                                                    'appointments'          => ['label' => 'Appointment data', 'stat' => 'appointments'],
                                                    'document_requests'     => ['label' => 'Request document data', 'stat' => 'document_requests'],
                                                    'civil_records'         => ['label' => 'Civil records', 'stat' => 'civil_records'],
                                                    'queue_tickets'         => ['label' => 'Queue tickets', 'stat' => 'queue_tickets', 'hint' => 'Includes walk-in, appointment, and document claim tickets plus speaker announcements.'],
                                                    'certification_prints'  => ['label' => 'Certifications printed', 'stat' => 'certification_prints', 'hint' => 'Removes logged certification print jobs only. Templates and calibration are kept. Resets the dashboard Certifications printed counter.'],
                                                    'certificate_prints'    => ['label' => 'Certificates printed', 'stat' => 'certificate_prints', 'hint' => 'Removes logged certificate print jobs only. Templates and calibration are kept. Resets the dashboard Certificates printed counter.'],
                                                ];
                                                foreach ($clearDataOptions as $typeKey => $option):
                                                    $count = (int) ($systemStats[$option['stat']]['count'] ?? 0);
                                                ?>
                                                <label class="flex items-start gap-3 rounded-lg border border-red-100 bg-white/80 px-3 py-2.5 cursor-pointer hover:bg-white">
                                                    <input type="checkbox" name="clear_data_types[]" value="<?= htmlspecialchars($typeKey) ?>" class="mt-0.5 rounded text-red-600">
                                                    <span class="min-w-0">
                                                        <span class="block text-sm font-semibold text-red-950"><?= htmlspecialchars($option['label']) ?></span>
                                                        <span class="block text-[11px] text-red-800/70"><?= number_format($count) ?> record<?= $count === 1 ? '' : 's' ?> in database</span>
                                                        <?php if (!empty($option['hint'])): ?>
                                                        <span class="block text-[11px] text-red-800/60 mt-0.5"><?= htmlspecialchars($option['hint']) ?></span>
                                                        <?php endif; ?>
                                                    </span>
                                                </label>
                                                <?php endforeach; ?>
                                            </fieldset>
                                            <p id="clearOperationalDataError" class="hidden text-xs font-semibold text-red-700">Select at least one data type to clear.</p>
                                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-xs font-bold">Clear selected data</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </main>

    <!-- Edit Staff Modal -->
    <div id="editStaffModal" class="fixed inset-0 bg-black/40 z-50 hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
            <h3 class="text-lg font-black text-slate-900 mb-4">Edit Staff Account</h3>
            <form method="POST" class="space-y-4">
                <?= authFormField() ?>
                <input type="hidden" name="settings_action" value="update_staff">
                <input type="hidden" name="active_tab" value="account-management">
                <input type="hidden" name="target_staff_id" id="editStaffId">
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">First Name</label>
                        <input type="text" name="edit_staff_first_name" id="editStaffFirstName" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Middle Name</label>
                        <input type="text" name="edit_staff_middle_name" id="editStaffMiddleName" placeholder="Optional" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Last Name</label>
                        <input type="text" name="edit_staff_last_name" id="editStaffLastName" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                    </div>
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Recovery Gmail</label>
                    <input type="email" name="edit_staff_email" id="editStaffEmail" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                    <p class="text-[10px] text-slate-400 mt-1">Gmail with Google 2-Step Verification required.</p>
                </div>
                <div id="editStaff2svField" class="recovery-2sv-field hidden">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="recovery_gmail_2sv_confirmed" value="1" id="editStaff2svCheckbox" class="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 recovery-2sv-checkbox">
                        <span class="text-xs text-slate-600 leading-relaxed">I confirm this Gmail account already has Google 2-Step Verification turned on. <a href="https://myaccount.google.com/signinoptions/two-step-verification" target="_blank" rel="noopener noreferrer" class="text-blue-600 font-semibold hover:underline">Enable 2-Step Verification</a></span>
                    </label>
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">Role</label>
                    <select name="edit_staff_role" id="editStaffRole" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                        <option value="Staff">Staff</option>
                        <option value="Administrator">Administrator</option>
                    </select>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white rounded-xl py-3 text-sm font-bold">Save Changes</button>
                    <button type="button" class="flex-1 border border-slate-200 rounded-xl py-3 text-sm font-bold close-modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reset Password Modal -->
    <div id="resetStaffModal" class="fixed inset-0 bg-black/40 z-50 hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
            <h3 class="text-lg font-black text-slate-900 mb-1">Reset Staff Password</h3>
            <p class="text-xs text-slate-500 mb-4">Set a new password for <strong id="resetStaffLabel"></strong>.</p>
            <form method="POST" class="space-y-4">
                <?= authFormField() ?>
                <input type="hidden" name="settings_action" value="reset_staff_password">
                <input type="hidden" name="active_tab" value="account-management">
                <input type="hidden" name="target_staff_id" id="resetStaffId">
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 uppercase mb-1">New Password</label>
                    <input type="password" name="reset_password" required minlength="<?= passwordMinLength() ?>" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-3 text-sm font-bold">Reset Password</button>
                    <button type="button" class="flex-1 border border-slate-200 rounded-xl py-3 text-sm font-bold close-modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <?= actionResultScript($flash) ?>
    <?= scriptTag('core/password-toggle.js') ?>
    <?= scriptTag('admin/system-settings.js') ?>
    <?= lucideInitScript() ?>
</body>
</html>
